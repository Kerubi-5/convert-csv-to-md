---
title: Design the Undesigned
status: draft
datePublished: '1548939229'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21341" src="http://martinstellar.com/wp-content/uploads/2019/01/MartinStellar_Coaching_Illustrations-Environment-and-state-1024x768.png" alt="" width="356" height="267" />It’s easy to spot good design - whether we’re talking about a car, a kitchen knife or a website.

Good design is a joy to use, literally so.

That’s what good design does: it affects your state.

Bad design also affects your state. Sometimes in obvious ways and sometimes subtly - but even then, it adds up.

Trouser pockets in just the wrong place, a steering wheel that blocks your view on your speed, an off switch in a hard-to-reach location… an annoying aggravation each time you interact with it.

Good design makes life easier, lighter, more efficient.

But there’s a design element that nearly all of us ignore.

And yet, it’s one of the most powerful, influential determinants of your wellbeing, productivity and results.

I’m talking about your mental and emotional state - something that’s fully in your control to design, if you pay a little attention.

How you feel, your grit and fortitude, your creative problem-solving abilities, your level of execution and persistance:

The higher your state, the better you’ll do and feel.

And that state is something you can design, with the lowest-hanging fruit being your environment, consisting of everything from people, to objects, to your planning, your physical surroundings, the music you listen to, the media you consume…

An entire system that envelopes you all day long… and I’ll bet there’s a bunch of things in your environment that do nothing to lift your state. And other things that clearly bring your state down. (News, anyone?).

This system has designed itself around you, and it does so all on its own. Life configures our environment for us.

Smart people work with their environment deliberately.

They tweak, and modify and configure and experiment, until they’ve designed their own optimal environment for living in, and staying in, the highest possible state.

When you do that, when you support your state intentionally, it has repercussions on all levels.

Taskload is easier to bear. Screaming kids don’t get to you quite as badly. Problems get easier to solve. Setbacks and disappointments are much easier to bounce back from. Aggravated relationships get easier to improve. Conversations flow with more ease. You get the uncanny feeling that hey, you got this. You’re in control.

And best of all? A high state is the best protection against damage to your state.

If your environment is the natural hodge-podge that life threw together for you, you’ll find enormous benefit in getting intentional about it.

Bring some design into your environment.

Design the undesigned, and you'll do wonders for your state.

You’ll see what I mean.

Cheers,

Martin

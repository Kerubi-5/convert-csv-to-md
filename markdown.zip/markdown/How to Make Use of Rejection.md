---
title: How to Make Use of Rejection
status: draft
datePublished: '1514480620'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/975aa2d2-4aac-4cfe-bf6c-6f0c4bac451e.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/975aa2d2-4aac-4cfe-bf6c-6f0c4bac451e.jpg" data-file-id="4835329" />Most of us don’t like being rejected, and lots of people are so afraid of it, they never take any action where they run the risk.

But to me, that’s no way to live.

Besides, what is rejection anyway?

It’s nothing but someone saying no to how they perceive something.

Rejection is never about you, but about the other person. It’s their view on you, or your work, or your opinion.

Still, it might not feel nice when it happens - especially if you’ve worked hard on a project or a design or a work of art.

So here’s a little reframe that will help you deal with - and even welcome - rejection.

I use it all the time, and it works very nicely indeed.

It’s this:

‘Rejection’ is the start of (or the start of deepening) a relationship.

When someone says no (let’s also stop using the word rejection), you have just learned something about that person.

So you get to ask yourself why, what’s happening there, in that other world that that person is.

And whenever you ask yourself what’s going on in the other world (meaning, you make it about them instead of about you), you open up to your own different view of them.

And you might learn that all that needs to happen is to create a different approach of communication.

Or to explain something differently, or modify the project, or show a different work of art.

Because in their world, there’s a reason to say no.

Change or remove that reason, and you just might get a maybe, a tell me more, or even a yes.

Make it your default reaction, when you hear a no: “What’s happening there, why do they really reject it? What do they perceive that they’re saying no to?”

More often than not, ‘no’ is simply down to a misunderstanding - and communication can fix that.

But only if you don’t take it personally, and make it about them.

And, when you do that you get to move forward and you have a relationship - or if there already was one, you get to create a deeper level of relationship.

This sort of reframing is part and parcel of the coaching process, and it’s magical to see clients pick up ideas like this, run with it, and discover a different way to live and work.

Available to you any time you want, just let me know when you’re ready.

Cheers,

​Martin

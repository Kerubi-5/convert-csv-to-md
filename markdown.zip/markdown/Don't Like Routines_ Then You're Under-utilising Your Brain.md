---
title: Don't Like Routines? Then You're Under-utilising Your Brain
status: draft
datePublished: '1510598204'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/f3ec77b4-dde6-4f23-8ec3-03097e4e0fbe.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/f3ec77b4-dde6-4f23-8ec3-03097e4e0fbe.jpg" data-file-id="4835197" />Every so often, I’ll hear someone say that they’re completely averse to all routines and all habits.

Usually, it’s said in a way that shows pride, as if being against routines is a good thing.

But if you think about it for a bit, it’s kind of strange.

For starters, we’re creatures made up of habits.

Even if you say you don’t like them, you’ve got them and you use them, all the time.

Habits in the ways we react, choose, think, speak, walk, write, relax… you can’t deny that you have habits.

But if you do deny it, and you claim you don’t want any habits or routines, you’re severely handicapping yourself.

Consider this quote from the famous poet and playwright W. H. Auden:

Routine, in an intelligent man [or woman, Ed.], is a sign of ambition.

Now, that’s easy to understand: when you create routines and habits, you’re building systems that maintain themselves, and that compound to results over time.

Where it gets trickier is getting people to see the flipside: the handicap that comes as part and parcel of not working with routines.

And that handicap is that you’re not using your brain the way it was designed.

See, routines make decisions obsolete. If you once decide that each morning you go for a run before breakfast, that decision has to be made only once.

Without that decision, you have to go back to making a decision about running, every single day. And that’s fine, if that works for you.

But remember that your brain is capable of far more than making daily decisions about immaterial things. In fact, having no routines means that you end up with what psychologists call ‘decision fatigue’.

The more things you need to decide during a day, the faster you’ll spend the limited amount of cognitive processing and discipline that we have available on any given day.

Yes, having to decide things all the time literally wears away your energy - there's plenty of studies that show this.

And so, avoiding routines is in fact a major contributing factor to procrastination… I bet you never thought of it that way, right?

Look, creating routines is absolutely not about living a dull and dreary life, where each day is a shadow copy of the previous.

Routines are about making a decision once about something, so that you’ll never have to spend energy on it again.

And if you do that over and over again, you’ll notice that you have more energy for actual creative work (which is the stuff that your brain was actually designed for).

But, you’ll never get there if you don’t give yourself permission to build fun and effective habits.

So, why not do an experiment?

Why not create a routine around something (whether in the area of work or personal life) and see how it works out for you?

You just might find yourself falling in love with routines…

Remember: a routine isn’t something fixed. If you create one that doesn’t work or isn’t fun or whatever, toy with it, play and redesign. Create a routine that’s just perfect for you, and then stick with it for a few weeks.

And let me know how that worked out for you…

Cheers,

​Martin

---
title: Everybody Does It
status: draft
datePublished: '1488184076'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - How to sell your work
  - Psychology in sales and marketing

---

A client in the Cabal mastermind group I run asked the group's opinion.

She’d been to an art show, where someone had put up a sign saying that prices were 50% off.

Except the final salesprice was what the works had originally been priced at.

In other words, an artificial price hike, in order to make the work appear more valuable.

Before posting her question in the group, she asked a few people their opinion, and she heard things like:

“That’s just marketing”.

Um, no. It isn’t.

It's deceitful and unethical. It’s marketing done wrong.

Very wrong, in my not at all humble, ethical opinion.

Others said: “Everyone does it”.

Which is just plain silly, and infantile to boot. What’s next: “They started it”?

Come on.

Obviously, I was pleased to see that the Cabal members didn’t think that way, and called it wrong.

Smart bunch, ethical too.

If you want to give discounts, give them on the original price, whatever it is that you sell.

But I say, don’t give discounts.

You’re not Walmart, you’ll never win big if you try to compete on price.

And also: if you’re reading me, I doubt that your work (art or coaching or training or whatever) falls in the low-price category.

Here’s what to do instead: give more value.

Deliver stellar service. Give something extra for free. Be your buyer’s best purchase ever.

That’s the ethical way.

There’s a wide grey area in what is and isn’t ethical, and that’s exactly the problem.

There’s no clear defining line between what is and isn’t. Like ‘white lies’, there’s arguments and justifications you can make. “Ah, just a little bit wrong. That’s not so bad”.

Except it is.

My recommendation is to always stay very far away from the entire grey area.

You’ll feel better about yourself, and in the end it’s better for business.

&nbsp;

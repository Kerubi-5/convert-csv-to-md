---
title: Donald Duck, Irony, and Resignation
status: draft
datePublished: '1546620257'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img class="alignleft wp-image-21223" src="http://martinstellar.com/wp-content/uploads/2019/01/MartinStellar_Coaching_Illustrations-Resignation-1024x768.png" alt="" width="345" height="259" />Years ago, a friend told me her son was depressed.

I asked what he did for a living, and she told me that he’s an inker for Donald Duck magazine.

And sad as it is when someone’s depressed, you’ve got to appreciate the irony of working a dull job at a company founded by an artist who broke lotsa rules - where you spend your days colouring inside the lines. Literally.

I never met the son, but like everyone, he grew up with dreams and ambitions - probably to do with being an artist.

And while I’m sure colouring inside the lines takes skill, it’s not quite the same as making your own damn art.

Now I’ll bet ready money that you’re different, that you’re building your own empire, carving your own path, that you ‘roll your own’.

Ah but not so fast. Are you sure that you too didn’t resign to some things, at some point?

Of course: we all do. Life is give&amp;take. Sacrifices are made in return for gains. We accept something uncomfortable because it prevents disaster.

But if you really look at your life - the people, places, habits and things in it - are you quite sure that you’ve not resigned to one or two things that just really shouldn’t be there any longer?

No matter how full your life may be, I’ll bet there’s things that should go.

In my example, I gave up my funk band when I joined the monastery (for a while I wanted to be the Funking Monk, but oddly, they wouldn’t have it).

That was a sacrifice I made gladly, in return for life in a brotherhood.

But once I left there over a decade ago, I stayed resigned to not be in a band.

Which is strange, because music had always been my biggest love.

Until I joined a band a few months ago, and I realised how much had been missing from my life.

And so it is with all of us: we give up things, or resign to things - painfully at first, but then we get used to it. We forget. Its priority disappears into history.

So here’s a question for you to ponder this weekend.

It’s a simple, but very sharp and pointed psychological hack to connect with a part of you that very, very likely, wants to be more alive.

Here’s the question:

What’s missing from your life now, that if your 7-year old self would know it’s missing, would make him or her cry?

I’m not saying you should go back to playing hide and seek (then again: why the hell not?): all I’m trying to do, is get you to open up your insight on what you may have given up at some point, and should maybe bring back.

What’s missing from your life?

What can you do to bring it back?

Or, if you know the answer: when will it finally be time to make it happen...?

Cheers,

Martin

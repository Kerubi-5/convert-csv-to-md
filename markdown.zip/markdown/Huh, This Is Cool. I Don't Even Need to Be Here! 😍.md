---
title: Huh, This Is Cool. I Don't Even Need to Be Here! 😍
status: publish
datePublished: '1644575411'
categories:
  - Assets and Leverage
  - Business and systems
  - Business Growth Fundamentals
  - "Doing it\r\n\t\t\tright as an entrepreneur or creative professional"
  - How to sell your work
  - "Psychology in\r\n\t\t\tsales and marketing"

---

<img class="size-medium wp-image-28331 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/12/MartinStellar_Coaching_Illustrations-Getting-ready-to-launch-SalesFlow-Coach…-but-300x225.jpeg" alt="" width="300" height="225" />I've not published a lot about it yet (except in my <a href="https://twitter.com/martinstellar/status/1491709585627000832">#BuildInPublic thread on Twitter)</a>, but I'm building an app that coaches people on working their pipeline.

And yesterday, I had fantastic proof of concept.

I literally saw the app work, and do what it's intended to do.

Which is:

Help people move their deals forward, by asking simple, but very specific, questions about those deals.

And it works. Saw it with my own eyes.

Here's what happened:

I've been conducting research interviews, where I meet with a coach or consultant for 20 minutes.

I pull up the app, share my screen, and give them control over my mouse pointer:

"Captain, you have the helm."

And it's absolutely fascinating to see someone interact with the app, click around, learn what it's meant to do. And people like it.

But yesterday was different.

This was someone I knew, a friend. So we had more time than normal, and he actually stopped to think, and answer the questions that the app asks.

And what I saw next was kinda magical:

Within 15 minutes, he'd scheduled actions for moving three deals forward, recorded a message for his VA to transcribe and send, and remembered two people that weren't in his pipeline, that he also scheduled actions on.

My app was literally coaching him on working his pipeline, the way I would normally do it...

And I just sat there and watched it happen 🤩

So now my team and I, we have our first, actual, proof of concept:

My sales and coaching methodology work, even in the form of an app, even when I'm not there.

And that means, I gotta get this thing out there and public, ASAP.

Because every quality coach or consultant should have an easier time enrolling buyers.

Now that I have an app that makes that happen, for free, I can finally put my ~30 years of learning psychology and communication and business to some public use.

So yeah. I'm excited.

I'm also in need of some help though:

To make sure the app works for everyone, not just my friend, I need feedback.

Want to help?

Then you can schedule a 20-minute zoom call here.

Your opinion and feedback will help me build SalesFlow Coach into an app that works for YOU.

Talk soon?

https://calendly.com/martinstellar/feedback-interview

Cheers,

Martin

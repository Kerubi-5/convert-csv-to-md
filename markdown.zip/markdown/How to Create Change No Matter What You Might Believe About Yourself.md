---
title: How to Create Change No Matter What You Might Believe About Yourself
status: draft
datePublished: '1516359304'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/68dd5f0c-d81a-4b3f-8834-635633fdb5aa.png" width="350" height="308" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/68dd5f0c-d81a-4b3f-8834-635633fdb5aa.png" data-file-id="4835389" />We all have an image of who we are.

And it’s always mostly wrong.

Just ask any friend, client or relative how they see you, and I’m positive that they’ll mention traits that you think you have, or omit bits that you thoughts are good or bad about you.

Just a fact of life: there’s a difference between how you on the inside see yourself, and how you are being perceived by others on the outside.

This matters, because in the self-view that you have, there are opinions and beliefs about yourself that hold you back. Can be in a big obstruction way, leading to self-sabotage and so on, or it can be in more subtle ways, causing you to not play as big as you could.

And I believe that literally everyone on earth could be playing a bigger game than they are, no matter how famous or successful or fulfilled they currently are.

So if you’d like to up your game, achieve more, create more, it’s important that you don’t let your self-image be the reason you don’t.

But you can’t simply change the way you think about yourself and expect to miraculously become someone you don’t believe you are.
Because the problem with self-image is that it exists on the level of beliefs, and thoughts don’t have much impact on beliefs, as I’m sure you’ll have noticed in life.

So the solution?

Simple. A practice of ‘act as if’.

Which is vastly different from ‘fake it till you make it’. I wouldn’t recommend anyone fake anything, ever.

Act as if is much more fun, honest, and useful.

Act as if means you decide on who or how you’d like to be, and then you decide to act as if you are already that person.

You play the game of behaving in the way that person would (or will) behave.

So for example: if you don’t yet believe that you are able to stick to a diet, ask yourself:

How would the version of me that CAN keep a diet behave?

How would that me think? What choices would that me make? Would that me even buy soda or processed food? Would the me that sticks to the diet give in to urges and cravings?

Next, start experimenting with those behaviours. Play with it, make it a game to see what it’s like to act that way.

You’ll find that that it’s not all that hard to act that way part of the time.

Sure, that doesn’t remove the problem itself in an instant, but it WILL show you that - sonofagun! - you actually CAN act that way!

Even if it’s only some of the times, even if it’s only in small ways… you are now living the experience of behaving the way you’d like to.

And that’s a powerful start to creating the change you desire. It becomes the carrot to your donkey, and if you keep up that practice, you will over time (and faster than you might expect) find that it becomes natural to act that way.

And bit by bit, you’ll change, and turn into the person that you’d like to be - regardless of whether or not you believe you can.

So, what’s going to be your ‘act as if’?

Cheers,

​Martin

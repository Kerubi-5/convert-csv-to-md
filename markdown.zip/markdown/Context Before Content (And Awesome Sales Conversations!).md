---
title: Context Before Content (And Awesome Sales Conversations!)
status: publish
datePublished: '1574413736'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing
  - Relationships

---

<img class="alignleft wp-image-22335" src="http://martinstellar.com/wp-content/uploads/2019/11/MartinStellar_Coaching_Illustrations-Awesome-sales-conversations-context-before-content-1024x768.png" alt="" width="351" height="263" />When you show up to a potential buyer - whether it’s in person, by email, phone or on social media - you’re asking them for their most precious and scarce resources:

Their time and attention.

And, if you do it right, people will be happy to give you those. Get it right, and people will give you permission to talk, ask, inquire, and explain.

What often goes wrong though, is that we launch into the content - the meat and potatoes of our thing - before we set the context.

That’s pretty much what’s wrong with traditional selling:

We have a solution, and we go out looking for a problem that it can solve.

And so we show up, and the pitch is on.

Thus, the context becomes ‘I have a thing, I want to tell you about it, tell me if you want it’.

In that context, it’s no surprise that people have no time, or make excuses, or raise objections.

Instead, set a different context right at the start: one that causes your buyer to care about the conversation.

And you do that by being *interested in them*, instead of trying to be *interesting to them*.

Nobody cares how interesting we might be, or our offer or service or product, until they realise that we are interested in them.

That’s a context most everyone will like, agree with, and it’s how you start conversations that everybody enjoys.

And that’s the kind of conversation that causes people to listen, consider, and buy, all without you ever having to sell anything unto them.

Much nicer for people to buy, instead of us having to ‘sell’, don’t you agree?

Cheers,

Martin

Oh, and: if it so happens that you want to buy ethical sales training, just raise your hand. It's super effective, will rock your business, and is MUCH more affordable than you would think. Let's talk...

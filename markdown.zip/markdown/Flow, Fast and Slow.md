---
title: Flow, Fast and Slow
status: draft
datePublished: '1492001083'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

The last week or so, I’ve been studying the psychology of flow.

That state you enter into, when everything just seems to work, you forget time, you forget yourself, and you’re in the zone.

Ohey, I haven’t eaten in six hours. That kind of thing.

And I thought that I don’t really get those ‘in the zone’ states very often.

But I was wrong.

Because the first thing I realised when I started digging into this is that being in the zone very often goes unnoticed. That’s the whole point of it, right?

To be free from self-reflection.

Pondering further, I realised that my daily 3-hour morning ritual (wash face, meditate, read&amp;breakfast, walk&amp;podcast) is one continuous flow experience.

And writing my dailies, that’s pure flow too, nearly every time.

But then something else hit me:

Coaching.

Coaching people, for me, is total flow.

I sit and listen, I ask questions, we do the normal human interaction thing, and suddenly it’s like a switch is flicked.

Suddenly, there’s resonance between my client and me. At least, that’s how I experience it. Can’t speak for anyone else.

But I do know that when that phase starts, the session really kicks into a higher gear.

What more?

Another thing I discovered about flow, is that I can trigger it by slowing down.

I know that deadlines, adrenaline and danger cause flow to appear, but fake self-imposed deadlines don’t work for me, I’m done rock-climbing, and there’s little danger here on the coast.

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/9bc66615-2b0b-49e2-b7c3-a1eb69b30f65.jpg" width="150" height="266" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/9bc66615-2b0b-49e2-b7c3-a1eb69b30f65.jpg" data-file-id="4834501" />So I slowed down. For an entire week, I focused on learning, contemplation, and drawing.

(Yes! The man who always said he couldn’t draw a stickfigure to save his life, has fallen in love with drawing... stickfigures. Go figure (badum-tsh))

Anyway.

If you want to experience more flow states, you can either go for the tension-induced kind, or you can try slowing down.

Worked wonders for me, and it might do too for you.

Meanwhile, to follow me on Instagram to see what my pen creates, <a href="https://www.instagram.com/martinstellar/" target="_blank" rel="noopener" data-cke-saved-href="https://www.instagram.com/martinstellar/">and come say hi to my little friend Qee.</a>

Cheerio,

Martin

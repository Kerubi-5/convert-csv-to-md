---
title: It's Foolish and We All Do It
status: draft
datePublished: '1538489568'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-20953" src="http://martinstellar.com/wp-content/uploads/2018/10/MartinStellar_Coaching_Illustrations-the-map-is-not-the-territory-1024x768.png" alt="" width="351" height="263" />Only a fool thinks the map is same as the territory.

Consider: Last time I checked, the world seemed like a pretty frigging big place.

There’s a world going on underground, there’s currents and gravity and micro-organisms, we have politics and artists who make brilliant stuff nobody will ever see, there’s music that never gets recorded, stars and galaxies and that bizarre huge emptiness between atomic nuclei, we have higgs bosons and women’s bosoms (what? I’ve waited years to make that pun), untold history and gravity that apparently indeed moves in waves…

In short, I think you’ll agree that the world is big.

Way too big to take in the entirety of it all. It would explode our minds if we did.

So we create a map, a representation.

It’s called perception, and it’s quite useful: it deftly identifies what matters, casually ignores what’s irrelevant to our lives, and delivers to us a model of reality that enables us to navigate this bewilderingly large world.

So far so good, and hey: thanks, evolution!

What’s not good though, is assuming that our map - our perceptual distillation of the world - is the territory.

But that’s what most of us do.

We behave and think as if our version of perception is real, and if the outside world doesn’t correspond, it’s the world that’s at fault, not our own interpretation.

Ludicrous, obviously.

Especially considering that it’s factually impossible to perceive what reality actually is, in its entirety.

Some branches of metaphysics claim reality doesn’t exist, but that’s not the point.

What is the point, is that you and I will never experience reality.

Only our own abstract of it.

The map that we create with our senses and our brain.

And if you want a sane, happy life, you’d better make it a habit to question whether what you believe something is, or means, or what someone’s intentions are, is actually IT.

Question everything. Path to sanity.

To quote one of my heros, Dr. Who:

“What else?”

What else can this mean?

What else does it represent?

What else does it reveal?

What other options does this give me?

The stronger you believe something, the more it deserves to be questioned.

I’m not claiming that I’m sane, but I’m a damn happy feller, and I promise it’s 90% down to questioning my beliefs.

How about you?

Cheers,

Martin

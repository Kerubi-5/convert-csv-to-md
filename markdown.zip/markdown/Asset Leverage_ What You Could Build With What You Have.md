---
title: 'Asset Leverage: What You Could Build With What You Have'
status: publish
datePublished: '1567507239'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft  wp-image-22025" src="http://martinstellar.com/wp-content/uploads/2019/09/MartinStellar_Coaching_Illustrations-Asset-Leverage-1024x768.jpg" alt="" width="352" height="264" />“Excuse me, are you a writer?”

A gent who has breakfast with his wife daily, at the same terrace where I sit to drink coffee and journal my head to clarity each morning.

I tell him that yes - except I don’t write novels, but ebooks and articles and so on. Functional, business-related writing.

We chat for a bit, and he tells me about his son, who spends hours each week, writing articles for his stormchaser website. “Have a look, it’s very popular”.

I click around a bit, and check his Twitter feed: 49.000 followers. Facebook: 25K followers. Nothing to sneeze at - popular indeed!

But when I ask if the son does this for a living or a hobby, he tells me that no, it’s just a hobby. “There’s no money in that”.

Wait, what? 75.000 social media followers means traffic to the website. It means popularity, engagement, platform, and it means there will be a small, but very engaged nucleus of followers, some of whom would be willing to pay money, if the offer is right.

For example: the site comes with a forum. What could be simpler than inviting followers and readers to subscribe to a private, paid-members-only section, with exclusive content and perks?

If the son puts it at $20 a month, it’s low enough for people to afford it, and he only needs 50 members to make $1000 a month - which isn’t a money-flood, but it’s a nice start and not that hard to attain.

Followers, or platform, are an asset - and any asset can be leveraged for impact, growth, and yes: revenue.

Question is: are you aware of the potential your assets hold?

And: If you were to pick one underused asset and you’d light a fire under that, put a turbo on it: which one would it be?

What would you do to leverage it?

Cheers,

Martin

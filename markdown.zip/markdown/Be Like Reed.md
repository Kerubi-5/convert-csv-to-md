---
title: Be Like Reed
status: publish
datePublished: '1492688429'
categories:
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/b5b4e3cc-b28c-4413-ba5d-2d33b4bedb22.png" width="207" height="276" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/b5b4e3cc-b28c-4413-ba5d-2d33b4bedb22.png" data-file-id="4834525" />There’s a lot of things we can do.

And there’s a lot of things we shouldn’t be doing.

Me, I’m all for action.

But at the same time, there’s a lot to be said for doing nothing.

I’m reminded of Sufi poetry, where the reed is used as a symbol.

The reed that makes the flute, the reed that serves as nothing more than a channel for air to flow through.

Impassionate, inactive, just a conduit.

That’s what I mean when I say ‘do nothing’.

To let life happen without imposing our will on it.

Without trying to do things and create stuff and make things happen.

The reed doesn’t make the sound, it’s just there to allow the sound to exist.

“But Martin, isn’t all that in conflict with my ‘do things, take action’ ?”

Not at all.

Point is that if we’re guided by what we think needs to happen, we’re coming at life from a binary perspective.

We choose this and then go do it, to the exclusion of everything else.

And because of that strong focus on one thing, we miss and overlook other things.

And those other things might be exactly what you need to know, see, or do.

Sometimes, big and bold action is what you need.

At other times, the best you can do is be still, observe the world around you, and listen.

If you do and you listen closely, you’ll know when the time for action has come.

And sometimes, doing nothing until that moment comes is the best thing you can do.

&nbsp;

&nbsp;

&nbsp;

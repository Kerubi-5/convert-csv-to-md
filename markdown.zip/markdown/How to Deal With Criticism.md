---
title: How to Deal With Criticism
status: draft
datePublished: '1499251670'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/7457cbd4-86c3-44d5-885d-847a225ec3da.jpg" width="350" height="208" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/7457cbd4-86c3-44d5-885d-847a225ec3da.jpg" data-file-id="4834773" />It’s easy to get stuck when people give you criticism.

We start second guessing ourselves, or we doubt ourselves or our motives, we wonder if we’re doing it right or whether or not we’re on the right path.

But if that happens, you’re missing an important point when it comes to criticism:

It’s not about you. Ever.

Whatever people complain about, whatever they criticise you for: it’s about them. Always.

Sure you might benefit from a change or implementing a recommendation. Nobody is perfect, present company included. We can always get better.

But the perception of whatever is ‘wrong’ is the perception of that person.

There can never be anything that’s objectively wrong, because it’s a valuation made by that person perceiving the thing.

This is great news for everyone who has trouble dealing with criticism: as of this moment, you no longer need to feel bad, get upset, or doubt yourself.

Because it’s not about you! How cool is that?

So next time someone has a go at you in whatever big or small way, just reply (or think) “Thanks for sharing your view”, and let it run off you like rain down a window.

There’s no need to let it affect you. And once you learn that, you’re free to objectively assess the message, and to choose to make it a learning point for you to integrate.

So remember: criticism isn’t personal, unless you take it personally.

Cheers,

Martin

---
title: Are You Using Your Genius? (CRD Pillar 9)
status: draft
datePublished: '1542362857'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-21092" src="http://martinstellar.com/wp-content/uploads/2018/11/MartinStellar_Coaching_Illustrations-CRD-Pillar-9_zone-of-genius-1024x768.png" alt="" width="351" height="263" />Before we dive in: this isn’t about *being* a genius - I wouldn’t want you to tune out because of insecurities or healthy humility.

What it’s about is a *zone of genius*, also known as your unique ability.

That thing you do in such a way, that there’s nobody in the world who could copy it.

(For deeper insight into Zone of Genius, read Gay Hendrix ‘The Big Leap’ - highly recommended). Short version: there’s 4 zones in which we operate: Incompetence, Competence, Excellence and Genius. Hendrix’s point is that the more we eliminate the first three and operate as much as possible in the genius zone, the better our lives, results, and business will be. And I concur.

For example, back when I was a fancy-pants bespoke tailor, I was rather skilled at making the clothes. I’d get comments like ‘magnificent’ and ‘you’re an artist’ and so on.

But I wasn’t a genius at making. In tailoring, my zone of genius was communicating with a client, and then designing a pattern and fit that they’d fall in love with.

Where it came to making, I was often excellent, but not genius. Didn’t have the experience to get it right every time, inside a normal timeframe.

Which meant that the more fancy and expensive a garment was, the bigger my loss on it was.

Had I outsourced the making process and focused only on comms and design, I probably wouldn’t have burned through the inheritance my good ole’ dad left me.

But it’s so easy to fall into the trap of trying to do it all.

Doing our own design, our own copywriting, creating our own ads and marketing strategy… whether we believe we can’t afford to outsource, or because we think our own skills are good enough…

We often end up doing many things, of which many get done either badly, or reasonably well, or good at best.

And that’s a problem, because the average of all the things we don’t do stellarly, is somewhere between mediocre and reasonably good.

Meaning, if we don’t carefully curate what we do and don’t do, the majority of our activities add up to average.

And you’ll agree that’s no way to run a life or a business.

This is why the final pillar of Calibrate Reality Dojo is Zone of Genius - and since elimination is one of the core tools of the system, today I invite you to spend some time thinking about how you spend your time.

Here’s a few instructions to help you:

1: List out all the activities you spend time on during the week

2: Mark each of the 1, 2 , 3 or 4, where 1 is stuff that’s your zone of genius, and 4 is incompetence.

3: Write them all down again, each in a separate column, marked 1 thru 4.

If you’re brave, step 4 is deciding to no longer to anything that’s in column 4. Just delete it, no matter how much you want to tell yourself that it has to be done.

Why? Because if you’re doing it in an incompetent manner, the results it gets you amount to little and you might as well stop wasting time on it.

Column 2 and 3, ask yourself:

Should I continue doing these?

Or should I outsource them?

Or, should I improve my skills, and bring them closer to my zone of genius?

As always, insight and clarity help you to make better decisions.

And to not make a decision on what to eliminate is also a decision.

Final thought: the way you operate in the different zones is what got you here.

If you want to get better results, something’s got to give - and moving more into your zone of genius, as much as you can, is the easiest way to start building better results.

Cheers,

Martin

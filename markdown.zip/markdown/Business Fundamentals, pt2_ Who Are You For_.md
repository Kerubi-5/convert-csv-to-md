---
title: 'Business Fundamentals, pt2: Who Are You For?'
status: publish
datePublished: '1615805922'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<p class="p1"><img class="alignnone size-medium wp-image-26642" src="https://martinstellar.com/wp-content/uploads/2021/03/MartinStellar_Coaching_Illustrations-who-are-you-for-300x225.png" alt="" width="300" height="225" />Thought it would be fun to dive deeper into The business Fundamentals I wrote about last week, so here's part 2:</p>
<p class="p1"><strong>Who are you for?</strong></p>
<p class="p1">Before starting out marketing your work (and also: several times a year, if your marketing is already running) you need to ask yourself:</p>
<p class="p1">Who am I for?</p>
<p class="p1">Who, very specifically, do I want to serve?</p>
<p class="p1">Who am I most excited about working with?</p>
<p class="p1">Which kind of clients just light me up like nobody’s business?</p>
<p class="p1">Who does something that I completely fully back?</p>
<p class="p1">Which clients have my values in common with me?</p>
<p class="p1">Who stands for something that I’d get on a barricade for?</p>
<p class="p1">Who has the kinds of problems I can solve, and is willing and able to pay for it?</p>
<p class="p1">Who can I help in such a profound way, that they become clients and referrers for life?</p>
<p class="p1">All these questions matter.</p>
<p class="p1">Because unless you have a profile of a person where each is addressed, you effectively have no targeting or positioning, and your marketing will be highly ineffective.</p>
<p class="p1">You’ll be pushing a boulder up a hill, and that’s how it will stay.</p>
<p class="p1">Until you get clear on the core, fundamental business question:</p>
<p class="p1">Who are you for?</p>
<p class="p1">Get that right, and you’ll be rolling a boulder on a plain, not up a hill.</p>
<p class="p1">Who are your people?</p>
<p class="p1">Who should you work to attract?</p>
<p class="p1">Who should you actively avoid courting?</p>
<p class="p1">That last one btw is extremely important as well.</p>
<p class="p1">Because we nearly always cast too wide a net.</p>
<p class="p1">You might be a terrific planning consultant, able to help anyone from healthcare to tech &amp; innovation - but if you don’t choose a niche, your messaging won’t specifically appeal to anyone.</p>
<p class="p1">They’ll see you, and say: “Sounds like a real pro, but not exactly for us”.</p>
<p class="p1">They’ll keep looking, and when they find a ‘planning consultant for the tech industry’, they’ll go “Ah! That’s exactly who we need”.</p>
<p class="p1">So there’s two sides to profiling:</p>
<p class="p1">Define who you are for, and then:</p>
<p class="p1">Decide who you are <i>not</i> for.</p>
<p class="p1">And then make all your publishing and communication and marketing creative about, and specifically for, the niche that you <i>are</i> for.</p>
<p class="p1">That’s positioning done right, and that’s how you get high ROI on your marketing efforts.</p>
<p class="p1">Happy to help you figure that Who part out - <a href="hello@martinstellar.com">just drop me a line.</a></p>
<p class="p1"></p>

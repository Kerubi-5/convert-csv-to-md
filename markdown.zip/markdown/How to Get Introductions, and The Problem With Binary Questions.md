---
title: How to Get Introductions, and The Problem With Binary Questions
status: pending
datePublished: '1649410407'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<p class="p1"><img class="size-medium wp-image-26586 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/02/MartinStellar_Coaching_Illustrations-Getting-introductions_binary-questions-300x225.png" alt="" width="300" height="225" />One of the best things that can happen for your business, is getting introductions and referrals.</p>
It's often the easiest and fastest way to landing a client.

For example, a while ago I had a friendly, casual chat with an entrepreneur, who introduced me to a friend.

Once I spoke with that friend, it took about 30 minutes for her to hire me for a paid speaking gig.

No selling required: she brought it up and volunteered the sale, simply because the right introduction had been made.

And it's perfectly natural to ask for an introduction, when you're having a quality conversation.

But, there’s a right way, and a wrong way to ask.

Most of the time, people say “Do you know anyone who…?”

No matter how you finish that sentence, it’s the wrong way to start.

Because it’s a binary question, meaning: the other person will look for a yes/no answer.

“Hmmm… do I know anyone…? Sorry, can’t think of anyone just now. I’ll let you know”.

Which rarely leads to an actual introduction.

Instead, consider asking: "Who do you know, that you think I should speak with?"

When you frame the question that way, it’s not binary, but open-ended.

The result is that the other person will start flipping through their mental Rolodex.

“Well… I know James, Jim, Jill, John, Janet, Julia, Gerard - oh wait! You should totally talk to Gerard!”

People will be happy to make an introduction, because it makes them look good (after all, the most valuable person in a network is the connector).

Your job is to make it easy for someone else to connect you to the right person.

And you do that by asking the open-ended question “Who do you know, that you think I should talk to...?”

Which reminds me:

Who do you know, who is a good egg, and would totally benefit from 1 on 1 personal training and coaching one their pipeline their deals, and their sales... that you think I should talk to?

Feel free to hit reply and let me know...
<p class="p1"></p>

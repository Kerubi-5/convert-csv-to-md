---
title: How to Reduce Overwhelm, Get More Done, and Move the Needle on Your Business
status: draft
datePublished: '1589451071'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img class="alignleft wp-image-21785" src="http://martinstellar.com/wp-content/uploads/2019/06/MartinStellar_Coaching_Illustrations-Priorities-overwhelm-and-moving-the-needle-1024x768.jpg" alt="" width="348" height="261" />Being human tends to be a spectacularly inefficient affair.

The mind cranks away on thoughts that we’ve thought before, or on things that we fear but will never happen, or it’ll just happily churn away on things that are completely inconsequential for our well-being, relationships, growth, and indeed: sales.

Meanwhile, our activities consist of a wildly diverse set, most of which do absolutely zero to advance our personal evolution: from mindlessly scrolling through a Facebook feed, to talking with people who gain nothing from it and neither do you, to organising or cleaning stuff just because it gives a fake sense of achievement.

Or, like my manicure, who almost weekly tells me that she spent the weekend ironing. I guess… if it makes her happy…

Problem is, we think that as long as we’re doing something, stuff is happening. And if we’re ‘not working’, we’re resting.

But doing nothing in particular is not the same as resting - not to your subconscious, which is probably very eager for some actual recovery time.

And doing whatever keeps us busy is clearly not the same as getting stuff done.

It helps to have clear lines and hard boundaries.

Rest is rest, and work is work, which replenishes your energy much faster than the pseudo-rest of procrastination.

And as for work, it’s good to demarcate and prioritise there as well:

There’s busywork, the day-to-day activities, and then there’s the kind of work that moves the needle. These are the growth-driving activities that over time build up to results, sales, growth, and revenue.

What’s that you say? You’re always short of time, for doing those GDA’s?

Gotcha!

That’s because, very likely, you spend too much time doing things that you didn’t plan, and didn’t define as the important stuff that gets results.

And that is how you get to constantly feel busy, see little result for it, and feel overwhelmed, frustrated and inadequate.

The solution?

Say no. Decide against automatic, ho-hum activities, and prioritise prioritisation (Yes, I meant to write that).

Decide what’s most important, give it priority, go do it, and only then go back to taking care of routine chores.

If something important deserves to get done, it deserves to get priority, don’t you agree?

Cheers,

Martin

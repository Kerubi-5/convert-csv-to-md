---
title: Do You Need to Use a CRM...?
status: pending
datePublished: '1641809402'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"
  - Relationships
  - Sales conversations everyone enjoys

---

[caption id="attachment_28514" align="aligncenter" width="800"]<img class="wp-image-28514 size-large" src="https://martinstellar.com/wp-content/uploads/2022/01/MartinStellar_SalesFlow-Coach-Questions-1-1024x500.png" alt="" width="800" height="391" /> Yes, questions really are the answer[/caption]

So, do you need a CRM?

The answer is yes, but it's also no.

No, you do not strictly need a CRM (Customer Relationship Manager), like Hubspot, or SalesForce, or Zoho.

But what you do need, is a central place where you list all your clients, former clients, and the opportunities that you're trying to convert into clients.

At its most basic, this can be a notebook, or a whiteboard with stickies on it.

A few steps up the technology ladder would be a spreadsheet, and beyond that, there's the many different software companies and their offerings.

But then the question is:

Which CRM (or database or any sort, paper or digital) is the best for you?

The answer is simple:

The one you actually use.

Because unless you use a CRM, in order to review your pipeline and take intelligent action on the opportunities in there, you'll find it very hard to keep your deals moving forward.

If you want your pipeline to work, and you want your leads to become clients, you'll need to actively, conscientiously, process the deals and take action on them, one by one, over and over again.

That's how you make sales happen.

Instead of what most people do, which is to just wait, and react to whatever your buyers may or may not do.

And this is where "CRM software" often becomes its own obstacle.

Most software is far too complex, too bloated, there's too many automations and integrations and funnels and what have you.

Depending on your type and size of company, it might be what you need - but for the majority of solo traders and small business-owners, it's overkill and the very software itself is the reason the software isn't getting used.

No, if you want to move your deals forward, the only thing you actually really need, is one single list of past, present and future deals...

And, of course, for you to review that list on a daily basis, and ask yourself questions like "What's required to move this deal forward?" or "What does this buyer need from me, in order to engage in a dialogue?"

This - daily reviews and intelligent questions - is exactly what I'm building with my SalesFlow Coach app.

The questions in the screenshot for instance: over time, each of these will get developed and turned into teachings and workflows, so that whatever list or CRM or database you use, you at least have the tool of querying your database, in order to always know what needs to happen next, for each of your deals.

Because not matter what technology you use:

The technology called "Questions" is the single part of your "tech stack" that everybody should use, and the SFC app will make that easier for you.

Anyway, I'm off to conduct research interviews, and learn how to best build this app out.

&nbsp;

&nbsp;

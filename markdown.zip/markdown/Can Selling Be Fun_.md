---
title: Can Selling Be Fun?
status: pending
datePublished: '1651706543'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="size-medium wp-image-25490 alignleft" src="https://martinstellar.com/wp-content/uploads/2020/02/MartinStellar_Coaching_Illustrations_Learnpeople-300x225.png" alt="" width="300" height="225" />

Almost every day, someone tells me a different reason why they don’t like selling.

“Selling is stressful”.

“It’s frustrating that the process takes so long”.

“I wish I wouldn’t have to always look for new prospects”.

“It’s such a waste of time, to issue proposals and not get the sales”.

I get it. Building your business, marketing, having sales conversations, writing proposals… it’s work, of the kind that you simply can’t get around.

But that doesn’t mean it has to be a slog.

In fact, for me it’s the opposite: I find the whole marketing and sales process a ton of fun.

Why?

For one thing, because it’s like a puzzle:

Who is this for?

How can I reach them?

Who’s most likely to buy?

What do they want to hear, or know, in order to want what I’ve got?

Puzzle, puzzle, puzzle.

Shifting pieces, figuring out what works, seeing a picture emerge… it’s endless discovery and learning, and I just love "learning people".

And that's the second reason I like sales so much:

Learning what life is like for that other person. Learning what it's like to be in their shoes.

Every person is a world, and for that person to buy my work, I need to 'learn that person'.

What are their fears and frustrations… which wants and aspirations do they have…?

How committed are they, how can I help them, what can I do to help them get out of repetitive and dysfunctional thinking, and operate and grow their business from the heart?

What’s the key I need to turn, in order for them to see their own abilities, leadership, communication and sales skills?

Who, in other words, IS this person - and how do I need to show up so that they can relate to me?

And, what's the identity-piece?

Meaning: if they decide to buy, what change in identity does that cause for them?

I promise, when you turn marketing and sales into that kind of exercise, it becomes a lot of fun.

Now, you can see selling as a separate thing, something you just have to do if you’re in business - or you can see it as an integral part of being human.

Where ‘being human’ means you exist in relation to others, and at any moment you have the opportunity to connect with someone, share in an experience, and figure out how you can create resonance with that person.

Much like you would with relatives, a partner, or a friend.

Selling isn’t some terrible task: it’s what we do all day long anyway.

And once you internalise that, once you make the shift into selling as a normal, helpful human activity, suddenly it becomes fun.

You don’t need to ‘get over yourself’ or ‘suck it up’ or ‘just accept sales’.

All you need to do is discover your own innate curiosity for others, and make it your mission to learn people, and figure out what's going on in their world.

&nbsp;

<hr />

On another note:
I'm building an app that coaches you on working your pipeline, moving your deals forward - and closing them faster and at better rates.
It's called SalesFlow Coach, and we're scheduled for beta-release early May 2022.
Register <a href="https://martinstellar.com/salesflow-coach-launch/">here</a> to be notified when it goes live.

---
title: >-
  Mini-Training SIBG 1.3: The Importance and Efficiency of a Goto Market
  Strategy
status: pending
datePublished: '1642413869'
categories:
  - Business and systems
  - Business Growth Fundamentals

---

[Mini-trainings / Stages and Ingredients of Business Growth / Pt 1.3 ]

<img class="size-medium wp-image-28538 alignleft" src="https://martinstellar.com/wp-content/uploads/2022/01/MartinStellar_Coaching_Illustrations-Mini-training_GrowthStagesAndIngredients_GotoMarket-Strategy-300x225.jpeg" alt="" width="300" height="225" />
Of course it's real nice when you figure out who your ideal buyer is.

And it's just lovely when you figure out your USP, and you know with certainty why people choose you over someone else.

But when you're setting up your business and your marketing, a customer and avatar and a USP aren't enough.

You also need to have a method for getting in front of those people, engaging with them, and creating clients out of the opportunities you generate.

In other words:

You need a goto-market strategy.

Because hey, people aren't going to come and kick down your door, just because you figured out the who and the why.

No, you also need to figure out the how.

And this is where it's easy to make fatally costly mistakes, especially if you try and operate at scale - and even more so if you're still in the set-up phase.

For instance, it can be an attractive option to start running ads.

Or you could try lead-generation by running automated outreach campaigns, using LinkedIn or email marketing.

The problem with that is not that it doesn't get you leads - the problem is that it does.

But wait, we're in business, we want sales, and for that we need leads - right?

Right.

But there's quality leads, and there's leads that are a complete waste of your time, for whatever reason.

So if you invest a few thousands dollars in advertising, and you drum up 20 leads a week, and you have to have a meeting with each of them... you'd better be damn sure that the majority of those people are actually qualified.

And this is where people often go wrong:

They focus so hard on generating leads in quantity, that they forget that efficiency comes from engaging with **qualified** leads.

The result is often frustration, wasted time, lost money, and a whole bunch of sales conversations that aren't ever going to go anywhere.

Put differently:

Don't look to scale up your efforts or your lead generation, until you've figured out your goto market strategy with predictable reliability.

And for that predictability and reliability to develop, you need to do things that don't scale.

Because that way you'll be so hands-on, that you get direct, live feedback on how well your targeting and messaging are working.

So when you're setting up, one of the best things you can do is schedule meetings with people, and ask them about their problems.

Sound familiar, right? Sounds similar to the research calls you scheduled in step 2, when you were trying to establish your USP, and yes:

It's very similar indeed. I mean, it's all part of selling, and that comes down to asking people about their problems until they ask you about your solution.

Aside from that:

If you do your USP research right, you'll already have potential buyers that you can talk to.

How?

By ending your USP research questions with:

"Once I conclude my research and develop a programme to address the issue you've told me about, would you like me to let you know?"

Not everyone will say yes - but if you interview 20 people, it's likely that 10 will give you permission to follow up, and it's likely that one or two of those turn into a client.

And no, that doesn't scale.

But when you land those clients, you'll know exactly which type of buyer will pay for your work.

And that means you'll be able to seek out exclusively the kind of buyer who's exactly like them.

And once you do that, you'll officially be in the Grow-Up phase of business - Part 4 of the mini-training tomorrow...

Cheers,

Martin

---
title: How to Be Happy Having Problems
status: draft
datePublished: '1513075652'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/48951048-c4de-4dd3-a9f6-b28751745215.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/48951048-c4de-4dd3-a9f6-b28751745215.png" data-file-id="4835273" />Ever noticed how when you solve one problem, another one shows up?

Funny how that happens.

You replace the battery in your car, and then the alternator burns out (or whatevs - I’m not a gearhead but it’s common for a new part to cause another part to fail in engines).

Or you clear away that debt, and suddenly you have a few hundred dollars extra each month.

Not exactly a problem, but it requires a decision: Go on a cruise? Save up? Retirement fund? New computer? Invest in training? Yes, you solved one problem and created another (good) one.

Problem: fridge is empty. Solve the problem, go shopping, problem solved. Next problem: deciding what you’re going to cook with all that you bought. And, make sure you use it all before expiry dates.

Problem: lack of money. So you get busy, find clients, and boom: new ‘problem’ - you have to deliver what you sold and make good on your word.

Current problem for me? I want to get featured on more podcasts, so I’ll need to send out pitches.

But I don’t really like that kind of work, so the solution is: hire a PR person to do it for me.

But that solution brings another problem, because there’s a lot of folks offering this service, and now I need to sift through all of them and decide who’s going to get my money.

In other words: whatever problem you solve, there’s another problem waiting for you, as a result of it.

Note that I use the word ‘problem’ in a broad sense. It can mean either something bad or something connected to potential and growth.

The point is that you’re in a situation that wants a solution, and creating the solution brings you a new situation that needs a new solution. (sorry if that one made your head hurt)

So what’s a smart person to do?

If life is one endless stream of ‘problems’?

Well I don’t want to call myself smart, but I do know what I like to do:

I choose the problems that I *want* to have.

I could easily say ‘I’ll hire an employee, to pitch me to podcasters and do other assistant jobs for me as well’.

But I don’t want to have employees - it would create the kinds of problems I don’t want to have.

So, I’ll find a freelancer instead.

Plan made, solution planned.

Oh wait, my site needs an overhaul before I can send podcasters over to check out my stuff. New problem.

I could get my learn on and create a site for myself - but that solution would bring me a lot of problems I don’t want to have.

Solution? Have my site built by someone else. New problem: I need to review the site and make decisions on how it should look and feel.

See, problems aren’t something to run away from, as if you’re an ostrich with your head in the sand.

Instead, they’re there for you to marry to solutions.

Just make sure you stop and think, so that whatever solution you choose, it brings a new problem - of the kind that you actually want to have.

Life’s a lot more fun that way…

If you don’t, you just might end up causing a string of problems, of the kind you’d really rather avoid.

And there’s no need for that.

You know which problems you enjoy fixing. You know what kind of solutions you like to work on.

Whatever choices you make, always be sure to choose in such a way that the new problem is one you'll enjoy.

Cheers,

​Martin

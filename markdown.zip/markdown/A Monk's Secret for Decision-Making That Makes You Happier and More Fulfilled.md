---
title: A Monk's Secret for Decision-Making That Makes You Happier and More Fulfilled
status: draft
datePublished: '1525285527'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft size-medium wp-image-20433" src="http://martinstellar.com/wp-content/uploads/2018/05/MartinStellar_Illustrations-conscious-and-unconscious-decisions-300x225.jpg" alt="" width="300" height="225" />Couple of questions for you

Do you remember the moment you decided how much salt to put on your eggs the other day?

Or those socks you’re wearing - do you remember making the choice that it was going to be those?

That traffic light turning yellow last month - you sped up instead of slowing down, and in retrospect it was a risky move… do you remember the exact moment you decided to push down on the throttle?

When you got that call and decided (did you really decide though? when? when exactly was the decision made?) to not answer, when later you found out they actually needed you this time...

The time you told your child off instead of slowing down and assessing whether there was something real and not another bout of crocodile tears… and they were hurt…

When your spouse told you - very subtly - that there was something bothering them but because of your own preocupations you decided to postpone inquiry till later… and it ended up in a tiff… and you didn’t even decide that, it was just an unconscious decision to not engage… you were hardly there to begin with, right?

Millions of decisions we make all day… tiny ones, bigger ones… inconsequential ones (we think!) and weighty ones…

One endless stream of decisions, and here’s the kicker:

The overwhelmingly vast majority of our decisions are made 100% automatically, without us even realising that we’ve been thinking and deciding. One flash: bam, decided. We just notice the result of it, not the actual moment of deciding.

But all those decisions have a bearing on your life. Your relationships, work fulfillment, create life, business success… you name it.

Your entire life is subject to changes due to the choices and decisions you make.

And it’s all pretty much non-linear: in decision&amp;event soup called your life, there’s much going on, most of it unseen, yet each of your decisions pushes the narrative of your life in some direction or other.

Your choices, in other words, in large part shape your life.

And oh, in case you didn’t get the point yet: You’re making 99.9999% of your decisions completely unawares, sight unseen!!!

That means that unless you have some seriously good policy on how your subconscious should handle all that automatic decision process, you might well end up with a life that isn’t what you want.

So there’s two tricks to work with here:

The first is simple: start paying attention. Become increasingly aware of what your mind does when you’re not looking, especially where it comes to decisions.

The second one is the monk’s secret:

Make a decision once, and never again.

You save the mental energy needed to think and decide about something.

You’ll be able to stop thinking so much because you’ve already made the decision. No need to think about it again - just do what you decided! Simple!

For example: I once decided on a simple morning routine. Meditate, read, walk. Done, decided. Never have to think about it again.

My first work activity in the day? Write you an article (I’ve been bad at that lately, but the decision is still there, making it SO easy to fall back into the habit, every single time I’m done having fallen out of it).

My shirts? White, mostly. Trousers blue or khaki. Never have to think about dress (a success secret from people such as Steve Jobs, and I think Einstein had similar simplicity in his cupboard).

Anyway, all these once-made decisions freesme up to think on the things that really matter:

How to best serve my customers, for example.

Or what to tell my readers, so as to help, but also look open for business.

What content to create so as to give you the best tools for growing your business.

(Hint: I’m coming out with a free webinar on email marketing soon - showing you exactly how I use it in my business, and there will be a paid course connected as well).

Eliminating decisions by making them once gives me freedom to create. To ideate and be an artist and a coach and a professional.

It’s working on the top-level things in my life, because I’ve decided, wholesale, to avoid as much as lower-level and mid-level deciding as I can.

Note: this doesn’t mean that you’re married for life to a decision that you made. When the time comes to change things up, then you take mental time and contemplate and re-decide.

But always work from the starting point of one decision for lower and mid-level things.

Does life become boring that way?

This (ex) monk tells you no. Quite the opposite.

Because once you stop wasting your mental energy on unconscious decisions that only need to be made once, you’ll be amazed at how much new and creative thinking starts taking place.

So what are you subconsciously wasting your mind-time on, that actually you could decide once and be done with?

Think… let me know.

Cheers,

​Martin

---
title: I'm Not Sure If I Just Had 💡  Moment Or a 🤦‍♂️  Moment, But...
status: publish
datePublished: '1612345175'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<p class="p1"><img class="wp-image-26512 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/02/MartinStellar_Coaching_Illustrations-playing-programmer-300x225.png" alt="" width="355" height="266" />But now that I’ve started building in public, something just resolved itself and became crystal clear.</p>
<p class="p1">See, I've always liked working with coaches and consultants, but as a niche that's way too broad.</p>
<p class="p1">And we all know that the narrower the niche, the easier to build a business.</p>
<p class="p1">But I just could never really figure out what kind of coach, or consultant. And so for the last few years - basically, since moving away from coaching artists - I’ve not really know who ‘my people’ are.</p>
<p class="p1">I’ve always know <i>what </i>I’m for - helping ethical people build a thriving business - but I just wasn’t clear <i>who</i> I was for.</p>
<p class="p1">But this morning, as I was journalling through the question of what type of content I want to be putting out, it hit me.</p>
<p class="p1">In retrospect, it’s dead obvious.</p>
<p class="p1">I mean all my friends are techies.</p>
<p class="p1">Developers, makers, builders, SaaS owners, coders and programmers.</p>
<p class="p1">I gravitate to that kind of person - for one thing because they tend to build really cool things, but also because of the way their minds work.</p>
<p class="p1">You have to be a logical, critical thinker, if you want to program something.</p>
<p class="p1">And as I move on learning about programming and taking my first steps learning Python, I realise:</p>
<p class="p1"><i>These</i> are my people.</p>
<p class="p1">Not surprising, since I got my interest in computers and programming from my dad, who was a systems analyst.</p>
<p class="p1">Used to go into banks and corporations to analyse their software, back in the day.</p>
<p class="p1">In fact, as a kid I used to ‘play programmer’ - rifling through boxes full of dot-matrix printouts of code that he’d taken home to analyse.</p>
<p class="p1">But I digress.</p>
<p class="p1">Yes, I love working with coaches and consultants.</p>
<p class="p1"><i>Especially </i>if they work with developers and SaaS, like some of my clients do.</p>
<p class="p1">So, if that’s you, and you want to land more developer clients, maybe I can help.</p>
<p class="p1"><a href="mailto:hello@martinstellar.com">Send me a message</a>, and let’s have a chat.</p>
<p class="p1">Cheers,</p>
<p class="p1">Martin</p>

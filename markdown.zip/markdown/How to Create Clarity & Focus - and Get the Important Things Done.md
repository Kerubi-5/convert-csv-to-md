---
title: How to Create Clarity & Focus - and Get the Important Things Done
status: publish
datePublished: '1595379281'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<a href="http://martinstellar.com/wp-content/uploads/2020/05/MartinStellar_Coaching_Illustrations-Urgent-vs-important.png"><img class="alignleft wp-image-24013" src="http://martinstellar.com/wp-content/uploads/2020/05/MartinStellar_Coaching_Illustrations-Urgent-vs-important.png" alt="" width="353" height="265" /></a>Phone calls, emails to answer, products to ship…

Social media and blogging and learning and fixing up your website…

If you’re like most people, you have a laundry list of tasks and todos and goals… and you just might find yourself overwhelmed by it all.

So here’s a very simple exercise to help you create clarity.

It’s based on the concept of urgent VS important, as you can see in the diagram above.

Point is, it’s very easy to always be dealing with the urgent things, and never getting to doing the important, non-urgent stuff. But it’s exactly those things that will ultimately drive your business forward.

The things that are important but not urgent, they typically have to do with building assets.

Things like the body of articles that I’ve written over the years - that’s an asset.

Or your network, or your skills in writing, or actually turning your writing into books…

These are the things that will have a big impact in the long run, but they’re never urgent.

Which is why, if you never get to them, your progress will be annoyingly slow.

By contrast, reserving time each day to work on the important things will ultimately move the needle on your business.

The principle of the exercise is beautifully simple.

Take your todo list, and for each item ask yourself in which of the 4 quadrants it belongs.

Mark the number of the quadrant next to each item.

Next, it’s time for action.

First, the lowest number: those things that are both urgent and important.

Before anything else, work through them, fast as you can.

Take a break.

Come back to your list, and have a go at the items marked #2.

Not so as to execute on them, but to plan them in your calendar.

The best is to only take a short block each day - maybe one to two hours, three at most.

Because you’ll always have to reserve time for dealing with things that suddenly become urgent and important, and the last thing we want is for those moments to push the important/non-urgent off the agenda.

There you go: A simple and beautiful system to help you create clarity, tranquility - and forward momentum that pays off.

Or, get my help on making the best strategic decisions - AND making sure that you get the right things done.

More info and application <a href="https://wp.me/P3Rm0D-66P">here.</a>

<span style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen-Sans, Ubuntu, Cantarell, 'Helvetica Neue', sans-serif;">Cheers,</span>

Martin

---
title: How to Use Generosity to Improve Your Marketing and Sales
status: publish
datePublished: '1622766837'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing
  - Relationships

---

<img class="alignleft wp-image-22191" src="http://martinstellar.com/wp-content/uploads/2019/10/MartinStellar_Coaching_Illustrations-Business-success-empathy-and-generosity-givers-and-matchers-1024x768.png" alt="" width="356" height="267" />If ever you wonder why your marketing isn't working better, ask yourself:

Have you built enough generosity into it?

If the answer is 'yes', ask:

Am I being generous to the 'wrong' kind of person?

Because if you give to takers, your gift goes nowhere and your generosity is wasted.

In his book Give &amp; Take, Adam Grant writes about givers, takers, and matchers - and research shows that givers - generous people - tend to be the most successful.

But, generous people also tend to be the *least* successful.

The difference between successful givers and unsuccessful givers, is that the successful ones don’t give to takers.

That's not selfishness or being uncaring: it's efficiency.

It's putting your resources where they'll have most impact.

For you, for the recipient, and for those that those recipients give to.

Takers are like a black hole: whatever goes in, never comes out again.

Matchers and givers however, give back or pay forward, or both.

Be generous to those two, and hope that takers will learn someday.

But don't give to them.

No matter how big your heart is, you'll never have enough energy to make it worthwhile to give to takers.

They'll just want more and you'll burn up whatever resource and goodness you have; it won't benefit them, or you, nor anyone else

Point is, generosity - in marketing and sales - is an enormously powerful driver.

It's leverage.

It rests on the principle of creating value, before asking or wanting anything.

So, do things that are valuable.

Make things that are valuable.

BE valuable - and not just as a human, because you already are.

Be valuable as a professional, in your marketing and sales.

Tune in to the people you want to serve, create something they'll love and that will help them, and give it to them.

Want to have a chat about how that could work for you?

<a href="mailto:hello@martinstellar.com">Send me an email</a>, and let's meet.

&nbsp;

&nbsp;

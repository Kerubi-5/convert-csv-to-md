---
title: 10 Work From Home Tips from an ex-monk (please share - people need it)
status: publish
datePublished: '1584990209'
categories:
  - Business and systems
  - Doing it right as an entrepreneur or creative professional
  - Hope&amp;Survival
  - Psychology in sales and marketing

---

<a href="https://mcusercontent.com/f05dc59f4bf8170c301679377/files/3c94cdcd-bcfb-49e2-acde-a80221b1a58a/Ebook_10_work_from_home_tips_from_an_ex_monk.pdf" target="_blank" rel="noopener noreferrer"><img class="alignnone" src="https://mcusercontent.com/f05dc59f4bf8170c301679377/images/0d070b3d-9317-4127-b6e3-08915c963ec4.jpeg" alt="" width="350" height="259" align="left" data-file-id="4837401" /></a>Hey there!

Ok, so here's the ebook I promised - 10 Work From Home tips from an ex-monk.

Click the image to view and download.

And, please share it with as many people as you like.

Working from home can be a challenge any time, but even more so now.

We all need some help &amp; good ideas, so do please share.

Thanks!

Martin

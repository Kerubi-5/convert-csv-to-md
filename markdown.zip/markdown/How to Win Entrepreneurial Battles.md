---
title: How to Win Entrepreneurial Battles
status: publish
datePublished: '1595465952'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/21493cf2-8036-4712-9c6f-2f8872fc5e7d.jpg" width="350" height="317" align="left" data-file-id="4836397" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/21493cf2-8036-4712-9c6f-2f8872fc5e7d.jpg" />Because hey, every entrepreneur is a hero in their own right - we all battle against challenges and crazy odds.

So: People tend to think that Napoleon was a great strategist, and it’s probably true.

But, strategy is nothing without implementation.

Proven by the fact that he never won another battle, once his marshall Davout had died.

Davout was the man who translated Napoleon’s strategies into marching orders for the troops, or however that works in the military.

Davout only ever lost one of old Nappy’s battles, and according to the internetz, after him it all went to hell in a handbasket.

Why would you care?

Because a) you absolutely, most definitely, need solid strategy if you’re going to win your own entrepreneurial battles.

But, you’ll also need to translate that strategy into the right actions, set the milestones and end goals, and get your head in order so as to actually get the actions and tasks done.

Or, what psychologists call <em>implementation intention. </em>

Just taking action won’t cut it. Neither will strategy without implementation intention.

It all comes down to decisions, based on questions like ‘what matters most, right now’ and ‘what should I focus on’ and ‘what should I avoid at all cost’ and, very importantly:

‘What needs to be DONE?’

These are the things we focus on, in my Strategic Accountability Coaching programme.

We won’t be fighting wars, but we sure as hell will get you set up, every week on Zoom, the right way, to make sure you choose the right tasks, and execute on them.

This is a powerful programme, and inbetween calls it gets you daily access to me by email, for any course correction or feedback you need.

You can go it alone, and you know how that works out.

Or, you can get my help, and be amazed at how focused, results-driven, and ‘DONE’ your performance can be.

More info and an application form here, if you’ve had enough of spinning your wheels: <a href="http://martinstellar.com/sac" target="_blank" rel="noopener noreferrer" data-cke-saved-href="http://martinstellar.com/sac">http://martinstellar.com/sac</a>

Cheers,

Martin

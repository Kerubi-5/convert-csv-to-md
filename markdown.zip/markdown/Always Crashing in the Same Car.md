---
title: Always Crashing in the Same Car
status: draft
datePublished: '1486016625'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

I don’t know what David Bowie really meant when he wrote a song with that title,
			but I do know this:

			We’ll always come back to the same issues, make the same mistakes, find the same
			limitations within us.

			And before you think that I’m being gloomy, let me assure you I’m not.

			It’s actually a good thing, provided you see this ‘always crashing in the same car’ the
			right way.

			Here’s what I mean:

			Let’s say you’ve worked hard overcoming fears and you’re doing well, you’re taking
			action, and boom: Another fear comes up and stops you in your tracks.

			Or you spend a lot of time and energy letting go of people-pleasing behaviour, and
			suddenly you once again find you over-exerted, on the giving end of a situation where
			you’re not being appreciated.

			Or you work for months getting over your procrastination, and one day you look at your
			to-do list and you realise you’ve been putting things off again.

			This isn’t a problem, this doesn’t mean you’re broken.

			It’s meant to happen that way, and it’s a good thing.

			Because each time you run into the same issue, you’re now at a different level.

			These things don’t happen in a circular way, but in a spiral.

			You pass the same points, but you’re now more experienced, you’re stronger, you’ve
			learned to recognise the signs.

			And when you’re aware of that, you can see it coming.

			Which enables you to take preventive action, and avoid falling into the same traps as
			badly as you used to.

			In other words: It’s good when ‘problems’ don’t really go away.

			Because dealing with them over and over again makes you better at dealing with them.
			Until such time that you get so sick and tired of it, you’ll rid yourself of the problem
			once and for all.

			Until it comes back again - because on some level, it always will.

			Just make sure you keep moving up on the spiral.

			Which I can help you with, if you want.

			Just say the word.

			Cheers,

			Martin

---
title: 'Grey Matters: Something Toxic in Your Life, and I Recommend You Get Rid of It'
status: draft
datePublished: '1527097606'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/bb50416a-a4d7-47e1-9113-76e621cbc3fe.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/bb50416a-a4d7-47e1-9113-76e621cbc3fe.png" data-file-id="4835745" />And I’m not talking about toxic people, or bad habits.

In fact, the toxic thing is a habit that you very likely don’t have.

Which is normal: almost nobody has this habit.

Ok, so consider the spectrum of thoughts and emotions that you move through.

On one end, you have things like doubt, depression, fear, worry - and whatever other non-positive awareness that you might have.

On the other end, there’s the positive and uplifting: joy, creativity, gratitude, appreciation of beauty, insight, and all the other good stuff.

Right, so what lies between those two extremes?

Hard to put your finger on, isn’t it? There’s all sorts inbetween the two polar opposites, and here’s the problem:

Most of all that thinking there, is totally below the level of conscious awareness.

They are what I call ‘grey matters’. Mostly unseen, but present and extremely influential, for the sheer volume of it.

Your brain happily churns away through endless thoughts and feelings, all day long. And you’re lucky that you’re not aware of most of it, because it would drive you crazy.

Except…

Except that when you make an effort - make it a habit - to shine a spotlight on all that slightly sub-conscious movement…

… you’ll start to notice some damn interesting patterns.

For example, you might find that there’s an auto-loop playing, which automatically causes you to procrastinate on something, the moment you think about it. And you don’t even notice you’re doing it - your mind does it on auto-pilot!

Or you might find that you repeatedly re-hash conversations from the past. “I shoulda said this or that”. Familiar?

Or perhaps you discover that you have a subtle but strong judgment of things going on, causing you to persistently re-frame your world in negative terms.

Or maybe you discover a little voice, that gently and repeatedly whispers in your mind’s ear that you’re not worthy, not ready, or not enough.

All kinds of things, different for everyone.

What’s in the grey area isn’t bad, but it can have devastating effects on your well-being and your success.

The remedy? Become aware of what goes on in your mind, just below the surface. Colour the grey matters, see what you discover.

That’s the toxic thing in your life, which I wish for you to remove:

And ongoing, mostly unchecked, very likely damaging in some way, narrative, 24 hours a day.

We notice the peaks and troughs, sure. But it’s inbetween those - in the grey matters - that you find the patterns that determine your view, thoughts, feelings, and actions.

And those, together, make your world, don’t they?

Thinking unawares is often toxic. So, best get yourself utterly familiar with the grey matters, so that you can start to change them into narratives and patterns of thought that actually contribute to your life.

Happy to help you shine a light - that's what coaching does: bring out the things behind the scenes, that cause the things you want to work on.

Let me know when you're ready for that, alright?

Cheers,

Martin

---
title: I Couldn't Launch a Paper Airplane if it Had a Rocket Strapped to its Back
status: draft
datePublished: '1522166172'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/59ce274c-c014-42f1-b7d1-bdacf62f1023.jpg" width="350" height="350" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/59ce274c-c014-42f1-b7d1-bdacf62f1023.jpg" data-file-id="4835589" />I couldn’t launch a paper airplane if it had a rocket stuck to it

Honestly though: Here’s a guy who records a video, to announce a couple of things about The Cabal Creative, and to share a message about the importance of showing up.

With the video - and the fact that I’ll be publishing one every day for a month - as an example of stepping up to the plate. Me eating my own dogfood, so to say.

So I merrily record, upload to Twitter…

… and proceed to delete the video after after pasting the link to it in the email I was preparing for you.

Which I then sent, broken link and all.

Resulting in hilarity this morning, when I opened up Twitter and saw this in my feed:

<img class="alignleft" src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/5acf5276-bc0d-4a57-bfe2-cfd6eaf1ad59.png" width="350" height="329" align="middle" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/5acf5276-bc0d-4a57-bfe2-cfd6eaf1ad59.png" data-file-id="4835585" />
Yeah. Like I said, couldn’t launch anything, not even a paperclip with my thumb.

What can I say? It was late, and I’d spend hours trying to upload the video, which was made stupid hard by all kinds of weird glitches and dropped connections.

But anyway, I’m undeterred.

Here’s the link to the (working) video from yesterday:

<a href="https://twitter.com/TheCabalCreativ/status/978330670815698945" target="_blank" rel="noopener" data-cke-saved-href="https://twitter.com/TheCabalCreativ/status/978330670815698945">https://twitter.com/TheCabalCreativ/status/978330670815698945
</a>
And here’s today’s video - about your hero’s journey.

<a href="https://twitter.com/TheCabalCreativ/status/978658495926030336" target="_blank" rel="noopener" data-cke-saved-href="https://twitter.com/TheCabalCreativ/status/978658495926030336">https://twitter.com/TheCabalCreativ/status/978658495926030336</a>

Yep, you’ve got one too, no matter how unheroic you think you might be.

Watch the video to learn why that matters…

Cheers,

Martin

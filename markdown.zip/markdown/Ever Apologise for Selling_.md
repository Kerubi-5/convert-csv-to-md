---
title: Ever Apologise for Selling?
status: publish
datePublished: '1498735078'
categories:
  - How to sell your work
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/8e8cf0c7-2d73-4338-b364-2f50fbef0265.jpg" width="291" height="274" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/8e8cf0c7-2d73-4338-b364-2f50fbef0265.jpg" data-file-id="4834753" /> There’s this strange thing where some people feel they should apologise for selling something.

But if that’s your case, may I just point out that what you make/do and sell, actually solves a problem?

That it’s something people really need, or want?

That when the buyer decides they want to buy, it makes their life better?

And, that if you don’t make a case of being open for business, and - ethically and non-pushily - selling your offer…

… the buyer might end up going elsewhere to spend their money - likely to another provider whose marketing and selling is stronger than yours…

But their product or service might not necessarily be as good as yours.

Which means that if you don’t make the effort to sell, you’re effectively doing your buyer a disservice, by allowing them to go elsewhere, and they’ll get less value for their money.

So if ever you feel conflicted about selling, or if ever you’re - gasp - tempted to apologise, remember this:

Selling is a duty for ethical entrepreneurs.

And if you do it right (i.e. instead of forcing the sale, you simply facilitate the buying process), selling can be an act of service.

&nbsp;

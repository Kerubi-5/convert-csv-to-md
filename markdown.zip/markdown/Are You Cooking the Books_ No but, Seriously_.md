---
title: Are You Cooking the Books? No but, Seriously?
status: draft
datePublished: '1542794714'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21101" src="http://martinstellar.com/wp-content/uploads/2018/11/MartinStellar_Coaching_Illustrations-Slice-of-life-cooking-the-books-1024x768.png" alt="" width="355" height="266" />Obviously you wouldn’t.

Your invoicing, your tax declarations, your profit&amp;loss balances, your budgeting, your insurance claims: why on earth would an ethical, honest and sensible person falsify the data?

You wouldn’t, because you know that a) it will likely be found out at some point, and b) because it’s unhealthy to act against your values.

And yet… there’s a good chance that in a sense, you are cooking the books - that is, where it comes to what you tell yourself about yourself, the world, and your place in that world.

And sure, I cast the first stone unto myself: it’s humanly impossible to not create a doctored version of reality. Can’t be otherwise.

At any moment in life, there’s millions of impulses coming at you and our brains would melt or explode or both, if we were to perceive it all.

So our subconscious conveniently and automatically filters a small set that our minds can handle, and then that’s what we call reality.

We take a slice of life, and we get to work using just that tiny bit, in order to make sense of the world and to move through it.

But the part does not equal the whole: it only represents it, and inaccurately at that.

So in a sense, we’re all, at any moment, ‘cooking the books’ of life. Automatically and subconsciously.

Smart people know that, and are weary of confusing a slice of life with life itself.

And the best failsafe, to protect you from inventing a reality that pleases but isn’t accurate?

Question… everything.

Perception is an assumption.

Question every assumption.

Try it. You’ll be positively amazed at how much more malleable life becomes.

You’ll discover that yes, you too can calibrate reality.

But only if you’re brave enough to challenge your belief about reality. Brave enough to consider literally everything an assumption.

It’s a fun exercise, and it’s a powerful framework for coaching.

Want to give it a try, see what changes in your world?

Then let’s talk…

Cheers,

Martin

---
title: About That Ad I Showed You Yesterday... And You, the Hero
status: draft
datePublished: '1524851840'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/7c020f3b-bd1a-4027-bbae-c53faad877b1.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/7c020f3b-bd1a-4027-bbae-c53faad877b1.jpg" data-file-id="4835673" />There’s a meme that’s been going round for decades: that Ernest Shackleton posted the following ad in a newspaper, when trying to recruit crew for his Antarctic expedition.

---
Men wanted for hazardous journey. Small wages, bitter cold, long months of complete darkness, constant danger, safe return doubtful. Honor and recognition in case of success.
Ernest Shackleton

---

Now, obviously I’m not going to sail a ship into the Antarctic ice. So why did I rewrite the ad yesterday? (aside from having fun doing a bit of my old job - copywriting)

-

Men and women wanted for risky journey… Extreme commitment required, long periods of doubt and second-guessing, constant risk. Success as likely as complete failure. Prosperity and recognition in case of success.
Reply to learn more.

--

Point is, I’m trying to tell you something about yourself.

Something that, if you take it on board, can have a profound and lasting impact on your life.

Meaning, a specific attitude I’d like for you to play with. Adopt even, maybe.

In my world, I’m an explorer. I might not be Shackleton or anything extravagant like that, but I’m as much trying to find my way - and survive, with all my limbs please - as best as can in this crazy and constantly surprising world.

Everybody is. So to me, everybody is an explorer. Whether consciously or not. Whether someone deliberately lives that way, or not.

And the entrepreneur?

Well, that’s the one I wrote my version of the ad for.

Here it is again:

Men and women wanted for risky journey…Extreme commitment required, long periods of doubt and second-guessing, constant risk. Success as likely as complete failure. Prosper  ity and recognition in case of success.

Reply to learn more.

Absolutely true, isn’t it?

So yeah. You’re on as risky a voyage as Shackleton, except the risk isn’t life or death. Same degrees of risk, and same highly unpredictable balance of probability between success and failure. There’s just no saying if you’ll ‘make it’ or not.

In other words:

Aw, my little hero, you.

And I mean that. Being an entrepreneur is, to me, a heroic thing.

And what I hope you bring into your life, is the attitude of a Shackleton: to rely fully on your skills and resourcefulness, and deliberately explore how to best ‘survive’ this entrepreneurial journey you’re on.

And in a very practical sense, I AM inviting you on a journey. No gloves and boots required, don’t worry.

I’m inviting you to apply to my private, POWERFUL coaching group The Cabal.

It’s a small, very together, team of creative professionals - and we’re looking for someone special, action-driven, and creative, to join our team.

And yes, it’s like the ad says. Requires commitment, will bring you through phases of doubt (which are awesome, once you get through them and we in the team will help you).

And, there’s risk too. Membership to this very exclusive group of salty (ha!) entrepreneurs comes at a cost, and there’s no telling when you start to see return on your investment. Could be a month, could be 3 - depends on many moving parts.

But we’ll be there to support you, and help you grow your business as fast as you can.

And that’s effective: one of our members saw her annual revenue multiply by five, last year.

Those effects can only come from changes on the inside - not from learning about Facebook Live or buying Google ads.

And that inside change, that’s what The Cabal is for.

Doors are open for application, and I’d love to find out if you and the group would be a good match.

Let me know if you feel the same.

Cheers,

​Martin

---
title: Eustress & Rising Tides
status: publish
datePublished: '1594772155'
categories:
  - Business and systems
  - Doing it right as an entrepreneur or creative professional
  - Hope&amp;Survival
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-23176" src="http://martinstellar.com/wp-content/uploads/2020/04/MartinStellar_Coaching_Illustrations-Rising-Tides-1024x768.jpg" alt="" width="355" height="266" />Yeah it’s a messy time, and yeah every business on earth is under stress…

But while some are under threat and the stress threatens to crush them, others are under stress because suddenly, in this changed world, there’s so many opportunities - a type of stress called <em>eustress.</em>

The restaurant that kept all their staff and went full-on delivery based, they’re under stress - the good kind.

Zoom, who saw their userbase go sky-high in a matter of weeks, is under good stress.

Online educators, the smart ones, are suddenly able to reach and sell to far more students than before: people have time, have more disposable income, and there’s only so much Netflix one can ingest.

And there’s a large demographic of people who are keen to learn things but never had the time. So I predict that the online learning market is going to grow massively.

Now what do all these have in common?

They benefit from a rising tide.

Sure you can look at how the tide has fallen across industries, and lament how people just ain’t buying.

But that does you no good, and it won’t land you the contracts where you get to serve your people, either. Double-bad.

So instead, move towards the rising tide.

If you read some articles on entrepreneurialism and how people are adjusting their businesses, you’ll find plenty of smart moves people are making, that you can borrow from and implement for yourself, in order to also get lifted by the rising tide.

Because while the economy may change or slow down, it’s not going to stop. And parts of it are going to rise, in a big way.

Go towards the rising tide, and I’ll bet there’s one in your industry as well, if you look close enough.

Happy to have a conversation about what that looks like in your situation.

Just <a href="mailto:hello@martinstellar.com">let me know you want to talk</a>, and we’ll set up a time.
Cheers,

Martin

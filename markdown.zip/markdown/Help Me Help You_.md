---
title: Help Me Help You?
status: draft
datePublished: '1511261053'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

A lot has changed over the last year or so.<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/0158e2f7-4efc-41c1-afbe-832a291d0398.png" width="350" height="386" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/0158e2f7-4efc-41c1-afbe-832a291d0398.png" data-file-id="4835217" />

Most notably, in the sense of the kind of people I work with.

When I started out, I was the business coach for artists. Because I love art, I love working with artists, and hey let’s face it: artists like us, we need all the help we can get, where it comes to building a business.

But gradually, I loosened up, and started working with different kinds of entrepreneurs as well.

The owner of a publishing company, an architect… also creative industries, but different from making and selling actual art.

And in the last few months, I’ve started to feel a little off-kilter. Not exactly clear on… who I’m for.

Or the kinds of problems that my audience most needs help with.

Used to be simple: I’m Martin and I help artists build a thriving business, by working on the inner game.

But at the moment, with new and different readers, I have questions.

What do you most need help with?

What’s the biggest bottleneck in your business or life right now?

What do you dream of, that you don’t know if you’ll ever build it?

So I’m asking for your help.

Help in creating clarity on how best to serve you.

Whether with the emails I write or the coaching we do, how can I best help you?

So if you’re willing to help (I hope you are), please reply and answer the following two questions:

What kind of industry do you work in?

And:

What’s your biggest challenge right now, whether professionally or personally?

Do please let me know - it will enable me to write the kind of articles that most help you…

Thanks!

Martin

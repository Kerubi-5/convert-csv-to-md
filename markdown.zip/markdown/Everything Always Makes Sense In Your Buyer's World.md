---
title: Everything Always Makes Sense In Your Buyer's World
status: pending
datePublished: '1633523786'
categories:
  - How to sell your work

---

<img class="size-medium wp-image-28078 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/10/MartinStellar_Coaching_Illustrations-Everything-always-makes-sense-in-the-world-of-your-buyer-300x225.jpeg" alt="" width="300" height="225" />It’s often said that humans are incredibly irrational creatures, but I don’t think that’s true.

I think people simply have an operating system that’s far more complex than we realise. Far more rules and biases and preferences that all need to work together, for each person individually.

So, you see someone doing something that looks completely irrational, including roundly ignoring your very astute reasoning on why another action would make more sense…?

Then you need to realise that in their world, they’re making perfect sense. Completely logical, here - sound reasoning, you see?

And you go: “Yeah, no, but...” and you’ve lost the race.

Buyer in need, but choosing to hire a sales team, instead of hiring you to optimise the team’s performance first?

Makes sense in their world.

Hot prospect, all engaged and on-board with your coaching programme, to help them write their book - but then says they need to wait till next year?

They’ve got a reason for that.

Client completely borking up the marketing implementation they bought from you, because they keep messing with the copy?

Yep, those changes had to be made. Obviously.

There are a million ways to look at a situation and make a decision about it.

No matter how illogical something might seem to you, it makes sense for the other person.

And when you’re dealing with buyers, you need to be careful not to fall into the irrationality trap, and dismiss something as illogical.

Instead, you need to ask them questions that help them identify the flaws in their logic.

Because if you try the default - jumping in with a helpful “No, it’s different, let me explain” - you’re making them wrong and yourself the boss of the situation.

Result: no buy-in, guaranteed.

It’s not enough to observe logical fallacies or irrational behaviour.

If you truly want to serve a buyer in deciding to buy your thing or not, you need to enable them to observe them for themselves.

And you do that by asking specific questions, like a coach or a therapist would do.

Here, <a href="https://martinstellar.com/helping-good-people-sell-more-and-generate-a-bigger-impact/">let me teach you how.</a>

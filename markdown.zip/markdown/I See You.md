---
title: I See You
status: draft
datePublished: '1538041354'
categories:
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-20942" src="http://martinstellar.com/wp-content/uploads/2018/09/MartinStellar_Coaching_Illustrations-I-see-you-1024x768.png" alt="" width="356" height="267" />It’s one of the most effective, most powerful things you can do:

To stop and properly pay attention to another person, in a way they can’t avoid noticing.

Whether you say it or  simply show it: to actually *see* someone.

Because we all need to be seen. Being invisible or going unnoticed is painful.

And sure, we see people. I doubt you’re blind to others.

But what about the inner elements of the other person?

Their needs, their wants, their fears and frustrations and desires and all the unexpressed but very real concerns they have…

Are you aware?

The simple truth is: you don’t need to be aware of it all. You couldn’t be.

But you can take a moment to take someone in, to listen, intuit, observe.

Create space for the other to be themselves - enable them to share and show what they so desperately need you to know.

Because we’re all so busy with our own lives, we often completely miss what the actions or inactions of the other is trying to tell us.

So in any situation where you want to change the dynamics, improve the relationship or  cause a breakthrough, there’s a simple formula with often dramatic effects:

Step 1: slow down, and don’t take yourself so seriously. This one is about the other, not you.

Step 2: Listen. Ask. Observe. Don’t give advice, don’t try to fix.

Step 3: And once you get the picture, tell them:

I see you (though often, by that point, you’ll no longer need to say it).

Cheers,

Martin

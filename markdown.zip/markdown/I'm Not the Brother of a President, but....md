---
title: I'm Not the Brother of a President, but...
status: draft
datePublished: '1499688603'
categories:
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/f440a467-a319-44b2-87b6-c7abd3366972.jpg" width="350" height="459" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/f440a467-a319-44b2-87b6-c7abd3366972.jpg" data-file-id="4834785" />… apparently I think like one.

Check out this little nugget, by Robert Kennedy:

“There are those that look at things the way they are, and ask why? I dream of things that never were, and ask why not?”

Fully agree with ole’ Bob.

History is full of people who asked “Why not?”

It got Amelia Earhart to become famous, it got the Wright brothers to fly, it got Edmundsen to discover the South pole, it got Copernicus to prove that we revolve around the sun.

Modern medicine, the device you’re reading this on... (I know, this list could get quite long)… it’s all because someone somewhere was creative enough to ask:

“Why not?”

When you ask that question, something interesting happens:

Your brain will automatically start answering it, and it usually takes the shape of “because XYZ makes it impossible”.

And that’s brilliant!

Because you then get to ask yourself: “How can I solve XYZ? How can I make what seems impossible, possible?”

Remember, what’s possible or not is very often just a belief or opinion.

Ask Nicolai Tesla, who invented wireless electricity. Nobody thought he was sane, but he knew it could be done, and these days you can wirelessly charge or power all kinds of devices.

As always, questions are the answer. To pretty much everything you want to create, build or achieve.

Makes my work a lot of fun, because coaching is very much about asking questions.

Questions that challenge, questions that dive deep - questions that bring out the genius in you.

Which is why Maria Brophy said:

“It’s like you have this long sharp needle, and you use it to get *right* to the core of the matter”.

Heh. I love my job.

Anyway, if you want to experience what happens when a coach asks you powerful questions that help you bring out your power, let me know.

I’m offering all my readers a no-cost 30 minute strategy session.

Say the word if you want one.

Cheerio,

Martin

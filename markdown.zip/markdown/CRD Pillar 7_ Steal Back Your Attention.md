---
title: 'CRD Pillar 7: Steal Back Your Attention'
status: draft
datePublished: '1542187412'
categories:
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-21043" src="http://martinstellar.com/wp-content/uploads/2018/10/MartinStellar_Coaching_Illustrations-Steal-back-your-time-from-Facebook-1024x768.png" alt="" width="351" height="263" />Did you know, there’s a war being fought over you?

Specifically, over your attention?

It’s true. All those ‘free’ websites, with all their highly addicting endless scrolling and their clickbait headlines: they need you.

They want your data, they want your clicks, and above all: they want your attention.

Because for each second you spend there, some advertiser makes money and pays the platform.

Attention is a super valuable, and extraordinarily abundant, resource.

7 Billion people, who all pay attention to something, all day long, consciously or not.

Except attention is not abundant - not for you or for me.

For us as individuals, attention is a finite resource.

We can only pay attention to one thing at a time, and only for the finite number of hours we’re awake each day.

And to make matters worse, paying attention to something costs energy, which is another finite resources.

And to make matters worse, what you pay attention to has a big influence on how you feel, think, and decide, and therefore on what you create in life.

This is why Pillar 7 in Calibrate Reality Dojo is Attention.

You want to get deliberate and intentional about what gets your attention.

And you certainly want to avoid falling into the trap of spending your attention on the addiction economy that so many businesses exploit shamelessly.

Because they’re fighting to steal your attention, and they’re REALLY good at it.

They’ve learned how to addict people to a dopamine drip, and I’m telling you:

Steal your attention back.

Because unless you mindfully and deliberately control your attention, someone else controls it, and that can’t be a good thing.

Next up, a question:

What in your life, business, or relationships, should you pay more attention to?

Next next up: Might be a useful question to journal on...

Cheers,

Martin

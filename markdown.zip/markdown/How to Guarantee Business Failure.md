---
title: How to Guarantee Business Failure
status: pending
datePublished: '1622107793'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<p class="p1"><img class="size-medium wp-image-26960 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/05/MartinStellar_Illustrations-Niche_segmentation_messaging_specificity-300x225.jpeg" alt="" width="300" height="225" />Or, at the very least, how to get yourself constant struggle, frustration, and underperformance.<span class="Apple-converted-space"> </span></p>
<p class="p1">Over the past few years, I’ve conducted hundreds of interviews with all kinds of business owners.<span class="Apple-converted-space"> </span></p>
<p class="p1">This in function of market research, and establishing product-market fit.<span class="Apple-converted-space"> </span></p>
<p class="p1">And what I find over and over again (honestly, it’s so prevalent it’s not even funny):</p>
<p class="p1">Hardly anyone has a proper definition of their ideal client.<span class="Apple-converted-space"> </span></p>
<p class="p1">Call it segment, or niche, or avatar:</p>
<p class="p1">There’s a particular, very specific type of client, who is absolutely ideal for you - and you for them.</p>
<p class="p1">They show up on time, they don’t haggle, they do their homework, they repeatedly purchase from you, they refer their friends, they get tremendous benefit from your service or product…</p>
<p class="p1">In short, it’s a match made in heaven.<span class="Apple-converted-space"> </span></p>
<p class="p1">And, logically, if you’d direct all your marketing and sales efforts to exactly that type of person, you set yourself up for the most attainable, and the fastest possible, growth.<span class="Apple-converted-space"> </span></p>
<p class="p1">Execpt most people don’t.<span class="Apple-converted-space"> </span></p>
<p class="p1">Whenever I ask “Who is your ideal client?”, in nearly all cases, the reply is broad, vague, and non-specific.<span class="Apple-converted-space"> </span></p>
<p class="p1">Developers! Coaches! Small to medium businesses! Leadership teams! Authors! Those are my people!</p>
<p class="p1">Yeah, but no.<span class="Apple-converted-space"> </span></p>
<p class="p1">If the specifitiy of your ideal customer doesn’t go deeper than a broad descriptor, you’ll get very little, and very unsatisfying, returns on all the time and money you invest in your business.<span class="Apple-converted-space"> </span></p>
<p class="p1">Whereas if you get super specific and hyper-focused on just a very small subset of a subset of that descriptor, then you’ll see very interesting and rewarding returns.<span class="Apple-converted-space"> </span></p>
<p class="p1">Because once you have a perfectly detailed description of your perfect and ideal buyer, you’ll know exactly what their lingo is, how they think, what they struggle with, what their goals are.<span class="Apple-converted-space"> </span></p>
<p class="p1">And that will enable you to create messaging that speaks directly, with utter precision, to exactly the way their mind works.<span class="Apple-converted-space"> </span></p>
<p class="p1">You’ll show up, with your messaging and value proposition, and the potential client will go “Huh, this is exactly for people like me. Tell me more”.<span class="Apple-converted-space"> </span></p>
<p class="p1">And that is something you’ll never achieve if your definition of a perfect client is broad and general.<span class="Apple-converted-space"> </span></p>
<p class="p1">And of course:</p>
<p class="p1">I know you don’t want to miss out on opportunities.<span class="Apple-converted-space"> </span></p>
<p class="p1">If someone shows up who’s different from your ideal buyer, and they’re qualififed, then of course you should let them buy your thing.<span class="Apple-converted-space"> </span></p>
<p class="p1">I’m not saying that you should exclude everyone who doesn’t fit your precise description.<span class="Apple-converted-space"> </span></p>
<p class="p1">What I’m saying is that you should have branding, postitioning, and a value proposition that are exceedlingly specific to your ideal buyer.<span class="Apple-converted-space"> </span></p>
<p class="p1">That way, the ideal buyer will click with your messaging, and also:</p>
<p class="p1">Those who are slightly different will recognise your specialisation, appreciate your professionalism, and a lot of them will ask: “Can you help people like me, as well?”</p>
<p class="p1">And that’s something that just won’t happen, if you show up looking like you’re for everyone.<span class="Apple-converted-space"> </span></p>
<p class="p1">You can't ever guarantee business success, but you can certainly make it more likely - and to do that, position yourself as the most trusted authority, for a very specific set of clients.</p>
And as always, if you need help figuring out who those people are and what to say to them, I'm <a href="hello@martinstellar.com">only one click away.  </a>

&nbsp;

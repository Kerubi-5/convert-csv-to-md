---
title: Never Make the Big Decisions...
status: draft
datePublished: '1523638191'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/384c52cc-e39d-4519-b532-36468ba3f9b5.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/384c52cc-e39d-4519-b532-36468ba3f9b5.jpg" data-file-id="4835637" />… that is, not unless you’re certain, convinced, have perfect clarity.

Another way of saying it: It’s not a decision until it’s a hell yes.

Until then - in my life at least - it’s a no.

The amount of clarity in my life simply because of this decision is staggering and SO utterly useful.

For example: this winter I had a phase of several months, where I tried to get myself to a couple of important and big decisions about my life and my career, and I just couldn’t figure out what to decide.

Normally, I would get lost in rational considerations, stuck in my mind, weighing pros and cons and wasting entirely too much energy.

Wasting energy in terms of the amount of brain-time I spend on it.

Not this time though. By now I’ve practiced the ‘absence of hell-yes equals hell-no’ attitude so extensively, I was able to let go.

I didn’t have the clarity I needed to make a decision, so I just stopped *thinking* about it.

Not that I dismissed the issues or pretended they didn’t exist…

No, I took my deliberations of it to the level of contemplation, up from the rational, fruitless, ‘think yourself to a decision’ into the level of ‘observe my thoughts and feelings about it, plus the things in my life pertaining to the issue, and wait for clarity’.

Because clarity will always come in the end, and most of the time it’s not because of thinking. And it’s never ever because of just thinking.

And you can’t force it. You just can’t think yourself to the right decision.

So when thinking ain’t enough to get you to a decision?

Stop thinking about it. Take a load off your mind, you know?

You’ve got things to do that are far more useful than running in circles in your own head.

The difference in these two attitudes is the difference between trying to shove an elephant into a cage, vs enticing and inviting him in with soft words and delicious food. Not that I think elephants belong in cages, but you get my point.

All this comes down to how you manage your energy, like I talked about in a video last week.

Because your energy (physical, emotional, mental, willpower etc) is renewable, but finite.

Only so much of it you can spend in a day.

So what big decision are you trying to get clear on…?

Three choices:

1: Continue running circles in your mind

2: Do what the monk for entrepreneurs suggests: stop *thinking* about it, and start to observe from a detached vantage point

3: Talk to said monk for entrepreneurs (hello!) because maybe, just maybe… he might be able to help you find the clarity you need, and end up with the hell-yes you're looking for...

Big decision facing you? Talk to me…

Cheers,

​Martin

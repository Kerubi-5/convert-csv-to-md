---
title: Become a Self-Breaking System
status: draft
datePublished: '1495106051'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

One of the big benefits of working with habits, is that it helps you to recognise
			and idenitfy systems.

			And that matters, because in the end everything is part of a system, and each system is
			part of another system.

			And every system is perfect, for the results it produces.

			But here’s the problem:

			Systems break.

			Systems fail.

			They have their weak spots and bottlenecks.

			But is that really a problem?

			I say no. It’s a good thing.

			Because when you build or observe a system, and something doesn’t work, you get to
			identify what went wrong - how the system produces an imperfect result.

			And then you get to fix that, and observe whether the result becomes different and more
			satisfactory.

			And that is why it’s good when systems break. It enables you to improve them.

			You too are a system.

			And you have things that can be changed of optimised, so that System You produces
			different results.

			In other words: Become a self-breaking system, because that’s how you get to improve.
			Systems are supposed to break. You are supposed to run into faults or errors. And you
			choose to fix them, or not.

			Reminds me of my time in the monastery, where we were told that vows are meant to be
			broken.

			Because that way you learn over time that you don’t want to break them.

			Like when I broke my vow of celibacy. I very quickly learned that I didn’t want to break
			it, ever again.

			Anyway, sit with it for a while.

			See System You, and accept that it will, has to, unavoidable break.

			Become a self-breaking system.

			Be ok with that. Because it enables growth.

			What also enables growth is building a system around building habits.

			And I’ll help you with that if you want, with my new Habit/Path coaching programme.

			Let me know if that interests you.

			Cheers,

			Martin

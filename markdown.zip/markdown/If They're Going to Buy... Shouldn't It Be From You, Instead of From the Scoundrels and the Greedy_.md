---
title: >-
  If They're Going to Buy... Shouldn't It Be From You, Instead of From the
  Scoundrels and the Greedy?
status: publish
datePublished: '1580720599'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - How to sell your work
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-22318" src="http://martinstellar.com/wp-content/uploads/2019/11/MartinStellar_Coaching_Illustrations-To-commerce-or-not-to-commerce-1024x768.png" alt="" width="351" height="263" />It’s easy to cast blame for all the ways that commerce and capitalism do damage.

Society and the environment sure don’t get better from the way Facebook treats users, or the way  some companies pollute our world.

But if you’re in business and you’re here to make a difference, it doesn’t make sense to cast blame - whether you blame marketing, or capitalism, or commerce, or corporatism, or money:

None of those are the actual problem.

They’re all agnostic of right &amp; wrong.

They’re just tools to be used in order to further a mission.

The type of mission determines whether you’re helping, or hurting things.

And how you use those tools is what makes for right or wrong.

And they’re powerful tools, too - so more than ever, the world needs good eggs - people like you - picking up the tools, and doing something good with them.

Because if you don’t, others will, and it’s plain to see that a lot of those others do not have the ethics and integrity as people like us do.

So you can dislike money or selling or capitalism all you want: if you don’t pick them up and do something good with them, others will - and you have no control over how those others go about their business.

But the buyer will buy - from you or from the other.

Shouldn’t it be you though?

That’s why, if you want to do something good, the best thing you can do is get good at being in business, sign on more clients - and scale up your impact.

Increase your slice of the pie for a good purpose, so that others without purpose, are left with a smaller pie.

Making sure that buyers buy from you, and not from the scoundrels and the greedy:

Sounds like a pretty good reason to grow your enterprise, if you ask me.

So: if right now you’re positioned for growth, you’re getting opportunities, but too often the sale doesn’t happen, let’s talk.

Helping entrepreneurs driven by purpose to create more clients is what I do, and I’d love to explore how we can get you to grow, sell more, and increase your impact.

Reply to this email and we’ll set up a time for a short call, to see what can be done.

Cheers,

Martin

---
title: How to Calibrate Reality
status: draft
datePublished: '1529397623'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/057b4af3-2ef1-4996-a93a-ad61ab0f8bf6.jpg" width="350" height="197" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/057b4af3-2ef1-4996-a93a-ad61ab0f8bf6.jpg" data-file-id="4835817" />Right, you probably think that’s hype: ‘calibrate reality’? Impossible!

Or maybe you think that I’ve given up on clear thinking, and now only believe in woo-woo stuff.

But nope, I’m dead serious.

You can calibrate reality, and I can teach you how to do it.

Here, let me show you how it works:

First, understand that whatever reality is or is not, no matter what science of philosophy or religion you adhere to, there’s one fundamentally true principle that applies to all of us.

We perceive. Ourselves, and others, and our reality and so on - and it just so happens that the psyche can not perceive without also interpreting.

Colouring what you see, if you will.

Or put differently: we all wear Self-Coulored Glasses, and they influence how we see that what we see.

Can’t avoid it. Perception IS a process of interpretation.

Right? So, then calibrating reality really becomes something very simple.

And, it becomes the one thing that for some thing is the very last thing they want to face:

That no matter what IS in your reality, it’s always only your perception, where you can make changes.

You can try to influence people or things in your life, but you’ve already found that it’s not much fun and a whole bunch less effective.

But if you change the way you see things?

Magic. Suddenly, everything is different.

Who wouldn’t want that?

Beats me.

But for me, and for my clients, calibrating reality is an ongoing, daily practice.

And it’s real simple:

1: Practice self-awareness

2: Learn to think about your thinking

3: Become a systems-thinker: develop the ability to see how certain ways of thinking and deciding and acting give you results you don’t want, and the ability to modify those systems for different results.

And there: you’re calibrating reality.

What’s that you say? That 3-point list sounds like it’ll take years to get the hang of this?

Well yes, obviously. You don’t get profound control over your reality just by wishing for it.

You can’t just call yourself a manifestor and then expect it to be so.

It takes time, and work, and patience, and scrutiny, and radical truthfulness with yourself, and tough decisions, and -

Hey did you hear that? That was the sound of half my readers clicking away from this article.

After all, most people don’t want to do the work.

They want to have things handed to them on a silver platter, without having to do any work.

Smart people like you and me though, we know things take time and work, and we’re happy to get our hands dirty.

Now, there’s one way to speed things up: having me show you how to do it. Guide you through the experience of reworking your perception.

That doesn’t give you a magic pill - I don’t sell hype. I’ll leave that to the scumbags in the coaching.

What I sell, is change. And I can’t change you: only you can do that.

But what I can do, is give you methods, training, experiences, insights and a lot more, that will enable you to develop your own skills much faster than on your own.

Including your skills at calibrating reality.

So, shoot me an email and let’s talk.

Cheers,

Martin

---
title: Keep it Wieldy
status: publish
datePublished: '1548058946'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21293" src="http://martinstellar.com/wp-content/uploads/2019/01/MartinStellar_Coaching_Illustrations-Complexity-1024x768.png" alt="" width="351" height="263" />All you need to play the blues is three chords.

BB King used to play spectacular solos with just a few notes.

Butter, garlic and an egg, and you have a delicious breakfast.

Charcoal and paper, and you can draw anything your mind can conceive.

Yes, I’m a stickler for simplicity.

And sure, there’s a place for complexity as well - without it, we wouldn’t have Bach or Indian curries or cars.

But in many cases, we make things far more complex than they need to be.

And complexity is costly in various ways: time, money, effort, or simply the space something complex takes up in your mind.

Complexity makes things unwieldy and bothersome.

And when it comes to business, that’s especially true.

Point is, there’s only a few ingredients required to run a healthy business:

- A product or service people want.

- A list of subscribers, i.e. people who have given you permission to communicate.

- A consistent habit of sending valuable content.

- A reliable, repeatable way of adding people to your list.

And that’s it, really. Even a website isn’t strictly necessary (though without one, building your list will be pretty difficult, so I wouldn’t recommend doing without one).

So if ever you feel overwhelmed or stressed out, ask yourself if things haven’t gotten too complex, because just like attics fill to capacity, most things in life get overly complicated over time.

Next step: eliminate.

Simplicity for its own sake is good, but simplicity for the sake of making things more wieldy is a super effective way to, well, become more effective.

Keep it wieldy.

&nbsp;

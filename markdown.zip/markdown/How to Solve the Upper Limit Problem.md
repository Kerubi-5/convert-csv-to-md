---
title: How to Solve the Upper Limit Problem
status: draft
datePublished: '1508760200'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/dda4b58a-883a-4f0a-afe5-89ad88dd82aa.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/dda4b58a-883a-4f0a-afe5-89ad88dd82aa.jpg" data-file-id="4835125" />A couple of weeks ago, the girls in the Cabal coaching group came up with an idea: what if we all read the same book at the same time?

I thought it was an excellent idea, so I suggested The Big Leap by Gay Hendricks.

A brilliant book, and highly recommended.

One of Hendricks’ core concepts is what he calls the Upper Limit Problem.

Which works like a thermostat of sorts: it’s a maximum level that we have set in our subconscious - for wealth, happiness, fullfilment… it can be anything.

And, if that thermostat is set too low, there’s a good chance that as we reach that (arbitrary and false) upper limit, we start sabotaging ourselves.

Just so that we don’t go above or beyond what we subconsciously believe is the maximum allotted to us.

And as is to be expected: within a few days, Upper Limit Problems started to show up.

And not just for the girls:

I too have my own upper limit problems.

So I asked my coach about it, and it quickly became clear where my own upper limit originated.

So many experiences in my childhood, where I’d be ‘put in my place’ by authority figures.

Teachers saying that I might as well drop out of school since I’d never graduate anyway.

Another teacher bullying me in front of the classroom, telling me and them that I’ll never amount to much.

My dad, even: “Hey do you see those chords Paul Simon is playing? I know I can play that song too!”

“Son, I wish you’d focus on getting better grades instead”.

Gee, thanks dad.

Now, I’m not saying this to elicit your sympathy. I’m no different from others, and we all have our upper limit problems.

The question is - to quote Paul Simon - what are you going to do about it, that’s what I’d like to know.

For me, the solution is simple:

To forget about me.

Because in the end, the upper limit problem I have is about me. The feelings I have, the subconscious convictions, the limiting experiences from the past… me me me.

And that just won’t do.

Because as anyone with some sense and some ethics will tell you, life gets better the more you make it about someone else.

And for me to navelgaze and be involved in my own problems and limitations… well, that just won’t help anyone.

Instead, I turn the Martin-now, with his insecurities and upper limit thermostat setting and everything, into a baseline state.

This, today, me, is the new normal.

And so from this new normal, what do I want to create?

What can I do or say that isn’t about me?

This:

Each of us, we have some sort of upper limit. You too.

And the more you run into it, and get annoyed by it, the more energy and power you have at your disposal in order to run right past them.

Make your work and your life about the other, and you will benefit automatically, and so will the other person.

AND you’ll be running right past your upper limits.

&nbsp;

---
title: 'I''m Not Saying You Can Predict the Future, but: You Can Predict the Future'
status: draft
datePublished: '1544608966'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21150" src="http://martinstellar.com/wp-content/uploads/2018/12/MartinStellar_Coaching_Illustrations-Lizard-brain-predicting-the-future-1024x768.png" alt="" width="351" height="263" />More specifically: you, the daily-life conscious individual you are, obviously can not predict the future, but:

Your lizard brain kinda can.

It’s the oldest part of the brain, way way older than the frontal cortex that enables you to think, and as such it’s got millions of years of evolutionary experience in perceiving things, extrapolating them, and assessing whether or not some is a risk or instead an opportunity to increase well-being.

In other words, it’s got a dead-right instinct for how to keep you safe, drive you away from pain, and towards pleasure, which is its only job description: keep ‘em safe, make ’em happy. Basically.

And the more you learn to trust it, the more you'll be amazed by its uncannily accurate knack for intuiting the outcome of situations and decisions.

Problem is, we can’t access the lizard brain directly, we have no ears to listen and it doesn’t have a mouth to speak. It doesn’t communicate in thought, the way the frontal cortex does.

But, it does speak to us, and it does so by talking to our gut, in a way.

That’s where you notice its messages.

Gut-instinct is real and should be taken seriously.

And it’s very easy to figure out what you’re being told, what the message is about.

Imagine you’re considering taking on a new client, or a new job, or you’re planning on a trip…

If the thought produces a tense, clenched kind of feeling in the lower abdomen, it’s a sign that there’s something not right, and you’re being warned of some kind of risk or danger.

If however the feeling is higher in the abdomen and feels more like a warm, expanding kind of excitement (which often goes together with some nervousness or even anxiety), it’s a sign that there’s an opportunity for well-being or increased happiness on the horizon.

So whatever situation or opportunity appears in life and whatever you think or feel about it, never forget to listen to what your lizard brain is trying to tell you about it.

And hey, if you presently have something in your life that your gut says is an awesome opportunity, but you want to make sure you’ll make the right decisions?

Then maybe I ought to coach you through the process.

I can’t promise we’ll be right for each other, but I’m pretty good at helping people make decisions.

Drop me a line if you’d like to talk and see if we resonate...

Cheers,

Martin

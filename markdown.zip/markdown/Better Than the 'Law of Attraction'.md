---
title: Better Than the 'Law of Attraction'
status: draft
datePublished: '1513770422'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/cdae1b3d-e9ab-48ad-9571-aab29fec43dc.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/cdae1b3d-e9ab-48ad-9571-aab29fec43dc.png" data-file-id="4835297" />There’s a lot of talk about the law of attraction.

And while there’s helpful ways of thinking, in some of the books and videos about it, it sure ain’t my thing.

I don't mean to rain on anyone's parade, but hey: thinking that you’ll be rich, or find a dream spouse, or become very successful, isn’t going to magically make it happen. No matter how much people tell you that it will.

You can’t dream, or wish, or think, things into existence. Believe me, I’ve tried.

(And yes, I know that the idea is about more than just thinking - but that doesn't change the point I'm making today).

So allow me to propose something else, something FAR more powerful. A much better law.

And something indisputable too.

I call it the law of creation.

As in: what you create, will then exist.

Can’t argue with that, right?

You create a painting, a meal, a conversation… you name it.

That’s why I call a human being a natural born creator.

We’re always, constantly, creating things.

The nice thing about that is that it gives you full control.

There’s no universe or godhead that you need to rely on, because you’re the one in charge.

You create.

Maybe right now, you’re creating an opinion about Martin, because you disagree with me.

Maybe later, you’ll create a decision. Or a thought about something.

And that last thing - the thoughts you create - are important.

Because what you think directs your feelings and decisions and actions.

And actions are the tool you use to create things.

So if you want to create a certain end result, start by creating the right thoughts.

Because while it might seem that thoughts come at you, and are not of your making, they are.

Except we usually let the mind create thoughts on its own, instead of taking charge of mind.

Don’t let your mind be your dictator - that’s not what it’s for.

After all, you’re the boss in your mind, right? Or at least, you’re supposed to be, and you can’t be.

One of the things I enjoy most in coaching, is helping clients change their way of thinking, making them more likely to actually get to their goal.

So, let me know if you want some of that.

Cheers,

Martin

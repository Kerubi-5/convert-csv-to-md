---
title: Go For Exhaustion
status: publish
datePublished: '1564045451'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft  wp-image-21923" src="http://martinstellar.com/wp-content/uploads/2019/07/MartinStellar_Coaching_Illustrations-Exhausted-VS-Depleted-1024x768.jpg" alt="" width="349" height="262" />There’s two kinds of tired: depletion and exhaustion.

Both are a consequence, and both require rest before you can give it another go.

But they are very different, and it pays to be aware, because depletion and exhaustion have different causes.

Depleted is how you end up when you’re running around putting out fires, going through mental loops, and doing the kind of busywork that doesn’t lead to results.

(Another big cause for depletion is having to make too many decisions, because decisions have a high cognitive cost).

Feeling, or being, depleted is no fun, not rewarding, and makes you want to hit snooze when you wake up in the morning.

Exhaustion however, that’s different. It’s what you feel after you climbed a mountain, completed a large customer project, or spoke to potential customers all day.

Exhaustion is the tired yet satisfied feeling you get after you’ve put in a long day of hard, focused, productive work.

Yeah you’re exhausted - but man, look at everything you got done… you’re *supposed* to feel tired, and it sure feels good.

The difference between depletion and exhaustion is big in many ways, and it’s a terrific way to measure how you’ve showed up to your work.

Exhaustion makes you wake up energised, and ready to rock and roll, whereas depletion has you wake up to another tiring day of ‘what actually am I supposed to be doing, what’s most useful’, which often leads to a day of procrastination and inconsequential activities.

When I end up feeling depleted, I know I’ve been working *in* my business, instead of *on* my business. Executing without much strategy or planning.

And when I notice that, I step back, stop doing things, take stock and map the playing field - and then I organise, prioritise, and plan… and only then do I go back to executing on my tasks.

Depletion is a warning sign that says ‘think’, so when you feel depleted, maybe it’s time for you to stop, and… think.

Don’t you think?

Cheers,


Martin

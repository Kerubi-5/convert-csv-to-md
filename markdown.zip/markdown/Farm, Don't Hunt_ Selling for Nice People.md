---
title: 'Farm, Don''t Hunt: Selling for Nice People'
status: pending
datePublished: '1661772401'
categories:
  - Ethics and marketing
  - Sales conversations everyone enjoys

---

<img class="size-medium wp-image-28442 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/12/MartinStellar_Coaching_Illustrations-Farm-dont-hunt-sales-for-nice-people-300x225.jpeg" alt="" width="300" height="225" />

Because really, did prey ever get better from being hunted?

Sure, the hunting analogy works, when applied to the selling process.

Patience, precision, understanding the prey, timing: there's a lot that carries over.

That prey thing though, that's where the analogy breaks.

I mean, that what gets hunted usually isn't all that jazzed up about the overall experience, right?

Instead, try farming, where you nurture, curate, foster and develop.

Relationships, introductions, reputation, opportunities, deals, helpfulness:

These are all things that exist in your business, and that you can nurture.

Whether you hunt for sales, or you develop those things in a caring and thoughtful way, is up to you.

But when you see your deals and opportunities and buyers in the light of farming, your being a good person who doesn't want to force or cajole people, stops being an obstacle.

You don't have to "hunt for clients" or "close sales".

You just need to "farm" what's already there.

Nurture relationships.

Fertilise your prospects' minds with useful knowledge and helpful questions.

Water their soil by making introductions to the right people.

Shine sunlight on them when you meet.

Prune away disqualified opportunities.

And, harvest your opportunities, every time someone says:

"I'm ready, it's time, let's do this".

I built an entire sales methodology around this way of handling your business and your sales process, and yes:

All of it is built into the SalesFlow Coach app I'm preparing to launch.

On which note:

Attentive readers will have noticed the PS that I've used lately, and some have told me "So <em>when</em>, Martin, is that app going to launch?"

Well, I can't promise, but:

In a few hours I'm meeting with my developer for a final check, and if everything works out, we'll be uploading the app today, ready to use.

Stay tuned...

&nbsp;

<hr />

If you want to be notified when the app launches and it's ready to help you close your deals faster and at better rates, you can register <a href="https://martinstellar.com/salesflow-coach-launch/">here</a> to be notified when it goes live.

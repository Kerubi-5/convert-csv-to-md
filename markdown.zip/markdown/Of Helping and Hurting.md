---
title: Of Helping and Hurting
status: draft
datePublished: '1544701337'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-21154" src="http://martinstellar.com/wp-content/uploads/2018/12/MartinStellar_Coaching_Illustrations-Best-year-ever-2019-1024x768.png" alt="" width="353" height="265" />Of course I like helping people. Every sane and healthy person does, if only because it confirms your values and makes you feel good about yourself.

But helping people isn’t why I’m a coach - something I only figured out a few months ago.

No, the real reason I coach people is because I hurt.

Not in a woe-betide me way, or suffering life - you’ll know by now that I’m not in favour of victimism, and self-pity is the scourge of a life well-lived.

No, I hurt because I see so many people who could live SUCH better lives, have better relationships, earn more money, be healthier, more fulfilled, less anxious… and yet many of the people I see in my practice and my daily life just never really reach those higher levels.

And for someone who cares as much about people as yours truly, you better believe that hurts like crazy.

Especially given that reaching those higher levels of money, well-being, success and whatever you desire isn’t complicated.

It’s not hard or difficult.

It’s not a struggle, and what’s more: the attitude of struggling or fighting is antithetical to running your life or business with ease and glee.

Key distinction here: the attitude is something you choose, always. It’s not because of how life messes with you that you struggle, but because you haven’t made the choice to live it masterfully, with ease and grace.

Make that choice, and everything changes. Promise.

And seeing people refuse that choice, and fight and struggle instead, well that hurts me.

And so I became a coach (hi!), because it’s the best way I know to help people.

When you do make the choice though, to accept that literally everything is a matter of how you handle your thoughts and perception, magic happens.

Like my client and friend Paula Mould, who just sent me a beautiful email expressing how thoroughly she’s enjoying her life these days - despite a recent divorce and enormous changes in her business (she closed her company down and pivoted completely - super hard process, but she’s masterfully made it work).

And how she got there?

With a little help from me, and a TON of self-reflection, looking in the mirror, and accepting full responsibility for her life and business - and by rigourously refusing to play the game called ‘blame life’.

And if you’re ready to do the same, I have an idea for you:

Right now, I’m looking for a few very select people, who want to start 2019 on a rocket.

As in: get the best possible start to make the year your best ever, with a little help from Martin.

Is that you?

Then let me know, and let’s have a chat.

Cheers,

Martin

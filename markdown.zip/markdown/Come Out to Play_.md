---
title: Come Out to Play?
status: publish
datePublished: '1506941820'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/b50da033-74e6-48b4-943f-066982ba5953.jpg" width="350" height="356" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/b50da033-74e6-48b4-943f-066982ba5953.jpg" data-file-id="4835057" />A client wrote in after seeing a webinar on the topic of play, as applied (or not) in the life of an entrepreneur.

It’s a webinar done by Peter Shallard, which I saw last year - and it changed my life.

The gist of it:

Despite our motivation, our mission, our assets and abilities and our big dream - it often seems as if something in us is doing whatever it can to stop us from getting ahead in our business.

Theories abound as to why: fear of success, fear of failure, negative self-talk… you name it.

But in many cases, the problem - and the solution - are quite simple.

For many of us, the single reason why we don’t achieve more, procrastinate less and take the big actions that really move the needle, is that we simply don’t play enough.

And you know who suffers most from that?

The inner child. And that inner child has a LOT of power.

So we tell it that there’s a phase of hard work coming up, and we make a deal with the inner child that after the slog, there will be fun! And money to spend! And holidays to go on! Really cool people to hang out with!

“Well ok”, says the inner child. “It sounds good and if you think you can make it happen, you have my blessing”.

And so The Work commences.

But since we tend to whitewash over realism with our unbridled optimism, things turn out to be tougher and more time-consuming than we thought.

Ok, thinks the adult in us. That’s normal. We plant seeds today, we harvest tomorrow. Got another slew of emails to reply to. Let’s get down to work.

Meanwhile, the inner child is getting impatient, and petulant, and frankly, starts to bully us.

And you can’t blame it, because hey: we promised him or her the payoff - and if we don’t keep our end of the bargain, of course the inner child starts throwing tantrums.

And that’s where the sabotage starts:

Suddenly, we find ourselves mindlessly scrolling through Flakebook, or cleaning out the kitchen cupboards, or frittering away our time calling one friend after another.

Because fun WILL BE HAD, your inner child will make sure.

Except it’s not really fun. It’s just a way to be ‘not at work’, but that’s not the same as enjoying free time. It’s not play - it’s procrastination, and it’s damaging because meanwhile we feel guilty for not getting stuff done.

So here’s the solution: play.

Every day, play. Do something whacky, or childish, or fun - something that you do simply because it makes you feel alive. Play.

But don’t make this an afterthought, something that you’ll find time for if and when.

No, you want to plan and program play into your day.

At the start of the day, set time aside for yourself and your inner child.

20 minutes, an hour - or block out a day for it - whatever works.

But make sure you give your inner child play time, and make sure you do it deliberately.

Knowing that it’s not you stealing time from work: instead it’s quite the opposite.

Play is a way for you to fill the well.

When I started to play, everything shifted. Stress went away, I became more productive, felt better about work… all kinds of positive effects.

Might want to try that for yourself…

And that client: play is something a bit forgotten in their life, which is why today we have a session. Just to play.

Because coaching isn’t only about doing deep inner work and having meaningful conversations about Very Important Stuff. Sometimes, coaching is simply about connecting with parts of yourself that have gone forgotten.

And yes, if that means that you and I get to play, then let’s play!

Our inner children will be most grateful…

&nbsp;

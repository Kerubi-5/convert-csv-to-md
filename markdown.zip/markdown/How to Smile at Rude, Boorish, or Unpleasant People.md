---
title: How to Smile at Rude, Boorish, or Unpleasant People
status: draft
datePublished: '1531333667'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/db8a371e-e53f-4124-bdf6-cdde94c40e2f.png" width="350" height="340" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/db8a371e-e53f-4124-bdf6-cdde94c40e2f.png" data-file-id="4835905" />But wait a minute… why?

Why on earth would you smile at someone who’s being unpleasant to you?

Let me explain. First, I’ll set the stage.

There’s a shop here in town, ran by two women, about my age.

I’ve been going there weekly for over a year, so I’m a regular.

And each time I go in and say hi they respond not with hello, but ‘digame’.

“Tell me”. Colloquial Spanish for ‘how can I help’.

When I pay, they take the money without a word of thanks (not that I expect gratitude, but it’s uncommon and it’s part of the overall picture I’m painting here).

When I leave I say goodbye, which 99% of the time goes unanswered. If they do say bye, it's more like a grunt than anything else.

And I’ve never, ever seen anything like a smile. Once there was a tiny almost-smile, and that’s it.

Nothing sympathetic there, nothing agreeable.

All in all, not a pleasant experience to go there.

But I make it a point to go to that shop and not another.

And not because I’m a masochist.

I go there to train spite my (human) tendency to not judge. To become better than that.

And so I say thanks, hello, bye, and I smile at them.

Oh I know, when someone isn’t pleasant, they didn’t earn a smile or a thank you, did they?

Maybe. Not the point at all though.

See, I observe that behaviour, then I have thoughts about it, then I have a feeling come from the thoughts, and together it resolves into an opinion: unpleasant people.

But are they?

Their parents don’t think so. Or their husbands, or friends, or children (ok, the children perhaps, sometimes).

So the opinion that they are unpleasant is mine only, and objectively not correct. Subjectively, in my world, yes: a correct opinion. But outside of me, in the real world, they’re who they are and probably not unpleasant.

And who knows why they behave like that?

Maybe they’re locked into a job and contract they hate. Maybe they have a beautiful dream of becoming an artist or entrepreneur, but mortgage and kid’s education and debts give them no choice.

Maybe they’re depressed, or they severely dislike each other?

Maybe they’re sisters and their father is suffering a long, painful, terminal illness.

Christ, maybe they simply just don’t like me for some reason. (a thing that’s not illegal yet, but wait till I’m President).

Who KNOWS what’s going on in their life! There’s no telling.

But it’s a fact that everyone has a reason for what they do or don’t do. And we don’t know those reasons.

So then why would I have the temerity that based only on my personal experience I get to judge them for how they behave towards me?

Ridiculous.

So, to spite my judgment, I go there. To say hello when I walk in. And thank you when I get handed my purchase. And say goodbye when I leave.

To train myself to not be so judgmental, because in the end, don’t we all judge more than we ought to or need to?

(If you say ‘not me’, you might be a buddha. And if you’re not, may I politely suggest you buy a quality mirror, and make a habit out of looking in it long and hard on a daily basis?)

The point of this all?

Living in judgment ruins your wellbeing.

Habitually judging people creates a reality for you where you get to be more angry, more opposed, or more dissatisfied than you need to be.

But on a deeper level: it’s not the highest level of living, that a human being can reach.

And for me, that won’t do.

If it’s in me to become a better man, then dammit I’m going to try and become a better man.

As for those ladies and their absent smiles?

I’ll get there. By god, I’ll keep at this until they do crack a smile.

Me, I’m committed to upgrading myself, every day and every way I can.

Are you?

Cheers,

Martin

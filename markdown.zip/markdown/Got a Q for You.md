---
title: Got a Q for You
status: draft
datePublished: '1498556687'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/067beac0-7748-465b-8374-8220b915769f.jpg" width="350" height="239" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/067beac0-7748-465b-8374-8220b915769f.jpg" data-file-id="4834745" />
You might know that I’m a big fan of podcasts.

In fact, many of my subscribers found me because of the podcasters who interviewed me.

And, I want to do more of those - because they’re fun and it’s a great way to get in front of somebody else’s audience (one of the best marketing principles you could think of).

But I just can’t be bothered to do the heavy lifting:

Writing to podcasters, pitching my story, following up, sending pics and bio information... not my kind of thing.

The lesson here: do what nobody does the way you do it (i.e. stay in your zone of genius) and outsource as much of the other tasks as you can.

And so, I’m hiring.

Because working with people (1 on 1 or in groups like the Cabal coaching group I run) is what I’m good at. And I want to focus my time there, not on pitching podcasters so they’ll interview me.

So here’s the question:

Do you know someone who is looking for part time VA/PR work?

If so, feel free to have them contact me.

Requirements - this person needs to be/have:

- A fan of podcasts

- Passionate about growth, personal development, business and marketing

- Native level English

- Observant and detail-oriented

- Personable yet professional

Yes I know: I just described myself, but nope: I’m not doing this job. I want to hire.

So, you know, send me any clones of me you might know.

Seriously though: I’m looking for a reliable assistant/PR person who knows how to pitch.

Know anyone like that?

Send ‘em over.

Cheers,

Martin

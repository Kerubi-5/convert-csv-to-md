---
title: My Rules for Having Calm, Focused, Super-Productive Days
status: draft
datePublished: '1535617454'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-20761" src="http://martinstellar.com/wp-content/uploads/2018/08/MartinStellar_Coaching_Illustrations-Cognitive-depletion_8-rules-for-productivity-1024x768.png" alt="" width="351" height="263" />I recently installed a few rules in my day, and fell in love with them faster than a adolescent boy falls in love with the prom queen.

They’re mostly based on making my deep-work (which I call Make Time) as efficient and effective as possible. They might help you too.

Problem is, we often jump from one context to the other, and we do it far too often.

Some emails here, some work there, back to emails, read a few blog post, do some work, skip over to social media, and then back to work - all the time, a constant back &amp; forth.

But the cost of this, the constant switching of contexts, is extremely heavy on our finite daily resource of energy.

It causes what psychologists call ‘cognitive depletion’ and it reduces our efficiency and productivity enormously.

The lowest hanging fruit, the quickest win in terms of more productivity, is to stop switching contexts so damn much.

So these are my rules, and I invite you to see which ones you want to adopt&amp;modify to your own needs:

Rules for results and massive productivity, in no particular order:

1: Make time (deep work) is sacred

I set a block of time for deep work, and there shall be zero communications during those blocks. No emails, no phone, no client calls (bar emergencies - clients have my cell number)

2: Nothing happens until my daily email has been sent

These daily articles are the core of my business operations, so they get full priority. Replace 'daily email' with your own most important, daily business activity

3: No optimising/ergology (office, computer, whatever) before 2PM.

I’m a sucker for automisation. And it’s real tempting to pause my work in order to, say, set up a keyboard shortcut in my text editor. But nope: I now set a quick task, and do those things during my siesta block, from 2 to 5.

4: First job after sending my daily: Identify and set three growth driving activities for the day

No exception. This alone creates enormous clarity and helps with focus.

5: Aggressively separate Me/Make/Meet

It’s tempting to knock off and take a walk/read a book when I get tired from work. Or to call up a friend. But no: Me Time happens outside of Make Time, and Meet Time as well

6: No learning during Make Time

If I stumble upon an interesting blog post while doing research, I’ll copy the URL and set a task in my task programme, to read at a later moment.

7: Day ends at 8pm

As a business owner, it’s easy to always be on. But that’s not healthy. This is why I plan my work around my free time (daily between 2PM and 5PM and after 8PM).

8 Process my task manager (Todoist is my fav) directly after setting my daily 3 GDA's

Once that’s done, it’s Make Time! I have clarity on my goals, I have a nice block of focused Make Time Ahead, I know my pending tasks have been scheduled, and I’m ready to knock it out of the park.

So if you feel like you do a lot, but you never really feel like you got a lot done, switching contexts might be the problem.

Put these rules to use for 7 days, and see if it helps.

And if you want help with this, or with any other aspect of your business, let me know.

Cheers,

Martin

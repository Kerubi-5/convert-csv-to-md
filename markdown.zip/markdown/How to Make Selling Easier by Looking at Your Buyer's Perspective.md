---
title: How to Make Selling Easier by Looking at Your Buyer's Perspective
status: pending
datePublished: '1655161895'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-21614" src="http://martinstellar.com/wp-content/uploads/2019/04/MartinStellar_Coaching_Illustrations-Empathy_perspective_sales-1024x768.png" alt="" width="352" height="264" />It would seem to make sense, that in order for someone to enroll in your offer, you need to find out how to get that person to see what you see.

Once they see your vision of their ideal outcome, then they'll get on board.

You know that if they go along with your proposal, they’ll benefit. You can see it, clear as day.

So, the job at hand becomes ‘how to convey my vision’.

But as you’ll have experienced, that’s a damn hard thing to accomplish.

People have their objections, their fears, their reasons why and why not…

But if only they would see what you see... then they'd buy in!

Right?

Wrong.

You can't sell people on your vision.

Instead, you need to step into <em>their</em> vision - or, apply what psychologists call 'perspective-taking'.

Because when a sale happens, it happens not in your world, but in the world of the buyer.

It’s the vision that <em>they</em> have, that determines whether or not they’ll buy into your proposal.

And once you see <em>their</em> side of things, you’ll be able to ask the questions they need to hear, in order to get clarity, remove doubts, and dissolve fears.

That way, their vision adjusts, so that it ends up overlapping with yours.

And that’s when the sale happens.

So how do you do that - how do you create a shared vision?

Simple: use empathy. And not the kind where you empathise with their problems, and give them a shoulder to cry on.

I’m talking about the empathy that enables you to see their world, through their eyes.

It’s not their job to take <em>your</em> perspective - instead, it’s your job to take <em>their</em> perspective.

Put yourself in the other person’s shoes, and your sales will be much much easier.

&nbsp;

<hr />

On another note:
I'm building an app that coaches you on working your pipeline, moving your deals forward - and closing them faster and at better rates.
It's called SalesFlow Coach, and we're scheduled for beta-release in June 2022.
Register <a href="https://martinstellar.com/salesflow-coach-launch/">here</a> to be notified when it goes live.

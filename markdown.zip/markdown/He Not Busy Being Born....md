---
title: He Not Busy Being Born...
status: publish
datePublished: '1594944665'
categories:
  - Business and systems
  - Doing it right as an entrepreneur or creative professional
  - Hope&amp;Survival
  - How to sell your work
  - Psychology in sales and marketing
  - Relationships

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/70f08b3e-c302-4cd4-9572-af7334c91979.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/70f08b3e-c302-4cd4-9572-af7334c91979.png" data-file-id="4836645" />I never got into Dylan, but I do know he’s an awesome poet - and I love me some good lyrics.

Saw him quoted the other day - you may know it: “He not busy being born is busy dying”.

And at times like these, that’s truer than ever.

If right now you’re not reinventing how you operate your business and marketing and sales - if you’re not working to reinvent yourself or rebirth your operations - you might end up in trouble, or end up unable to fix the trouble you're already in.

Of course this isn’t new.

A business is either constantly being innovated and optimised, or it should expect ‘shock by change’, at some point in the future.

Soon or later, problematic or disastrous - trouble ahead unless we reinvent.

And if, at this moment, you’re trying to figure out how to reinvent things and you’re asking ‘How do I keep selling?’ rest assured that you can stop doing that.

If you want to keep selling, the question should be:

‘What are my people’s needs, right now, under these circumstances?’

This, too, applies to business under any circumstances - but if right now you want sales keep to keep rolling in, that empathic way of approaching your market will a) give you answers as to what solutions people need, and b) make you stand out from all the tone-deaf competitors who simply keep pushing out their offers, as if nothing has happened.

If you want to be busy being born, be busy learning people.

What do your people need?

What if you'd be in their shoes?

What’s it like to be them?

That attitude, the answers to those questions, and a recipe for having conversations with people that identify those needs and that position you as the single best source to fill those needs, is what you'll <a href="https://gumroad.com/l/AAKEu">learn in this 1-hour training</a>.

Cheers,

Martin

---
title: If It's Not Alright...
status: publish
datePublished: '1569325632'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img class="alignleft  wp-image-22087" src="http://martinstellar.com/wp-content/uploads/2019/09/MartinStellar_Coaching_Illustrations-Will-it-be-alright-in-the-end-1024x768.png" alt="" width="349" height="262" />It reads like one of those fluffy, new-age inspired quotes that are so popular with the kids on social media:

“Everything will be alright in the end - and if it’s not alright, it’s not the end”.

It’s easy to think of situations where that doesn’t really apply - but there’s one situation where it very much does apply: Sales.

When you’re talking to a potential client, ‘alright in the end’ hopefully means ‘they bought your thing’.

But most people freak out when ‘in the end’ turns into ‘no sale’, and treat it as if it’s the end.

But it’s really just the start of a negotiation.

When a client says no, there’s no reason to act as if everything is ruined - not as long as you’re still conversing with them.

If someone is talking to you, part of them wants something that you have.

And unless it’s said outright, ‘no’ rarely means ‘no, go away’.

Instead, it means ‘not that, not like that, not right now’.

To which the perfect reply is: ‘then what, then how, then when?’

Cheers,


Martin

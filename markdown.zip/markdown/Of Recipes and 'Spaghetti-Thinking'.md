---
title: Of Recipes and 'Spaghetti-Thinking'
status: publish
datePublished: '1594082704'
categories:
  - Business and systems
  - Doing it right as an entrepreneur or creative professional
  - Hope&amp;Survival
  - How to sell your work
  - Psychology in sales and marketing

---

<a href="http://martinstellar.com/wp-content/uploads/2020/04/MartinStellar_Coaching_Illustrations-Systems-vs-spaghetti-thinking-scaled.jpg"><img class="alignleft wp-image-25247" src="http://martinstellar.com/wp-content/uploads/2020/04/MartinStellar_Coaching_Illustrations-Systems-vs-spaghetti-thinking-1024x768.jpg" alt="" width="346" height="260" /></a>Oh sure, I get it: no system ever guarantees a perfect outcome - after all, a system can only get the result it’s built for.

If the system isn’t perfect, neither should we expect the outcome to be.

And so the feedback I got last week - that even my brand spanking new IP to Profit system can’t guarantee to bring in sales for people who use it - was on point.

Especially at a time like these, we just can’t know which system for generating leads, making proposals and creating clients is going to work, or not.

But:

In my - systematic and obviously biased - opinion, it’s better to have a reasonably logical system you can run and optimise, than to practise what I call ‘spaghetti thinking’.

Like a bit of advise I saw the other day, where the instructor had some recommendations for drumming up business.

They were good instructions, but they were kind of like loose tactics - like throwing spaghetti at the wall.

Simple actions we can take like calling up clients and former clients and using ‘helping instead of selling’ as a way to find new gigs.

And yeah, that can work, and it’s good advice. But it’s going to work a lot better if you include that kind of tactic, inside a larger, planned, strategy.

Because then you get to make educated guesses.

You get to ask the right questions, of the right people.

You end up offering the things they need, instead of the things you <em>think</em> they need.

You get to aim your efforts precisely, and you get to measure and iterate for continued growth in results, and yes: sales.

When sales are falling you need to take action, sure.

But do you want to randomly throw ingredients into a pot and hope the end result will be edible?

Or are you going to use a recipe and have that guide you along the way?

A system, a strategy: all that is like a recipe.

Whether it works or not depends on many things: The cook, the quality of the recipe, the ingredients.

But even someone who can barely cook, can create something that tastes quite nice, so long as they follow a recipe.

And IP to Profit is just such a recipe.

Have a look, see if <a href="http://martinstellar.com/turn-your-intellectual-property-into-a-revenue-centre/">it looks apetising...</a>

Cheers,

&nbsp;

Martin

&nbsp;

&nbsp;

&nbsp;

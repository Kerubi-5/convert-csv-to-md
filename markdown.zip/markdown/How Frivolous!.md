---
title: How Frivolous!
status: draft
datePublished: '1520422846'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/158020ec-093c-456b-abff-731440dd3a81.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/158020ec-093c-456b-abff-731440dd3a81.png" data-file-id="4835521" />You might wonder, what’s got into me. All this stuff about art and building a studio for myself.

The frivolity of it, right?!

Am I not in business anymore? Coaching ambitious and driven creative entrepreneurs?

Oh yes I am.

But here’s the thing: I need play.

And so do you.

Well, not that I mean to tell you what’s good for you, but there’s evidence that without play in the life of an entrepreneur, things are far slower and more difficult, by a large measure.

Joe Polish (a smart and well-known speaker, author, and marketing/business thinker) talks about the difference between an ELF business and a HALF business.

Easy, Lucrative and Fun, or Hard, Annoying, Lame and Frustrating.

And without play? You’re perfectly set up for a HALF business, and who wants that?

No, I say play.

Play with things. Throw away some time, for no other purpose than you having fun.

It’ll do wonders for your creativity at work, and your overall state of mind.

Yesterday I played with charcoal. Today?

Who knows…

Sometimes clients visit here, and we work face to face.

It’s a lot of fun, especially when it’s a full-day coaching session, and we get to walk, talk, and play together.

Because if there’s one thing that nobody tells you about business, it’s that play is essential for entrepreneurial growth.

Play isn’t frivolity: it’s a tool.

Use the tool.

Play.

And, if you could do with a day that will transform your life for good and you want to come out to Southern Spain for it, let me know.

After all, I am the monk for entrepreneurs: the world’s most playful business coach.

And you bet that’s good for business.

Cheerio,

Martin

---
title: 'It''s the Singer, Not the Song: Your Revenue Needs More Than Just a System'
status: publish
datePublished: '1609460521'
categories:
  - Business and systems
  - Doing it right as an entrepreneur or creative professional
  - Ethics and marketing
  - Hope&amp;Survival
  - How to sell your work

---

<img class="alignleft wp-image-23077" src="http://martinstellar.com/wp-content/uploads/2020/04/MartinStellar_Coaching_Illustrations-IP2Profit_systems-1024x768.jpg" alt="" width="351" height="263" />When I launched the IP to Profit system back in spring, for developing a new revenue centre out of your customer list, my coach said:

“In such uncertain times, how do you know that a system will work?"

Brought back memories of that Stones song: It's the singer, not the song.

Because he's right.

Not just in uncertain times, but always:

We can’t ever know if a system will work, because any system depends on how you use it, how well it's executed.

Everything hinges on how we show up to a task or a project.

How we operate, implement, execute.

The song (i.e. the system) might be good, but if it also 'sounds' good (gets you sales) that's because of the 'singer' (you, the one operating the system).

And the IP to Profit system is no exception.

Sure it’s really well-built even if I say so myself, and yes it’s got all the steps to go from market research, through the copy you need to write, through selling and optimising your campaign.

And yes, you can make a revenue centre around your Intellectual Property, even at times like these…

...but it'll require the best of you.

Meaning: By itself, the IP to Profit system itself isn't enough - it's down to you, and your dedication and attitude and execution.

If you've got those in place, then you *might* be able to make your IP earn you money, even if the business world right now is in full VUCA (Volatility, Uncertainty, Complexity, Ambiguity).

Point is, if you don’t use some sort of structure or framework or system, it’s hard to know what to do, and in which order.

And from the actions you take, it’ll be hard to measure what worked best so that you can iterate and optimise, if you're not using a testable system.

And that’s why the IP to Profit system is so useful:

Not because it promises the end-all solution, but because it gives you a framework in which to operate, enabling you to indeed show up as your best self, and get the most out of it.

And, it enables you to get the most out of your single most valuable asset:

Your list, your database, all the people in your world you can talk to and help.

And to leverage that asset in a systematic way and keep your serving and selling going, consider getting the system: a 1-hour training, yours to have and own, slides included.

It's pay-what-you-want (including free, if you want) until next Friday. Don't miss it...

Cheers,

Martin

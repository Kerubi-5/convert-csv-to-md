---
title: Music, Space - Silence and Sales
status: draft
datePublished: '1561971119'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-21850" src="http://martinstellar.com/wp-content/uploads/2019/07/MartinStellar_Coaching_Illustrations-Music-space-silence-and-sales-1024x1024.jpg" alt="" width="350" height="350" />Way back when, I spent 6 months in university, studying musicology.

My favourite professor was a Sinologist (where Sinology is the study of Chinese culture, language, history, etc) and he taught me something that serves me to this day.

In Eastern traditions, music isn’t a matter of sounds, notes, patterns, and rhythms:

Music is the silence inbetween the sounds, punctuated by the sounds.

Something that a guitarist I know has no idea of, because when he plays, he’s not silent for a single moment - his playing is literally an endless progression of sounds… which makes for pretty awful music.

How does this relate to business and selling?

Very simple:

When you’re in a sales conversation with someone, one of the best things you can do is to shut up.

Not just to let the other person talk, but also to let the other person *think*.

Which most people get wrong: instead of giving others space, we fill every silence with words.

We keep talking, afraid to let a conversation pause - but it’s in those pauses that the other person reaches insight, identifies objections and comes up with questions.

Silence and space are what make a sales conversation natural and progressive, whereas if you just keep talking, you give the other person no space, and they clam up.

Yes, it can be uncomfortable to be silent and wait for someone else to say something, or to give you a cue to say more.

But in that silence, that’s when things shift for people.

And the most important moment for you to hold still and say nothing at?

Right after you quote your fee.

Think about it:

You’ve just told someone a number, and now they need to figure out how that number fits in their world, their business, their emotions, their budget…

The worst thing you could possibly do at that point, is keep talking.

Instead, sit back. Be quiet. Take the pressure off. Give that person time to integrate the conversation you were having, with the dollar amount required to acquire your product or services.

Put differently, let that person hear the ‘music’ (i.e. their own inner world) inbetween the sounds (the things you’ve been saying to each other).

The result?

Beautiful music, and a far easier sale than if you keep talking.

Space and silence might be uncomfortable for you, but the more you can accept that and stay quiet all the way until they start talking again, the better you serve them and the more likely that you’ll get that sale.

Cheers,

Martin

---
title: New! Extrafree Mirth & Merriment!
status: draft
datePublished: '1502185010'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/65065c9d-afca-47cb-a83d-73d4280acdae.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/65065c9d-afca-47cb-a83d-73d4280acdae.jpg" data-file-id="4834889" />Over the last few months, you’ll have seen me create illustrations to go with these daily coaching emails.

Mostly because I have fun making them, but also because it’s useful to connect a visual with a written message.

But what you might not know is that I’ve also started drawing comics - the consequence of a challenge that Maria Brophy gave me.

At the moment I’m at day 21, and if I keep this up for another week, I’ll have reached my goal of an uninterrupted chain of 30 comics in 30 days.

(This, incidentally, is a powerful tool for building up momentum. Google ‘Seinfeld Method’ for more info. And no: I don’t consider myself as funny as Seinfeld. This trick is about productivity and slowly building up momentum).

Anyway, the comics are a little peak into the more weird ways my mind works, and if you enjoy a daily chuckle, I invite you to follow me on Instagram.

My latest angle?

The adventures and learning curves of a very very stupid Artificial Intelligence, named Larry.

Follow him and the comics here: <a href="http://instagram.com/martinstellar" target="_blank" rel="noopener" data-cke-saved-href="http://instagram.com/martinstellar">http://instagram.com/martinstellar</a>

Cheerio,

Martin

---
title: Are You Forcing People to Pay Interaction-Tax?
status: pending
datePublished: '1651503017'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img class="size-medium wp-image-26659 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/03/MartinStellar_Coaching_Illustrations-Interaction-tax-fast-way-to-improve-sales-300x225.png" alt="" width="300" height="225" />

The other day I wrote about ‘selling people a problem’ - i.e. when the buyer perceives a complication or cost, that goes along with your solution.

Today, let’s look at interaction-tax.

And while it’s a word I made up, each of us force others to pay that tax.

- An email that’s long, and carelessly worded?

Now your buyer needs to allocate mental resources to even grasp the core of your message: you're making the pay interaction-tax.

- A Zoom call with a buyer, where you let them ramble and you don’t guide the conversation to a result of some sort?

They just spent an hour with you, and no real advance was made: Interaction tax.

- Need to tell an employee that you’d like to see them take more responsibility - but you cloak it in a ranting complaint about company morale?

Interaction tax.

- Present a demo with logic gaps, and your listener needs to think to connect the dots? Interaction tax.

In so many ways, so very often, we force people to pay a cost to interacting with us, and it goes directly against results, and against everybody’s interests.

My favourite pet-peeve in this context?

Those blighted audio messages people are always sending each other on Whatsapp. Horrible thing.

Oh, so you can’t be bothered to think out, and type up, a pithy, 1-sentence message?

Well, now the recipient needs to spend 90 seconds listening to you rambling, about something that could have been said in 5 seconds, or read in 3 seconds. Interaction tax.

Of course it’s not your intention - but it’s crazily easy to levy interaction tax on others.

Don’t do it - especially when you’re dealing with a stakeholder, such as a client.

Any interaction they have with you, be it written feedback on something, or an email or text reply, or a work meeting or session:

Carefully tailor your interaction and messaging to be as friction-free and low-cost as possible for the other.

Avoid making people pay a cost to interacting with you, and you’ll magically start seeing things move more smoothly with everyone - including your buyers.

&nbsp;

<hr />

On another note:
I'm building an app that coaches you on working your pipeline, moving your deals forward - and closing them faster and at better rates.
It's called SalesFlow Coach, and we're scheduled for beta-release early May 2022.
Register <a href="https://martinstellar.com/salesflow-coach-launch/">here</a> to be notified when it goes live.

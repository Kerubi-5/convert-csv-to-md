---
title: Is Failure Real?
status: draft
datePublished: '1515488632'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/695baaf4-c012-48a0-a858-b718308c9820.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/695baaf4-c012-48a0-a858-b718308c9820.jpg" data-file-id="4835357" />There is no failure. Not in my world.

Oh I do things wrong, and I make mistakes, and I break things and what have you - but however badly something turns out, I never consider it a failure.

Because there IS no failure.

There's only feedback.

And yes, I know that sounds like yet another wonderful motivational quote. Go ahead, I’ll wait while you post it to Facebook.

But it’s true. When you consider something or yourself a failure, that’s just a story you tell yourself.

And I sure prefer telling myself another story: that when it didn’t work, I learned something - that I now have data to base my new decisions on.

Which is why I’m not afraid to “fail”, in fact I’ll often do exactly those things that have a chance of not working out.

Because this way, I can’t lose. Either it works, or I learned something useful - about myself, or the world.

It’s an attitude that makes life a lot more fun, and it sure brings levity to your days.

Because after all, isn’t life one great laboratory experiment, where you constantly try things, and get better and smarter at living life as you go along?

You, the researcher… how cool is that!

Helping clients figure out which things to try that may or may not fail - and then helping them integrate the feedback (be it positive or negative) is one of the fun parts of the coaching process.

Try it sometime. Can’t fail.

Cheers,

​Martin

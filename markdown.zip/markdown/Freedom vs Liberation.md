---
title: Freedom vs Liberation
status: draft
datePublished: '1549454911'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21366" src="http://martinstellar.com/wp-content/uploads/2019/02/MartinStellar_Coaching_Illustrations-Liberation-vs-freedom-1024x1024.png" alt="" width="351" height="351" />It’s natural to desire freedom.

Freedom to make your own choices, spend time the way you want it, spend money as you please, freedom from oppression and manipulation and restrictions… all good things.

But freedom is an abstract, it’s not tangible. I mean, you couldn’t bring me freedom and put it on the table, point and say: ‘That. That’s freedom’.

And if that’s not enough, there will always be things that prevent us from being truly free.

You’ll always be subject to the rule of law, for example (unless you’re a maffia boss or other kind of outright crook, and even then you won’t be free, because you’ll be hiding from the law).

Freedom is elusive, impossible to define, and non-existent as a ‘thing’ or a state of being.

Even in alternative circles or hippy culture, where the idea of being completely free is so popular. Simply try showing up there in high heels and a miniskirt, or a business suit, and you’ll quickly see how people there are not at all free either.

This might all sound very gloomy, but worry ye not for I shall proceed to hand you a mental ninja-move:

Forget about being free or the desire to be free, and contemplate on liberation instead.

For one thing, liberation leads to increased freedom, and even better:

Liberating yourself from things is something tangible and practical - it’s something you can DO.

Some things, you’ll never be free of.

Having children, noise in your street, traffic lights, earning a living, breathing and eating, having to sleep, aging, and so on.

But beyond that type of thing, there’s a million things in your life that you can liberate yourself from.

Each time you liberate yourself from something, you become a little bit more free - which is a lot more fun that living with the frustrating desire to be ‘free’, whatever that means.

Freedom isn’t a thing - it’s a sliding scale.

You move up it the more you liberate yourself from things, and the easiest way to get started is by eliminating stuff.

Because we’ve all got too much ‘stuff’ in our lives, be it people, places, habits or things.

The struggle to be free will always be that: a struggle.

But the process of ongoing liberation?

Fun, effective, and yeah: liberating.

Let me know if you’re ready to start taking action - i.e. start making decisions on which things you want to get rid of.

It’s easier than you think, I’ll show you.

Cheers,

Martin

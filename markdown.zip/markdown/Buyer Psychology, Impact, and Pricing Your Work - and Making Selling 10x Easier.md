---
title: >-
  Buyer Psychology, Impact, and Pricing Your Work - and Making Selling 10x
  Easier
status: publish
datePublished: '1611535401'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-22197" src="http://martinstellar.com/wp-content/uploads/2019/10/MartinStellar_Coaching_Illustrations-Sales_cost_value_impact-1024x768.png" alt="" width="354" height="266" />What would you prefer: a dollar, or ten dimes?

Sounds like it's the same thing, but it isn't.

See, there’s a common misconception in the mind of many business owners:

That selling at a lower price point makes it easier to land clients.

But that’s the kind of sloppy thinking that makes for a tough business to run.

Think about it:

For every lead that you create, you have to spend resources:

Money, time, mental resources, and so on.

If you then try to create a client at say $100, you have to spend ten times the resources to reach *counts fingers* $1000 in revenue.

And then you have to deliver your service - your coaching, training, consulting, whatever it is you do, ten times.

But if you try to create a $1000 client, you have just reduced your efforts and the cost of generating that client by a factor 10.

And the ‘secret’ is that it’s usually just as much work to land a $1000 client, as it is to land a $100 client.

So far for the logic.

Next up: the psychology of the buyer.

If you do something really valuable for people, something transformative, something that gets them a high return on the investment they make with you (whether that’s in terms of cash returns or changes in their life), you want people to buy because of the value you deliver.

Your best buyers are those who want the impact you provide.

And if you price your work low, you’ll end up talking to people who aren’t looking for high impact and high ROI, but instead they’ll be looking for low price.

And the psychology of low price is that as long as the dollar amount you propose isn’t what they’re happy to spend, no amount of promised impact will convince them to hire you.

In other words: there’s value-buyers, and price-buyers - and price buyers are very, very costly because they tend to be very hard to convert.

Whereas value-buyers are more discerning, easier to identify, less concerned about dollar amounts - AND they are overall much more fun to work with.

A price-buyer thinks in terms of scarcity. They want ‘value for money’, and while you should obviously provide value for money, that kind of buyer will always want more, because they tie value to a dollar amount.

Value buyers however, tie value to impact.

And if you position yourself right, and put yourself in front of people who want impact, you’ll find that they’re far easier to enroll.

Yes it’s scary to ask for the big bucks, but you’ll find that people who want to buy impact are the kind who are much less concerned about the actual price.

And, bonus: that’s also the kind of buyer who is more likely to actually have the money to invest with you.

So before you go out and underprice yourself, ask:

Who do you actually want to work with?

People who count dollars… or people who size up the impact you can deliver for them, and base their decision on that impact - the outcome you promise?

As for me and the impact that my work delivers:

I can help you get comfortable with selling your work, and get really good at it.

And the impact of that… well, that’s huge.

No more stress, no more awkwardness… and instead, an approach to enrollment that both you and your buyer enjoy.

And, you'll be working to earn a dollar, instead of ten dimes - and that's a lot easier.

Want that?

<a href="https://calendly.com/martinstellar/30-minute-appointment-with-martin-stellar">Then talk to me</a>, and let’s see what we can do.

We'll take 30 minutes on Zoom to see where you're at, and whether the 1on 1  <a href="https://martinstellar.com/helping-good-people-sell-more-and-generate-a-bigger-impact/">LEAP training on ethical selling</a> is right for you.

If it is, we'll take it from there, no pressure.

&nbsp;

Cheers,

Martin

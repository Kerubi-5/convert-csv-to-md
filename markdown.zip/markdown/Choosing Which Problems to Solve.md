---
title: Choosing Which Problems to Solve
status: publish
datePublished: '1579683696'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - Psychology in sales and marketing

---

<img class="alignleft  wp-image-22541" src="http://martinstellar.com/wp-content/uploads/2020/01/MartinStellar_Coaching_Illustrations-Choosing-problems-1024x768.jpeg" alt="" width="351" height="263" />At any given time, there’s a million things you could try to fix, change, or improve in your business - a million different problems you could solve.

But which one are most in need of solving?

Those that are easy to solve often don’t make that much of a difference, whereas the hairy ones are often too complex or time-consuming to tackle.

And yet, the hardest, most complex, most complicated problems tend to make the biggest difference once they get solved… except we avoid it, because they’re so complex.

The solution is to look for the problem behind the problem (similar to the 5-why’s exercise).

If ‘no traffic to my site’ is the problem, an obvious solution would be ‘fix SEO’ or ‘start guest posting’ or ‘start a podcast’.

Or you could ask yourself why you have no traffic to your site, and you realise that behind ‘no traffic’ lies ‘no visibility’, and behind that you might find ‘never made visibility a priority’ and behind that ‘insufficient attention to long-term business sustainability’.

Pretty nice discovery on the heart of the matter, I’d say.

And if you then solve that problem, and you make long-term thinking a priority, you might end up with solutions and actions that don’t just bring traffic, but that make your business healthier in general.

The problems you look at are only the surface.

Dig deeper before trying to solve them.

Cheers,


Martin

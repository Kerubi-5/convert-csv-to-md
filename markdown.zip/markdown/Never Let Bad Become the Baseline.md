---
title: Never Let Bad Become the Baseline
status: publish
datePublished: '1571644741'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft  wp-image-22157" src="http://martinstellar.com/wp-content/uploads/2019/10/MartinStellar_Coaching_Illustrations-When-bad-becomes-the-baseline-1024x768.png" alt="" width="351" height="263" />You may have heard me say it before: any skill or talent is also an achilles’ heel, and vice versa.

An ability to listen deeply can cause you to not speak when the other person needs you to.

Creative skills can work against you if you lean into them so much that you don’t take time to think clearly and you end up making sloppy decisions.

Being open-hearted, compassionate and generous can cause us to take crap from people when that helps neither them or us.

Or, a very common one: being intelligent and well-read often goes together with overthinking things.

And the big one: our innate ability to be gritty, to push on, to keep ourselves together under stress, can be utterly devastating.

When that happens, bad becomes baseline. And I’m beginning to suspect that rather a high percentage of people deal with that.

Examples:

Anxiety is horrible, but once you learn how to deal with it, it becomes less noticeable, and constant states of anxiety become the baseline (something that media play into very cleverly).

Lack of sleep sucks, but you get used to it, and being tired and cranky becomes a baseline.

Depression creeps up but it gets pushed down, and it becomes baseline to feel gloomy or angry about things.

A hateful marriage becomes baseline over time, when we teach ourselves to just suck it up and deal with it.

In all such cases, we accepted something bad, got used to it, got good at dealing with it (read: got good at pretending we don’t notice), and it became the baseline.

I haven’t read any studies and I’m not an expert, but I’m seeing a LOT of people who have a low baseline for things - relationships, free time, money, business results, time spent on hobbies, crappy jobs, a business that runs you versus the other way round - and it hurts me to see it.

So today I want to ask you:

Is there any area in your life, where without you being aware of it, you allowed a bad thing to become a baseline?

And if there is, isn’t it time to raise the baseline back to normal levels?

If yes and yes, and if one of those things is ‘too many sales opportunities are lost’, then that’s something I can help with.

*Especially* if you’re a kind and compassionate person whose work is meant to make things better for others, because heart-centered entrepreneurs are often those who struggle most to create new clients.

(It’s what I call the good-egg problem, where we don’t sell effectively because we don’t want to violate our values).

Enrolling buyers gets easier though, when you let values drive the sales process - and I can show you how.

There are still a few seats available for the pilot launch of my 10-week training on ethical enrollment, so if you’ve been on the fence about joining the programme, let me know.

I’ll send you a calendar link where you can schedule a call with me, and we’ll have a friendly conversation to see if this is the right programme for you, at this point.

Let me know…

Cheers,


Martin

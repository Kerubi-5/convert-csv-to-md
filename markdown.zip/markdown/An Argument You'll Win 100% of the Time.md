---
title: An Argument You'll Win 100% of the Time
status: publish
datePublished: '1594341272'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - Psychology in sales and marketing

---

<a href="http://martinstellar.com/wp-content/uploads/2020/04/MartinStellar_Coaching_Illustrations-Never-argue-for-your-limitations.jpg"><img class="alignleft wp-image-23365" src="http://martinstellar.com/wp-content/uploads/2020/04/MartinStellar_Coaching_Illustrations-Never-argue-for-your-limitations-958x1024.jpg" alt="" width="351" height="375" /></a>“Well”, said my coach: “You’re lucky I’m not buying that story, otherwise you’d really be in trouble”.

And once again, I was confronted with the fact that I was arguing for my own limitations.

Problem is, if you argue for your limitations, you’ll win the argument 100% of the time.

Like a few years ago, when my friend Tone said I should create slideshows and record videos and webinars and stuff.

“But I don’t know design! I can’t be on camera! Learning how to make slides makes me anxious just thinking about it!”

And so for years, I didn’t.

Nowadays though, I create slides on the fly, and deliver trainings left and right, and in fact it’s one of my most fun activities.

But I argued for my limitations, won the argument (of course) and spent years not doing something that’s super fun and super useful for business.

Whenever you’re looking for reasons why you can’t, or shouldn’t, you’re arguing for your own limitations, and when you win, those (usually imaginary) limitations become a fixture.

Limitations are real, we all have them.

But what if you leave them, and argue for potential and possibility instead?

Because for every limitation you may have, you also have an opportunity, or a potential, that you can argue for. Gets you a lot further.

And that’s where coaching comes in - especially the accountability coaching programme I relaunched.

It’s fast and efficient: 20 minutes a week, with a monthly 1-hour deep-dive call - to get you focused on the projects that most move the needle on your business, and to help you hone in on - and execute on! - the activities that get you the biggest results, the most efficient way.

Some of you who have spoken to me know that a regular, full-on coaching programme has a significant price-tag, but not so with accountability coaching.

Instead, I designed the method and process to be as efficient as possible for both of us, so that you can get guidance and keep moving forward, at a price that doesn’t break the bank.

If you want to finally make waves and you’re looking for help to keep you working on what matters most, <a href="https://martinstellar.com/strategic-accountability-coaching/">have a look here.</a>

Cheers,

Martin

&nbsp;

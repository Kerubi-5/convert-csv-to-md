---
title: How Do I Stop Being Ghosted?
status: pending
datePublished: '1657091166'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img class="size-medium wp-image-21899 alignleft" src="https://martinstellar.com/wp-content/uploads/2019/07/MartinStellar_Coaching_Illustrations-Selling-as-service-300x225.jpg" alt="" width="300" height="225" />How do I get my buyer to stop ghosting me, and reply?

It's the wrong question to ask.

It's like asking "how do I get the eggshells out of my omelette?"

How to get them out isn't nearly as useful, as breaking the eggs in such a way that you don't get eggshells in your omelette to begin with.

(Hint: tap the eggs on the countertop, not on the edge of the pan. But I digress)

If you don't want people to ghost you, the question isn't "how do I get them to stop, and reply?

It's: "How do I engage with future buyers in a way that makes them keen and eager to keep communicating with me?"

And the answer to that is simple:

Don't look like a salesperson. Because what's the default attitude to salespeople?

They get ignored.

So, don't pitch. Don't convince, don't persuade, don't try and reason with your buyer.

Instead, be helpful. Make your selling an act of service.

Show interest (in them, not in the deal), listen to them, and ensure that each interaction is useful and helpful.

And no, that does not mean "Give free consulting until they buy".

All it means is "Help them get to a decision, either yes or no".

Start with that attitude and that message, and you'll find you get ghosted far less.

&nbsp;

<hr />

On another note:
I'm building an app that coaches you on working your pipeline, moving your deals forward - and closing them faster and at better rates.
It's called SalesFlow Coach, and we're scheduled for beta-release in June 2022.
Register <a href="https://martinstellar.com/salesflow-coach-launch/">here</a> to be notified when it goes live.

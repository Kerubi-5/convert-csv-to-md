---
title: Excellence, Habits, and Excellent Habits
status: draft
datePublished: '1496836360'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/e4febe7e-fb91-4414-8b3b-77818133e674.png" width="350" height="197" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/e4febe7e-fb91-4414-8b3b-77818133e674.png" data-file-id="4834665" />We are what we repeatedly do. Excellence, then, is not an act, but a habit. ~ Aristotle

Now, I’m not saying Aristotle was the wisest of them all, but if you manage to stay around that long, it’s got to mean something.

And I can attest to the truth of the quote, because the more habits I build, the better things get.

Yet most of us pretend we don’t have any habits, or that we don’t need them.

But you’d be wrong, because we’re all creatures of habit.

Without them, the human race wouldn’t have survived.

You can call the freeze-flight-fight response an evolutionary mechanism and all, but in the end it’s just a habitual reaction that kept us alive.

We’re creatures of habit, all of us.

The difference is that for some, habits are unseen and unnoticed, but they’re there - and for others, habits are something built and refined deliberately.

And it’s the latter category of people that have the easiest, most fruitful, and most successful lives.

Not because I say so, but because that’s always been my experience, and it’s something you’ll see proven when you look into the lives of
successful people.

And you too have habits, even if you think you don’t. Because thinking you don’t and disrupting habits each time you notice them… that’s a habit too.

You have milk in your coffee. You unplug from work at 6pm. You react in a habitual way when someone pushes your buttons. You feel like crap when that relative calls and stomps on your dream. You prefer this route over that one on your way home. You always add salt or you never add salt.

Habits, all over the place, all the time.

So here’s my challenge for you: What if you would get deliberate, systematic, and excellent… at building habits?

What would your life look like if you could effortlessly install new (and fun!) habits into your days?

What level of success or wealth could you reach if only you had habit A or B or C?

And if you think that you can’t get there because you have bad habits that you need to break first… don’t worry.

You don’t need to break bad habits. Forget about that stuff.

Instead, focus on building good ones, and you’ll gradually see them replace the bad ones.

So, which excellent habits would you like to develop?

And, would you want help with that?

Cheers,

​Martin

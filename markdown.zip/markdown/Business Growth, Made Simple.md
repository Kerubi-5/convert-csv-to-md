---
title: Business Growth, Made Simple
status: publish
datePublished: '1577716391'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-22421" src="http://martinstellar.com/wp-content/uploads/2019/12/MartinStellar_Coaching_Illustrations-business-growth-keep-it-simple-1024x768.jpeg" alt="" width="353" height="265" />Ever notice how easy it is to complicate things?

We decide to grow our business, choose an approach and a plan, and before we know it there’s endless todo-lists, multiple areas of attention, several projects simultaneously under development, and a feeling of overwhelm that creeps up on us like thunderclouds on the horizon.

When in reality, growing a business can be very simple, even if that doesn’t mean it’s easy.

That said, the simpler things are, the easier to handle they are.

So if you want to grow your business in 2020, here’s a simple (heh) rule of thumb to guide you:

Create incremental growth in three core areas:

1: More potential clients

Plenty of options to make that happen: Social media posting, speaking gigs, workshops in your area, host webinars, organise an online summit, run FB ads… whatever is easiest (sic) for you in order to increase visibility

2: Higher conversion rates

Lots of people don’t pay attention here, and that’s costly because every potential customer who finds you or contacts you, has incurred a cost in your business - either in terms of time or money. The more people you can enroll, the more efficient your business becomes.

So ask yourself: what can I change in my branding, my site, my activities, my communications, so that more people sign on? (Hint: getting better at enrolling helps here, and my LEAP Ethical Sales Training makes you lots better).

3: Increase value per customer

I’m not saying you should supersize your customers, and unless you’re MacDonald’s I doubt your customers ‘want fries with that’.

But, there’s a good chance that a buyer will want an add-on when they buy from you, or perhaps after working with you, there’s another programme or course that would help them.

Except many business owners wrap up client projects and move on to finding more buyers, which that means you’re leaving money on the table - and it means that you might be underserving your buyers.

Sure, you’re not going to foist an upsell on anyone… but what if you can provide or do something that would delight a current customer, after their first stint with you?

Well, if you don’t offer it, nothing will happen. But if you do offer it, what might happen is that they buy, which brings the total lifetime value of that customer up.

So here’s some questions for you:

Do you think you could generate 10% more potential clients, next year? Can’t be too hard, can it? Only 10%….

And, could you raise your conversion rates by 10%? Probably yes, right?

And then, what if across the board you could raise the average customer lifetime value by 10%… could that be done? Very likely, yes. Again, 10% isn’t that much.

But if you apply the 10% growth across all three areas, you end up with a total of 33% growth for your business, and that’s nothing to sneeze at.

AND it’s something that most businesses can attain, AND it’s a super simple, testable strategy: 10% across three areas... what could be simpler?

So if you want to grow in 2020, do it the smart, simple way. Increase prospects, increase conversion rates, increase customer LTV, go for 10% in each area.

Simple, manageable, and a nice way to stay clear of overwhelm.

Want to chat and work out a few (simple!) ideas to help you grow 10% in each area?

Let me know…

Cheers,

Martin

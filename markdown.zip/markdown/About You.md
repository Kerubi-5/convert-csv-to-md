---
title: About You
status: publish
datePublished: '1561487892'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - How to sell your work
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-21822" src="http://martinstellar.com/wp-content/uploads/2019/06/MartinStellar_Coaching_Illustrations-Ethical-Selling_About-you-1024x768.jpg" alt="" width="346" height="260" />If there’s one thing that nearly everyone in business gets wrong when it comes to marketing and selling, it’s this:

Making it about ourselves.

We tell people about our work, our credentials, our guarantee policy and our T&amp;C and our experience and our success stories…

And your buyers… well, I don’t mean to be harsh, but: they don’t care.

That’s not because they don’t care about you (in fact, if you do sales right, people will actually like you, and thus care about you to some degree), but because a buyer can’t live without asking:

WIIFM?

What’s In It For Me?

If I spend this money, what will I get out of it?

What will my results be?

How will my life change, my business grow, my relationship evolve, my back feel, my team collaborate, my golf game improve?

In other words: a buyer has no choice but to look out for themselves.

Everybody needs to preserve their well-being: it’s a biological and evolutionary imperative.

Problems arise when the ‘for you’ message gets buried under ‘about me’ messaging.

That’s when a buyer fails to feel that what you’re offering really will help solve their problem, and when they don’t feel that, they don’t buy.

You want people to care about what you do, and what you could do for them?

Then talk to them about them - their fears, frustrations, their wants and aspirations.

&nbsp;

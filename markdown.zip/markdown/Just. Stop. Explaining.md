---
title: Just. Stop. Explaining
status: publish
datePublished: '1498047147'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

Ever wondered what makes people buy?

			It’s not because of a desire to own.

			Not because of disposable income.

			Status isn’t it nor is adding value to their lives.

			People don’t buy because of persuasion or a good sales pitch.

			People don’t buy in order to invest, or to feel good about themselves, or because it
			makes them happy.

			All those things, and many more, are part of the reasons, but none of them are at the
			core.

			The real, ultimate reason to buy, the one cause that’s at the root of all other reasons,
			is simple.

			People buy things because they feel understood.

			When a vendor - of anything - manages to make a person *feel* that their problem is
			understood and will be solved by proceeding to checkout, that’s when a sale happens.

			And this is why a salesperson who listens more than he or she talks will have far easier
			time finding buyers who convert.

			So if your sales aren’t happening, ask yourself:

			Are you explaining - are you making yourself understood?

			Or are you making your prospect feel understood.

			If the former is the case, maybe change tack.

			More explaining won’t make a buyer feel understood.

			But more listening just might. Probably will.

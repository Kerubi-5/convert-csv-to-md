---
title: 'Careful: Don''t Major in Minor Things'
status: publish
datePublished: '1661152722'
categories:
  - Doing it right as an entrepreneur or creative professional
  - How to sell your work

---

<img class="alignleft wp-image-21960" src="http://martinstellar.com/wp-content/uploads/2019/08/MartinStellar_Coaching_Illustrations-Dont-major-in-minor-things-1024x768.jpg" alt="" width="348" height="261" />
<div>

Whatever it is you want to achieve, improving your knowledge and skills are a great way to make it happen faster and with more ease.

</div>
<div>

But are you sure you're not majoring in minor things?

</div>
<div>

Yes, it’s useful to learn the ins and outs of managing your website, but once your site is ready, how much will it add to your bottom line that you are now a Wordpress ninja?

</div>
<div>

Taking a course in how to use social media for your business: useful if you want to increase visibility.

</div>
<div>

But if your goal is "more sales", then getting better at being visible is a fairly minor part of it. Much more useful to learn how to turn more sales conversations into actual sales.

</div>
<div>

Or consider design: Sure, having design skills is useful - but why learn it, if you can hire a designer?

</div>
<div>

The question to ask yourself is: that thing you're looking to learn and improve, is that worth it? Is it the most useful, the most leveraged, the biggest driver of impact and revenue?

</div>
<div>

Is that thing so important, that it makes sense to reach expert level, whilst the skills that bring in sales remain underdeveloped?

</div>
<div>

You only have so many hours in a day, so it’s wise to think about what you work to improve.

</div>
<div>

And that's where we often make mistakes:

</div>
<div>

We develop or improve things that we're bad at, or mediocre at best

</div>
<div>

But in many cases, it’s a lot better to leave some of those things as is, and instead spend our time on things that we’re already pretty good at.

</div>
<div>

For example: A few years ago I sang in a local band, and I played rhythm guitar too. As far as the guitar goes, I'm somewhere between capable and decent. Nothing special. Now I could spend a lot of time upping my guitar game, and it would be useful. But, it would steal time from my vocal training, and I'll never be as awesomely terrific as our lead guitarist Phil, anyway. So becoming GOOD at playing the guitar would mean I'm majoring in something minor. Meanwhile, I'm the lead singer - so I'd better get as good as I can at singing, develop that skill, and leave the guitar-y awesomeness to Phil.

</div>
<div>

It’s all about efficiency.

</div>
<div>

To go from zero or sub-par skills, to reasonable ability, can take a long time and a lot of hard work. And you’ll still be only reasonably skilled.

</div>
<div>

But to go from ‘pretty good at this’ to expert level is often a lot easier to achieve. AND you’ll end up being highly skilled in it, which beats ‘reasonably skilled’ any day of the week.

</div>
<div>

Besides, if your modus is to constantly develop skills you don’t have or that you suck at, you’ll end up what they call ‘a bag of highly developed shortcomings’.

</div>
<div>

Again, it’s not bad to learn things. By all means, make learning and training part of your world.

</div>
<div>

The question is though: what is the one thing that you do fairly well, and that if you dedicate yourself to it, you could do terrifically well?

</div>
<div>

What <em>major</em> things should you major in?

&nbsp;

</div>

<hr />

&nbsp;

On another note:
I'm building an app that coaches you on working your pipeline, moving your deals forward - and closing them faster and at better rates.
It's called SalesFlow Coach, and we're scheduled for beta-release in June 2022.
Register <a href="https://martinstellar.com/salesflow-coach-launch/">here</a> to be notified when it goes live.

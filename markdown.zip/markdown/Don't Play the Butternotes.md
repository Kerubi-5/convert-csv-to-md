---
title: Don't Play the Butternotes
status: publish
datePublished: '1526488222'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - How to sell your work
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/bc052ced-0f36-437c-9995-ab2df9718730.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/bc052ced-0f36-437c-9995-ab2df9718730.png" data-file-id="4835725" />Once upon a time, Herbie Hancock was on stage, playing with Miles Davis.

And he wasn’t feeling it. Herbie was not a happy bunny. Everything he was playing sounded trite, old, familiar, and uninspired.

He got increasingly frustrated with himself, which Miles picked up on. (Obviously).

Walks over to Herbie, leans in, and rasps in his ear: “Don’t play the butternotes”.

Took a moment, but then Herbie got it: the butternotes, those are the easy, the familiar, the standard and the bits that go down smoothly.

In music, those would be the 3rd, 5th, and 7th of a scale.

Herbie stopped playing those notes, started to play around them, and everything shifted. So much so, in fact, that it changed the course of Herbie’s musical career.

Playing the butternotes… what a brilliant concept!

In business, the parallel to playing butternotes would be things like phoning it in.

Coasting. Pushing the buttons, keeping the show on the road. Business butternotes are the attitudes and activities that are in your comfort zone, that don’t stretch you, that don’t do anything to create growth.

For me, playing butternotes is doing things like staying on top of my inbox. Publishing my daily article. Having chats with entrepreneurs. Good stuff and necessary, but not the kind of thing that drives growth. Which is what I (you too?) ultimately want.

And so, I study lots. I push myself. I get on a stage with barely any experience behind me, to deliver a 3 hour masterclass on marketing.

Sure I play the butternotes, but I do the other stuff as well.

So what about you?

Are you playing butternotes, too much?

And if so, what ‘wildly creative and jazzy solo-notes’ would you like to be playing as well?

When you’re not ‘phoning it in’, what actually is your greatest, most high-leverage activity?

And what if you’d make it a priority in your days or weeks, to work on it?

&nbsp;

---
title: Laying Down the Law... No Need to Bark
status: draft
datePublished: '1510046905'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/6effd76b-0057-469f-8e11-f71056c8769d.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/6effd76b-0057-469f-8e11-f71056c8769d.jpg" data-file-id="4835177" />Yesterday, a client and I spoke about aggression, and how speaking up and taking a stance doesn’t require any aggression or shouting.

Put differently: it’s not about who barks the loudest.

Instead, it’s about being clear and unequivocal. It’s about ‘laying down the law’.

Two stories from my life to illustrate that.

First, I take you back 3,5 decades.

In those days, I used to get bullied every day. And I’d grown stoic, thick-skinned. Whatever they did or said, I had learned to just not give a damn.

Until one day, when the top bully in school decided it would be fun to not just insult me, but my mother as well.

And, that was a step too far.

I walked up to him, grabbed his shirt, and while gently bumping him up against the wall, calmly told him: “You do NOT talk about my mother”.

This kid was a head taller than me, but he was petrified. And the whole class stared at us, agape.

He never mentioned my mother again, and it was from that day that the bullying started to stop, and fast too.

And I never even had to bark at him. I just laid down the law.

Another example: back when my tailoring company was floundering, I found a biz consultant in the States, and I REALLY wanted his help.

But I didn’t have the money, so I sent him a request to give me consulting, in return for a handmade suit.

He replied that he had no need for a "homemade" suit, but thanks just the same.

Oh well. Doesn’t hurt to try.

I thanked him for his reply, but stopped to point out that - while I know he doesn't need one - it's a handmade suit. Not a homemade one.

And the difference is BIG.

The guy decided to check out my website, saw that I wasn’t a home-stitcher but an actual bespoke tailor, and wrote back:

"Dude! I had no idea! I still don't need a suit, but seeing you're a real goddam tailor - I want one. How do we make this work?"

Again, no barking required. Just calmly explaining.

Very often, we default to reactions that are far stronger, far more aggressive, than needed.

Be it because of a defense mechanism that gets triggered, or because we feel threatened, or because we’ve always been used to being forceful… in many situations you’ll get better results from calmly stating your case.

Taking your stance, but in a way that displays power, but without exerting any.

And that’s the big problem with being forceful: yes you put more weight behind your words, but it actually makes you look weaker.

Real strength is perceived when you show that you have no need to show it.

Calm, understated confidence. Goes a long way. And if you don’t believe me, just remember how hard it can be to stop a bully.

And while it’s often said that the only way to deal with a bully is to bully him, my experience shows that isn’t true.

So… in what ways do you react by default, give it more force, use passive aggression… when really you don’t need to?

Cheers,

​Martin

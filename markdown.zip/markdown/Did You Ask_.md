---
title: Did You Ask?
status: publish
datePublished: '1488530735'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

I hear this a lot:

"I don’t know how to get people onto my email list."

Which is a problem, because a list is the most important asset your business has, when it comes to finding buyers.

And you’ve got to always be growing it.

So how DO you get people onto your list?

Well, one thing you could do is ask.

In person: when you’re at a meeting, a party, a show, or you strike up a random chat with someone...

If they are interested in you and your work, why not just ask?

“Hey, I write daily emails about these things. They’re fun, short, and inspiring. Want to receive them?”

On your printed materials: all it takes is a short line similar to the above, plus a link to your signup page.

Or on your website, when new visitors land: whether you use an optin form, or a popup, or SumoMe, or Hellobar or whatever tool you prefer:

Tell people about your emails, and ask.

And here’s the most important piece of advice, for whenever you ask:

Answer the ‘what’s in it for me?’ question.

Before people make a decision to sign up, they want to know what value you’ll deliver.

Alright, that’s all for today.

I need to get up to Guadix for a press event. I’m liking this PR thing, these days. Even got a full-page interview in the paper last Tuesday.

Hey, and if you want my help on things like growing your list, getting exposure, becoming more visible, and ultimately growing your business:

Just ask.

&nbsp;

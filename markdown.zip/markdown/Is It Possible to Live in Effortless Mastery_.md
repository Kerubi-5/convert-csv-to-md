---
title: Is It Possible to Live in Effortless Mastery?
status: draft
datePublished: '1530006003'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/5f1a5f87-a9fa-4aed-ad00-5c8b0454d0a4.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/5f1a5f87-a9fa-4aed-ad00-5c8b0454d0a4.png" data-file-id="4835861" />If you ask me, then it’s a resounding yes. Effortless mastery is pretty much the mode of my life these days.

Which doesn’t mean I do everything right - falling with a bike and breaking a rib might be an effortless thing to do, but masterful it is not - but it does mean that whatever befalls me don’t bother me none.

Example: inside of one week, three disappointments were thrown at me:

First, I realised that work obligations would very likely prevent me from travelling to Holland this week, for the last chance to see my lifetime musical heroes perform.

Then, I had that accident and broke a rib - making it 100% certain I’m not going to Holland.

And then to put a cherry on top, I lost my wallet.

I can remember a time when this would have sent me into a tailspin of ‘life sucks’, ‘why me’, and ‘this damn world is out to hurt me' kinda narrative.

These days though? I take it in stride. One door closes, another opens, one thing ends and another starts.

That doesn’t mean I’m happy about setbacks, they just don’t set ME back.

This is what I call living with effortless mastery.

And I want to know what you think of the following, a new training course I’ve created.

It’s called: The Stellar Edge: get an unfair advantage in business and life.

This is what’s in the tin:

TSE shows you how to think and decide like a CEO, in order to get you better results.

The program instills in you an ability to create flow in life and business.

The result: you end up in control of life, and increasingly live with effortless mastery.

That there is the USP, and the promise the programme makes.

What do you think, is that - control, flow, and effortless mastery - something you’d want in your life?

If so, register here for the free TSE webinar: http://martinstellar.com/the-stellar-edge

Cheers,

Martin

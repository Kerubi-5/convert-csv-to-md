---
title: How to Stop Worrying and Learn to Love 'the Close'
status: publish
datePublished: '1606437307'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - How to sell your work
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/ff8f4ae9-980e-41a6-b8a6-d36fe2019f24.jpg" width="350" height="367" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/ff8f4ae9-980e-41a6-b8a6-d36fe2019f24.jpg" data-file-id="4834893" />What's your biggest obstacle, where it comes to enroll buyers in your work?

The question often brings interesting answers:

Some people say it’s finding buyers in a down economy, others say it’s their own penchant for procrastination, and yet other say it’s identifying their ideal buyer in the first place.

And the other day someone said their biggest struggle was 'the close'.

You know, the point where someone commits to giving you money for your work.

Personally, I don’t like the term. Sure you close a deal, but I much prefer to think of it as a starting point instead.

You open a buyer relationship with your client. Much nicer than ‘closing them’. No?

This isn’t just semantics, either.

Think about it: when someone wants to buy from you, they’re buying into your world.

They enroll in what you offer, and the premise that paying for it is worth it.

Someone who buys from you enrolls into your world.

And that makes all the difference, because all of a sudden it’s not longer about you wanting the other person to buy something.

It’s become a matter of them wanting to own what you have.

So instead of an outward ‘buy this’ push, ‘the close’ is about extending an invitation.

Which the other is, of course, free to accept or not.

A lot of salespeople know this, and use it to create successful and satisfying business relationships.

But there’s also a ton of marketeers and sellers who move beyond the social nature of selling, and who make it into a sort of ‘buy this or the puppy gets it’ transaction.

Which has given sales a bad reputation, but more dangerously: it has caused quite a few ethical providers of high quality goods and services to dislike ‘the close’.

And so, I often hear people say “I don’t like selling. I’m just not good at it”.

If by that you mean the notoriously unethical ‘ram it down their throats’ sales process, then good on you. Nobody should like that kind of selling, or indeed practice it.

But if you’re not like that, and you care about solving problems for your buyers…

I would suggest you switch your view on selling to having someone enroll in buying the solution you offer.

Because that way it becomes a lot more fun, and a lot easier too.

Want some personal, 1 on 1 help with that?

Then the 10-week 1 on 1 personal training on ethical selling that I built will radically improve your results, like my client Mairi tweeted, the other day:

<img class="alignnone wp-image-26019 size-full" src="http://martinstellar.com/wp-content/uploads/2019/07/Testimonial-Tweet-Mairi-1.png" alt="" width="748" height="264" />

For more info on that training, <a href="http://martinstellar.com/helping-good-people-sell-more-and-generate-a-bigger-impact/">have a look here...</a>

<span style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen-Sans, Ubuntu, Cantarell, 'Helvetica Neue', sans-serif;">Cheers,</span>

Martin

---
title: Did You Buy the Story?
status: publish
datePublished: '1509535203'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - How to sell your work
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/6ac7cd2f-1321-4632-825b-2fdf7ef30354.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/6ac7cd2f-1321-4632-825b-2fdf7ef30354.jpg" data-file-id="4835165" />All of us, we tell ourselves stories. And, we buy into them. We believe the stories we tell ourselves.

And some of those are not at all helpful. Allow me to explain:

Right now, I’m preparing a series of talks that I’ll be giving in Malaga soon.

It’s part of a project I’m running with my friend and business partner Antonio, who runs a co-working office, which is the place where I go on Thursdays.

Anyway, the talks will be around the subject of sales - something we all need in business, but at the same time, there’s a bunch of misconceptions.

So let’s play dispel-the-myth for a moment, shall we?
Myth #1:

<strong>Selling isn’t ethical</strong>

Oh I don’t know. A hammer is as harmful as the person wielding it. Likewise, sales are exactly as ethical as the business person conducting a sales process. So long as your primary interest is the customer’s well-being, and your mission is to have them make the best possible decision (including if that means not buying, and you accept that gracefully) you’ll be fine and perfectly ethical.

Myth #2:
<strong>
"Sales require being pushy"</strong>

Hey now… the fact that too many companies use aggressive sales techniques doesn’t mean that it’s the only way to go. And in fact, a non-pushy, conversation-based sales process is quite effective. Equally effective, maybe even more so, as the pushy kind. See Myth #1 and the bit about “it’s about them, not you”.

Myth #3:

<strong>“People these days are smart and informed. They make up their own minds to buy, I don’t need to sell.”</strong>

Let me know how that works out for you. Even though the first part - people are (generally) smart and informed - is true, that doesn’t mean you wouldn’t do them a favour by being active in the process.

It’s a fact that people take more action the more you prompt them, and if your product or service really delivers and improves things for the buyer, your being with them as a trusted advisor, and guiding them to the best decision is effectively an act of service.

But if you leave it up to the buyer to decide what to choose and when, they might get distracted by life etc, and never take action. Which means they wouldn’t benefit from what you sell.

And worse: they might end up buying from a competitor whose work isn’t as good as yours, but whose marketing is more effective. That would be a disservice to your prospect.

Myth #4:
<strong>“Selling isn’t required if the product is good”</strong>

Ha! Pardon me while I laugh my head off. I have a misspent $150K inheritance saying this isn’t just a myth, but a full-blown fallacy-cum-sophism, with a side of delusion, wrapped in speciousness. Add foolishness, makes its own sauce.

See, I used to make suits, by hand, that would fetch $3K, and people were more than happy to pay the price. They were that good. But I believed in the myth that quality sells itself and so I did almost no marketing.

Consequently, I went bankrupt and I had to close my tailoring company.

Quality may, in some cases, sell itself. But if you don’t get out there, show up, and invite people to buy, the odds are high that it won’t work. Very very very high. Don’t make the mistake I did, but learn (ethical and fun) marketing and selling before it’s too late.

Myth #5:
<strong>“I’m just no good at selling”</strong>

This might be true on the level of business agreements and actual sales (and you can learn to improve in those areas), but on the level of being human, it’s outright false.

You sell all the time, every day, we all do.

We sell our spouse on getting milk on the way home. Sell our kids on eating their greens. Sell our colleague on helping out with a project. We sell someone on an idea we’d like them to consider. We sell a friend on spending some time together instead of each lounging on the sofa watching Netflix at home.

But here is where it gets interesting: we also sell ourselves on the idea that we’re no good at selling - and we buy into that story! How’s that for disproving that you’re not good at selling!

Food for thought methinks.

&nbsp;

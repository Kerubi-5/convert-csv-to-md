---
title: >-
  How to Ethically and Legally Use Other People's Content to Build Yourself and
  Audience
status: draft
datePublished: '1597910246'
categories:
  - How to sell your work
  - Psychology in sales and marketing

---

These days, ‘content marketing’ is all he rage.

The idea being that you create materials that first entertain or teach, and secondly inform a prospect on why or why not to buy something.

Which is a good strategy, but now that the whole world and their hamster have a blog/Tumblr/Pinterest/Instagram, it’s becoming hard to stand out from the crowd.

Enter the term ‘content shock’ - where there is just too much, a tsunami of fresh content coming at us every hour.

How on earth do you set yourself apart from all the others?

It’s pretty simple, actually.

Hugh MacLeod famously said: “Don’t stand out from the crowd - avoid crowds altogether”.

Now, what’s the kind of person most apart from crowds?

The leader, of course.

So, why not become a thought-leader?

That way, people don’t just look to you for your art, but for the intellectual and social value that you bring them.

And, it’s not actually very difficult.

The trick is to use other people’s work.

And yes, that’s legal, and yes it’s ethical.

In fact, you do people a favour, if you do it right.

Not by stealing their content or plagiarising things.

No, the trick is content curation.

Meaning: you hunt for the kind of content that your ideal audience finds relevant and interesting, and you relentlessly provide that to them.

Everybody wins: the creator gets shared, you build an audience, and your audience gets fed information they care for.

Think about it: Someone who is incredibly well-read and therefore has answers to all kinds of questions and problems: that’s someone you’d value, right?

So, why not become that person?

These days, content curation is one of the easiest, most fun ways to build an audience of fans.

And it’s not just me saying so:

Copyblogger - not exactly a stupid bunch - released a new website platform with all kinds of bells, whistles and kitchen sinks built in, and guess what’s the driving force for driving traffic and building a list of email subscribers?

Content curation.

Whether you use Twitter, Facebook, Instagram or you just blog, becoming a source of exactly the information that your audience is hungry for works like a charm.

Sure does for me: my Twitter following grows every day that I send out new links. And so can yours.

So in the next LEAP, I’ll explain exactly how to listen to your audience to find out what they want, and how to make the process of content curation as easy as 30 minutes a day.

Sign up here --&gt; http://martinstellar.com/leap-to-more-sales/

Cheers,

Martin

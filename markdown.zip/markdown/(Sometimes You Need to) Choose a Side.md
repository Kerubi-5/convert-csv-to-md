---
title: (Sometimes You Need to) Choose a Side
status: draft
datePublished: '1508926967'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/392d071c-6158-4ddd-9e9a-83597da1cf15.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/392d071c-6158-4ddd-9e9a-83597da1cf15.jpg" data-file-id="4835133" />There’s an interesting phenomenon here in Spain - or at least, in the Andalusia area where I live.

And it’s a phenonemon that clearly spells the difference between who will go places, and those who will very likely stay stuck.

The difference is in accepting the status quo. Settling for. Resigning to what is.

When the economy started to fall a few years ago, I was amazed to see how flat so many people were.

Flat as in: resigned, overcome, powerless.

“Well of course business is bad. The economy is in the tank. We just have to wait for it to fix itself again. It always does”.

And yes, in the end there’s always ups and downs. A downturn never lasts.

But why on earth would you just resign to it and wait?

Don’t these people know that if a) you make smart decisions and b) you take massive action, you can actually solve problems?

In a sense, it’s one of the charms of the culture here: a non-stressed, accepting, why-bother-getting-mad attitude.

It’s one of the reasons I like this area so much. It’s free of pretence and there’s tons of genuinely wonderful people here.

But many of those people are still in trouble. Many companies are closing down. Houses and cars get repossessed.

And the only thing people in those situations need, is a simple shift in thinking.

A shift to “Yes, I can take action to fix this”, instead of “It’s an external problem, I need to wait”.

This difference, between those who resign and those who get busy, is important.

And you get to choose which side you’re on.

Me, I know where I stand. I’m the kind who takes action.

And this is why when selecting who I should or shouldn’t work with, I look for the markers.

Is this person switched on? Taking action? Looking for ways out, or forward? Willing to discard dysfunctional self-talk?

Because unless someone fits that kind of profile, I can’t coach them.

Coaching isn’t magic, and even the best coach in the world couldn’t help someone who isn’t coachable.

Maybe there’s no difference between Andalusia and other parts of the world, where it comes to the percentage of people who believe that patience is the only solution.

Even so, I’ve given up trying to tell others that yes, there is a way out.

Someone who is stuck in that kind of thinking isn’t going to listen to reason.

The only thing that can possibly help, is to lead by example.

Because when you try to explain and convince, you’re battling somebody else’s reason. And reason is smart, it will always find a way to argue its way to being right.

Much better to simply show what can be done - because you can’t argue with results.

But, maybe you don’t need no convincing. Maybe you already know that smart decisions and massive action will work.

If that’s the case for you and you want to be sure you make the right decisions and take the right actions, that’s when you talk to a coach. Hello.

Just reach out if ‘n when you’re ready.

Cheers,

​Martin

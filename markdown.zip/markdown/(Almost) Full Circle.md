---
title: (Almost) Full Circle
status: draft
datePublished: '1504003461'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/30e955a2-1552-423e-88c5-13fbb21ccd9e.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/30e955a2-1552-423e-88c5-13fbb21ccd9e.jpg" data-file-id="4834961" />Back when I was a youngster, I didn’t really know what to do with my life.

I had talents and interests, but aside from playing the guitar, I didn’t have any goals.

So my parents set me up with a batch of personality tests, to try and find out what would make the perfect job for me.

The results were interesting: based on my interests and skills, I would apparently be best suited to become one of two things.

The first suggestion: air traffic controller.

I still don’t know how the hell they came up with that, because while I perform fairly well under stress and I like technology and communications,
guiding planes in and out of airports was… a stretch, to say the least.

But the second career option blew me away even more:

Apparently, I was the perfect candidate to become… a museum curator!

I laughed my head off, because back in those days, I had no feeling, no interest, and basically no appreciation for art. Just didn’t feature in my world.

Music was art to me, and that was all the art that I needed. So obviously, curating art for a museum was one of the most boring prospects you could have given me.

But somehow, the test was smarter than I thought, because right this moment, I find myself organising an international art exhibition.

Not exactly a museum curator, but still… scarily close, isn’t it?

Funny how things can end up (almost) full circle.

Anyway: this exhibition we’re setting up, is the result of a year working with a small group of artists, who are all part of my Cabal coaching group.

The show starts on September 15th, here in Andalusia.

And while you might think that putting on a show, while these artists visit Spain for a retreat with me is the end of it, it’s just the beginning.

This Cabal group may be small, but it’s very powerful.

And once the retreat is over and fall sets it, we’ll be opening up our community.

Because the process we’ve been through this last year (‘we’ meaning my clients but my own process too) is something very strong, and very life-changing.

And we want to have this experience available to others (you?) as well.

Why?

Because together we strive to build, maintain, and grow Collective Forward Momentum.

And each week I see what this does for my clients, and I’d love nothing more than for others to be part of that movement.

So stay tuned. Good things are afoot.

Meanwhile, I’m off to create drawings to hang at the show.

Cheers,

​Martin

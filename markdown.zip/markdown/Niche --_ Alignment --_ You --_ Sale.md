---
title: Niche --> Alignment --> You --> Sale
status: publish
datePublished: '1599697153'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing
  - Relationships

---

<img class="alignleft wp-image-22234" src="http://martinstellar.com/wp-content/uploads/2019/11/MartinStellar_Coaching_Illustrations-values_niche_alignment-1024x768.png" alt="" width="347" height="260" />You can get all marketing-technical when it comes to finding the right niche for your work - and it’s useful, if only for the ‘huh, they made that for me!’ reaction people have when you get your niche right - but it’s easy to forget that a niche consists of people.

So who are the best people to talk to? Who are your most likely buyers? What are they like? What do they care about? What do they need to hear, in order to care about my thing?

Questions like these are what an entrepreneur's business - or nightmares, depending where you're at - are filled with.

And nope, it’ll never get easier, you’ll always have to re-think and re-adjust, as your business and your person evolve.

Here’s three questions though, that may help you shift your thinking:

1: What values would I love to see in my buyers?

The trick here, is to look for shared values. When you have the same brand of ethics, integrity, morality and values as a potential buyer, you’re more likely to get along - to have rapport, even before the first meeting.

This bit is a must-have: shared values are what make selling SO much easier.

2: What would you take a stand for, and what would your ideal buyer take a stand for?

This contemplation isn’t about must-have, but rather: nice-to-have.

Perhaps you’d take a stand for equality, but John Prospect might be all over workplace health and fair treatment. John and you don’t need to take a stand on the same things - so long as they are similar enough for you two to have overlap in terms of purpose and mission.

That helps you align, helps you two move forward together - which hopefully will include moving forward in a professional (i.e. paid) relationship.

3: What drives you up the wall, and what about them?

In your ideal buyer… what are the kind of things that they loathe, resent, would never stoop to, condemn, or remove from their life?

And what about you… what kind of thing really gets your goat, makes you angry, is unjust, should stop or change - what would you stand up against?

The overlap of what you and the other consider as ‘this is wrong, it should change’ is where you have a shared drive, an energy: a motivation to make stuff happen.

Again, these are nice-to-haves in terms of matching - not specific hard items like the values in point 1.

How to make this work:

Do some journaling, make lists, map things out. Be exhaustive and brainstorm-y.

In the center of the Venn diagram, start jotting down aspects and qualities about your ideal client - the kind of <em>person</em> inside of your niche that might be in the market for your work - AND they’ll have so much in common with you, you could have been friends for years.

None of this guarantees a sale - but it’s a damn fine way to find people you can move forward with, in some way or other.

And because you’ll have so much common ground, the chances of them buying go up enormously.

Every day I help entrepreneurs - coaches, trainers, consultants, designers, authors - land more clients, by getting real specific about identifying, and finding, the people they love working with and who are ready to buy.

And yes, my clients and I have things in common: we agree that truthfulness, integrity and justness are inviolable values.

We both take a stand for doing right by people, and using commerce as a way to improve things - and we don’t abide things like racism, bigotry or divisiveness.

So if you’re like that too and you’re ready to convert more opportunities into sales and stop losing so many opportunities, I can help with that.

<a href="mailto:hello@martinstellar.com?subject=I'm%20ready%2C%20let's%20talk!">Ready?</a>

Cheers,

Martin

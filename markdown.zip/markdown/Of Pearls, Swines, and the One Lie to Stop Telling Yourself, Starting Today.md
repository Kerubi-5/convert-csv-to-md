---
title: Of Pearls, Swines, and the One Lie to Stop Telling Yourself, Starting Today
status: draft
datePublished: '1488276784'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

What do you believe in?

What do you hold to be true?

I’m not talking about religion, but about what you believe to be true about the world.

Because there’s one lie that I keep hearing over and over again, and I highly recommend you get rid of it.

“People just don’t pay that kind of money”.

It’s not true, and you shouldn’t believe it.

Because whatever you make and whatever you get paid for it these days, I’m sure you consider it to be worth more, right?

But if that’s what you believe, and you also believe people won’t pay you more, guess what will happen?

You’ll find ‘proof’ of that ‘truth’ over and over again.

Oh but you’ve tried it!

You’ve shown your work to people, and they tell you you’re asking too much!

Happens to me too.

And each time I get that reaction, I know this:

I’m showing pearls to swines.

I’m presenting something very valuable (my work) to someone who isn’t able to appreciate its value, or who isn’t prepared to invest in themselves.

Don’t try to put pearls before swines.

Because no matter how much you want to earn, there’s people out there who’ll pay you that much for it.

It’s just a matter of accepting that, and making it your mission to a) find those people and b) ignore everybody else.

I was contemplating this topic, whether I should write it.

And then I saw an article this morning, saying that two people have made a very sizeable downpayment to SpaceX (many millions, I imagine), so that they can be space-tourists in 2020, and fly around the moon.

Who says people don’t spend good money, hm?

They’re out there, and they’ll be happy to meet you and pay you.

But only if you make the effort, and learn the smarts, you need to find them.

And if you want help with the effort or the smarts, let me know and we’ll see if I can help.

&nbsp;

---
title: Force vs Power
status: draft
datePublished: '1548334002'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21324" src="http://martinstellar.com/wp-content/uploads/2019/01/MartinStellar_Coaching_Illustrations-Force-vs-Power-1024x768.png" alt="" width="348" height="261" />You’ve got dozens, maybe hundreds of different strengths and traits you can lean into in order to create results.

Resilience, resourcefulness, creativity, exploration and execution - too many to list.

In many cases though, our default is force.

Push harder. Explain again, but better, and louder. Beat yourself into action. Persist no matter the clear ineffectiveness.

Sounds tiring, if you ask me.

I prefer operating from an attitude of power, rather than force.

Using force means you have to exert yourself; it comes with a high cost.

But power?

That feeds you. It’s a practically unlimited source of strength inside.

All you need to do is stop forcing things, center yourself on where your strengths lie, and allow yourself to be pulled forward by your internal, psychological power.

It’s a lot more effortless, and don’t we all want things to be easier, lighter, and not so damn hard all the time?

Exactly.

Here’s how to know when you’re forcing it instead of relying on your power:

Resistance.

When someone resists you, or when the task seems to push back against you, or when something just keeps breaking no matter how hard you try to make it work, you’re very likely trying to force something.

When you notice resistance (including resistance in yourself), ask yourself what it is you’re trying to force.

Next, identify which of your innate, natural abilities can be leveraged in order to create the result you’ve been trying to force, and use that instead.

With a bit of practice, you’ll make power the default, and you’ll meet a lot less resistance and frustration in your projects and relationships.

A simple shift in orientation, with a dramatic effect on your mastery in business and life.

Give it a try, let me know what changes you discover.

Cheers,

Martin

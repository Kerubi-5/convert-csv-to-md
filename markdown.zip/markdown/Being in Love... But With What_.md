---
title: Being in Love... But With What?
status: draft
datePublished: '1519405354'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/_compresseds/2098fef6-5691-4cff-bc2a-ad0ee2ae643f.jpg" width="350" height="466" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/_compresseds/2098fef6-5691-4cff-bc2a-ad0ee2ae643f.jpg" data-file-id="4835485" />I’ve spent a great deal of time contemplating love, recently.

Not the interpersonal human love, but Love as a deeper, higher, divine, or transcendent concept.

And I realised that I’m in love with the wrong thing. (Bear with me - this article will help you with your business).

See, I wonder why I have so little patience lately. It’s unlike me.

These drawings I do, it’s almost as if I can’t bear spending time on them.

(Aside from the drawings you see daily and which I make on my iPad, I also draw with ink on paper, and it’s especially clear there: no patience).

Part of the reason is that I really like Japanese art, where something like three strokes can depict an entire personality.

And yes, I know that the only way to get to that kind of skill is if you spend years (or rather: decades) practicing.

And the strange thing is that I respect that, and that I’m able to work like that.

For instance, back when I was a tailor. Never mind the many years of learning - even when that phase was done, I still had to apply ridiculous amounts of patience, every time I made a suit.

80 hours of work for a two-piece. At a minimum.

And 80% of that time, sewing by hand.

Some 400 tiny hand stitches, for each side of the chestpiece that lines and shapes the outer shell cloth - and that’s just on the inside. Another 500 or more for the outside and finishing. On each side, left and right.

A double-breasted suit can have up to 6 buttonholes in the front, plus 4 on each sleeve. Each one done by hand, placing stitches less than a millimeter apart. An hour for each one, more than an entire day of making buttonholes. That picture? Less than half of the inside of one lapel, all stitches done by hand.

In other words:

Patience? I’ve got it - in spades, buckets, and wheelbarrows.

But when it comes tot drawing? I want it done, done now, done fast.

And as I write this, something is becoming clear to me:

I’m in love with the result, but not with the process.

As a tailor, I loved - absolutely adored - the process. Seeing the progression of the stitches lining up, noticing the irregularity, seeing the exact moment where I got up to pour some coffee, because there’s this tiny skip in the line at that point.

I loved seeing all the hundreds of individual pieces come together, seeing the 2-dimensional pieces turn themselves into 3-D.

But with drawing? I’m not there. Not yet.

The lesson here?

The end result is nice. It’s good to love it. It’s the goal you’re trying to reach.

But if you don’t also love the process, you’re missing out. If you don’t love (which is not the same as enjoying - the one can exist without the other) the process, you’re frustrating, and maybe even sabotaging, yourself.

Because by only loving the end result, you’re robbing yourself of falling in love with the process.

Why this matters to you?

Because your business result (the recognition, the money in the bank, the thrilled clients who paid you a high fee and so on) are a beautiful goal and something to love.

But if you don’t also love the process of building up to that, you’re letting your impatience take the fun out of it.

And where’s the fun in that?

So I’m going back to the basics: I’m going to practice doing the work in drawing, for love of the process. Forgetting about the result while I’m at it.

What about you and your business… what about being in love with the process, regardless of the results?

Cheers,

​Martin

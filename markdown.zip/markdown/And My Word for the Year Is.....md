---
title: And My Word for the Year Is....
status: draft
datePublished: '1484557151'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

... actually not a word, but a phrase.

			The other day I had a skype call with my wonderful friend, the artist and coach Jessica
			Serran.

			And she asked me what my word for the year was.

			After a moment’s pause, I said: “Let’s take it to the stage”.

			Because really, I’m done playing small.

			I never thought I had grand things to share, but over the years - working with artists
			and authors and all kinds of entrepreneurs - it’s been made clear to me that whatever
			message I do have to share,
			needs to get out into the world.

			And working like this, with a small list and a handful of wonderful clients - well, that
			just isn’t big enough.

			Besides: Aren’t I the one who always tells you to dream big, that the bigger and more
			audacious your goal, the better?

			Right.

			So I’m stepping up to the plate.

			First, I’m writing a book.

			Not another ebook either: here we’re talking about a physical book.

			And not self-published, but published by an official publisher.

			I am SO excited. He accepted my book proposal in the 1st of January, I have the outline
			basically done, and this week I’m going over it with his editor.

			With a bit of luck it’ll be out in the wild sometime this summer.

			And next? Well, let’s take it to the stage, right?

			I’m planning to start speaking in public, to get in front of even more people.

			Where this will take me?

			No idea, but I’m dreaming big.

			Reaching a TED stage will be just a milestone.

			A big one, but you bet I’m not going to stop there.

			So that’s my word (phrase) for the year.

			Let’s take it to the stage.

			What’s your word for the year?

			What’s the sign that governs this year for you?

			(And no, I’m not talking about the Zodiac. I mean the word that signifies what you want
			this year to be like for you).

			I’m curious, let me know.

			Cheers,

			Martin

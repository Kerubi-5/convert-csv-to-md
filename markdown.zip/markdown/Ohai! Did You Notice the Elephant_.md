---
title: Ohai! Did You Notice the Elephant?
status: draft
datePublished: '1483520618'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

Back when I lived in the monastery, I was witness to some pretty amazing things.

			And when I say ‘pretty amazing’, I mean ‘not pretty’ and ‘amazingly selfish’.

			Which is normal, of course.

			Because contrary to what most people believe, a monastery isn’t a place where you go
			because you’re so pure and perfect - instead, you go there to improve.

			So you come in bringing all your imperfections, your ego and your arrogance and
			selfishness.

			And then you spend a couple of years engaged in a titanic battle of the egos.

			And I saw it all: greed, envy, theft, self-pity, selfishness, callousness, hurtfulness,
			egotism, pseudo-humility - the works.

			Was I any better?

			Hell no!

			I had - and have - a huge ego. In fact, to quote Zaphod Beeblebrox:

			If there’s anything bigger than my ego this side of the Milky Way, I want it hunted down
			and shot.

			But anyway, on with our story:

			Any time I would try to raise an issue about others with the abbot or one of his
			assistants, it was dismissed outright.

			Never once did I get a chance to complain about others, not even if they were very
			clearly in the wrong.

			Instead, I just kept being pointed back at myself.

			Because I, and my reactions and opinions and judgements: that was the elephant in the
			room.

			SUCH a valuable training.

			Because really: what can you possibly do about others?

			Who are you going to change?

			And what’s more: how can you judge another, when you don’t know where that person is
			coming from, and which previous experiences force them to behave the way they do?

			It is, in fact, arrogant to judge others, because what gives you the right?

			Are you so much better, so exalted that you get to pass judgment over others?

			Of course not.

			And besides, you can’t ever change a person.

			Except... the person called you.

			And that’s what my training taught me: that no matter what another person does, the only
			useful direction to look, is that big damn elephant in the room.

			The one called ‘you and your way of dealing with others and with yourself’.

			Much more useful than pointing at others, if you take responsibility for your own
			reactions.

			It’s not easy, I admit.

			But here’s the trick:

			When you reserve your opinions only for yourself, everything gets easier.

			Take it from an old monk.

			So whatever situation you find yourself in, whatever another person does wrong, or to
			wrong you:

			Deal with yourself.

			Observe your thoughts and opinions and judgments - and work on those.

			Because really, it’ll make everything easier.

			Cheers,

			Martin

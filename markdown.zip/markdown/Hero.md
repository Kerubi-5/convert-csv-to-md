---
title: Hero
status: publish
datePublished: '1546948529'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21237" src="http://martinstellar.com/wp-content/uploads/2019/01/MartinStellar_Coaching_Illustrations-Hero-1024x929.jpg" alt="" width="351" height="318" />The hero isn’t me.

At best, I can be a guide, instructor, mentor, coach.

The real hero, that would be you.

I’m saying this because it’s really easy to get it the wrong way round, and think that someone with a successful business and a prolific writing habit is something special - and that wouldn’t help you.

I’m nobody’s hero except my own, in my own story - and that’s my business thank you very much.

The real hero, that’s you, in your story.

You’re the one facing challenges, you’re being called to adventure, and you’re the one on a path of discovery, growth, travails and successes.

As I’ve said before: never think that someone’s showreel says anything about their behind-the-scenes. I promise, there’s plenty of non-heroic, procrastinaty, faily stuff behind my scenes, because I’m no different from anyone.

You’ll probably have your own, and that’s exactly why you get to be the hero in your story:

In your quest, you get to overcome the setbacks and have the learning experiences and the different kinds of catharsis, that all belong to your story.

So, forget about how good other people look on camera, and focus on yourself, your path, and your own hero’s journey. Plenty of work to do there, without creating confusion by bringing someone else’s story into the mix.

And if, like Paula Mould said, you want to have ‘your own personal Yoda’ in your life - meaning you’re ready to heed the call to adventure and want to work with me, click reply and let me know.

Either way, this story is yours, and you’re the protagonist.

Go be a hero.

&nbsp;

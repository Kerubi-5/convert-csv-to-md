---
title: Ever Have Days Like These?
status: publish
datePublished: '1589778706'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<a href="http://martinstellar.com/wp-content/uploads/2020/05/MartinStellar_Coaching_Illustrations-hard-work-and-nothing-to-show-for-it.png"><img class="alignleft wp-image-24586" src="http://martinstellar.com/wp-content/uploads/2020/05/MartinStellar_Coaching_Illustrations-hard-work-and-nothing-to-show-for-it.png" alt="" width="352" height="264" /></a>You reply to your final email of the day, dot a few more i’s, and shut down your computer.

Another day done - the life of an entrepreneur.

And it’s been a good day, too: you’re tired, you can tell that you’ve worked hard. Sure deserve a nice relaxed evening.

But as you close the door on your home office and you look back on your day, an uncanny notion creeps up:

For all the time, effort, and exertion you’ve put in…

What, actually, have you been working on? You know that you checked off a bunch of stuff, but for the life of you, you can’t recall the details of it.

Things got done - but which things… no real recollection.

Ever have that feeling?

If so, it’s because you didn’t pick the right things to do.

You were taking care of business, but not building your business.

You were working in your company - even doing client sessions, perhaps - but you weren’t working on your business.

Days like that, they give us a false sense of accomplishment, and it’s that voidy-kind-of-feeling when looking back, that tells us exactly how false.

But days when you crank on, working on the big things, the stuff that brings in opportunities and sales and money, those are days when you remember exactly what you’ve been doing.

And those days are the days that you grow your enterprise and your empire.

Far too many entrepreneurs have far too few days like that.

You too?

Then <em>this</em> will help. <a href="https://martinstellar.com/sac" target="_blank" rel="noopener noreferrer" data-cke-saved-href="http://martinstellar.com/sac">Have a look...</a>

Cheers,

Martin

&nbsp;

---
title: Don't Close the Sale - Do This Instead
status: pending
datePublished: '1655075565'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - How to sell your work
  - Psychology in sales and marketing
  - Relationships

---

<img class="alignleft wp-image-21539" src="http://martinstellar.com/wp-content/uploads/2019/04/MartinStellar_Coaching_Illustrations-The-sale-close-vs-open-985x1024.png" alt="" width="351" height="365" />

I’ve never liked the idea of ‘closing a sale'.

To me, it’s the complete opposite of what actually happens when somebody buys.

At that moment, the point of purchase, you might technically "close the sale", but the buyer opens up something new.

Consider:

You buy new shoes, and within days your knees or your back stop hurting.

You buy a new mattress, and wake up more rested than you have in years.

You hire a professional to do a specialised job for you, and suddenly you’re in the safety and comfort of knowing that something you need, is being taken care of expertly.

A new car, computer, or phone - what a joy to use a brand new piece of kit!

All these, and all other purchases, have one thing in common:

They open up a new phase in the life of the buyer.

Not only that: when people buy, they open up a new version of the relationship they have with you or your brand.

A purchase means the buyer opens up a phase of change.

So if you don't know how to get a buyer over the line, or you're conflicted about selling, remember this:

Trying to 'close a sale' is far less effective - and much less fun - than inviting your buyer to step into change.

&nbsp;

<hr />

On another note:
I'm building an app that coaches you on working your pipeline, moving your deals forward - and closing them faster and at better rates.
It's called SalesFlow Coach, and we're scheduled for beta-release in June 2022.
Register <a href="https://martinstellar.com/salesflow-coach-launch/">here</a> to be notified when it goes live.

&nbsp;

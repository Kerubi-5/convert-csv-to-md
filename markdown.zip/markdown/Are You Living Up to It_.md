---
title: Are You Living Up to It?
status: draft
datePublished: '1485155648'
categories:
  - Doing it right as an entrepreneur or creative professional

---

I couldn’t tell if he was the Cheshire Cat, or Buddha, or my dad or my abbot.

			But this was my dream, so it didn’t matter.

			Besides, the smile was there.

			And he just looked like someone with lessons to teach.

			From the depth of my mind, a question came up.

			“What does it mean when they say: ‘Hell on earth?’”

			He waved his arm and a scene appeared.

			A huge banquet hall, with rows and rows of tables.

			Succulent dishes as far as the eye could see.

			At the tables sat people, but not as you and I know them.

			Because these people didn’t have hands - instead, they had chopsticks where hands would
			be.

			And no matter how hard they tried, they were all but unable to feed themselves.

			What a strange sight.

			So I asked:

			“And heaven on earth?”

			Another scene appeared, almost perfectly identical.

			Except for this:

			Instead of trying to feed themselves and failing, the people fed each other across the
			table.

			And the smile asked me:

			“Which world do you want to live in?”

			“The latter of course!” was my reply.

			And as I slowly woke up, his final question rang through my mind:

			“Are you living up to it?”

			Cheers everybody.

			Happy Monday.

			Martin

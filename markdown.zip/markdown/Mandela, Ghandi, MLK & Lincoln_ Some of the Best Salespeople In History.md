---
title: 'Mandela, Ghandi, MLK & Lincoln: Some of the Best Salespeople In History'
status: publish
datePublished: '1598783271'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - How to sell your work
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-21472" src="http://martinstellar.com/wp-content/uploads/2019/03/MartinStellar_Coaching_Illustrations-Selling-vs-enrollment-1024x768.jpg" alt="" width="351" height="263" />If you struggle with the idea of selling because you think it’s wrong, unethical or manipulative - or the biggest problem of all: that it doesn’t align with your values: I wrote this one for you.

Because yes, the names in the subject header each were phenomenally good salespeople.

Even Jesus was a terrific salesman.

Yes, I’m going there. You coming?

See, while they didn't sell time or goods for money, they all spent their lives... selling ideas.

They had a mission for the benefit of others, they believed in it, and they worked tirelessly to give people reasons to buy in to that mission.

Their job wasn’t to sell so much, but to *enroll* people in their mission.

And that’s what ‘selling’ comes down to.

Enrolling someone in something.

Joining a movement for change, finally going on a diet, sticking with your exercise regime, flossing, or indeed: seeing yourself as a happy, satisfied buyer of something, who’s happy that the money was spent - because look at that computer or car or training or coat that I’m so happy with!

It's all sales.

And where it comes to selling in an actual business context, what you’re doing isn’t manipulating or forcing or coercing, or even persuading:

Instead - if you do it right and you’re ethical (unlike politicians, who are also good sellers but who often appear to suffer from a severe lack of ethics) - ‘selling’ to a potential buyer is a way to invite them to buy into a different view on themselves.

Integrous, effective, ethical selling means you provide a way for the other person to see themselves in an ‘after’ stage, where the problem they have is solved..

You don't 'sell things to people' - they enroll themselves, <em>if</em> they want to.

Note that I’m eating my own dogfood here: I’m trying to find a way for you to buy into a different view on sales - one that, if you adopt it, will make a massive difference to your enrollment process. I hope it's working.

And if it is, and you're 'buying', and you like this different way of looking at sales, and you want to make it part of your business and let it make your own enrollment easier and more effective and fun?

Then one way to do that, is to get my 9-week training on ethical selling.

<a href="http://martinstellar.com/leap-ethical-selling-framework/">More information here.</a>

Cheers,

Martin

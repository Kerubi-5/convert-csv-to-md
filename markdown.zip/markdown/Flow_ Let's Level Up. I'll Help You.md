---
title: 'Flow: Let''s Level Up. I''ll Help You'
status: draft
datePublished: '1491208466'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

If you have read me for a year or more, you’ll know that my life is an ongoing experiment.

I never stop learning, and I’m always looking for ways to get better at things.

Develop skills, learn tricks, create hacks and so on.

For example, I learned about how our brain is malleable, and I found that podcasts (my preferred method of learning) is just too slow.

So I experimented, and now I can learn at 3x normal speed because I trained my brain to adjust to that higher speed.

And whenever I learn new useful stuff, I share it with you in these dailies, as I’ve done for years.

And, well... things are about to get a whole bunch more interesting.

Because for the last few years, I’ve been fascinated by peak performance. The things people do these days - it’s just amazing. We’re capable of SO much more than we think.

And so we see people surfing enormous waves, and surviving.

There are athletes doing extreme sports, people backflipping motorcycles, skateboarders jumping the Great Wall of China 5 times in a row...

It’s like there’s a new breed of human arising, and I want to be one of them.

Like Steven Kotler describes in his excellent book The Rise of Superman.

In business we see it too, amazing things are happening.

For example, there’s Singularity University, which studies if and how we can become immortal, and they’re finding amazing things.

Or think of Tesla.

I mean, how far out of the box must you think in order to successfully build and sell electric cars, when for decades Big Oil&amp;Gas is saying green energy is too expensive and unsustainable, and is doing all it can to stop companies from taking off?

How the hell do people manage to pull stuff like that off?

So in my research, I came across a binding factor, something that everyone who breaks the paradigm of possibility has in common.

Flow.

People who do seemingly impossible things are able to enter the zone, where all sense of self disappears, and there’s only 100% focus on one single thing.

The same kind of state that meditation aims to create.

But despite my 20+ years of meditation, I don’t experience flow a whole lot.

When I meditate, I can maintain single-pointed attention maybe for 5 minutes at a time.

And while I’m happy with my life and the results I create, that just won’t cut it.

So, I’m going to learn flow. How to create it in myself.

For starters, I’m buying an EEG headband, to measure my brain activity.

I’m listening to audiobooks and podcasts, and I’m going to experiment the hell out of this flow thing.

Because if a) I’m capable of more, and b) deeper&amp;longer states of flow are what I need, then I want to get to the bottom of this.

And I’ll share whatever I find with you, in your inbox.

So stay tuned.

Let’s level up.

Cheers,

Martin

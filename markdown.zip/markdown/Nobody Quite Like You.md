---
title: Nobody Quite Like You
status: publish
datePublished: '1504691549'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/7f97d322-2ec2-4945-856f-6832ac69829b.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/7f97d322-2ec2-4945-856f-6832ac69829b.jpg" data-file-id="4834993" />One of the most rewarding - and joyful - things about my work as a coach, is helping people get clear on what they’re REALLY very good at.

Some call it a superpower, Gay Hendrix refers to it as the zone of genius, but whatever name you give it: there’s something that you do, that you excel at, and which nobody else does quite the way you do it.

That’s you’re zone of genius.

And more often than not, we don’t realise what it is, this superpower - and if we do, we tend to take it for granted.

“That’s nothing special, I’ve done it all my life”.

Ah but yes: to YOU it might not seem very special, since you’re so used to it and it comes so naturally. Second nature, you don’t even have to think about it.

But that effortless grace you display in doing that thing, that’s exactly what makes it so irresistible and powerful in the perception of others.

Examples: connecting people, communicating astutely, creating design or strategy that just works, building a network, ethical selling, inspiring people… all these are potential superpowers, depending on the individual.

And if you have one (hint: you do, no matter how insecure you are or how much you under-appreciate yourself) you’d better get deliberate about using that skill.

Because remember: there’s nobody in the world who does it quite the way you do it.

Note that this doesn’t mean you have to be the best at it - the zone of genius is about your doing something in a way that’s highly effective, in a way that nobody else could or would copy.

But exactly because it comes naturally to us, we tend to ignore its potential. We busy ourselves with much low-level activity, stuff you could easily outsource, while being ignorant of the ease and grace with which results could show up, if only we’d make our superpower our main focus.

So ask yourself: what is your superpower - your zone of genius?

And: what if you’d scrap a bunch of rote-tasks, and replace them with working in that zone of genius… what would that do for your life and your business?

&nbsp;

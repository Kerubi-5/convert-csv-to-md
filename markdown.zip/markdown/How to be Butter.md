---
title: How to be Butter
status: draft
datePublished: '1489040964'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

There are things you can’t avoid.

			Someone telling you no, or putting you down.

			Or the long and arduous effort to build up enough assets so that you’ll see results.

			Or trying things, one after the other, and none of them seem to work so you try
			something new which then also doesn’t work.

			And for most people, those kinds of disappointment can be disheartening, disruptive, or
			even depressing.

			But it doesn’t have to be that way.

			Not if you’re butter.

			Bear with me, I’m not crazy.

			If you take a stick of butter and rub it on a window, all the rain will just run off.
			Nothing sticks.

			And that’s something you can achieve too, by way of the attitude you choose.

			Because when things affect you, it means that you allow it to stick to you, like those
			pesky houndstongue burs that stick to your sweater in the forest.

			And you can choose to not be ‘stickable’ when things happen.

			You can choose to be impervious, to let it pass by without affecting you.

			A bit of stoicism, you know?

			“Ah, so this happened. Moving on”.

			Because if it happened it’s already in the past.

			Why sit with it and let it ruin your day?

			Most all things only stick when you allow it to.

			And you can stop allowing that, revoke that permission.

			Sure makes life easier, I can tell you from experience.

			Anyway, I must crack on. Deadline for the manuscript of The Prosperous Artist is at the
			end of the month, and there’s a lot of writing left to do.

			Cheerio,

			Martin

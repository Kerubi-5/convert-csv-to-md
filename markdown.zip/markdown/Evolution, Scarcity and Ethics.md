---
title: Evolution, Scarcity and Ethics
status: publish
datePublished: '1601513208'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - How to sell your work
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-21780" src="http://martinstellar.com/wp-content/uploads/2019/06/MartinStellar_Coaching_Illustrations-Evolution-scarcity-and-ethics-1024x768.jpg" alt="" width="356" height="267" />“Hey”, I said. “I thought you didn’t eat sugar?”

“I do!” she replied. “But my parents won’t allow me, and in school I can’t because the teachers will tell on me. That’s why I always turn down those birthday cakes and stuff”.

A school excursion, and we were about 8 years old. This girl’s parents were severely into holistic and healthy living, and apparently sugar was of the devil.

The moment we’d gotten off the bus, she’d spotted a little shop and bought a bag full of sweets which she was now moving into her mouth in an industrial manner.

“You won’t tell the teacher, will you?”

I told her no, and she offered me some of her stash.

The desire for something unattainable is baked into our psyche, and we can’t avoid judging something scarce as something valuable.

Goes back to our prehistoric times, when leaves and predators were abundant, but prey, berries and nuts were hard to get.

Scarce resource = high value… that’s how our subconscious works.

Marketers have figured this out, and created an artform out of manipulating us.

Sale ends, limited stock, offer expires, buy now, don’t miss out… we all know the drill, and most of the time the scarcity is artificial and fabricated.

In itself, there’s nothing wrong with a limited-time offer: it can help people who are the right buyer, to get off the fence and make the decision to purchase.

But the way it’s usually done, scarcity is used to trigger super-primal survival instincts, to make us feel on a subconscious level that unless we buy now, our safety, well-being and lineage is at risk.

That might sound dramatic, and it is: rationally we know it ain’t all that bad, but our subconscious is highly irrational, and simply perceives: ‘Scarce! Grave risk, unless I get! Must! Get!’.

The first problem is that it isn’t right to treat people that way. It’s manipulative and very dodgy.

The second problem is that if you drive too hard a sale, you end up with the wrong buyers.

You’ll pull in people who buy not because they want or need your thing, but because their lizard brain drives them to do it.

And then you get refund requests, buyer’s remorse, info-products that never get used, bad reviews, complaints on forums… all the things that don’t help your business - or indeed your buyers.

Selling something is fine - after all, we all like buying things and the majority of people sell things that are worth buying.

But there’s a line between manipulating people based on fear, and helping people who want to buy make the decision to do so.

There's a hard and sharp line between the two.

I'll bet you're on the good side of that line, and so:

If you consider helping people make a decision to buy or not buy something noble, then I can help you get really good at creating buyers, without having to resort to sleazy tactics.

I'll show you the framework for Ethical Selling that took me 25 years to develop, and works wonders.

<a href="https://martinstellar.com/helping-good-people-sell-more-and-generate-a-bigger-impact/">Here's where you can get started.</a>

Cheers,

&nbsp;

Martin

&nbsp;

&nbsp;

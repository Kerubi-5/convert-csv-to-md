---
title: 'CRD Minicourse, Pillar 2: Outcome-Aligned Decisions'
status: draft
datePublished: '1541504824'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21064" src="http://martinstellar.com/wp-content/uploads/2018/11/MartinStellar_Coaching_Illustrations-CRD-Pillar-2_Outcome-aligned-decisions-1024x768.png" alt="" width="351" height="263" />It’s awesome when we make a decision, and we get the outcome we planned for.

You decide to visit your mother, you programme your GPS, and presto: a few hours later you’re knocking on the door. Happy outcome. Bring flowers.

Most of the time though, the outcomes we get are probably nice, but nowhere near what we hoped for.

For example: you decide to launch a new website, because that way you’ll get more traffic, subscribers, and business.

Site goes live, you watch the statistics, and you realise: no bump in traffic, meaning your decision was incomplete. Just a new website won’t do the trick.

Whenever this happens, it’s because you’re not a GPS.

A GPS holds a map, an accurate representation of the outside reality.

But we don’t have that same map. Our view on the world isn’t accurate at all, and it’s far from complete (as per yesterday’s article: you only ever perceive a tiny fraction of reality, not the whole thing).

Think of it like this: there’s you here, a timeline stretching to ‘outcome’, and inbetween there’s a whole bevy of activities and decisions to be made.

What you do in the middle section determines whether you get the outcome or not.

And what determines what you do in that middle section?

Exactly: the map you have at this moment of reality, or in other words: what you believe the world to be like.

And if that map ain’t right, neither will your actions be, and you won’t get the outcomes you want.

Simple? Yes. Easy to fix? Sure thing!

Question is: do you *want* to fix it?

Because doing so means you’ll need to give up what we tend to treasure most: our opinions, views, convictions, and: beliefs.

They say that money is the root of all evil, but it’s not. The worst, most insidious and most damaging thing, is our attachment to what we tell ourselves about the world.

The more we cling to that, the more it becomes a personal ideology, and the more we doggedly operate in accordance with erroneous interpretations.

So if you want to get that flow and effortless mastery I’m always on about, there’s one seminal decision to make.

Decide to question what you call reality.

It's the only way to start making decisions that are aligned with the outcomes you're after.

Just like with a GPS: if you start out with a bad map, who knows where you'll end up...

Cheers,

Martin

---
title: Cheapest VS Best - And What About the Middle Ground?
status: publish
datePublished: '1527787471'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/726617f4-0020-44d5-b0c1-9003e6257a91.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/726617f4-0020-44d5-b0c1-9003e6257a91.png" data-file-id="4835761" />Yesterday I went on a team-building excursion with a client and his employees.

15 Kilometers, walking upstream in a riverbed. Was fun.

But some half an hour in, one of the girls ran into a problem: her shoes started falling apart.

Literally so: while they sported the Nike logo, they clearly were cheap Chinese knock-offs, because the soles started to unglue themselves.

(How on earth someone manufactures shoes with glue that’s not water-resistant is beyond me, but whatever. Cheap is cheap).

Got me thinking about the buying decisions we make.

Often, we go for middle ground pricing&amp;quality.

You know, value-for-money kind of decisions.

But is that smart?

To me, it’s not.

Example: when I’m travelling and I didn’t bring my headphones but I need them for client sessions, my only option is to buy a set.

And given that I have a high-quality set at home, I go for the cheapest option: $1 headphones from those bargain shops. Makes little sense to buy a second expensive set if I have one waiting for me.

At that moment I know the quality I'm buying is ultra-low and so when they break after a few weeks, I don’t mind. I bought disposable.

Not that I like the idea of disposable products, but a $15 or even $35 set won’t last that much longer and will get disposed of soon just the same.

By contrast, consider a pair of shoes I bought 25 years ago.

I wore them daily for 15 years, the last 5 of which while rebuilding the monastery.

Those shoes suffered. Hard.

So you’d think they’d be dead, but nope: All I need to do is send them to the factory, get them resoled and fixed up, and I’ll get them back as good as new. And yes, those shoes did cost $500 back then.

Was it worth it?

I’ll say. Shoes that survive 15 years of hard use, and can be fixed to get a new lease on life? Totally worth it.

But when you go for the middle ground, you don’t get that kind of option.

Medium-range products or services are subject to economy of scale: the provider needs to closely guard his cost&amp;profit numbers, and shave off any bit of cost they can get away with.

Which often means that while you think you’re getting value for your money, you’re actually getting less value than you pay for.

I’m sure it’s happened to you as well: you buy something with an expectation of some degree of quality and durability, only to end up disappointed.

Me, I avoid anything middle ground. I’ll always prefer the best of anything (example: getting my coaching from Peleg Top, and Mark McGuinness, cost me a pretty penny both times, but DAMN it was worth it!), even if that’s costly. It almost always ends up worth it.

This is why I’m not cheap either (sorry, not sorry) - because I want to give my clients the best, deepest, most transformative coaching experience I can.

I’m not claiming to be the best, but I’m damn good and I’m worth it. (this is not arrogance, it’s confidence - subtle difference).

And it ain’t just me saying so:

“I so look forward to these weekly calls, Martin.

They’re so very helpful.

You’re our secret weapon.

~ Richard Hall, richardhallfineart.com”

Anyway, enough shameless self-promotion.

Let me if ‘n when you’re ready for real, lasting change.

Cheerio,

Martin

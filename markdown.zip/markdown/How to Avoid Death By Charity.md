---
title: How to Avoid Death By Charity
status: publish
datePublished: '1645452209'
categories:
  - Business and systems

---

<img class="size-medium wp-image-28267 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/11/Untitled_Artwork-10-300x225.png" alt="" width="300" height="225" />There’s a really dangerous trap that you can fall into, and it can be devastating to your business.

It can, in fact, literally take your business down.

It’s called ‘death by charity’, and it’s super easy to fall into, especially if you’re a good person and you want to help people.

But just as I said last week: if you don’t put your own oxygen mask on first, your business isn’t sustainable and you’ll end up going out of business.

Because you either run a business, or a charity. Can’t have both.

What you can have though, is the ability to be charitable, when called for.

That’s being a good human being, and it’s also good marketing.

Where most good-egg coaches and consultants get it wrong, is making charity part of the branding and operations.

Giving away free sessions, or having eleventy sales meetings with a buyer, until the buyer is so wisened up because of it, they run off and go implement on their own.

Instead of making charity part of your marketing, make it part of ‘surprise and delight’.

When someone deserves it, and you believe in them, and they’re either a giver or a matcher (NEVER give charity to takers), then sure, you can do something for free, as a gift. Why not.

But not by default, not as part of you trying to land your clients.

If you don’t watch out, your entire business is at risk of death by charity, and that serves nobody.

Cheers,

Martin

If this makes sense and it’s already how you work, and you want to close more sales, <a href="https://martinstellar.com/helping-good-people-sell-more-and-generate-a-bigger-impact/">sign up here</a>. I can coach you live on how to have the kind of conversations with buyers that make them volunteer “let’s do this!”

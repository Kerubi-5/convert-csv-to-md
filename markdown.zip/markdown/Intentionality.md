---
title: Intentionality
status: draft
datePublished: '1546360990'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21208" src="http://martinstellar.com/wp-content/uploads/2019/01/MartinStellar_Coaching_Illustrations-Intentionality-1024x953.png" alt="" width="350" height="326" />Oh I know, it’s too late to ask you to think of a word for the year.

But I’m going to throw one into your mix anyway:

Intentionality.

If there’s one change you want to make this year in how you operate, make it this one.

To be deliberate, considered - *to be intentional* with the way you do things.

We move through life half-asleep far too often.

Operating by rote, responding by default, half-assing our efforts.

Nothing intentionally done, just another day at the office. Hey ho.

But if you get intentional about things, you’ll get interesting results.

You’ll be actively connecting dots, and learning why things work the way they do.

And, you’ll be learning why you’re getting (or not getting) the results you’re getting (or not getting).

Which enables you to make choices that get you different results.

But you don’t get there without intentionality, which is a kissing cousin of self-awareness.

Every morning, I spend 20 minutes writing in my journal, in a section called Daily Intentionality.

It orients my mind and it prepares the tool I have in life (i.e. the self) for performance. Sharpening the axe, if you will. (I’ll stop there with the metaphors).

And, I try consciously to be present mentally, throughout the day. Pretty damn hard, but so worth the effort.

What I do, creates results. The more I’m there when I’m doing them, the better the results are likely to be.

So that’s my word for your year, in case you were still looking for one:

Intentionality.

Cheers,

Martin

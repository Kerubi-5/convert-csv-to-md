---
title: How to Start Liking 'Necessary Evil'
status: draft
datePublished: '1486363923'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

I’ll be the last to tell you that there are things you *have to* do.

But there are certain things that are preconditions for other things.

Feeding yourself so that you stay alive, is an obvious example.

Another one, more poignant to where it comes to running a business:

Getting your work seen by he people who want to buy it.

In other words, the boogeyman called marketing.

You  don’t have to do it.

But without it, folks won’t find you and therefore won’t be able to buy from you.

So it’s a necessary evil, right?

Something you just have to suck it up and do it.

Nah. Where’s the fun in that?

I posit that anything can be made into something you like or enjoy, or at the very least, don’t mind so much.

The trick is how you frame things.

The meaning and importance and context you give it.

So here’s a nice frame to put your marketing and business building activities into:

Marketing is discovering ways to find people you can have a conversation with.

Frame *that* and hang it on your wall.

Because what can be more fun than discovering people who are eager to talk to you, who like you and your work, and who’ll give you money for it?

Ok, maybe chocolate is more fun, or skiing or... well, use your imagination if you have to.

But you get my point: conversations are fun, they are what human beings thrive on.

And it just so happens that a business also thrives on having conversations.

So from now on, I invite you to change your perspective.

To stop looking at marketing and selling and promotion as something unavoidable, something you have to do.

Turn it into something you do for the fun of it.

Make it a game, an ongoing experiment, where you get to play researcher and test different ways to show up and be found.

There. No more ‘necessary evil’.

And if you want help in how to run your experiments and reframe things and finding buyers?

Then I’ll walk with you.

Here’s the first step: a few questions before we talk --&gt; <a href="https://martin283.typeform.com/to/v7Dsh8" target="_blank" rel="noopener" data-cke-saved-href="https://martin283.typeform.com/to/v7Dsh8">https://martin283.typeform.com/to/v7Dsh8</a>

Cheers,

Martin

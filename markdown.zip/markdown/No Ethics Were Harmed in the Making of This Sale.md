---
title: No Ethics Were Harmed in the Making of This Sale
status: publish
datePublished: '1592378067'
categories:
  - Ethics and marketing
  - How to sell your work
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-21633" src="http://martinstellar.com/wp-content/uploads/2019/04/MartinStellar_Coaching_Illustrations-No-ethics-were-harmed-in-the-making-of-this-sale-946x1024.png" alt="" width="351" height="380" />Do you consider yourself an ethical person? Someone with integrity? Someone with values that speak of care for others?

And, do you ever feel conflicted when it comes to selling your work, or quoting prices, or indeed: setting rates that your work is worth?

If yes, then it’s very likely that your ethics and values are the very thing that cause you to undercharge, or to miss out on buyers.

“I wouldn’t stoop so low as to manipulate people into buying!”

Nor should you. Not people like us.

But, if you do care about others, and if your product or service genuinely solve problems and make people’s lives better, isn’t it an act of service when you enable people to buy?

Right, that’s what I thought.

So then how do you get around that barrier, set up by your morals and values?

It’s simple:

Forget about all the sleazy, pushy sales tactics that reek of the 80’s. That’s not you, and you don’t need them.

Next, reframe what selling really is:

It’s helping someone make a decision. Selling is guiding someone through a decision-making process.

Finally: be unattached to the outcome, and embrace the no.

When you have something to sell, you’ll go through an ocean of no, so you might as well get comfortable with it.

And the more comfortable you are with the no, the less pressure the buyer will feel, meaning they’ll have fewer objections and worries - AND you’ll be selling without ever violating your values and ethics.

&nbsp;

Cheers,

Martin

---
title: >-
  Local Business Marketing Help, This Wednesday: Live Q&A, With Charlie Birch
  and Yours Truly
status: draft
datePublished: '1587978833'
categories:
  - Business and systems
  - Doing it right as an entrepreneur or creative professional
  - Ethics and marketing
  - Hope&amp;Survival
  - How to sell your work
  - Psychology in sales and marketing
  - Relationships
  - Talking words

---

<img src="https://mcusercontent.com/f05dc59f4bf8170c301679377/images/1b247907-b3f2-4ace-a428-92b2973b4338.jpg" width="350" height="262" align="left" data-file-id="4837505" data-cke-saved-src="https://mcusercontent.com/f05dc59f4bf8170c301679377/images/1b247907-b3f2-4ace-a428-92b2973b4338.jpg" />Attentive readers will have noticed that I like helping people - and if there’s one group of business owners in need of help right now, it’s the owners of physical businesses.

It’s all very nice (truly, it is!) when you have digital assets and marketing funnels, but if you happen to depend on people showing up to your premises, you might be struggling.

Which is why this Wednesday, my former client and good friend Chacha (aka Charlie Birch of CharlieBirchConsulting.com) are co-hosting an open Q&amp;A session on Facebook.

Because even if right now you can’t open your doors to people, that doesn’t mean people don’t want what you do.

And there’s a million ways you can adjust, pivot, or reinvent, even if you’re a local business.

Now I’m not specialised in local businesses - I just know how to connect dots and invent solutions.

Charlie though, she’s a passionate advocate for local business, and she’s one smart cookie. And, she’s clever where it comes to finding what makes a business unique - in other words: the Unique Selling Proposition that every business needs to be clear on.

Oh, and she’s incredibly good at connecting people, so you might want to show up and become part of her world. Will do you good.

Anyway, we decided to put our heads together and spend an hour trying to help.

If you own a local business, join us this Wednesday 29 April, at 10AM Eastern / 4PM CEST - <a href="https://www.facebook.com/kgbirch/posts/10100242797643785?notif_id=1587480023983328" target="_blank" rel="noopener noreferrer" data-cke-saved-href="https://www.facebook.com/kgbirch/posts/10100242797643785?notif_id=1587480023983328">register here to attend.</a>

And of course, if you don’t have a local business but anyone in your circles do, feel free to forward them the link.

Thanks!
Cheers,


Martin

---
title: 'Magic: Deep Single-Pointed Attention'
status: draft
datePublished: '1525891452'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/921e634d-d9e3-4dc1-a463-8c76f759ee42.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/921e634d-d9e3-4dc1-a463-8c76f759ee42.png" data-file-id="4835701" />There’s nothing special about me. Not in any unique, 'you-ain't-got-that' kind of way.

Sure I have abilities: sing, coach, draw, write and so on… But all of those became what they are because of learning and practice.

Not because of some special talent I was born with. Just abilities, that I developed.

What I do have though, and maybe you don’t have it yet, is a habit of giving things 100%, fully focused, single-pointed attention.

And that stuff, that’s magic.

For example: a few years ago I auditioned for a band. And, “what song do you want to sing, Martin?”

Stupid courageous, I said “I feel good”. You know, James Brown.

Which isn’t a hard song to sing, but it’s a bitch to do *right*.

I walked in, sang the song, and bam: Hired on the spot. Nailed it, in other words.

But here’s the kicker: I hadn’t had singing practice in over 5 years, I’d never sung the song before, and best of all: I practiced the song all of 5 times, the day before the audition.

Logically, someone not-pro like me, out of practice, on a new song, couldn’t land a gig like that. Except I did.

So how did I swing it?

I gave it my all. I fully leaned in to the experience coming up. For a week, I read about James Brown, listened to all the funk classics, really got my groove on, and dove into it.

And on those five micro - rehearsals, I went all-out, party-time.

And by the time the audition came, I was no longer present. I was not there. The guy singing, that was Martin but without the self-awareness.

I gave it single-pointed attention, and I became the song.

Lost myself, total state of flow.

And these days, I realise that this can be down to a decision.

To commit to the moment of creating or showing up, to block out everything that’s not that moment, and to lose yourself in being the best version of yourself, without actually trying.

There’s no you who is trying, when you’re in a state of flow. There’s just doing.

And all this is just about adecision that you make.

The decision to go into something 100%.

Just like you do with your best zone-of-genius deep work, the kind of all-in, full-on commitment that you already have to doing the important work.

Now, what if you could apply that to your business?

What if your biz development activities would also be a dream to perform?

Totally possible, you know.

Just comes down to the choices you make, about *what* you’ll be doing, and *how*, to get the result you want.

Anything can be made fun, and an opportunity to lose yourself and excel. Even business stuff.

Pick a result, consider the many ways to get it, and then choose the one method or channel that most makes you feel alive.

And if you’re not clear on what to choose, then I’m here to talk, to look at the options, and to create clarity on where to give it your all.

Cheers,

​Martin

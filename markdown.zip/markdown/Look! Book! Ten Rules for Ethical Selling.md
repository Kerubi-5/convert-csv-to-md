---
title: Look! Book! Ten Rules for Ethical Selling
status: publish
datePublished: '1583251562'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - Ethics and marketing
  - How to sell your work
  - "Psychology in sales and\r\n\t\t\tmarketing"

---

<img class="alignleft  wp-image-22762" src="http://martinstellar.com/wp-content/uploads/2020/03/MartinStellar_Coaching_Illustrations-10-rules-for-ethical-selling-1024x1024.jpg" alt="" width="352" height="352" />One of my favourite things when working with clients, is looking at the assets that aren't being utilised in their business.

Makes for fun and fast growth, when for instance you take the asset called 'subscriber list' and you start talking to the people there. After all, most people collect email subscribers, but never send.

But once you start to communicate with them? Replies, downloads, sales... like I say: it's fun!

And in the spirit of eating my own dogfood: I've taken some of my own assets, and put them together in a little ebook, for your entertainment and education.

<a href="https://mcusercontent.com/f05dc59f4bf8170c301679377/files/424e0983-63a5-4a56-905d-c91c85450f48/10_rules_for_ethical_selling_MartinStellar_LEAP_to_Ethical_Business_Growth_Series.pdf" target="_blank" rel="noopener" data-cke-saved-href="https://mcusercontent.com/f05dc59f4bf8170c301679377/files/424e0983-63a5-4a56-905d-c91c85450f48/10_rules_for_ethical_selling_MartinStellar_LEAP_to_Ethical_Business_Growth_Series.pdf">Click here to download 'Ten Rules for Ethical Selling'</a>

Enjoy!

Cheers,

Martin

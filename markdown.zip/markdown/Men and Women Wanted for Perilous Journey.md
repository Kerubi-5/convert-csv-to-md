---
title: Men and Women Wanted for Perilous Journey
status: draft
datePublished: '1556529738'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img class="alignleft wp-image-21657" src="http://martinstellar.com/wp-content/uploads/2019/04/MartinStellar_Illustrations-men-and-women-wanted-for-risky-journey-1024x768.jpg" alt="" width="351" height="263" />Extreme commitment required, long periods of doubt and second-guessing, constant risk.

Success as likely as failure.

Wealth and recognition in case of success.

Reply to learn more.

Cheers,

​Martin

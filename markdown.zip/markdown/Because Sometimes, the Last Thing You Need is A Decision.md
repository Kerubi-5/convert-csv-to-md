---
title: Because Sometimes, the Last Thing You Need is A Decision
status: draft
datePublished: '1520351183'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/a4709961-5a62-4da6-8ece-7d42eb392ff2.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/a4709961-5a62-4da6-8ece-7d42eb392ff2.jpg" data-file-id="4835517" />I’m all for taking action, and I’m happy to make decisions on which actions to take… but sometimes, it’s just not the right time for a decision.

For me, something is either a hell yes, something I really want to do/experience/buy/own or commit to, or it’s nope. Not gonna happen.

Makes life a lot easier. Frees you from rationalising your way into tentative “well I guess I’ll give it a try” or “I’m not really feeling it, but those experts say so, so I guess I’ll go for it” situations.

When you’ve considered the pros and cons to a reasonable degree (hint: that’s probably a lot sooner than you’d think), there’s no clear sense of “YES!”, then why not make no decision?

Opportunities abound. What you’re not saying yes to right now will still be around later on, and otherwise there will be new opportunities. Promise.

Forcing yourself into a decision because you're afraid of missing out... well, that's a fools errand.

Here’s an example of an opportunity to take - or to leave, as you see fit: have a conversation with an experienced business coach, about how to grow your business.

Or not: it's up to you. Whenever you’re ready.

But it will sure raise your revenue, and who doesn't want that?

So drop me a line once you get to ‘hell yes’.

Cheers,

​Martin

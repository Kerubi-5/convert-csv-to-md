---
title: 'Introducing: The Ultimate Teacher'
status: draft
datePublished: '1494596413'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/a50948d3-8386-4ba2-8cdd-35e0c4859a58.jpg" width="300" height="169" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/a50948d3-8386-4ba2-8cdd-35e0c4859a58.jpg" data-file-id="4834601" />Used to be, I would get terribly annoyed when I’d run into problems and limitations that I thought I’d overcome.

Anger, sloth, self-pity, impatience… Come ON Martin. Are you still not over that?

Gradually though, I learned that this isn’t the attitude that helps.

Like I said the other day: you’ll run into the same stuff, all your life, over and over again - but if you play the game right, it’ll be in subtler ways. It’ll be less problematic.

That’s just the way we grow.

It’s how the ultimate teacher gets us to be our best selves.

And the ultimate teacher… well, that’s life, of course.

People like me, and the authors and speakers and teachers in the world - we’re helpful folk.

But the real teaching happens to you at every moment you are willing and ready to learn.

There’s a lesson for you waiting in every interaction, every book, every chance occurrence.

What matters is that you go through life with the attitude of being the eternal student, ready to learn whenever and wherever.

Because the ultimate teacher is ready for you 24/7.

And it’ll patiently teach you the same thing, over and over again.

“Have you learned the lesson yet? Ok, here it is again”.

It’s not frustrating to me any longer. It’s a blessing.

Cheers,

Martin

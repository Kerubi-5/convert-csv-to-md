---
title: Erm... Could Be You're Asking the Wrong Question?
status: draft
datePublished: '1487142458'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

One of the members of my Cabal coaching group is beginning to warm to the idea of
			writing daily emails to her list.

			Because that’s just how persuasive I am.

			No wait: that’s how clever she is.

			But after yesterday’s email, she writes:

			“Been thinking about this as it relates to selling my art and ask of myself what would I
			really write about daily that would help...”

			Ah, good question, and one that I hear a lot.

			But the question is incomplete.

			It’s not ‘what could I write that helps me sell my art’.

			No no no, don’t ever start there.

			The real and right question is: ‘What can I write that would help... THEM?’

			Them as in: your readers.

			See, sales come as a consequence of your marketing.

			They are not the primary goal.

			The primary goal of your marketing is to create and foster relationships with your
			audience.

			Sales come as a result of that.

			Because for an entrepreneur, people matter. Have to matter.

			It’s only corporations that can ignore people and get sales with nothing but ads and
			slogans and pushy in-your-face marketing.

			Us entrepreneurs, we fortunately can’t and don’t need to behave that way.

			Just build relationships, one conversation and one person at a time.

			And, yes: sending daily emails is a BRILLIANT way to to that.

			Fun too.

			Now, as for her question: ‘What to write about’ - that’s a topic for tomorrow’s email.
			But for now, I’ll leave you with a counter-question, to ponder as you go through today:
			What could you say to potential buyers - or indeed write about - that would be helpful
			to them?

			Because that - being helpful - is where all ethical marketing starts.

			What could you write that would be helpful, in any way you can think of, to your
			audience?

			More tomorrow,

			Martin

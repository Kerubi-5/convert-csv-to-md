---
title: Here, Use My Flashlight
status: draft
datePublished: '1539766685'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-20989" src="http://martinstellar.com/wp-content/uploads/2018/10/MartinStellar_Coaching_Illustrations-Awareness-and-thinking-1024x768.png" alt="" width="351" height="263" />Interesting conversation with my coach yesterday, when I asked him why people sometimes cling to completely illogical or even nonsensical views and beliefs.

His reply: “So have you noticed your bias towards logic &amp; reason? I'd almost be tempted to say you were a head type. :)"

Ah, but there he’s mistaken.

I’m not a head-guy, but an awareness guy.

I know the limitations of thought - after all, the conscious mind is a pretty small box to live in, if you compare it to the subconscious, which is an area that includes emotions, instinct and intuition.

But for better or worse, thinking is something we can’t avoid doing, it’s the human condition.

And that ongoing thought process we live with each day, that’s simply our mind explaining our world to us.

But if you let that run unchecked, you might well be telling yourself all kinds of falsehoods about your world.

That one is a jerk, the other a loser, the economy is screwed, politicians are liars all of them, you’re a failure, your kid is a nuisance, your spouse is selfish…

One opinion, one solitary interpretation, one potentially incorrect view after another.

Can’t be stopped, not even if you’re a monk living in reclusion (I tried).

The mind churns on, that’s what it’s for.

And I’ll be the last to claim that the process of thinking is wrong, or unnecessary, or more important than emotions.

But what I do claim is this:

99% of your thinking is done unawares, but programs you for future interpretation of the world nonetheless.

And the more you become aware of that thinking, and learn how to get better at it as your awareness increases, the happier you become and the better your results get to be (that too, I tried).

When you find life difficult, or business unsatisfying, or relationship troublesome, the place to start is shining a light on your unconscious thought patterns.

And I’ll be happy to lend you my flashlight, if you want some help.

Cheers,

Martin

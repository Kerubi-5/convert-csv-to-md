---
title: How to Rescue your Well-Crafted Articles From the Content Graveyard
status: draft
datePublished: '1496331337'
categories:
  - Doing it right as an entrepreneur or creative professional

---

Doesn’t it drive you crazy, when you create terrific articles for your audience, and then they all but disappear as time goes on?

Especially if you publish frequently, and each new one pushes the great thing you wrote yesterday down the list.

And let’s not even mention social media: you post something you spent a lot of sweat equity on, and before the day is out it’s buried beneath all kinds of other updates.

Of course you can use services like Buffer to re-schedule, but that’s a lot of manual work.

Or Edgar, but that’s a pretty expensive service.

Well, I have a solution for you.

I want to introduce you to my friend Ben, and his company Missinglettr.

The Missinglettr platform is an amazing service, which gives every article you write a life time of one whole year.

Here’s how it works:

As soon as you publish an article, Missinglettr pulls it in.

It then automatically creates a social media campaign out of it, with nine individual updates, spread out over a year.

You can customise them as you will, and you can have them sent to Facebook, Twitter, LinkedIn and Google+ (with Pinterest and Instagram being added soon).

I’ve been using the system for myself, and I love it.

For one thing the way it makes creating a 1-year campaign so effortless, but also because it’s smart software: It automatically pulls quotes from your writing, and I’m frequently amazed by how well it know what to select.

I’m telling you, Missinglettr is the bee’s knees if getting your articles read matters to you.

So if you want to give it a spin, here’s the link to use - there’s a free starter plan if you want to test it out: <a href="http://missinglettr.com/?ac=AQRlkyTo" target="_blank" rel="noopener noreferrer" data-cke-saved-href="http://missinglettr.com/?ac=AQRlkyTo">http://missinglettr.com/?ac=AQRlkyTo</a>

Disclaimer: that’s an affiliate link, so if you end up subscribing to any of the paid plans, Ben pays me a commission.

But you get 2 campaigns per week with the free plan, so unless you write as often as I do, you can use the system at no cost.

Give it a try!

<a href="http://missinglettr.com/?ac=AQRlkyTo" target="_blank" rel="noopener noreferrer" data-cke-saved-href="http://missinglettr.com/?ac=AQRlkyTo">http://missinglettr.com/?ac=AQRlkyTo</a>

Cheers,

Martin

P.s. Full disclaimer: I'm helping Ben grow his business, so if you have questions and you contact support, you might even see me give you the reply. Anyway. Happy Missinglettring

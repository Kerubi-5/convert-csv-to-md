---
title: How to Sell Things and Still Sleep at Night
status: publish
datePublished: '1608598414'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - How to sell your work
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-21456" src="http://martinstellar.com/wp-content/uploads/2019/03/MartinStellar_Coaching_Illustrations-Selling-is-a-transfer-of-enthusiasm-1024x768.jpg" alt="" width="349" height="262" />“Oh if you like that movie, you should totally watch Star Trek: Deep Space Nine”, said my mastermind buddy.

I wasn’t feeling it - I mean I like Star Trek just fine, but it never impacted me as much as some other scifi shows and films. And DS9, the few bits I'd seen, just didn't grab me all that much.

He went on: “I really like it as a show because it’s kind of the forgotten stepson of the franchise and it’s the deepest one. Really interesting commentary on occupation, religious freedom, and racism”.

With that, I was sold. Must give it a try.

And I joked: “You should be in sales”.

Here’s why this matters, if you own or run a business.

Because if you do, you need to sell your work or products.

Without sales, you don’t have a business.

But most people have hangups about selling.

Limiting beliefs, erroneous views, and of course the bad taste we have in our mouths, seeing how sleezy and corrupt and unethical sales can get, if it’s the wrong person doing it.

But, as per Daniel Pink: to sell is human.

“Shall we go get a pizza?” --&gt; selling someone on an idea.

“Don’t beat up your little brother” --&gt; selling your toddler on learning and adopting societal norms.

“Eat your greens” --&gt; selling your kid on learning to do what’s best for them.

“Will you marry me?” --&gt; selling your partner on forging a lasting bond.

Sales are a tool for creating an exchange of value, nothing more or less.

Another tool is a hammer, a tool made for putting nails into things.

And both tools are agnostic of ethics - it’s the handler of the tool who puts on the ethics and morals. Both can be used for right or wrong.

So, if you have doubts or concerns about sales, or if you think selling is bad, or that you’re not good at selling, here’s the solution:

Transfer enthusiasm, because in the end, that’s what selling is.

It’s what my buddy did, and it works, and it’s ethical.

He suggested reasons that might make me care, by appealing to values that are important to me.

How to transfer enthusiasm?

That’s a long story and it's what I show my clients and students, b<span style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen-Sans, Ubuntu, Cantarell, 'Helvetica Neue', sans-serif;">ut the basic rules are as follows:</span>

1: Be real. If you’re not enthusiastic about what you’re selling, you're selling the wrong thing.

2: Care about the other person and their needs. If someone buys something, it’s because they want their life to improve, in whatever way. To be effective at selling - and I mean: transferring enthusiasm - you’ve got to actually care about them and the outcome they're looking for.

3: Listen. Not for the cue on what you’re going to say next, but really, truly, listen to what’s going on in the other person’s mind and emotions.

4: Once you ‘get’ what’s going on for them, make sure that your replies are tailored to join the conversation that’s going on in their minds.

5: Ask for a decision. Note that this is different from pushing people into one.

6: Accept ‘no’ with grace and gratitude. The person who says no has just freed you up from a conversation that won’t lead anywhere useful either for you or for them.

That’s something to be grateful for - you get to move on with your life, and they too.

You now have more time to seek other potential candidates, and have conversations with them.

Bonus: you get to sleep at night, because you know you’ve operated with ethics and true human concern.

More bonus: you'll always be able to restart the conversation with the person who said no, because you treated them with care and respect.

Now: Do you want to get really, really good at having those kinds of conversations, and develop your ability to enroll people - AND feel good about it?

Then <a href="http://martinstellar.com/helping-good-people-sell-more-and-generate-a-bigger-impact/">this training will do the trick. </a>

Cheers,

&nbsp;

Martin

&nbsp;

&nbsp;

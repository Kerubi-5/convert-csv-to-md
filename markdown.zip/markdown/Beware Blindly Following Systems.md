---
title: Beware Blindly Following Systems
status: pending
datePublished: '1656921332'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-22029" src="http://martinstellar.com/wp-content/uploads/2019/09/MartinStellar_Coaching_Illustrations-Framewords-vs-systems-1024x768.jpg" alt="" width="351" height="263" />

It’s tempting to look for a system, something that can be run, tested, and optimised.

Social media strategies, sales conversations, lead generation, standard operating procedures for creating and publishing content…

Most anything can be turned into a system.

And the promise that ‘a system’ holds is very alluring, which is why there are so many gurus out there hawking plug-and-play systems for business.

From doing keyword research to updating websites to setting appointments with potential clients: someone, somewhere out there, has a box for sale that is supposed to do it for you.

And some of those systems are really good - but by themselves, applied without consideration and strategy, they're not likely to help you very much..

If you buy a system without understanding the underlying framework, you are extremely likely to end up in the category of buyers who say "It’s good but it didn’t work for me".

See, no system is applicable as-is, in all possible contexts and situations.

In the majority of cases, you’ll want to make small, strategic adjustments.

Modify wording, or frequency, or your pitch… do your hashtag research differently or use a slightly different layout for your ebook or break some rule or other.

No matter what promise a seller makes:

There's not system that works out of the box. If you want to use a system, make sure you understand how that black box works, so you can tune it to <em>work for you</em>.

&nbsp;

<hr />

On another note:
I'm building an app that coaches you on working your pipeline, moving your deals forward - and closing them faster and at better rates.
It's called SalesFlow Coach, and we're scheduled for beta-release in June 2022.
Register <a href="https://martinstellar.com/salesflow-coach-launch/">here</a> to be notified when it goes live.

---
title: Every Decision and the Cost That it Brings
status: draft
datePublished: '1537807930'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-20931" src="http://martinstellar.com/wp-content/uploads/2018/09/MartinStellar_Coaching_Illustrations-More-of-what-works-1024x768.png" alt="" width="351" height="263" />That course on how to use Instagram for your business might seem like a good deal:

Low price, easy modules, made by someone you trust.

But beyond the dollar amount, what’s the real cost?

You’ll have to reserve time for learning, and then for implementing. That’s expense #1.

Then there’s the amount of time you won’t be spending on other business matters.

Obviously, adding one thing into your business mix means you’re robbing time from something else, so here we have another cost.

Next, there’s the cost to your self-esteem, if this turns out to be yet another purchase that ends up in the backwaters of your download folder, never to be used.

Finally, there’s the cost of ‘getting really good at it’.

A training is only as useful as your level of mastery, and it’s only with diligent practice and improvement that you start to see real payoff, only once you become masterfully good at it.

So that $39 training suddenly doesn’t look so cheap, does it?

With everything in life, there’s a potential benefit from making a decision, and there’s a guaranteed cost.

Problem is, we tend to only focus on the (not at all guaranteed) benefits, and conveniently ignore the cost, which is often staggeringly high.

Or, as the behavioural economist Dan Ariely would have it: we’re predictably irrational.

This problem of hidden costs (or: opportunity cost) is only phase one.

Phase two is: chasing sunk costs.

Because today we make a decision that seems reasonable and well thought out, when we find that it wasn’t the perfect choice, we often justify that old decision by tossing more effort into trying to make it work after all.

So when you’re faced with a decision that stands to have a big impact, think about hidden costs before jumping in.

Next, ask yourself how you’ll prevent yourself from chasing sunk costs. Most of the time, a firm decision on ‘results by date x’ (and please: be reasonable here with your expectations. Start with ‘proof of concept’ and work up from there) should be enough to have you abandon the experiment and chalk it up to experience.

When you do your due diligence, you’ll often find that the hidden cost alone is so high, the experiment isn’t even worth it.

Which is excellent, because it prevents you from giving it time, which you can then shovel into: doing more of what works.

Most big decisions (especially those sold with hype by marketers) are only a way to procrastinate anyway.

You know what works in your business.

Go do more of it. Really.

Cheers,

Martin

---
title: Let's Break Things
status: publish
datePublished: '1604278498'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - Ethics and marketing
  - How to sell your work
  - "Psychology in sales and\r\n\t\t\tmarketing"

---

<a href="http://martinstellar.com/wp-content/uploads/2020/06/MartinStellar_Coaching_Illustrations-Lets-break-things.png"><img class="alignleft wp-image-24805" src="http://martinstellar.com/wp-content/uploads/2020/06/MartinStellar_Coaching_Illustrations-Lets-break-things-1024x768.png" alt="" width="350" height="263" /></a>Gutenberg said: 'Copying texts by hand? How tedious, how inefficient. That ain’t right'.

And he went on to invent a printing press, and he broke how things were done.

Steve Jobs said: 'Computers big and bulky, and only for corporations? That ain’t right'.

He went on to put a personal computer in every household.

Abraham Lincoln saw slavery, and said: ‘No you don’t’ - and became one of the people most associated with abolishing it.

Just a few random, yet impactful, instances of people saying ‘that ain’t right. I’m going to break that’.

History is full of examples like these.

And if you look at the world we live in, I’ll bet there are quite a few things you consider wrong.

Things that should change, be disrupted, be righted, be broken and replaced by something better.

At what point does it become right for a politician to lie?

What makes it right for a corporation to please its shareholders, whilst treating its customers like cash-cattle, and damage the land in the process?

How is it right for a (social) media corporation to foster hatred and divisiveness, with its clever algorithms designed to hook people and keep them addicted to fear and panic?

There are many things in the world that just ain’t right, and as a business owner, you get to choose whether or not you help break them, and build something better instead.

And it’s wonderful to see all the driven and passionate founders and coaches and activists and authors and researchers taking a stand, and saying ‘this ain’t right. I’m going to change this’.

If you’re an entrepreneur who is in business to break thins so that something better can be built, you’re my kinda hero. Keep going.

And if you also want to move faster, break things faster, and build a better new faster, then maybe I can help.

<a href="mailto:martinstrella@gmail.com">Hit reply</a> and let me know what wrong you’re righting, and let’s have a chat.

Cheers,

Martin

&nbsp;

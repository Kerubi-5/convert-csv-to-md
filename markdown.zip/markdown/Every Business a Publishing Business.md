---
title: Every Business a Publishing Business
status: publish
datePublished: '1624322680'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - Ethics and marketing
  - How to sell your work
  - "Psychology in sales and\r\n\t\t\tmarketing"
  - Relationships
  - Talking words

---

<a href="http://martinstellar.com/wp-content/uploads/2020/04/MartinStellar_Coaching_Illustrations-Every-Business-is-a-publishing-business.jpg"><img class="alignleft wp-image-23311" src="http://martinstellar.com/wp-content/uploads/2020/04/MartinStellar_Coaching_Illustrations-Every-Business-is-a-publishing-business-1024x998.jpg" alt="" width="351" height="342" /></a>

Yesterday I suggested you view yourself as running a relationship business, but today there's another enormouly important POV you'll want to incorporate.

It’s said that every business is a publishing business, but it goes further than that.

Every individual is an independent publisher.

We publish all the time, it never stops.

We publish our thoughts, the food we make and share, we publish our helpfulness and our embrace, we publish our values and our goals and our tweets and our care and concern and strategies and solutions and recommendations...

We're always publishing and it’s all there, for everyone to see, so long as they pay attention.

Now why is it that so many businesses don’t get the attention they deserve - people just don’t seem to pay attention?

Because those businesses don’t make publishing a focal point in their marketing.

They just do it willy-nilly, or as an afterthought, or as 'Content strategy, guys - we need a content strategy!’.

At the far end of doing it <em>wrong</em> are the companies you bought something from 3 years ago, you never heard from them since then, and suddenly they mail you to say 'We’re still open, despite the virus!’.

Yeah, wow. Man I suddenly, instantly, love that company SO MUCH! *clicks unsubscribe*

A little bit better but still not the kind of publishing people really pay attention to:

Companies who only mail their list when they have a sale going on or something new to offer.

And then, there’s pretty much the holy grail of publishing: Seth Godin, who has been sharing a useful idea with his list 7 days a week, for years running.

And while your humble narrator isn’t quite as steadfast as Seth, I can tell you that sending daily emails is magnificently powerful.

It takes 20 to 30 minutes a day, and clients show up to work with me, when they’re ready, and all I need to do is share something that I hope is useful, daily, and publish it.

What could be easier?

Meanwhile, the process automatically creates a library of articles - actual assets - that I can repurpose and turn into books, trainings, slideshows and so on, creating more assets that I can then publish.

So: Whatever it is you do for a living: you’re a publisher.

And whether you write daily, or publish videos on Instagram or Youtube or articles for an industry publication:

It pays dividends to take your publishing seriously.

And that is one of the things I help people with: building a lightweight, easy to maintain publishing strategy that creates visibility, a loyal audience, sales, and revenue.

Are you ready to get serious about publishing your business, strategically, with minimal effort and maximum efficiency?

<a href="mailto:martinstrella@gmail.com">Then let’s talk</a>, and see if we ought to work together...

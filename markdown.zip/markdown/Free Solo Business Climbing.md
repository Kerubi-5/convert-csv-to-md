---
title: Free Solo Business Climbing
status: draft
datePublished: '1580203717'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-22580" src="http://martinstellar.com/wp-content/uploads/2020/01/MartinStellar_Coaching_Illustrations-business-owner-is-free-soloist-1024x768.jpg" alt="" width="348" height="261" />Saw a rock climber on youtube the other day. Nicely strapped in to his harness, helmet on, safely in his ropes.

And then he noticed a guy coming up the wall below him - a free solo climber.

No gear, no ropes - just shoes, shorts, and a bag of magnesium on his hip.

As he passed the first climber, you could see the intensity of his state. Never even seemed to notice the first guy. Completely in the zone. (And you’d better be of course, if you’re hanging off a cliff face with nothing to protect you_.

My point with this?

Most people who get their business to some sort of stability think they’re like climber #1. Things in place, infrastructure, advertising that works, money coming in &amp; being invested…

“Got my helmet, my harness, my ropes… if I play it right, things will continue good”.

Except that’s a mistake. A business owner is as much as risk as a solo climber, in that anything can happen at any moment, that voids your safety or security. I.e. a rock can fall or a rope can break.

Or in business terms: A privacy law like GDPR can decimate your list, or a platform can ban or demonetise you, or a competitor can suddenly show up and start eating up the market you’re in, or a disaster in your personal life can wipe out your finances…

Like a helicopter, a business is inherently volatile - including the big ones (even Jeff Bezos said that Amazon won’t be around at some point).

Now, back to our climbers: the reason the soloist doesn’t fall, is that he relies 100% on his own skills and focus.

And while it’s good to have gear and protection and buffers and infrastructure in your business, never forget that it’s by virtue of your skills and focus that you built, and can sustain &amp; grow, your business.

We all need to build our business assets in order to protect us, but you can’t rest on your laurels, can’t afford to think the rope will catch you if you fall.

Use your skill and focus in business to prevent the fall in the first place.

See yourself as a free solo business climber, and show up with the focus and application of skills required…

… and stay safe…

Cheers,

Martin

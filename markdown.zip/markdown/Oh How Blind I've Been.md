---
title: Oh How Blind I've Been
status: draft
datePublished: '1517237113'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/79d20d0a-2577-438b-94b6-44eb5e1925d1.png" width="350" height="262" align="left" data-file-id="4835413" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/79d20d0a-2577-438b-94b6-44eb5e1925d1.png" />Last week I had a consult with Peter Shallard, the shrink for entrepreneurs.

And I almost wish I hadn’t.

Almost.

Because what I learned rocked my world, and not in an uplifting way.

No, what I learned was harsh. I got to have a cold hard look at reality.

A reality in which I play it safe. Play small.

Which is ludicrous, because here’s the guy always talking about big ambitions… who has to face the fact that he himself actually doesn’t have a big ambition.

I thought I did, but that was a story I told myself.

A story in which I would rise to high levels of personal and professional success… but without enough of the actions that make that success real.

And I discovered why it’s been like that. Which was another insight that wasn’t pretty.

Here’s the deal: I’ve basically been holding back, because so long as I don’t give it my all, there’s no risk of failure.

After all, if I don’t play all out, there’s always tomorrow. Always the hope and chance that one day I’ll make it.

But if I do play all out, and if it turns out that it didn’t work… then that would mean that I’ve failed. And apparently, my subconscious refuses to let that happen.

Just like that person who is always ‘working on my novel’ but never ever finishing it, because at that moment it might turn out to be a flop. And we can’t let that happen, can we.

Yes folks: while I preach ambition and action to anyone who’ll listen, I’ve been confounding myself completely, totally blind to the fact that I fell for one of the biggest traps in the life of a creative professional: playing small so as to avoid the risk of failure. And I didn’t even see it.

And what do we do when we discover we’ve been playing small?

That’s right: we step up our game.

I’ve no idea what that will look like, but I do know that I want to be challenged. Because playing small is not my style.

What about you?

Any areas in business or life where - unbeknownst to you - you’ve been playing small, when that’s actually not what you want?

Cheers,

​Martin

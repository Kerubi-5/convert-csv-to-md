---
title: And Now for Some Good News
status: publish
datePublished: '1584439814'
categories:
  - Relationships
  - Values

---

<img class="alignleft  wp-image-22857" src="http://martinstellar.com/wp-content/uploads/2020/03/MartinStellar_Coaching_Illustrations-Good-news-1024x768.jpg" alt="" width="351" height="263" />I’m interrupting normal broadcast for different kind of message, because in the last few days I’ve been falling in love with humanity.

Normally, Twitter (I don’t spend time on other social media) is a place rife with arguments, polemics, divisiveness and ‘I’m right, and you’re not’. (some of that still goes on, but MUCH less).

But in the last few days, I’ve seen so many people do so many beautiful things, it makes my heart swell.

Some guy, saying ‘If you can’t pay the bills, send me a scan and your Venmo, and I’ll pay them.

Convertkit giving a user $500, because the user was short on money.

A startup opened up a phone service, connecting people in quarantine by phone, for free.

Companies like Zoom and HeySummit giving free access to their platform.

And… well, it’s so much, I can’t even remember all the truly awesome things people are doing for each other. Too much to mention, too much to remember.

And it’s not just on Twitter:

Here in Spain, beautiful things happen too.

Each night at 8 or so, the entire town gets out on their balconies and terraces, to applaud our healthcare workers. Just beautiful.

A guy posting a notice near the elevator of his apartment building, saying ‘if you can’t get out of the house, let me know and I’ll get you your groceries’.

Owners of shops donating facemasks and soap and gloves. And more, much much more.

I never knew I’d see it in my lifetime, but for once, it seems like humanity finally realises that we’re all in the same boat, and it’s best if we all row together.

Or maybe that’s just the treehugger in me thinking that, but: damn, folks. You all are doing wonderfully beautiful things for each other.

I love seeing that. Let’s do more of it, yeah?

Like the song says: accentuate the positive.

Be well.

Martin

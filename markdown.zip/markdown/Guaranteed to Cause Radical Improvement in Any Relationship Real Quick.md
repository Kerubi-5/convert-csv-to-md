---
title: Guaranteed to Cause Radical Improvement in Any Relationship Real Quick
status: draft
datePublished: '1543838316'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"
  - Relationships

---

<img class="alignleft wp-image-21126" src="http://martinstellar.com/wp-content/uploads/2018/12/MartinStellar_Coaching_Illustrations-no-blame-diet_relationships-1024x768.png" alt="" width="355" height="266" />If there’s one thing guaranteed to ruin relationships, it’s blaming other people.

This one doesn’t put the cap on the toothpaste, that one doesn’t eat their veggies, the bus driver acted like a jerk, your boss is an idiot, your father is selfish, your employees underperform, your competitor cheats, banks are swindlers and politicians are liars…

Blame, blame, blame.

A world of people who are ‘doing it wrong’, and: if only they’d get it, and change their ways.

THEN your life would finally become easier.

Well, sorry but it just don’t work that way.

No matter what someone else does, does wrong, or doesn’t do:

You’ll never in a million years change them.

And as long as you blame the other, you’re the victim.

Poor me, suffering at the hands of all those idiots out there.

I say, flip it around.

Instead of blaming others, what about taking ownership?

What would your life be like if you were fully, 100% responsible?

I’m reminded of a navy seal whose platoon (or team, or whatever it’s called in the army) lost a soldier due to friendly fire.

As the leader of the team, he had to think long and hard about what had gone wrong, and there were all kinds of individuals and procedures to blame for the disaster.

But he ultimately realised that as the leader, there was only one person responsible: He himself.

He took full ownership of the problem. No blame, except unto himself.

And that, becoming fully responsible for whatever situation, is a masterful jedi-move.

It doesn’t mean you’re to blame for the situation - it means that you are the single responsible party for creating change or improvement.

It means that you ‘become the problem’.

And when you do that, things change drastically, real fast.

So if your world is filled with people who get to be blamed, I suggest a ‘no blame diet’.

For 21 days, monitor your words, actions, and above all: your thoughts.

Notice how much you’re in the habit of blaming others, and deliberately avoid saying or thinking anything that puts blame on the other person.

Inspire yourself, become the problem, blame nobody (not even yourself), and you’ll find yourself being the author of radical improvement in your relationships.

Do you dare to try?

Because not blaming and taking full ownership, is one of the bravest things we can do.

Do you dare - do you have the guts to go on a no-blame diet?

Cheers,

Martin

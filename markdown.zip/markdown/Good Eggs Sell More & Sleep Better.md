---
title: Good Eggs Sell More & Sleep Better
status: publish
datePublished: '1580123385'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - How to sell your work
  - Psychology in sales and marketing
  - Relationships

---

<img class="alignleft wp-image-22571" src="http://martinstellar.com/wp-content/uploads/2020/01/MartinStellar_Coaching_Illustrations-Good-eggs-sell-more-and-sleep-better-1024x768.jpg" alt="" width="355" height="266" />“We didn’t like that estate agent”, she says. He kept showing us properties that were above our budget - and like, 200K over budget. It was weird”.

Friendly dinner conversation, at Burn’s night with friends this weekend. (Yes, there was haggis, and no: it’s not as bad as people say).

“It bit him in the ass though, because in the end we bought a property through a different agent, and it turned out that Mr. Greedy Agent also had it in his portfolio - but because he never showed it to us, we bought it through someone else”.

And so it is with selling: if you try too hard, if there’s neediness, if there’s greed, it’ll backfire.

It’s quite the opposite to my friend Dick, who’s one of the top sellers in his agency.

His secret? “I sell people the house they want, and make sure they don’t buy the wrong house”.

That’s ethics in selling, it’s looking out for your buyers, and it’s a perfect way to do well.

Good eggs sell more, and they sleep better. (well, they *can* sell more, if you learn how to)

When you’re an ethical person, with a lot of integrity, never make the mistake of thinking that this makes selling (or enrolling buyers) harder - it doesn’t have to be that way and in fact:

If you know your values and you lead with integrity, it makes selling a hell of a lot easier and a lot more fun too.

Want to talk about how that would work in your business?

Let me know…

Cheers,

Martin

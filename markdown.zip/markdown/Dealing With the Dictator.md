---
title: Dealing With the Dictator
status: draft
datePublished: '1516009920'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/6d832a56-9f8f-4d2f-b734-2ed3c281cb22.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/6d832a56-9f8f-4d2f-b734-2ed3c281cb22.png" data-file-id="4835373" />The problem with mind is that most of us don’t know how to use it.

And even if we do know, we often let it use us, instead of us using it.

Not that there’s anything wrong with mind itself - it’s a magnificent tool and we can do many great and wonderful things with it.

But only if we’re in control. Only if we’re master over our mind.

Because if we aren’t, then mind is master over us and it’ll control and dominate.

Which does us little good. A dominating mind burns energy, runs round in circles of thought over and over, doubts itself, second-guesses everything you decide or consider…

In short, being ruled by mind is a messy and unpleasant way to live.

Compare that by having your mind at your disposal, as the powerful tool it is… while listening to your intuition as your guiding source.

I’m not saying it’s easy, but it’s so worth it.

When your instinct and intuition inform your choices, everything changes.

Suddenly (well, gradually instead of suddenly, to be precise) you start to listen to what comes from a deeper level of your being.

It’s hard to explain but believe me when I say that living from the heart, listening to what your heart tells you, makes for a very different experience of life.

Note that here I’m using instinct, heart, intuition, and gut feeling as various descriptors of one single thing: to not be stuck in the head.

The focus you take is fairly arbitrary - whether you call it a higher power or intuition really isn’t relevant to anyone but you - so long as you strive to gain control over your mind.

Because mind is a dictator: the moment something happens that mind doesn’t agree with, it stages a coup, takes control of your emotions and your thoughts, and off you go into things like anger, despair, doubt, self-recrimination, self-sabotage, destructive behaviour… you name it.

So how does one learn to control the mind?

I can’t speak for you, but for me the trick has been meditation. Not as a religious practice, but as a psychological tool for taming the beast.

Now many people will say they can’t meditate because their mind is in the way. They think it’s not for them because they don’t reach those beautiful peaceful states that others talk about.

If that’s you, consider this: those peaceful states might be nice, but in nearly all cases it’s mind thinking of peace. It’s not the real thing.

And more importantly: meditation isn’t about emptying your mind. That’s not the point of it.

The point of meditation is to train yourself to bring your mind back to one particular focal point, over and over and over again.

Each time you try to focus, your mind will wander, and each time that happens, you bring your attention back. That’s what meditation is about, and if you do that daily for a few months, you’ll start to see a very interesting change in how you and your mind relate to each other.

And yes, that takes work.

But consider the flipside: if you don’t learn to control your mind, it’ll control you.

And I bet you’ve experienced how little fun that is.

So… time to regain the control that’s yours to have?

Cheers,

​Martin

---
title: On Marketing, Scarcity and Ethics
status: draft
datePublished: '1488447413'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - How to sell your work
  - Psychology in sales and marketing

---

Comes another question about what is and isn’t ethical in marketing:

Specifically, around the topic of scarcity.

You’ll have seen the offers and pitches:

“While supplies last”.

“Offer ends at midnight”.

“One time only offer”.

So is that kind of thing right? Is it ethical?

It depends.

Of course it’s tempting to create an offer based on scarcity.

And as long as it’s genuine, I don’t see a problem with it.

An artist for example can have a limited edition of prints. Nothing wrong with that. Get one before they’re gone.

But if the artist then creates another limited edition run, that’s where it gets dubious. Limited means limited, and if you are an ethical business person, you have to stick with what you said.

I’ve made offers based on scarcity too.

For example, my 2,5 hour masterclass on marketing: that was $25 before the event, 50 afterwards, and at some point I announced that the price would go up to 100 by a certain date.

But if I were to say ‘while supplies last’, that would be deceitful, because they are videos, and there’s no end to the supply, they won’t run out.

And I could invent another thing that makes it scarce, but why would I?

It’s good to offer something special at a special price, with a limit on time or volume.

But only if the scarcity is real, and not a lie.

Because nobody likes a liar, and there are far too many unethical business people out there. You don’t want to be one of them.

Meanwhile, if you want that masterclass, it’s still available. No scarcity there.

It’s a workshop I gave to a group of artists last year, but the lessons and methods for communication, marketing and selling in it, apply to any (ethical) business.

And you can get the full 2,5 hours here: <a href="https://gumroad.com/l/artmarketingmasterclass#" target="_blank" rel="noopener noreferrer" data-cke-saved-href="https://gumroad.com/l/artmarketingmasterclass#">https://gumroad.com/l/artmarketingmasterclass#</a>

Cheerio,

Martin

---
title: 10 Million Voices | Ain't Nobody Got Time For That
status: publish
datePublished: '1585043953'
categories:
  - Doing it right as an entrepreneur or creative professional
  - Hope&amp;Survival
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-22910" src="http://martinstellar.com/wp-content/uploads/2020/03/MartinStellar_Coaching_Illustrations-Urgency-and-state-management-1024x768.jpg" alt="" width="347" height="260" />Two things I noticed this week:

On Sunday, the world online seemed to have calmed down a little: Twitter seemed slightly quieter, and the online groups I’m in were mostly deserted.

Made me wonder if people were spending the day actually with their families. That would be a nice side effect.

The second thing, and I hope this is useful to you, was a few thought leaders in the entrepreneur space whose discourse started getting a little defeatist. Which I understand, and I don’t blame them.

But.

Everybody has a soapbox these days.

There’s 10 million voices to listen to.

And whether it’s you, or me, or another online entrepreneur:

If you, like some of those others seemed to, end up wondering ‘why bother’ or you’re feeling anxious or depressed… ask yourself who you’re listening to?

Which biases are you consuming, which narratives feed your mind and emotions, which agendas are behind those narratives, and, very importantly:

What emotional reactions and states are being triggered in you?

Because while I don’t advocate living in lala land thinking that all the wrongs in the world will right themselves automatically, I do recommend you keep your mental and emotional state optimal. Fortitude and a healthy, reasonable dose of optimism matter.

And what this outlet or that speaker, this author or that vlogger says, affects your state.

Which brings us to the 3rd thing I noticed, already last week:

I’ve been finding myself saying ‘ain’t nobody got time for that’ a lot more.

Which is a bit harsh, but it's because I feel a sense of urgency. There’s stuff to be done - for myself and my work and for my clients and my friends.

And we all have stuff to do, and nobody ain’t got time for things that take down our state, sap our strength, make us feel helpless or cause us to procrastinate.

Ain’t nobody got time for that.

So the voices you pay attention to: select them with care.

Observe your state, and ask yourself: which voices cause my state to lift up, and which cause negative reactions and dips?

Engage with the people in the first group, and beware of (or eliminate your intake entirely) voices in the second group.

Ain’t nobody got time for that.

Cheers,

Martin

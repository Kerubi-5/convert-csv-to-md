---
title: 'Confucius Say: Man Who Hunt Unicorn, Never Eat'
status: draft
datePublished: '1533627523'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-20680 " src="http://martinstellar.com/wp-content/uploads/2018/08/MartinStellar_Coaching_Illustrations-Unicorn-1024x768.png" alt="" width="482" height="362" />Jim Rohn famously said: “Your level of success will seldom exceed your level of personal development because success is something you attract by the person you become.”

Sounds like a man after my heart, this Mr. Rohn.

Except for the ‘attract’ bit, because you don’t attract success: you create it, one step at a time.

Most people though, try to create success by hunting for unicorns.

“That new website, that’s what will bring me the customers!”

“Learning that new skill, that’s gonna do it!”

“Once I get my husband to stop calling all my business decisions into question, then I’ll be able to really move forward!” (followed by googling a relationship therapist, when they’d be better served with the help of a divorce counselor, because you can’t change others and shouldn’t try)

“I just need to crack the code on SEO/Adwords/Influencer marketing, and then I’ll have a thriving business!”

All of these, and all the other unicorns: nonsense. Won’t work. Some of it might help, but looking for the magic solution won’t get you the real, actual success that you want so badly.

Much better to gradually, slowly, steadily, transform yourself into the kind of person who creates success for themselves.

And the best place to start?

Clear, critical thinking. Followed by making decisions that balance gut-feeling with rational validation.

And I can’t wait to show you my Calibrate Reality framework for doing just that.

Won’t be much longer now…

Cheers,

Martin

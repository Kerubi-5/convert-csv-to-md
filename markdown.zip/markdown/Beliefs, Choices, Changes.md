---
title: Beliefs, Choices, Changes
status: draft
datePublished: '1551266899'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-21428" src="http://martinstellar.com/wp-content/uploads/2019/02/MartinStellar_coaching_Illustrations-Beliefs-and-choices-1024x768.jpg" alt="" width="348" height="261" />Invest or not, cinema or theatre, icecream or chocolate, get married or not… most choices in life are evident.

Other choices though are practically invisible, but they have the biggest effect on life.

These kinds of choices are beliefs.

But wait, weren’t we talking about choices?

Yes we were, and we are.

Because a belief exists because at some point, we decided - we chose - to adopt a certain belief about something.

Beliefs don’t magically install themselves - we choose them, and usually we’re not even aware we’re doing it.

But aware or not, a belief is almost always the consequence of some sort of choice.

A person gets crushed by life, decides to go insane, and actually ends up a looney (strange but true: true insanity can actually stem from choosing insanity)

Another person gets crushed by life and decides to overcome the hardship - and hello, Victor Frankl.

You might give it your all in business, fail one time too many, decide you’re not cut out to be an entrepreneur, and you can spend the rest of your life believing that to be true.

You can choose to see yourself as incessant personal evolution - an infinitely upgradeable system - and you’ll find yourself growing and learning and thriving, just because you live with the belief that you’re made for growth.

Every belief has behind it a choice.

One way to change your beliefs is to analyse what those choices were, but then you get pretty close to psychotherapy.

I find it more useful to ask:

What beliefs do you want to choose?

Cheers,

Martin

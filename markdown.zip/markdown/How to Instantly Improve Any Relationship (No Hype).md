---
title: How to Instantly Improve Any Relationship (No Hype)
status: draft
datePublished: '1532533091'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignnone" src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/6582a94d-b539-47dd-ba7e-1e111cacbd05.png" alt="" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/6582a94d-b539-47dd-ba7e-1e111cacbd05.png" data-file-id="4835953" />This one is so easy, everyone can do it.

But it’s also something that many people don’t want to do. The choice is yours.

If you want to improve a relationship, whether it’s with a spouse, child, business partner, employee or manager or team member:

Stop trying to change the other person.

Oh I know. There’s something wrong with what they do, or say or whatever. And yes, you might be right.

But that’s not the point, because you can’t change someone else, and you shouldn’t try.

For one thing, it signals to the other person that there’s something wrong with them, and the message the other one gets is on the level of identity. And nobody likes to have their identity attacked or criticised.

That by itself will a) prevent any change from happening in the other person (telling someone what to do or how to behave will always cause the subconscious to rebel and object, and b) it’s guaranteed to erode the relationship, if not outright sabotage it.

A fine and beautiful way of putting it comes to us from the late great philosopher and contemporary mystic Alan Watts. (note: if you want to learn about actual real spirituality instead of the modern hippy-dippy pseudo spirituality that’s so popular with the kids these days, look the man up on Youtube. He’ll open your eyes).

Anyway, as a Zen monk and priest, he would often officiate as a wedding celebrant.

And before any marriage took place, he’d always ask if either of the engaged found that there was anything at all, anything whatsoever, that ought to change in the other person.

If either would answer in the affirmative, he’d say that unless this view and desire was let go of, he refused to wed the two people together.

Interesting, no? Someone who’s been chosen as the celebrant of preference, who refuses to give the two lovers the thing they want most… unless they’re willing to accept the other as they are, 100%.

And it applies to all of us. When we want to change the other, or feel that the other needs to change, things won’t end well.

Obviously that doesn’t mean that there’s nothing wrong with the other person.

Someone who is abusive (which can be psychological as well as physical), someone who’s co-dependent, someone who is selfish or addicted or lazy or whatever, might have a real toxic effect on you. (And if you’re in an abusive relationship of any kind: Please, run for the hills, no matter how scary the unknown might seem. Anything is better than an abusive relationship).

And if someone’s shortcomings or defects are a toxic influence on you, then you can either change the nature and dynamics of the relationship (not the same as changing the other person), or move away from the person.

But the one thing you can not do if you want to improve a relationship, is expect the other to change. It just doesn't work, ever.

And you’ll find that the moment you let go of the wish for them to change, something will start to shift in the relationship.

Maybe gradually, maybe impressively, but simply by removing your expectation as to how the other should be, you open up the relationship and change is extremely likely to happen.

Oh, and hey: if you really believe someone should change, have a look in the mirror. Changing self is the best (and only) change you can make…

Cheers,

Martin

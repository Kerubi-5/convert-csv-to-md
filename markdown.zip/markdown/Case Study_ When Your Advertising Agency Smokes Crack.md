---
title: 'Case Study: When Your Advertising Agency Smokes Crack'
status: draft
datePublished: '1499763649'
categories:
  - How to sell your work
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/_compresseds/7d6c4039-04b4-432a-9473-08ca0f4331e8.jpg" width="350" height="262" align="left" data-file-id="4834789" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/_compresseds/7d6c4039-04b4-432a-9473-08ca0f4331e8.jpg" />Lesson time today.

This is an add in the window of a bank here in town - and there’s so much wrong with it, I hardly know where to start.

(I used to write salescopy for a living, so I know a thing or two about advertising).

For starters, the message “Family aspirations” - related to the fact that you can get a Samsung TV financed at no interest.

That’s the family’s aspiration? Ho hum.

But it gets worse.

Is this ad agency trying to say that the family aspiration is to do a goofy dance?

Or that getting a payment plan TV makes you do it?
Next, the design: I’ve walked past this ad every day for the last two months, and it wasn’t until I took this photo that I actually noticed the ad is about a TV.

(In Spain, banks are so desperate to get your business that they bribe people by giving stuff away. I hear that next year, they’ll offer you a free baby with a new account. Or take your current one off your hands, depending on your situation).

But in all advertising and marketing, you have to lead with the benefits, front and center.

I get a TV at downpayments, with 0% interest?

Then throw that message in my face!

Honestly, this ad is a trainwreck, a volcanic eruption, and a failed space mission, all wrapped into one.

The agency who made it (and who pocketed many many thousands of dollars for it) should be fired.

And the advertising genius (a Mad Man he is not) might do well picking up another job.

Pretty cynical stuff, ye?

Well here’s the lesson for you:

Whatever method or materials of advertising you use, never - EVER - go with what you want to say.

Instead, go with what the viewer (your ideal buyer) wants to hear.

Speak of the benefits of buying from you.

Show people that you get them, that you can relate to them.

This ad fails all those tests: what you see here is the result of the agency thinking they’re being clever.

And clever advertising rarely works.

Connect with your people - that’s what works, it’s what makes people feel that you can read their thoughts.

And THAT is why people buy from you.

Anyway. Sometimes people ask me what my work is like - and while coaching is a lot about psychology and transformation and so on, the fact that I cut my teeth creating copy and marketing strategies for people means you don’t just get a coach who helps you on a personal level: I *get* business, from the inside out - so I can help you with that as well.

So if you want both, just holler.

Cheers,

​Martin

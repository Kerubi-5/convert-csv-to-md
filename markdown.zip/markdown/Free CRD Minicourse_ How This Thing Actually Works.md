---
title: 'Free CRD Minicourse: How This Thing Actually Works'
status: draft
datePublished: '1541413930'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21061" src="http://martinstellar.com/wp-content/uploads/2018/11/MartinStellar_Coaching_Illustrations-Question-everything-1024x768.png" alt="" width="348" height="261" />I thought it might be useful to explain what this Calibrate Reality Dojo framework is really all about.

You know, in case you didn’t make it to the webinar last week.

So over the next 9 days, I’ll be highlighting each individual pillar.

Think of it like a mini-training...

The premise of CRD:

Everybody can, and ought to, live with effortless mastery.

Without it, we get stress, procrastination, bad outcomes, and generally a life that doesn’t feel like we have any control over.

But with effortless mastery, we get to be creative and resourceful, we get excellent outcomes, and we work in effective and efficient ways.

I built CRD to help you make that real, with three simple modules:

Module 1: Think and decide like a CEO.

Of which pillar 1 is: question everything.

The simple fact is, successful people take time to think things through.

They know the importance of giving proper, rational thoughts to things.

Because if we don’t, we sorta guess at the best choice in any given situation, and since we’re guessing, those choices often don’t get us the desired outcomes.

And to make thinking properly easier, the first thing - a ninja-move of sorts - is to question everything.

Question your views, your interpretation, your beliefs. Question your why, question the data, question your VA and your designer and your clients.

Question 'reality'.

Never take anything for granted, and never take anything at face value.

What you take for granted could hide a data point that could make all the difference in your business, if only you stopped to look at it, to think about what that thing actually is. And can also be. And also, and also.

Everything is many different things at the same time.

The ‘face value’ vision you get of it, that’s just the first convenient interpretation of what the thing is - not the thing itself.

So, don’t stop there, but think about what else it may mean, be, represent, or tell you.

We live in a world of millions of impulses coming at us relentlessly.

Our brain can’t help but filter out a tiny set of impulses, so that we get to interact with the world in a way that doesn’t drive us insane.

Given that fact, it’s not only arrogant, it’s also outright foolish to operate under the assumption that our view of a minute amount of data coming in from the world, is an accurate representation of what that entire world is, does, or means.

What we know about the world is, factually, incomplete. And in most cases: pretty erroneous as well.

That’s why questions are the answer, and the more questions you pose yourself, the greater your clarity and insight will be, which enables you to make better decisions.

And since decisions are the cornerstone of how your individual life shapes up, better decisions is the road to a better life and more prosperous business.

But before we get to decisions, first we need to look at the precondition for good decisions:

Sensible, reasonable, logical thinking.

Which is a lot more fun than you might think, so stay tuned for that tomorrow…

Cheers,

Martin

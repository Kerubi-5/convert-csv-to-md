---
title: Lean on Me
status: draft
datePublished: '1483602403'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

It doesn't happen very often, but today I have nothing to say.

Reason being: my client, the wonderful and talented Robbie Kaye posted something on her site.

It took all my words, so today I leave it up to Robbie:

###

LEAN ON ME

As an athlete, now retired, I’ve had several coaches and what I found is that the good ones made me want to work harder, push my limits beyond what I thought I could do.

I trusted them to catch me as I flung my body through the air twisting and turning and searching for the ground.

They instilled a kind of discipline I had to learn.

I needed that extra push.

Fast forward 42 years.

I’ve been pretty forthcoming about my struggles as an artist and the fears I’ve had about moving forward.

I guess you could say I hit rock bottom… I lost belief in my artistic work and myself.

I knew I couldn’t do it myself anymore and I needed help.

Feeling stuck was a normal state of mind…until I met Martin.

Martin Stellar is my coach.

In almost a year of working with him, I have unlearned some really bad habits and beliefs, which was and continues to be necessary to learn how and when to get out of my own way on this beautiful path of life.

Martin is a coach for entrepreneurs or anyone who seriously wants to sculpt a better life.
<div></div>
<div>

He is the kind of coach who goes deep and makes it safe to go deep too.

It’s pretty amazing to have a place to go where you feel that safe.
<div></div>
<div>

This is not always a feelgood session type of thing, there are growing pains and lots of work.
<div>

You may have seen on my <a title="" href="https://www.facebook.com/robbiekayearts/" target="_blank" rel="noopener" data-cke-saved-href="https://www.facebook.com/robbiekayearts/">Robbie Kaye Arts FB Page</a><a href="https://www.facebook.com/robbiekayearts/" target="_blank" rel="noopener" data-cke-saved-href="https://www.facebook.com/robbiekayearts/">,</a> artists and their work from around the world.These artists are in a mastermind group that Martin put together called “The Cabal.”

I was invited and get to be in this amazing group too.

The Cabal is my support team, my mirror and comrades and will tell it like it is… just like Martin and he is there too.

Now, because it is the beginning of a New year and I am far enough along so that I can look back and see how far I’ve come, I wanted to share these life-changing opportunities in my life.

If something like this appeals to you, you can contact Martin at <a href="mailto:mailto:martinstrella@gmail.com" target="_blank" rel="noopener" data-cke-saved-href="mailto:mailto:martinstrella@gmail.com">martinstrella@gmail.com</a> or get his inspirational emails and sign up <a title="" href="http://martinstellar.com/" target="_blank" rel="noopener" data-cke-saved-href="http://martinstellar.com/">HERE</a><a href="http://martinstellar.com" target="_blank" rel="noopener" data-cke-saved-href="http://martinstellar.com">.</a>

</div>
<div></div>
<div>

I almost don’t want to share him, but I will!

This isn’t about a New Year’s resolution; this is about someone helping you grow those wings as you jump, ready or not, making lasting and conscious change.

</div>
<div></div>
<div>

I’m still growing mine!

I hope your new year is off to a peaceful and productive start.

Take care of you,

Robbie

</div>
</div>
</div>
###

So yeah, clearly I have nothing to add to that.

Other than: Thank you Robbie. It's amazing to see how hard you work and challenge yourself.

As for you, my dear readers: if you want to be part of this small elite team of change makers, here's info on how The Cabal works, plus a link to apply for membership.

Cabal details here:  <a href="http://martinstellar.com/cabal-group-coaching-action-takers/" target="_blank" rel="noopener" data-cke-saved-href="http://martinstellar.com/cabal-group-coaching-action-takers/">http://martinstellar.com/cabal-group-coaching-action-takers/</a>

Cheers,

Martin

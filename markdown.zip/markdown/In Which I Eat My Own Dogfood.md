---
title: In Which I Eat My Own Dogfood
status: draft
datePublished: '1486982885'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

“Will you also be talking to the press?”, he asked me.

I blink, and stutter: “I’m not sure. Nobody asked me”.

He tells me to talk to the organiser of the press conference, surely they’ll allow me.

This was last Friday, and the press conference was to present a series of lectures and workshops in Granada, with the specific intention of helping musicians live off their music. If you read last Friday’s missive, you’ll know that I’m one of the trainers there.

So I walk up to the organiser, and ask her if she wants me to say a few words too.

But it’s a busy moment, and some confusion arises: While I wanted to know if she wanted me to speak, she thinks I’m asking if I’ll be allowed to.

“Sure Martin, if you want. I’ll call you to the mic. Si?”.

At that moment, my lizard brain wakes up, and instantly panics.

But your Spanish is rickety!

You didn’t prepare anything!

And there’s journalists here!

Camera’s!

Erudite teachers!

Highly placed politicians!

Earthquakes, zombies, hurricanes, cosmic apocalypse and a lifetime of inferno that would have Dante nod in approval!

My knees shaking, but my voice steady, I smile at her and say: “Yes, I’d be happy to”.

And I meant it, even though the moment I stepped up to the mic I was dead-nervous and stayed that way throughout my little talk.

The point being?

I was exceedingly uncomfortable doing this, and that’s exactly the reason I did it.

After all, it’s very good for me to tell you that stepping out of your comfort zone is important and pays off, but it’s meaningless and hypocritical if I don’t do it myself.

And so, I served me up a nice plate of my own dogfood, and I ate it.

And yes, of course you’ve heard it a million times before: do the scary stuff.

Get out of your comfort zone.

Because hearing it and knowing it isn’t enough.

It’s in the doing it that you find the magic.

So, I’m curious:

What’s the scary thing that you wish you’d do, but you don’t?

Let me know, maybe I can give you a few pointers to make it easier.

Cheers,

Martin

<!--End mc_embed_signup-->

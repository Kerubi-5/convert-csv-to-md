---
title: About You...
status: publish
datePublished: '1546540917'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"
  - Relationships

---

<img class="alignleft wp-image-21220" src="http://martinstellar.com/wp-content/uploads/2019/01/MartinStellar_Coaching_Illustrations-Making-it-about-you-1024x768.png" alt="" width="353" height="265" />One of the easiest ways to miss out on getting outcomes with people?

Making it about you - and we all do it.

Truth is, It’s never about you.

Your potential buyer isn’t interested in the bills you need to pay. They just want to get a job done or a problem solved and they’ve got money for it.

But if there’s even a hint of neediness in your approach - if you make it about you - you’ll break trust and they’ll go elsewhere.

You might know for a fact that education X is going to be awesome for your child, but if they go for it because of your persuasive powers instead of their own desire, they’ll likely loathe it and/or drop out.

You’ll have made their path about you and your views, and not about them and their future.

Your course, project, training, art or book might be radically life-changing - but it’ll only have that effect on others if you sell it for the purpose of changing the life of others first, and that of yourself second.

No matter how good our intentions, your point of origin matters a lot when it comes to those intentions becoming real.

It’s easy to drive on with our point, because we think we know what’s best.

But even if we’re right and we do know, insisting on or enforcing our views makes it about us, making the other you’re doing it for, tune out.

Whatever result you want to achieve with someone, be it in a business or personal context: make it about them. You’ll get a lot more done with people, including signing on buyers for your coaching or consulting services.

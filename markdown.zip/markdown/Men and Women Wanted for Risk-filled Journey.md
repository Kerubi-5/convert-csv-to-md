---
title: Men and Women Wanted for Risk-filled Journey
status: draft
datePublished: '1524769081'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/8b9e1468-2e69-4e05-8422-9f29d85021b4.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/8b9e1468-2e69-4e05-8422-9f29d85021b4.jpg" data-file-id="4835669" />
Men and women wanted for risky journey…

Extreme commitment required, long periods of doubt and second-guessing, constant risk. Success as likely as complete failure. Wealth and recognition in case of success.

Reply to learn more.

Cheers,

​Martin

---
title: Does That Help?
status: draft
datePublished: '1500543872'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/2943fb19-86a7-4f25-89d0-fea0d131a18e.jpg" width="350" height="406" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/2943fb19-86a7-4f25-89d0-fea0d131a18e.jpg" data-file-id="4834825" />It’s easy to tell yourself that you’re doing it wrong, that you’re stupid, or lazy, or lack skills or that you tend to procrastinate.

And most of us will tell ourselves things like that.

I know I do.

But ask yourself:

Does that help?

“I don’t like selling”.

Does that help?

“I’m too introverted to create a network of interesting people”.

Does that help?

“I have a habit of negative self-talk”.

Does that help?

The answer is, of course, no. No it doesn’t help.

So what to do instead?

Well, back to baseline thinking:

As you are now, you’re perfect.

Ah, oh - but there are things you want to change or improve! Good stuff!

Then tell yourself a different story.

For example: “I want to learn how to sell my stuff in a way that doesn’t feel icky”.

More helpful, yes?

Or: “I want to get more productive”.

“I’d like to meet interesting people in a way that doesn’t require me to do ‘networking’”.

Get the picture?

Core notion: the stories we tell ourselves either help or hinder us.

So when you notice negative ones, ask yourself: “Does that help?”.

Next, tell yourself a story that actually helps.

Which I can help you with, if you’ll accept my invitation for a no-cost strategy session.

You can do so by answering a few questions, here: <a href="https://martin283.typeform.com/to/v7Dsh8" target="_blank" rel="noopener" data-cke-saved-href="https://martin283.typeform.com/to/v7Dsh8">https://martin283.typeform.com/to/v7Dsh8</a>

Cheers,

Martin

---
title: A Few Select Individuals...
status: draft
datePublished: '1545649958'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21187" src="http://martinstellar.com/wp-content/uploads/2018/12/MartinStellar_Coaching_Illustrations-ownership-airways_grace-and-ease-1024x768.png" alt="" width="351" height="263" />Saying ‘nothing changes if nothing changes’ is nice, but incomplete.

Better would be ‘nothing changes if *nobody* changes’.

The easy option is expecting others to change (with the additional entitlement bonus of getting upset when they don’t. Double win).

Who&amp;how you were is what got you here, and you’ve probably already experienced that this iteration of you has run into its limitations.

But if you decide to change (change yourself, not other people) you’ll find that the you that you’ll be, will get you more, new, different, and better things.

The mistake most people make is ignoring that ‘change the self’ bit, and instead try to change external factors: people, marketing, website, reactions, team members… you name it. Anything other than ‘self’, please.

I promise, it won’t get you what you want. At best you’ll get a small set of the outcomes you want, but not all of them.

But if you make it your mission to change yourself instead of other&amp;external, you’ll find that you get exactly what you want, because you’ll be adjusting your self, vision, goals and desired outcomes, in alignment with the way things develop.

Which means you might end up with a Blue Maserati instead of a red Ferrari, but hey: Sportscar, right?

When you make your mission to change the external, you’re imposing your will on the world, and I’ve found the world is entirely aloof of whatever the hell we happen to want. The world just doesn’t give a damn, and tends to show us more resistance, the more we try to change it.

But work with what the world shows you, and allow yourself to flow through the experience of discovering how to get the most out of what you have at your disposition?

Magic. Promise.

Want to experience what that’s like?

Then maybe 2019 is the year where you’ll get me to show you how to do it: to move effortlessly through life and business, with a clear sense of direction, execution on exactly the projects and tasks that will get you the results you want,
and the uncanny experience that hey, you got this down pretty good.

Want?

Holler.

Cheers,

Martin

P.s. I’m looking for a few very select entrepreneurs to work with starting January. This is in the form of an in-depth, virtually unlimited coaching programme that runs for 3 months.
It’s intense, and while it’s a sizeable investment in increased well-being and business results, it happens to be extraordinarily effective for the right person (i.e. one who takes full ownership of behaviour and actions and wants to not make the mistake of expecting others to fix things).
Let me know if that’s you, and we’ll have a chat to see if we’re a good match.
Incidentally, 'a few select individuals' is entirely accurate. There's VERY few people in the world who are actually gutsy enough to exclusively look for solutions within self. Apply if applicable.

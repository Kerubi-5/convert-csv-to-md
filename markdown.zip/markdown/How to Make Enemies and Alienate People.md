---
title: How to Make Enemies and Alienate People
status: pending
datePublished: '1619687846'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-21860" src="http://martinstellar.com/wp-content/uploads/2019/07/MartinStellar_Coaching_Illustrations-How-to-make-enemies-and-alienate-people-1024x768.jpg" alt="" width="351" height="263" />Saw two examples of how to network with people, at an event in Malaga a while ago.

One good, and one disastrously wrong.

Before the socialising part, each of us got one minute to pitch our business from the stage.

Afterwards, I was accosted - literally - by a Spanish business owner.

She came up to me, introduced herself, and without pause launched into an endless, aggressive salespitch.

How her co-working space is this and that, how there’s seminars and a virtual mentoring programme... on and on.

I couldn’t get a word in edgewise.

Not even to say that I have no need for any of it, because my friend Antonio runs his own co-working place, and I get everything she offers and more, for free, at his company, each time I go to Malaga.

Silly of her, because acting this way was nothing short of repellent.

Compare that to the second experience:

Guy comes up and tells me that my pitch really interested him.

And, would I mind if he gave me a little feedback, and a tip on how to improve my presentations?

Look what he did there: he built rapport (in a sincere way, I could tell he wasn't faking it) and then asked me permission to give feedback.

Next he told me something useful, and invited me to stay in touch.

Effectively, he sold me on liking him, and on wanting to meet again.

Obviously, he's hoping to get business out of me at some point - every business owner is.

But the way he did it pulled my closer, whereas the lady drove me away.

Now, I imagine that you're far more like that guy, than you are like that lady.

I imagine that if you read my stuff, you probably like to give value, and listen, and try to attune to what others experience and need.

But what if all that doesn't land you the clients you want?

What if you don't manage to get paid what you're worth?

Or, what if you do, but you just really don't like the sales process?

And, what if you want to do something about it?

Then I can help.

More information <a href="http://martinstellar.com/helping-good-people-sell-more-and-generate-a-bigger-impact/">here.</a>

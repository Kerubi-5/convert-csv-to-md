---
title: Buyer Objections and the Dreaded No... What if It's an Invitation?
status: publish
datePublished: '1652137433'
categories:
  - Ethics and marketing
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-21636" src="http://martinstellar.com/wp-content/uploads/2019/04/MartinStellar_Coaching_Illustrations-Buyer-objections-and-the-dreaded-no-1024x768.jpg" alt="" width="355" height="266" />

The other day, someone said: “When a buyer tells me no, or that they don’t have time to talk about my offer, I’m not really sure what to do.

“Usually, I default to trying again, push a little harder, try a different angle”.

Yesterday, someone else said: “When they tell me no, I just consider it a lost sale”.

Option 1, going in harder, will rarely work.

If a buyer objects, at whatever stage and for whatever reason, there’s some sort of fear going on, somewhere on a deep psychological level.

It’s the buyer's lizard brain signalling ‘danger’.

And if you then press on, you’re only confirming to the lizard brain that it’s correct in warning the buyer of some sort of risk (even if it mistaken), and objections and resistance increase.

Option 2 - walking away from the sale - obviously doesn’t help either.

But what about a middle way?

What if someone’s objection or refusal isn’t a rejection, or the end of the conversation - but instead it’s an invitation?

What if you use the no as a starting point for a different line of conversation?

What if the no is an invitation for you... to ask a question?

After all, a no means there’s something going on that prevents the yes - so why not try and figure out what that thing is?

Like so:

Buyer says “No”.

You: “Excellent, thanks for telling me”.

You now know where you stand, and where they stand. And, you’ve honoured their stance graciously.

Next, you ask a question. For example:

“Can you tell me in what way the offer doesn’t meet your needs?”

Or: “Quick question: What would make it a yes?”

Or: “Shall I follow up with you at a later date, when you have more time?”

Or: “Is there anything else I can help you with?”

Or: “Would you like me to point at some resources that might help you solve XYZ? There’s a few books I know that might be useful to you”.

And if none of these seem appropriate, why not ask for an introduction?

“Anyone come to mind who might be interested?”

See, the no can never be met with force.

It’s not nice, and not effective - not unless you’re a pushy seller, and who wants to live in the 80’s anyway?

The no doesn't have to be the end of a conversation, not if you keep the conversation open.

And you do that by asking questions.

<hr />

On another note:
I'm building an app that coaches you on working your pipeline, moving your deals forward - and closing them faster and at better rates.
It's called SalesFlow Coach, and we're scheduled for beta-release early May 2022.
Register <a href="https://martinstellar.com/salesflow-coach-launch/">here</a> to be notified when it goes live.

&nbsp;

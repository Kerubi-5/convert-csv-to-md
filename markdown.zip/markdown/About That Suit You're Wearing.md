---
title: About That Suit You're Wearing
status: draft
datePublished: '1509976871'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/085e4955-dd2a-43fe-a152-35528fd74309.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/085e4955-dd2a-43fe-a152-35528fd74309.jpg" data-file-id="4835173" />Let’s look at sanity and sanitation for a moment, because they’re related in a way that most people overlook, and they will make or break your days, your life, and your success.

See, most people wash their clothes with a certain frequency. It’s the sane thing to do, and it’s a healthy thing: Keeping your clothes sanitised is a good way to keep bacteria and germs from making you ill. And it’s a better look than unwashed garb. With me so far?

Cool. Then why do so many people never ‘wash’ the attitude-suit they wear?

How come so many people just keep using the same mode of thinking, the same perception of the world, the same self-view… without ever updating, washing, or replacing it?

It’s like they’re given a suit (in this context, think of it as a role you play, or an attitude you ‘wear’) when they’re 18 or so, and that’s all they have.

Johnny gets bullied in school, he learns how to play the victim role, and for decades that’s his ‘suit’.

Lisa learns that helping others has benefits, even if it’s at the cost of her own well-being, and so she wears the martyr role, all her life.

Luke becomes a success as the highschool football team’s captain, and all his life he is in control, running teams, giving orders - but never learning how to properly listen to his employees.

Martha was successful as a young secretary, and stayed in that role all her life - even though her compassion, drive and intelligence qualify her to be the CEO of a major company.

And yet, all these people just play the same role, all the time. They *could* live a different life, and it wouldn’t be all that difficult… except they’re so used to wearing the same suit, it just never occurs to them. Or it seems impossible.

And that just isn't sanitary: to always stay stuck in the same role. And once you know that all day and each day, you get to choose the suit you wear, it's pretty insane to stay with one that's outlived its use.

So, look at yourself and your attitude and the role you play in life.

And ask yourself: how long have I been wearing this suit? Isn’t it time to take it to the laundromat? Or maybe take it off and burn the thing? Wear something else?

Something that enables you, empowers you, opens up doors and possibilities?

Exactly. Time to take a trip to the laundromat, wouldn’t you say?

Oh and… if you want a new ‘suit’ to wear, why not have this ex-tailor (true fact) help you design one that’s the best choice for reaching your goals…?

Cheers,
Martin

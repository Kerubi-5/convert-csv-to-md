---
title: 'Announcing Live Training: Helping Good People Sell More'
status: draft
datePublished: '1599813519'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - How to sell your work
  - Values

---

Tl;dr:

Next Thursday at 2PM CEST / 8AM Eastern, I’m co-hosting a live training session on ethical selling, with Will Saunders of Good Will Studios.

You can <a href="https://www.eventbrite.com/e/helping-good-people-sell-more-tickets-120176756915">register here.</a>

----------------

<a href="http://martinstellar.com/wp-content/uploads/2019/03/MartinStellar_Coaching_Illustrations-Selling-as-an-act-of-service.png"><img class="alignleft wp-image-21491" src="http://martinstellar.com/wp-content/uploads/2019/03/MartinStellar_Coaching_Illustrations-Selling-as-an-act-of-service-928x1024.png" alt="" width="349" height="385" /></a>Have you ever noticed how the more integrity someone has, the more difficult it becomes for them to enroll buyers?

Makes sense, for purpose-driven business owners:

We know that our work makes a difference and we love it when people buy - but we just will not go against our values.

And thus, we don’t enroll as many people as we could, and the impact of our work doesn’t reach its full potential.

I call this the ‘good egg problem’: we want to do our work, but our values prevent us from actually getting the sales.

I too used to struggle with this: I’m an ex-monk, and integrity and ethics are non-negotiable for me.

So then how do I grow my business, while keeping my values intact - what’s the trick?

Over time, I figured it out.

The ‘trick’ is in selling more because of your values, not despite them.

That’s what sets an ethical business owner apart from all the others.

People like us, the enrollment process we use should be based on ethics, values, empathy, and integrity.

And when make your enrollment process revolve around the other person - when you turn the sales process into an act of service - not only will you be able to sleep at night, you’ll also see more

people signing up for your work.

It took me years to figure out how to do this, and these days I coach and train ethical entrepreneurs on how to make selling, growing revenue and increasing impact a natural, fun, humane thing to do.

In the end, I decided to codify my method into the LEAP Ethical Selling Framework.

And with the support of Will, founder of Good Will Studios - a '<a href="https://www.goodwillstudios.com/branding">branding for good</a>' creative agency - I’ll be teaching the framework live, on the 17th of September, at 2PM CEST (8AM Eastern).

We’ll take 30 minutes to show you how the framework goes together, and afterwards there will be time for Q&amp;A.

Here’s what you’ll learn:
<ul>
 	<li>How to have enrollment conversations that everybody enjoys, and that people will even thank you for</li>
 	<li>How to take the awkwardness out of selling, by making it all about the other person</li>
 	<li>Why ‘closing a sale’ is a losing proposition, and why you want to ‘open’ things up instead</li>
 	<li>Why you must always lead with no, so that the buyer never feels pressured or forced</li>
 	<li>Why empathy and integrity combined make for a sales conversation you can be proud of</li>
 	<li>How to enroll clients with ease and grace</li>
 	<li>How to sell your work while staying true to your moral and ethical values</li>
 	<li>How to have sales conversations that are fun and 100% free of pushiness or manipulation</li>
 	<li>How to get inside the mind of your buyer, so that they'll see you as a trusted advisor instead of a seller they need to fend off</li>
 	<li>How to have sales conversations that create clients exactly because the conversation itself is an act of service</li>
 	<li>How to reduce objections and build trust automatically</li>
 	<li>How to increase your conversion rate</li>
 	<li>How to sell your work at higher fees</li>
 	<li>How to earn more money and generate a bigger impact with your work</li>
</ul>
Join us on the 17th for a fun, interactive session that will radically transform the way you view and handle that whole dreaded selling thing…

<a href="https://www.eventbrite.com/e/helping-good-people-sell-more-tickets-120176756915">See you there!</a>

Cheers,

Martin

---
title: Making Time for Our Most Important Roles
status: publish
datePublished: '1577964651'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - How to sell your work
  - Psychology in sales and marketing

---

<img class="alignleft  wp-image-20860" src="http://martinstellar.com/wp-content/uploads/2018/09/Favorites-1-of-4-1-1024x768.png" alt="" width="351" height="263" />I often talk about ‘the suits we wear’ - the different roles we play depending on the context we’re in, or the task that’s at hand.

One of the fastest and easiest ways to create a sense of purpose, achievement and well-being - and to actually make results happen - is to get very conscious of these roles, and get very deliberate and intentional with them.

Because there’s a ton of them that we use - suits we wear - throughout our days: the seller, the writer, the listener, the bookkeeper, the courier, the self-carer, the student…

This can be either massively helpful, or dreadfully destructive, and the difference lies in intentionality.

Because most of the time, we jump from one role to the next as the situation seems to demand - like we’re multitasking our way through different ways of operating and showing up.

And that switching from one role to the next, that’s very costly in terms of our mental and emotional energy.

And, it slows us down because with each switch, we need to adjust and settle in, which can easily take 20 or 30 minutes.

Switch three of four times in a day, and and you lose an hour or more of your day - and most of us are switching all the time… no wonder we feel so drained and ineffective at the end of a day!

So to get the most out of all you got, consider the three main roles, and plan time for each:

There’s the Maker, who executes on tasks, gets jobs done, checks things off. That’s the creative, productive role, the one that produces output and tangible assets.

There’s the Strategist, who analyses the status quo, assesses the playing field, and who creates and schedules plans, develops hypotheses and tests in order to improve operations.

And, very importantly, the Strategist lays out the work for the Maker, who loves that because the Maker doesn’t want to think, plan, or decide - the Maker just wants to know what nail needs hitting next, so that he can get on with it
and get jobs done.

And then there’s the third main role, which I’ll call The Performer, though that’s not an ideal label.

But the Performer is the one who shows up, delivers a talk or a pitch, who publishes videos and articles, who writes books and teaches and coaches and trains:

It’s the public-facing side of your brand and business.

Each of these core three roles need attention, and space blocked out in your calendar.

Because these roles are essential for building and growing a business - for anything in life that you want to achieve, really.

I mean, you’ll never catch that flight unless you spend at least some time, and yesterday’s dishes tend to not get done unless we call in the Maker.

That’s why I like to see these roles as distinct identities I can step into, and I make sure I plan time for each of them.

And if ever you find yourself struggling, or annoyed that things aren’t working, ask yourself:

Is my Strategist getting enough time, and doing a good job?

Is my Maker supplied with outlined workplans, and given time to make things?

Is my Performer (or Artist, or Teacher, or Coach, or whatever is your ‘show-up’ archetype) getting out there enough, and am I creating enough time for him/her?

You’ll notice that each question includes ‘time’, and you’ll likely find that one or more aren’t getting dedicated, intentinally planned time, but instead are being given the scraps of the calendar.

Switch that up, block out time for that role, and watch what changes.

Should bring interesting results, so let me know if you anything cool happens…

Cheers,


Martin

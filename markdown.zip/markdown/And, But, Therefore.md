---
title: And, But, Therefore
status: publish
datePublished: '1637658326'
categories:
  - How to sell your work

---

<img class="size-medium wp-image-27942 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/08/MartinStellar_Coaching_Illustrations-And-But-Therefore-300x225.jpeg" alt="" width="300" height="225" />You may have heard me talk in the past about the importance of rephrasing or restating a buyer’s problem - the idea behind it, that if you can formulate somebody's problem better than they could, they automatically credit you with having the solution.

Which makes sense, because if you can really sum it up very concisely, then obviously you get them.

And that “They get me!” is what makes a buyer want to know more about working with you, or makes them want to buy from you.

But how do you do that?

How do you actually create that message, on the fly, in a conversation?

Real simple:

I heard a guy on a podcast called Randy Olson, and he talks about the ABT framework, which is:

And, But, Therefore.

The framework actually comes from the makers of South Park - they've been using it for years to create their stories and episodes.

And in my case, an example would be like this:

“I work with coaches and consultants who are on a mission to do something positive with their work - they are purpose and mission driven.

“And, they have a high degree of values and integrity.

“But that means that very often, they don't manage to land the client, because they don't want to compromise on their values.

“They don't want to be spammy, or unscrupulous, or scuzzy or scammy or pushy, and so they lose out on sales, because they don’t have the sales conversation or the money conversation, or they don’t follow up.

“Therefore, I created a framework for ethical selling, which is based on integrity, ethics, and empathy, and it really helps high integrity entrepreneurs to land more clients.”

Simple, no?

And, But, Therefore.

I strongly invite you to look at his framework, maybe read up on it a little bit, and see how you can use that for your own work.

And, when you're talking to a buyer, and they are describing their situation, listen for the And, But and Therefore statements that they make - so that when your time comes to say “So what I’m hearing you say, is…” you’ll know exactly how to wrap up their situation in a pithy statement that gets them feeling “They get me!”

Want to have a conversation about your own sales conversations, and how to make them land you more buyers, at better rates, without ever compromising on your values?

Pick a time here: https://calendly.com/martinstellar/20min


Cheers,

Martin


&nbsp;

---
title: Evict the Lodger
status: draft
datePublished: '1501234238'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/f43fe445-9566-4ee9-b372-cbee55cb38a7.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/f43fe445-9566-4ee9-b372-cbee55cb38a7.jpg" data-file-id="4834857" />Sometimes, it’s like there’s a lodger stuck in our heads.

That voice you hear, saying you can’t make or aren’t worth it or that it’ll never work.

That others have it better or that your life isn’t working.

Or whatever other story the lodger seems to be telling you.

But that voice, the self-talk, the story you tell yourself: that’s under your control, you know?

There’s no rule or biological or psychological that says you need to put up with that abuse.

Because let’s face it: that kind of negative self-talk is abusive.

You wouldn’t take it from someone else, so why would you take it from yourself?

Don’t put up with it.

Evict the lodger.

Instead of letting that voice talk you down, shut it up. Get rid of it.

How?

Well, not by trying to not hear it, that won’t work.

The most effective way is to replace that negative story with a new one.

Fill your head with another narrative, one that says that you CAN do it, or that your success will show up, or that your business will grow, if only you keep plugging away at it.

Don’t fight the lodger - simply put so much ‘other story’ in your head, that there’s no more space for him or her.

That’s how you evict the lodger.

But if this is proving too difficult, if the lodger is too persistent, I’ll help.

Just answer a few questions here, and I’ll give you a no-cost coaching session.

We’ll evict your lodger together: <a href="https://martin283.typeform.com/to/v7Dsh8" target="_blank" rel="noopener" data-cke-saved-href="https://martin283.typeform.com/to/v7Dsh8">https://martin283.typeform.com/to/v7Dsh8</a>

Cheers,

Martin

---
title: Never Get Good at the Small Tasks
status: publish
datePublished: '1532685795'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/f781d7c2-001e-4a53-8c86-45412b008f9f.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/f781d7c2-001e-4a53-8c86-45412b008f9f.png" data-file-id="4835961" />In any given day or week, how many of your tasks and activities should actually not be done by you?

Unless you have a team working with (and even if you do), there’s going to be a ton of things that need to be done, but they’re the little things, the day-to-day.

Scheduling posts, filing paperwork, replying to low-importance emails (as opposed to high-importance customer inquiries), updating your website… heck even doing the dishes or washing the car.

Most entrepreneurs (even successful ones, and even those who do have a team) will automatically default to ‘taking care of business’ kind of tasks.

The smart ones know that automating and systemising things makes those things faster and more efficient. So far, so good.

But, not perfect.

Because when we optimise and automate the small tasks, we end up being very skilled at the small stuff - and no matter how automated, we’re still required to monitor, tweak and improve them over time.

And that means we become a kind of micro-manager of ourselves, on small things that don’t make a big difference in our business. They’re necessary, but they don’t cause growth - they just support growth or prevent it from slowing down.

I heard about this ‘small jobs’ concept from James Schramko (seriously smart business thinker - you’ll do yourself a favour by listening to his various podcasts).

He used to sell luxury cars (ethically, from what I can tell - not your typical car-salesman), and one of the tasks in his week was to cut rubber floor mats to size (boggles the mind why that would even be necessary for luxury cars, but hey), until one day someone in the dealership said: ‘Never get good at the small jobs’.

So simple, so useful.

Me, I’ve decided to not even deal with the small tasks any longer. I’ve finally decided to hire a virtual assistant, because really it makes no sense for someone who can deliver powerful transformational coaching, to deal with day-to-day (required) trivialities.

It’s why hired a cleaning lady before I could ‘afford’ it. It’s why my new VA is going to scout for a publicist who can get more views on my work, because hunting the job boards for the right candidate is not my forte and in terms of the work I should be doing, a waste of time.

If you’re an artist, get yourself a studio assistant, if only for one morning a week.

If you live in an area where dust or vegetation messes up your car, don’t wash it yourself but have your friend’s son do it for some pocket money.

Get yourself someone to handle your taxes, someone to mow your lawn… whatever you need to get done that doesn’t either bring you real joy, and/or doesn’t contribute to the growth of your business.

Now, you might think that you can’t afford to but remember this: your time is worth more than what someone else earns for simple and small tasks.

Thinking that you’d better keep the money and do it yourself is scarcity thinking, but worse: it robs your business of the supervaluable hours you could be putting towards actually growing your venture.

And you don’t want to steal the most valuable work from your own business, do you?

&nbsp;

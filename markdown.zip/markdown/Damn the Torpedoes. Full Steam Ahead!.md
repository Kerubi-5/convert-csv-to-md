---
title: Damn the Torpedoes. Full Steam Ahead!
status: draft
datePublished: '1484645720'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

So far, I’ve only told three or four people what my upcoming book will be about.

			No public mention, no drumming up attention...

			Because: “What if someone ‘steals’ the (very cool) title?’

			What if someone with a bigger audience and a bigger marketing budget picks it up and
			creates a course or brand around it, before my book gets published?

			So I asked my publisher, Maurice Bassett, his thoughts.

			In a nutshell, his answer was: Damn the torpedoes. Full steam ahead.

			And yeah, he’s right.

			For one thing, I should eat my own dogfood: when a client tells me they need to
			copyright something, my answer is always: “Do you? I think you need everyone in the
			world to know that you created this. Your audience will protect you from copycats”.

			Also: these days you need a lot of publicity before a book comes out.

			Because it’s a crowded marketplace, and now that the internet has emancipated us, and
			given us the chance to self-publish, there’s a slew of books published every day.

			And some of them sell really well, even though the content and quality aren’t all that
			great.

			Hey ho, three cheers for marketing.

			So if my book is to do well, and change lives the way I intend it to, I need to start
			spreading the word.

			And I start today.

			If all goes well, this summer Maurice will publish:

			“The Prosperous Artist - The creative professional’s guide to allowing money into your
			life”.

			And boy does it make me nervous to tell you about it.

			Sh*t’s about to get real.

			But yes. Damn the torpedoes, and full steam ahead.

			So today’s lesson is this:

			The thing that scares you and makes you nervous - it’s very likely exactly the thing you
			need to do.

			What’s your scary thing, the one you want but your fear is stopping you?

			Cheers,

			Martin

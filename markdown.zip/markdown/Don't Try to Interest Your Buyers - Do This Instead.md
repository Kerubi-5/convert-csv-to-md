---
title: Don't Try to Interest Your Buyers - Do This Instead
status: pending
datePublished: '1649159672'
categories:
  - How to sell your work

---

<img class="size-medium wp-image-28004 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/09/MartinStellar_Coaching_Illustrations-Dont-try-to-interest-your-buyer-do-this-instead-300x225.jpeg" alt="" width="300" height="225" />
<div>

Here’s a mistake I see all the time:

</div>
<div>

Trying to look interesting - trying to interest a buyer in what we say, or what we can do for them.

</div>
<div>

It doesn’t work.

</div>
<div>

That's not because you or your words or your work wouldn’t be interesting, mind you.

</div>
<div>

It's because unless you know - with certainty and accuracy - what they’re interested in, you’re shooting in the dark.

</div>
<div>

You’re lobbing ideas at them, hoping that something will stand out so resoundingly interesting, that they ask “tell me more”.

</div>
<div>

And, you’ve probably experienced that the harder you try, the harder it is to get that reaction from people.

</div>
<div>

If, however, you ask them what <em>they</em> are interested in…

</div>
<div>

Well, then you have the perfect topic of conversation, and you’ll end up making the perfect proposal, because it’ll be highly relevant to - wait for it - their interests.

</div>
<div>

Now, there’s all kinds of reasons why someone might try and look interesting.

</div>
<div>

Can be neediness, can be ego-driven, can be to hide insecurities…

</div>
<div>

But the reasons don’t matter.

</div>
<div>

The only thing that matters when you are talking to a buyer is the thing that <em>that</em> person is interested in.

</div>
<div>

Nothing else matters, beyond the interests of your buyers.

</div>
<div>

So if you want sales and happy buyers and the revenue that comes with it, your #1 goal is:

</div>
<div>

Ask questions that help you learn what they are interested in.

</div>
<div>

Put differently:

</div>
<div>

When talking to a buyer, you have one job:

</div>
<div>

<em>To be interested in them.</em>

</div>
<div>

Get that right, and they’ll automatically start getting interested in you, and your solution.

</div>

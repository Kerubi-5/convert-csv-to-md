---
title: Ands vs Buts
status: draft
datePublished: '1498156548'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/633e1014-7aec-4042-88b5-2a7d57901722.jpg" width="291" height="311" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/633e1014-7aec-4042-88b5-2a7d57901722.jpg" data-file-id="4834737" />Tell me if you’ve ever said or thought this:

“Yes, but…”

Sounds familiar, no?

Problem is, the word ‘but’ effectively negates whatever comes before it.

“Yes but” basically means “No, because”.

Won’t get you anywhere. It’s a blocker, it stops your creativity in the face of problems, obstacles, or struggles.

Much more useful to work with “And”.

Let’s say your site visitors aren’t subscribing.

You could say “I’m getting visitors but they’re not converting to subscribers”.

And then what?

Better say: “I’m getting visitors who aren’t subscribing - and I get to find a way to change that”.

Sounds a lot more fun, right? Includes possibility, creativity, change - it’ll actually set you up to fix the problem.

Subtle change, big difference.

So look at the way you talk to yourself.

Notice how often you use the word ‘but’ - and replace it with ‘and’.

See what that does for your inner world and the results you’ll see in your outer world…

Cheers,

​Martin

---
title: Attached to the Problem?
status: draft
datePublished: '1524482913'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/694ac3b8-387b-4ada-a63e-2b01e40ce497.jpg" width="350" height="262" align="left" data-file-id="4835657" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/694ac3b8-387b-4ada-a63e-2b01e40ce497.jpg" />I keep seeing a strange and fascinating phenomenon:

People being really attached to their problems.

Saying they want to change, find a solution, get rid of it… but at the moment you start digging down and looking at solutions…

They shut down, lock up, and stay with the problem.

As if keeping the problem makes life more worthwhile.

Example: “I overthink stuff, I’m always stuck in my mind”.

Says me: “That can change. There’s ways to train your mind”.

“Really? I want that!”

But if I then suggest an action - journalling, meditating, long walks, a creative practice - it’s “But it’s good to think about things, it’s useful”.

Yeah, sure. If you’re happy being stuck in mind… go ahead and stay there.

Me, I find mind-space pretty boring, personally. What I *think* is rarely original, and often a re-run. That’s how mind works, just rehashing the same old stuff.

It’s only when I intuit, explore feelings and ideas, ideate and create - THAT’s when interesting stuff comes up in my mind. I feed my mind things that inspire, so that mind creates new things, instead of trying to use mind to get there which is laborious, slow, and uninspired.

Anyway, this whole ‘attached to problems’ attitude is very prevalent in Western culture, and I blame Freud.

It’s probably not all his fault, but he’s the one who made ‘problem thinking’ so popular.

And now we’re stuck with a view on our psyche that says there’s something wrong with us, by definition, and we need to fix it.

Fun fact: I used to date a therapist, who had the utterly bizarre view that every human being is by nature neurotic. And, she considered that a normal and good thing. Yea. People are weird.

Here’s my take: a problem (or issue, obstacle, stuckness or whatever) is only as important as you make it.

The amount of attention and thought you give it feeds it, gives it importance in your life and then you start to believe in that importance.

This doesn’t meant that a problem should be ignored - but breathing life into it sure doesn’t help. It’s bad enough as it is, why would you want to scale it up?

If it’s a problem you can fix, then get to work and fix it (it’ll probably take time, but that’s ok).

And if you are currently not able to fix it, then the worst possible thing to do is constantly spend mind-time on it. Problems don’t disappear from thinking, but from action. Once you’re thought about it left, right, up, down and under, you’ve probably thought all that you can about it.

Either fix it, or move on until you can actually do something about it.

Here’s the kicker:

If you find that you want to get rid of problem XYZ, and you know how to do it - but you don’t…

Would that be because you’re attached to it, for some reason or other?

Next: what benefit do you get from keeping the problem? There always is a (often twisted, but present nonetheless) benefit - what would it be?

Start there.

Cheers,

​Martin

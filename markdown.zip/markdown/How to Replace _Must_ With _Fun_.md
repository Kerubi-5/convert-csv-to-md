---
title: How to Replace "Must" With "Fun"
status: draft
datePublished: '1515587953'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/2dba0f54-b26a-40a1-9617-6c0439537761.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/2dba0f54-b26a-40a1-9617-6c0439537761.png" data-file-id="4835361" />All those things that you “must” do as a business owner...

Taxes, marketing, social media… shipping products, making sales… etc etc.

Wherever you look, you’ll see people tell you that as a business owner, there’s things you just have to do. Suck it up, it’s part of the game.

Well, I question that.

Because there’s a big difference between an outcome that you want or need, and the way to get that outcome.

For example: paying taxes belongs to being in business. It’s an outcome.

But who says you need to file your taxes yourself? (the way to get the outcome).

You can just as easily have an accountant do it for you, right?

Same thing with social media: the outcome you want is visibility and for new clients to find you and end up doing business with you.

But who says you need to run social media yourself? If you don’t enjoy it, why force yourself?

You could also outsource the job, or you could create a different way to connect with new clients, for example by using networking, or advertising, or participating in forums.

See, you can always pivot, change, create a different approach to get the same outcome, whether that means outsourcing or going in a lateral action.

But the one thing I don’t recommend anyone do, ever, is to force yourself to do things that you resent or.

When there’s a hundred different ways to choose from, each of which can get you the same outcome? Folly to do it in exactly the way you don’t like.

So here’s a simple tool to help you make life and business easier, and more fun.

Step 1: define a desired outcome. Make it specific, or even better: use the SMART goal model: A goal should be Specific, Measurable, Achievable, Realistic and Timebound. So “Get more clients” isn’t a useable goal, but “Create 3 new clients this month” just might be.

Step 2: Consider the method you’re about to use for that outcome, and ask yourself:

a: is it fun?

b: can you make it fun? (for example, by turning it into a game, or a creative pursuit)

c: if you can’t make it fun, drop the method and ask yourself: what other method can I find or create that will get me the same outcome?

There’s many ways to fry an egg. Don’t let some guru or so-called expert sell you on the idea that this or that way (or worse: his way) is the only method you should use.

You should use the method that works for you, which automatically includes the notion that you enjoy it.

And boom: life suddenly becomes more fun, and business results become easier to attain.

Working with clients to find hacks or workarounds for the things they don’t enjoy is one of the most fun parts of my job, because it’s a process of you discovering how to use your creativity for reaching your goals.

Tell me that doesn’t sound good…

And yes, I’m here for you when you’re ready.

Cheers,

​Martin

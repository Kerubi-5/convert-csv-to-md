---
title: 'Lead Generation: Pay Upfront, or Pay Later On?'
status: publish
datePublished: '1657030948'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img class="size-medium wp-image-28972 alignleft" src="https://martinstellar.com/wp-content/uploads/2022/07/MartinStellar_Coaching_Illustrations-The-upshot-or-paying-lead-generation-cost-up-front-300x225.jpeg" alt="" width="300" height="225" />It's the fashionable thing to do these days:

Get a couple of software subscriptions for sourcing a list of leads, for writing outreach copy using AI, and for automatically sending sequences of messages to people by email or LinkedIn.

And then you end up sending such gems as "Hey Janet, love your work. We should talk because I have this system that can reliably bring in dozens of highly qualified leads each month!".

Uhuh. I'm sure you do.

But I suppose you're going to generate those leads by running the same automated campaign and funnel, that you're running on me, right?

Yeah about that:

I don't like being in that kind of funnel, and I sure as hell don't want to put my buyers into one.

Sure I have a sales funnel, and lead generation - but you'll never see me spam people on LI, hoping that 1 in 100 will reply.

No, I get personal, I study people, I do my homework on them - and THEN, to a small set of manually selected people, I send a personal message.

Not "personalised", those cheesy images where they're holding a coffee-mug with your name super-imposed on it.

No, an actual personal message, talking about them and what they show on the internet about their business, and why I think we should talk.

And then I receive replies like "I didn't know I wanted stone-cold outreach today, but this rocks, thank you for taking the time".

Sure, it's a costly process, to manually review people and create personal messages.

But the upshot is a much higher percentage of replies, and far more calls with the right people.

Sure beats having dozens of "exploration calls" that go nowhere and clutter up my pipeline with unqualified deals.

Buying automation is tempting, but a pipeline full of bad deals means you pay a tax on that time-saving automation, with every failed call you have later on.

I prefer paying the cost up-front, by studying people and getting on calls with the right ones.

<hr />

On another note:
I'm building an app that coaches you on working your pipeline, moving your deals forward - and closing them faster and at better rates.
It's called SalesFlow Coach, and we're scheduled for beta-release in June 2022.
Register <a href="https://martinstellar.com/salesflow-coach-launch/">here</a> to be notified when it goes live.

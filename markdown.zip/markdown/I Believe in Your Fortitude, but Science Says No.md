---
title: I Believe in Your Fortitude, but Science Says No
status: draft
datePublished: '1537947080'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-20937" src="http://martinstellar.com/wp-content/uploads/2018/09/MartinStellar_Coaching_Illustrations-Cortisol-stress-and-state-management-1024x768.png" alt="" width="355" height="266" />Ok, science doesn’t actually talk, but there’s real proof that no matter how resilient you are, certain harmful influences affect you badly, whether you want to or not.

The other day I was on a skype call with a friend who owns a SaaS company.

Software as a Service - where clients subscribe for a monthly fee. You know, like Mailchimp, Buffer, that kind of company.

And as with every SaaS, customers come and go. Some stay for years, others for months, but there’s always a degree of churn. Part of the deal.

He mentioned that he gets an automatic notification each time someone signs up or cancels, so I suggested he disable the notifications for when people leave.

And then he made a mistake that nearly all of us make, unawares:

“I don’t have to, Martin. It’s part of how things work, and it doesn’t affect me when a few people leave each day”.

This is, factually, incorrect.

He might be able to rationalise what’s happening, but that doesn’t stop his subconscious from registering a threat, and it doesn’t stop his endocrine system from releasing cortisol and other stress hormones.

And no, seeing a few clients cancel their $20 subscription doesn’t reduce him to an incapable, stress-riddled wreck.

But, it’s one little stress-factor in a day, one of many different ones each day.

A dangerous traffic situation, your kids coming home with bad grades, your spouse picking a fight, and let’s not forget the avalanche of bad news so many people are addicted to:

All these instances and many many more, induce stress, which shows up on a physical, hormonal level in all of us.

And you better believe that this affects your ability to think, decide, operate, and perform.

Under stress we don’t do well, unless we’re running from a saber-toothed tiger.

Which is why I recommend all clients that they assess how many stressors are present in their lives, and eliminate as many as they can. And I recommend you do the same.

Because the way you handle yourself - specifically, your cognitive and emotional states - determines how you perform, which determines your business results.

So drop the news, you won’t miss anything.

Stop complaining, because telling yourself how crappy things are also sends a stress signal to the brain.

Forget about Facebook, where everyone wants to tell you how bad this thing or that thing is.

Replace the loud aggressive ringtones on your phone with gentler ones, so that you don’t get the cortisol spike each time someone rings you.

In the end, we’re subjected to a barrage of stressors each day, and you’d do well removing all of the ones in your control.

Because while your mind might be able to put perspective on things, your neurochemistry doesn’t, and that’s a fact.

Manage your states, because they’re too influential and precious to just let the world drag them down.

The result?

Calm seas, smooth sailing.

Oh, and better creative work, better decisions, more productivity - which ultimately contribute to a bigger business and more money in the bank.

And I think we all want that, right?

Cheers,

Martin

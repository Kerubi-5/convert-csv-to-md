---
title: No Script? No Good (Bad Example Included)
status: publish
datePublished: '1586347997'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img class="alignleft wp-image-23117" src="http://martinstellar.com/wp-content/uploads/2020/04/MartinStellar_Coaching_Illustrations-Why-you-need-scripts-1024x768.jpg" alt="" width="349" height="262" />Got some interesting feedback yesterday from a friend, on a little video I recorded.

It’s three minutes, and if you <a href="https://youtu.be/Y0qa1b8_ADY" target="_blank" rel="noopener noreferrer" data-cke-saved-href="https://youtu.be/Y0qa1b8_ADY">watch it here</a>, you’ll see that initially, I’m fairly straight in contact with the camera, but halfway through I look away more.

My friend said that I ought to improve that, because it’ll inspire more confidence - and I agree, completely.

Just so happens, looking into the void is what I do when I’m thinking - I know it happens to me all the time, also when I’m coaching people.

Now how come I look at the camera at the start, but not later on?

Because the first section, that’s stuff I’ve talked about over and over - it’s internalised.

The second part, where it’s about the specifics of the video, that’s something I didn’t get to practice a lot yet. So I have to think, to make sure I say the right(-est, if you will) things.

This is exactly why actors learn a script. It’s why musicians play scales until their fingers bleed, or the ears of their housemates. It’s why dancers practice moves until they look effortless.

And, it’s why in the world of business, those who are best at selling - enrolling buyers - use scripts.

And then people rear up and protest “I don’t want to sound robotic, I want to be open and flow with the conversation, I don’t use scripts!”

Perhaps. And that would likely be why you’re not getting higher conversion rates on your sales conversations.

Think of it like this:

If a musician needs to remember which notes follow one another in a scale, he won’t be free to creatively express notes.

If an actor didn’t imprint the script before going on stage or camera, he’ll be thinking about the words to say, not about acting them.

If a dancer didn’t hardwire moves into their body memory, their dancing won’t look natural and effortless.

And, if you’re in a selling situation and you don’t (yet) have your script memorised, you’ll be thinking about what to say (see above), instead of about how to best connect with the other party.

And that’s why we all need scripts, pitches, blurbs - and business messaging that instantly, confidently, tells another “*This* is what I do, for *that* kind of person, and if that’s you, then *this* is why you might care”.

So yeah, I’ll be practicising and re-recording. You bet.

As for you… are you going to do some scripting?

Let me know if you want me to help you with that.
Cheers,

Martin

P.s. Does <a href="https://youtu.be/Y0qa1b8_ADY" target="_blank" rel="noopener noreferrer" data-cke-saved-href="https://youtu.be/Y0qa1b8_ADY">that video</a> make you curious whether or not your IP can be turned into revenue as well?
Book a short conversation here, and <a href="https://app.acuityscheduling.com/schedule.php?owner=11652475&amp;appointmentType=10482980 �" target="_blank" rel="noopener noreferrer" data-cke-saved-href="https://app.acuityscheduling.com/schedule.php?owner=11652475&amp;appointmentType=10482980 �">let's find out...</a>

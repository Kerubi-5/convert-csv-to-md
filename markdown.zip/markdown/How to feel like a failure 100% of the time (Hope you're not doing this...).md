---
title: How to feel like a failure 100% of the time (Hope you're not doing this...)
status: draft
datePublished: '1526400585'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/6310c360-8954-4842-a848-8be0295316fe.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/6310c360-8954-4842-a848-8be0295316fe.png" data-file-id="4835721" />The subconscious is a curious thing.

It’s like a simple, autonomous control centre for your life.

It has no intelligence, so it runs on two basic instructions:

“Keep ‘em happy, keep ’em safe”.

In other words: It's job to move you towards pleasure, and away from pain.

It/’s the boss behind the scene, who causes you to choose and act in ways that increase well-being, and avoid danger or risk.

But to the subconscious, there is no time. Unlike our consciousness, which has memory and can project things into the future.

So to the subconscious, there’s only now.

And that’s where most all of us set ourselves up for trouble.

Each time we decide to do something - for example: fix website - the subconscious thinks that it’s something you need to be doing now. Or all the time. Or at least, get it started. It doesn’t know time remember? So it doesn’t compute that you’ve decided to do the thing tonight, or next month.

It hears that you want to do this thing, it registers that as something that will increase well-being and there isn’t any risk, so it rolls up its sleeves, telling you to get your doing on.

Now, if you then also decide to do another thing - say, wash the car - you’ve just caused your subconsciousness to experience failure.

After all, you can’t update a website and wash a car at the same time.

I tried, and it wasn’t pretty.

This single thing - the inadequate management of tasks - is one of the biggest reasons for procrastination.

Because we plan and decide to do things, all of the time.

In our minds, there’s a huge list of open loops and future plans: tasks to be done, people to call, projects to start or finish… a wash list of duties.

The subconsciousness looks at that pile of mess, and realises that there’s no possible way you could fix your site while filing your taxes, as you learn how to play bassoon whilst and at the same time juggling fish and singing Leaving on a Jet Plane.

It sees clearly why you feel stressed, overwhelmed, confused and frustrated.

And it’s job is to have you not be in such a state, so it solves the problem for you.

It quietly closes the door on your endless list of todos, and tells you that it’s ok to while away the afternoon watching Netflix. Because don’t worry: the tasks and todos won’t disappear, they’ll still be there for you to work on tomorrow. But first, some R&amp;R. Right?

Right. Procrastination.

The solution is simple:

Take notes. Write things down. Commit every idea and task and project and todo to a system of lists. Paper, phone, computer: all good. Just don’t try to use your mind as a storage device, because that's not what it is. It was made for thinking, not remembering.

Your mind has a capacity limit, and if you fill it with stuff to remember, you won’t have any space left for it to do the important work:

Create, ideate, solve problems, build and invent and design. That’s the sort of stuff your mind is good at.

Let an external system (external brain) collect all the stuff to remember.

This by itself will have a massive impact on your productivity, focus, calm, and well-being.

Not to mention reducing your tendency to procrastinate.

Your brain was made for thinking.

Give it space to do so.

Cheers,

Martin

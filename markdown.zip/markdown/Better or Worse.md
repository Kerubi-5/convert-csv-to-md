---
title: Better or Worse
status: publish
datePublished: '1582806434'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - Psychology in sales and marketing
  - Relationships
  - Values

---

<img class="alignleft  wp-image-22726" src="http://martinstellar.com/wp-content/uploads/2020/02/MartinStellar_Coaching_Illustrations-Business-and-choices_better-or-worse-1024x768.jpg" alt="" width="355" height="266" />He’s a terrific guy, an awesome waiter. He does have the Granada ‘mala folla’ attitude, but once you accept that, you realise he’s actually not boorish at all - that’s just his sense of humour.

And at work? I’ve never seen a waiter run faster than him. It’s astonishing.

But the other day, having lunch with friends, the terrace was just so full that we had to eat our paella starved of drinks. He just wasn’t able to keep up.

This morning over coffee I asked if they shouldn’t hire another waiter, to help him.

Turns out, his boss doesn’t like paying wages. Thinks he can handle things by himself.

Which he can, but if you’re serving 25 tables at the same time AND there’s nobody behind the bar pouring drinks for diners… Then it simply is impossible to handle things well.

This owner, they are doing damage to their business.

Everyone I know in town loves this restaurant - and everyone complains about the service.

Which isn’t my friend the waiter’s fault - he’s running as fast as he can.

But to the customer, it doesn’t matter whose fault it is. They want a good meal and decent service.

And the greediness of the owner… well, customers only care about that once it affects service or quality, right?

Here’s the moral of the story:

While profit is essential in business, and you sometimes need to make tough decisions, never let quality and service suffer.

Yeah, it’s bad for business.

But more importantly: it’s backwards thinking, because quality and service grow a business, while inefficiency and wastage slow it down.

If you’re going to optimise for profit, start by looking at bottlenecks, redundant assets and processes, and numbers to grow: traffic, inquiries, conversion rate, number of followup actions and all those fun digits that tell you whether
your business is doing well or not.

Make things better, instead of worse.

Are you looking to make some choices at the moment? Maybe I can help you there... and help you make things better.

Cheers,


Martin

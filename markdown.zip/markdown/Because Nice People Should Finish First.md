---
title: Because Nice People Should Finish First
status: publish
datePublished: '1617926609'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - Ethics and marketing
  - How to sell your work
  - "Psychology in sales and\r\n\t\t\tmarketing"

---

<img class="alignleft wp-image-22717" src="http://martinstellar.com/wp-content/uploads/2020/02/MartinStellar_Coaching_Illustrations-helping-ice-people-sell-more-1024x768.jpg" alt="" width="355" height="266" /><span style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen-Sans, Ubuntu, Cantarell, 'Helvetica Neue', sans-serif;">A while ago, a friend held my feet to the fire about my work, USP, and elevator pitch.</span>

To her, ‘coach and consultant for ethical business growth’ isn’t what I should run with.

So I tried to explain:

“You ever notice how people high in integrity, folks who really want to do right by people, are often the ones who have most trouble growing their sales and their business?

"I help that kind of person sell more because of - not despite - their values. I call that ’solving the good-egg problem”.

“Yeah”, she said: “Too long”.

By this time, I was getting frustrated.

I mean, she knows me, she knows what my work is about. What I stand for, and which values are sacred to me.

And besides, I wasn’t sure if she was challenging me on my USP, or my tagline, or my elevator pitch.

So I blurted out: “I help nice people sell more”, and that seemed to hit home - and since then it has stuck.

Because the harsh truth is that in business, many people believe that nice people do finish last.

And that’s not how it should be.

Nice folk should finish first. Not despite the fact that they are nice, but <em>because</em> they are nice.

And helping nice folk grow their enterprise, that’s something I get up for every day.

So if you want help with the mindset and decision and strategy side of things, I can coach you on how to be a powerful, skilled business owner. The leader in your own team, whether you’re a solopreneur or not.

If you have that down pat but you want your marketing to get you higher returns, I can consult you on that, and/or implement a marketing system guaranteed to grow your business. (actual guarantee, not just words).

Or, if you have your self-leadership rocking, and your marketing rolling, but you want to learn specific business skills, such as selling, email marketing, productivity or negotiation, I can provide you with custom-made training.

Put differently:

If you’re a good egg, and you want to grow, you might be the kind of person I work with.

Because nice people should finish first.

And if right now you’re eager to make that growth happen, then maybe we should talk and see if I’m the right guy for you.

Sounds good?

<a href="mailto:nicepeople@martinstellar.com">Let me know…</a>

---
title: Have You Tried?
status: draft
datePublished: '1497866022'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/66370d22-5a1f-4e8b-81e6-5e4720132776.jpg" width="235" height="255" align="left" data-file-id="4834729" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/66370d22-5a1f-4e8b-81e6-5e4720132776.jpg" />Imagine that your life is a hologram, that nothing is real the way we think it is.

That whatever we perceive is the consequence of a thought, followed by a decision and action.

Imagine that there are no limitations, that you can create anything you like, almost as if by magic?

With just your intent and your zest for action… if you would get to create whatever you want… what would it be?

What would you create?

Oh I see - that’s not how the world works.

Are you sure though?

You’ll create more by trying, than you ever will by considering things impossible.

Have you tried?

Cheers,

​Martin

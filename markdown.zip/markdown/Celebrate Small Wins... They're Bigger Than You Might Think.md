---
title: Celebrate Small Wins... They're Bigger Than You Might Think
status: draft
datePublished: '1522954485'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/2371f63c-b199-4702-b8f3-957331e6b733.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/2371f63c-b199-4702-b8f3-957331e6b733.png" data-file-id="4835617" />There’s something baffling that I keep seeing.

It’s a kind of impatience, combined with not appreciating small, but important wins.

For example, a good friend of mine runs a startup company, and things are growing nicely.

The beta version is live, people are liking it, and so now he needs investors, to really build up the software, and grow the user-base.

So he’s been to New York, Silicon Valley, Chicago… meeting investors and delivering his pitch for getting an investment - which is generally well-received.

And then he tells me that someone present at one of those pitches really liked the company and my friend.

So much so that he contacted one of his buddies, who happens to be a world-famous serial entrepreneur and investor. Can’t tell you his name, but in the tech world he’s as famous as Tony Robbins in the self-help world. Big player.

So mr. Big Time Investor hears about the company, likes it, and contacts my friend: “Let’s meet for a coffee next time you’re stateside”.

My friend tells me this, and I almost fall off my chair. How very cool! What a win!

“Yeah but”, he says, “It doesn’t mean anything. Not until we actually receive the investment”.

Well, I roundly disagree, and I said as much to my friend.

Because yes, in itself it’s not a result that drives growth.

But… it’s an indicator that major growth - meaning, a considerable investment - is becoming more and more likely.

I mean, for a hotshot investor to actually contact a completely new player, and invite them to a conversation?

That means my buddy is doing something very, very right - and it’s only a matter of time until it turns into actual results. Big players don’t tend to deal with beginners, unless the beginner in question shows some real promise.

In other words: My friend received confirmation that he’s doing it right, and that he’s interesting.

To me, that’s a reason to celebrate - maybe not to the point of going on a cruise, but dammit man: stand still for a moment, and realise what you’ve accomplished!

A moment like that, a small win, is special!

It’s the buds starting to appear on your crop, that you’ve planted and watered and cultivated for so long.

Don’t know about you, but when I see my plants budding, I smile and appreciate it.

Because I know what’s going to come next, if I just keep watering.

So celebrate your small wins.

Especially the ones that aren’t real results yet, but that indicate that you’ve got a good thing going.

THAT’S gratitude put into practice, and gratitude matters.

Cheers,

​Martin

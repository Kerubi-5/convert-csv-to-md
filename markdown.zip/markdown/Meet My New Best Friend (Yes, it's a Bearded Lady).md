---
title: Meet My New Best Friend (Yes, it's a Bearded Lady)
status: draft
datePublished: '1508143722'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/71f41dfa-c61f-4eb1-8f83-73d074c53008.jpg" width="350" height="376" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/71f41dfa-c61f-4eb1-8f83-73d074c53008.jpg" data-file-id="4835101" />The other day, I read about a young woman in the UK, who goes by the name of Harnaam Kaur.

Because of a medical condition, she has a beard. Like, a real and proper one. The kind that many a man would be jealous of.

And after years of waxing and being subjected to bullying, she finally decided to leave it be.

To just be who she is: a lady with a beard. A lady beard, as she calls it.

When I first read the story I didn’t know what to think. “Good on her” was about as far as I got.

But today I googled her, looked at her photos again, and realised: “That beard does actually look good on her”.

Not to mention the bias-destroying, beauty-concept-upending result that she’s creating in the world.

A body confidence activist - with boobs, and a beard. How cool is that?

I can only imagine how tough it must have been for her, in order to reach the point where she took such a brave decision.

So, here’s the lesson:

Instead of trying to fit in, making herself be someone she’s not, she chose to be fully herself.

And boom: a following, a career as a model, and a message that serves and benefits anyone (male, female or other, beard or no beard) who’s ever been made to feel inferior because of their looks.

Good show, Harnaam.

Now let’s translate this to you. Yes, you can put down the wax strips while we talk.

Seriously though:

In what way have you tried to fit in when that actually violates your integrity as a human being?

And: did it help?

Finally: ready to stop doing that?

Because trying to fit in doesn’t help.

It disables you from living as yourself, and because of that, you’ll be less able to serve and help and inspire other people. So you don’t win, and neither do others.

That’s what you get from fitting in.

So: ready to stop trying to fit in…?

Be yourself? Unabashed? Despite the fear and the consequences?

Cheers,

​Martin

---
title: Any Excuse, to Avoid at All Cost
status: publish
datePublished: '1560771795'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img class="alignleft wp-image-21797" src="http://martinstellar.com/wp-content/uploads/2019/06/MartinStellar_Coaching_Illustrations-Avoidance-and-importance-1024x768.jpg" alt="" width="350" height="263" />People often ask me variations of ‘what should I do?’

What should I do to:

- Grow my list?

- Have more buyer conversations?

- Drive traffic to my site?

- Spread the word about my business?

- Raise my rates?

- Increase my close rate?

When you’re asking yourself questions like these, there’s two ways to approach the conundrum.

The first is where you get all heady, start thinking about options, previously failed experiments, pros and cons… and you often end up doing nothing specific in order to get what you want.

The other option, and one that’s often a breatkthrough approach, is to ask yourself:

“What am I avoiding most strongly? What could I do, but I just have SO many objections and reasons not to? What am I most procrastinating on?”

See, the only real, useful answer to the question ‘What should I do?’, is ‘Yes’.

Because you already know the answer - you know what to do.

What to do is, in nearly all cases, the thing you’re avoiding at all cost.

For me, it’s starting a podcast and releasing short daily videos.

I KNOW it’s going to help my business, but I have a list of excuses longer than an airstrip. Yet I know it’s going to have to happen sooner or later.

Me, I know what I should do, and I believe so do you.

The real question is:

What needs to change in your thinking or your deciding, in order for you to actually get to doing it?

What do you need to believe about your abilities is persistence?

And, at the upper level of psychology: who do you need to be - as in, what identity do you need to choose to operate from?

The degree to which you avoid certain activities is a direct indication of how much of a difference that activity can make for your business.

The moment you ask 'what should I do' is the moment you know the answer.

If it's something you want to avoid at all cost, it could be just the thing to do.

Will you do it?

&nbsp;

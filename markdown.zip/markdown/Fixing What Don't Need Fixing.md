---
title: Fixing What Don't Need Fixing
status: publish
datePublished: '1502444827'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/e2eb31b8-864c-4760-b653-27d80baf7f44.jpg" width="350" height="389" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/e2eb31b8-864c-4760-b653-27d80baf7f44.jpg" data-file-id="4834901" />Let’s follow up on yesterday’s email, about trying to fix one thing, when something else might be a better idea.

A while ago, a client asked questions about getting onto twitter. How it works, what the best strategy is, and so on.

I gave her some ideas, but then I asked about the why. What would be the logic?

After all, this client has a fairly strong presence on Facebook, and is wildly admired by her followers.

Not thousands of followers, but still: engagement is engagement.

You measure engagement in strength first, and numbers second.

So if it had been my business, I’d have left Twitter for what it is, and focused on increasing my Facebook visibility.

After all, doesn’t it make sense to improve what already works - instead of adding on something new?

To optimise something good into something better, by learning and getting smarter and more strategic - instead of taking away time from it, just so you can invest that time into a platform where you’re starting from scratch?

Obviously, this is not a matter of the right or the wrong choice - that’s always up to the individual.

But, I’ll always ask the strategic questions: is this the easiest way to fix the problem at hand?

Because very often, we take the long way round. We choose an action that gets results, but at the cost of not getting at the low-hanging fruit.

If your soup lacks salt, do you add some in - or do you cook up a savoury side-dish to go along with it?

Me, I’d just grab the salt shaker.

&nbsp;

---
title: On Being... Relentlessly Helpful
status: draft
datePublished: '1487061896'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

Maybe you think I’m talking nonsense, when I tell you that daily emails do wonders for your business.

What with all the pundits saying that you should only send email occasionally.

So today I’ll show you someone else’s take on things, from a Cabal client who took my cue, and started writing dailies just a few weeks ago.

Says Paula Mould, in our private Facebook group:

###

So I'm going to be in the paper again. And I was told why. This is useful information for all of us.

I can talk about my work.

The reporter told me that with most artists, she has to spend an hour dragging information out of them. It's exhausting.

So at my opening, with 9 artists to choose from, she zoned in on me and did an on the spot interview and photo op.

This is the second time I've been interviewed by this person. And there will be more because of that one important thing. [she means: being comfortable talking about her work - MS]

If you're not comfortable talking about your art, your ideas and your work you need to start getting comfortable. It pays off in unexpected ways.

Martin will love this bit: writing about my work through daily emails helped a lot. The ideas I was interviewed about were already solid because I already wrote about them. Boom.

###

Boom indeed, and yes I love it.

That last line is golden: her ideas and what she would say was already congealed, because she’d been writing daily.

Which is a different way of saying that writing daily to your audience changes you.

It’s not just about marketing or sales, you see?

First it’s about the relationship that you develop with your audience.

From which comes a more engaged audience, and that will lead to more buyers for you.

But, and this is crucial: writing daily changes you.

It’s transformative, almost therapeutic.

When you start writing with the intent of showing up in a helpful and inspiring way (meaning: not salesy, but meaningful) you change the way you see yourself, your audience, and the way you relate to them.

And that’s golden, because the ultimate consequence will be more sales, and that’s never bad.

Simply put: there's magic in being relentlessly helpful, both for business and in a personal sense.

Now, I have this email marketing mentorship program that gives you a 1-on-1 training, but it’s costly and that puts it out of reach for many  people.

So right now, I’m developing a different structure, where you get me to teach you the ins and outs of email marketing, but at a much more accessible price point.

Details to follow in the next few days.

For now, ask yourself: why would you NOT want to show up in a helpful, meaningful way, that also gets you more sales?

Cheers,

Martin

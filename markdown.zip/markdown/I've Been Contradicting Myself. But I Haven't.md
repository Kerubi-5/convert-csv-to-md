---
title: I've Been Contradicting Myself. But I Haven't
status: draft
datePublished: '1507117559'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/796f04f0-f548-4108-a832-98a2a3eb83a1.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/796f04f0-f548-4108-a832-98a2a3eb83a1.jpg" data-file-id="4835065" />I realised I may have been confusing you.

On the one hand, I talk about stuff like taking control, and having agency, and all the other enabling attitudes we all need.

But at the other side of things, I talk about play, and letting go, and being non-attached to the outcome of things, and yielding and submitting.
In which I contradic myself. Between yielding and submission, and taking or having control. But I”m not contracting anything because yielding doesn’t mean you beome passive. And control doesn’t mean holding on in a clutching way.

So have I gone loopy, and started contradicting myself?

Not at all. (re the contradicting bit. I may or may not be loopy but that’s a different story).

To be serious: being in control and yielding are not opposites - not if you do it right.

Because yielding and submitting doesn’t mean that you lay down and take the beating that life gives you, nor does it make you passive or disempowered.

Yielding means that you listen to life, open to what is there to learn or observe, and act on the information you receive.

While being in control doesn’t mean that you cling to how you think things should be, in an attached and stressful way.

Being in control means that you act on best judgment, non-attached to the outcome, and ready to adjust to the new information that your actions trigger.

In other words: there’s a middle zone, where you’re both open, and in control.

That’s the state and attitude I want to get you to.

It’s like martial arts, where you are open as well as ready for action.

Or, to use an example more familiar to me: like sailing.

With your hand on the tiller, you feel the rudder and the waves and the wind - you steer the ship, under your control - but at the same time, you do it with a light touch - listening to the elements and the ship.

That’s the middle way, where you control your life and mind with calm, detached clarity and openness.

To practice that attitude, try this:

When you feel tension in your mind, emotions, or body, realise that this is because you’re clinging to an idea or expected outcome. At that moment, stop what you’re doing, breathe, and try to relax into a state of observing and listening.

And when you feel that stuff happens to you instead of through you, it means you’ve gone too far in the direction of yielding, of giving away your control.

At those moments, take a few deeps breaths, hold the last one in for a moment, and observe as your heartrate and temperature climb a bit. Let go, decide on an action (the simplest and smallest action you can come up with) that enables you to make use of the things that ‘happen to you’. And then do that thing, right away.

Easy? Depends. Simple? Yep. Effective? You bet, especially if you actually practice the exercise.

The result?

Slowly, you grow to be the captain of your ship, master of your life. And a master would be worthless without clarity and detachment.

Meanwhile, the invitation for a no-cost strategy session is still open.

Apply by answering a few short questions:   <a href="https://martin283.typeform.com/to/v7Dsh8" target="_blank" rel="noopener" data-cke-saved-href="https://martin283.typeform.com/to/v7Dsh8">https://martin283.typeform.com/to/v7Dsh8</a>

Cheers,

Martin

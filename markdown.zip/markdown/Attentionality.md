---
title: Attentionality
status: draft
datePublished: '1549626378'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21374" src="http://martinstellar.com/wp-content/uploads/2019/02/MartinStellar_Coaching_Illustrations-Attentionality-where-is-your-mind-1024x768.png" alt="" width="356" height="267" />It breaks my heart to see people struggle, be it in life or business or relationships.

Especially when the remedy - or at the very least, a massive improvement - is so close at hand and so simple.

Because the easiest way to end up in a state of struggle, fretting, worrying, procrastination or what have you, is to not be intentional.

Specifically, being intentional about your attention and where you place it.

Enter the concept of attentionality:

A deliberate, thoughtful method of setting an intent on where you place your attention.

After all, your mind is always paying attention to something or other.

And poblems occur when we allow it to pay attention to the ‘wrong’ things - i.e. allowing it to focus on things that we didn’t deliberately set for it as a point of focus.

Not sure this applies to you?

Ok, try an experiment:

Set a reminder in your phone, to show up every ten minutes, and display the question: “Where is your mind?”

You only need to do this for a few hours, in order to realise that your mind goes ALL over the place, and very often ends up occupying itself with trifles, negative thoughts, blame, complaints, and a host of other topics that don’t contribute to your well-being, focus, productivity or results.

And all this just because we let our minds roam unleashed nearly all of the time.

I like to think that 95% of our mental time is spent on random stuff, in which you’ll find a lot of negatives.

But in that 95%, your mind is programming itself for what it will think about next, what it will opine about events and people, how it will interpret things, and what it will or won’t cause you to procrastinate on.

The remaining 5% may be constructive creative thought, or focus on problem-solving or executing on deep work, but if there’s too much crap in the 95%, it’ll sabotage the results of that 5%.

This is why mindfulness has become so popular: when you become more mindful of what your mind is doing at any given time, you’ll find it easier as well as desirable to become more directive of what your mind is doing.

Put differently, it’s worth your time to develop meta-awareness: to make it a habit to think about your thinking.

Pay attention to your mind, because otherwise it’ll choose its own area of focus.

Ask yourself, throughout the day:

Where’s my mind?

Cheers,

Martin

---
title: Choices, and Those Things You Pretend Don't Exist or Don't Matter
status: draft
datePublished: '1523465736'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft" src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/2d898021-b9dc-433c-9efb-5a4c3a2c7331.jpg" alt="" width="350" height="262" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/2d898021-b9dc-433c-9efb-5a4c3a2c7331.jpg" data-file-id="4835629" />I have this close friend here in town, who never answers her phone.

She always calls back, and usually within a few minutes - but she just never picks up when it rings.

No big deal of course, but it’s curious because whenever people joke about it (she answers nobody’s calls, not just mine) she says:

“I know, there’s something wrong with my phone”.

Sometimes it’s the device, other times it’s the notification settings that on an Android can be confusing for someone not tech-minded (which she very much isn’t), but it’s always:

“There’s something wrong with my phone”.

Except there isn’t. Not year after year.

No, what’s happening is that she has an apprehension, or fear, or anxiety or something else that makes her want to avoid dealing with that darn phone.

Easy enough to just to call people back. Whew.

In other words: “Phone” is an object of resistance for her, and she’s keeping it that way.

She keeps the whole concept and notion of it hidden away, something to just never look at.

Another way to put it: it’s her choice to not deal with her phone. Not consciously, but a choice nonetheless.

And we all have things that we know deep down need attention…

… but we do anything we can to ever get there and give it that attention.

Could be budgeting and money, could be learning how to write copy, could be finally getting active with your social media or your website… we all have things we’d rather ignore, stuff into the back of the closet and pretend it’ll be alright.

There’s an excuse, another priority, or - worst of all - a story we tell ourselves about why not or why not now.

And it’s a choice, it always is.

My invitation is for you to look in the closet, and pick something that you know you keep deciding not to deal with.

Next, I’m not going to ask you to deal with it.

Instead, I want you to do something much simpler and achievable:

From now on, each time you make the choice to not deal with item X, do it deliberately.

Decide consciously to ignore it.

Tell yourself: I know this needs work or attention, but I’m deciding now to not do it at this moment.

Then proceed to go about your business.

Do this exercise, and practice it. You’ll find that before too long, you’re no longer content to make that decision, and you’ll find yourself deciding to yes, actually: do something about it.

Because it exactly those things we least want to recognise or deal with, that are the biggest obstacle and/or create the biggest growth opportunity.

Simple exercise, fun results. Try it.

Cheers,

​Martin

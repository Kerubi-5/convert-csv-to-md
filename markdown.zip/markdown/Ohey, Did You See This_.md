---
title: Ohey, Did You See This?
status: draft
datePublished: '1484210277'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

Heya, just a quick heads up today.

Last week I published a new ebook: ‘The End of Procrastination’.

In case you haven’t downloaded it yet... could be for various reasons.

Maybe you didn’t see the message - but you’re seeing it now.

Or, could be that you figured ‘I’ll download it later’ in which case I highly recommend you click the link below and read that little puppy.

Because if there’s one thing that shouldn’t stand in your way of a happy, fulfilled and prosperous life, it’s procrastination.

So, go here to pick it up now: <a href="http://martinstellar.com/endofprocrastination/" target="_blank" rel="noopener" data-cke-saved-href="http://martinstellar.com/endofprocrastination/">http://martinstellar.com/endofprocrastination/</a>

And, if you already read it and like it, do please forward this email to anyone you think would benefit.

Or share it on social media with the convenient buttons below:

Anyway: there’s a cure for procrastination.

You’ll find it in this book --&gt; <a href="http://martinstellar.com/endofprocrastination/" target="_blank" rel="noopener" data-cke-saved-href="http://martinstellar.com/endofprocrastination/">http://martinstellar.com/endofprocrastination/</a>

Cheers,

Martin

P.s. Oh and: did I mention you can get it for free? You can. Just saying.

&nbsp;

&nbsp;

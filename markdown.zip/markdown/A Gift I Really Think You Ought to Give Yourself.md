---
title: A Gift I Really Think You Ought to Give Yourself
status: draft
datePublished: '1519640782'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/dcd79bda-7dff-4be5-a4c4-570d3708b857.png" width="350" height="350" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/dcd79bda-7dff-4be5-a4c4-570d3708b857.png" data-file-id="4835489" />I take off my shirt and shoes, and lay face down on the table set up on the beach under a party tent.

Nice. I’ve been looking forward to this.

She rubs the oil between her hands and starts working my back. She’s good, too.

A gentle breeze rolls in from the sea.

The sound of children playing in the surf, and seagulls, and occasionally the sound of the girl in the restaurant kitchen nearby, yelling the order the cooks need to follow so that all the meals show up at the right time. “Cantar las comandas” - singing the orders.

As my back receives the treatment, I meditate and slowly sink into deep, deep relaxation.

Damn, this is blissful.

An hour later I get up, pay, and ride my bike back up to my house. Refreshed, renewed, ready for some serious client sessions.

I never realised it, but these massages are just one of the ways I go on ‘artist’s dates’ with myself.

Never realised it until last week, when my coach recommended I’d make a habit out of going on artist’s dates.

Truth is, I frequently do them. Sometimes I’ll drive to a spa to lay in a flotation tank for a while. Sometimes I take an unknown road and get hopelessly, beautifully lost, and sometimes I spend a day rearranging stuff in my house.

And every time I do one of those things, it feeds the soul and fills the well.

Last weekend (because it’s really useful to do what your coach tells you) I turned the entire weekend into an artist’s date. Spent time to carefully create a playlist (old school funk music, my fav). Cleaned out a bunch of old stuff, reorganised my studio, relaxed watching videos in the middle of the day. So nice. Thanks, coach.

So while I might not be your coach, I kinda am in a virtual way, with these coaching emails.

And it’s going to REALLY be worth your time to also go on artist’s dates.

I know that I will, like before, except no longer ‘by accident’ - no, I’m going to plan them. Got my next one figured out and planned already.

And, I really hope you’ll do it too. It’s good, even if you’re not an actual artist.

To go on a date with yourself… the way Julia Cameron describes in The Artist’s Way (excellent book btw, I recommend it).

If you do a Google search, you’ll find a ton of ideas, from planting things in the garden, to being a tourist in your own city. So much fun.

So, if you feel stressed, overwhelmed or just looking for more fun, why not go on a weekly artist’s date?

And drop me a line, I'd love to know what your choice of artist's date is...

Cheers,

​Martin

---
title: "Buy This or the Puppy Gets It: the Dirty Little Secret of the Business World, and How\r\n\t\t\tYou Can Prosper Despite of It"
status: publish
datePublished: '1487834243'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - How to sell your work
  - Psychology in sales and marketing

---

The more time I spend being in business, and especially online, the more I’m confronted with the unethical behaviour of some people.

Now, I happen to like marketing.

Used right, it’s a force for good.

Martin Luther King for example was an excellent marketer, so let’s call this point QED.

And I like selling too, and I’m good at it.

But I often walk away from a sale.

Because that’s my code of ethics: if someone isn’t ready and eager to work with me, I shouldn’t have their business or their money.

I shouldn’t and won’t persuade people into working with me.

So what’s that dirty secret in the business world?

It’s this: manipulating people into buying by leveraging the wrong element of the human psyche.

We’re built, hardwired and programmed, to a) avoid pain and b) move towards pleasure.

That’s deeply ingrained in our subconscious, and it has an influence (and often a mandate) in literally everything we do.

But a LOT of marketing works on that first one: avoiding pain.

In a narrower sense: loss aversion. The fear of missing out.

“Get this now or you’ll never build a business!”

“Buy this or you’ll be a loser forever!”

“If you don’t enroll today, this offer will go away forever!”

“Buy this or the puppy gets it”. (Hat tip to Hugh MacLeod)

And that’s wrong.

Sure it’s good to have a limited time offer, to make a special deal that will disappear, or to create an offer at a one-time-only discount.

But to pummel people into compliance by ruthlessly pushing that button that tells your gut “Your life won’t work without this” ?

That’s trying too hard.

But, the fact that so many people do this and do it aggressively, gives you an advantage.

Because you get to show up as an ethical business professional, with an interest in your client’s well-being.

That allows you to build relationships with people.

And over time, those relationships will turn into sales.

So when you see people driving hard sales based on unethical ways to exploit fear of loss or threat:

<span style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen-Sans, Ubuntu, Cantarell, 'Helvetica Neue', sans-serif;">1: Close the page and move on. I don’t feel that kind of person deserves your business and even if they do: if you were to buy, you’d do it because you’re being manipulated. And you deserve better than that.</span>

2: Smile, knowing that you’re not like that, and that while those folk have to advertise and sell sell sell and work intricate systems of adwords and SEO and conversion rates, you’re building an audience and relationships and therefore: a healthy and ethical business.

3: Write an email to your list. Because whatever your business and whatever your audience, email marketing is a fun and non-pushy way to show up to people who just might want to work with you.

And if now or at any point you want to work with me, you know what to do.

&nbsp;

---
title: Do You Dare to Lift Up the Carpet?
status: draft
datePublished: '1483434277'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

Oh all those things that have gone hidden.

			The things of life that we sweep under the carpet, pretending that they’re not there.

			Old hurt, fears, hangups - the little (or large) bits of ourselves that we or others
			have condemned, and that rather than get rid of, we decided to hide.

			We all have them of course, myself included.

			And as long as that stuff keeps hidden, we can get by, most of the time.

			Even if hiding things in the subconscious will always backfire, sooner or later.

			Much better to lift the carpet and make clean. Properly.

			But when you do, it can get messy.

			Especially when it’s stuff that goes back a long way.

			You lift the carpet, wield the broom, and before you know it, you nearly choke on all
			the dust.

			But it’s part of doing inner work, and while it might be unpleasant, remember that it’s
			a good sign.

			In fact, when I coach people and nothing old and forgotten comes up, something isn’t
			happening that should be happening.

			So, welcome the mess.

			Yes it can be nasty, but remember that for each issue that comes up, you get the chance
			to finally, for once, get rid of it.

			Those things to leave behind, that I wrote about last Saturday?

			That’s what I’m talking about.

			It takes a courageous person to do it, but I’ve never seen someone who didn’t benefit
			from stirring the pot.

			The sediment comes up, and then you get to filter it out.

			Or, to quote Theresa of Avila:

			For wood to turn into charcoal, every impurity needs to be burnt up.

			It crackles and pops and all colour of flame shows itself.

			Until there’s nothing left but pure carbon.

			And that process applied to the human being, is the work of giants.

			Only the brave can do it.

			And only those who desire radical change and freedom from the past are able to do it.

			So don’t be afraid.

			You’re not meant to be a slave to anything.

			And unshackling yourself, while sometimes hard, is good.

			And when you get assailed by the old mess you tried to hide for so long, remember this:
			It’s your chance to finally do away with it.

			*Sweep sweep*.

			Want help with that, you ready to finally clean house?

			Let me know.

			I might be able to help.

			Cheers,

			Martin

---
title: Change is an Inside Job
status: draft
datePublished: '1530870747'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/a8380363-e686-419b-b0eb-0ff585914b46.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/a8380363-e686-419b-b0eb-0ff585914b46.png" data-file-id="4835893" />Look, I get it. If there’s not enough traffic coming to your site, if there’s a relationship that’s not working, if money is low, if your potential clients don’t buy… something’s got to happen.

Something’s got to change.

Decisions to make, work to do.

But never forget that the biggest, most important change you can make is on the inside.

And a scarily high percentage of people get that ass-backwards.

They think that inner change is all very nice and useful, and - I’ll get to it once I’ve solved my practical problems.

In other words, inner change ends up on the someday/maybe list.

And I don’t know about you, but in my life that’s not where it belongs.

After all, the way you are determines how you experience life and how your life runs.

Angry people are angry, judgmental people don’t take ownership, people who hide behind ‘I can’t’ or ‘I don’t know’ will struggle to advance… you get the picture.

So for me, the priority of change is self-first. After that, everything else gets easier.

And looking back, I now see that this priority already existed in me when I was 20 and entered a monastery. So yeah, 20 y/o Martin: thanks much. Great job.

So today I invite you to stop everything for a moment, and reflect:

Which things about you would you love to change… but you’ve not given it enough priority?

And what would happen if you would give it that priority it deserves?

What, in effect, is the most core, most fundamental thing you’d like to change about yourself?

This is high-level thinking, so try to go above and beyond the obvious, like ‘procrastinate less’ or ‘improve my dietary habits’.

Give yourself some time to reflect on it. Take a walk, or journal/brainstorm the question, or whatever method works best to create clarity.

But don’t skip it. Because improving your way of showing up to life can’t ever be a someday/maybe item.

Change the inside elements, and everything else will become either easier, or irrelevant.

Like that time I went bankrupt, and I sailed through it with nary a tear or moment of stress - just because stuff on the inside had changed.

And that kind of effortless mastery could be yours too - but only if you're committed to creating inner change.

Cheers,

Martin

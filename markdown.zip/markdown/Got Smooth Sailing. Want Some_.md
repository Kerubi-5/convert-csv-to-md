---
title: Got Smooth Sailing. Want Some?
status: draft
datePublished: '1532365055'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/ada9379b-6d1d-4408-a646-35a1c8e919cd.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/ada9379b-6d1d-4408-a646-35a1c8e919cd.png" data-file-id="4835941" />A girl I used to date had a habit of debating things and taking a contrary position by default.  (obviously, the affair didn’t last long).

When I asked why she had that habit, she said that it makes things more lively. Spices things up.

Said that you can’t have the good without having the bad, and that it’s normal for people to disagree. Healthy, the spice of life.

I told her that in my world, it’s perfectly possible to have good, without bad.

That you can have variation between normal - baseline good - and higher levels, like really good, awesomely good, and just plain lovely good. That there’s no need to be at odds.

And I told her that I try everything I can to create smooth sailing in my life.

(Which, I might add, I’ve developed to a rather pleasing degree of perfection. Life really is smooth sailing for me, most of the time).

To which she replied by sending me one of those perfunctory quote cards you see on social media, with the text (translated from Spanish):

“No calm sea ever created an expert sailor”.

I sighed. You know those moments when something happens, and you know for a fact that the end has come, it just hasn’t shown up yet? That was that moment for me.

Because someone who believes that disagreement and yelling at me is normal and healthy, well I just don’t have space for that in my life.

Anyway, the quote might sound fun, but it’s actually completely wrong.

Sure you can get really good at sailing, crossing tempests and stormy seas.

(You can also get very wet or very dead, but that’s not the point).

So if you survive stormy weather, you might get good at sailing. Sure. Though one has to ask if an expert sailor wouldn’t avoid ending up big storms to begin with.

But to me, real excellence in life (be it sailing, relationships, business etc) isn’t in how to handle hard times or strife. For me, that’s beginner-level stuff.

No, real excellence is in how well you handle, and optimise, runnings when stuff is already going pretty well.

Tuning the sails just so… setting and correcting your course exactly to work with the waves and currents, instead of against.

Getting the most out of the weather, your ship, your intuition, the wind.

That, to me, is what excellent and expert marinership is about.

And that’s how I try to live, and again: pretty smooth sailing here.

And I’m not saying that to brag, but to inspire you to also seek the way to turn good into excellent.

To help you want to create flow and mastery in life and business.

To hopefully light a fire in you, to discover how you also can learn to live effortlessly. Because you can, no matter what the circumstances. I promise.

And if you want to learn how I managed to do that, then you definitely do not want to miss the free live webinar I’ll put out soon, for the Calibrate Reality training I’m creating.

I’ll take you through the basics of my method - my system - for living with effortless mastery.

If you put the method to use for yourself, you’ll be able to create smooth sailing, a little more every day.

Because life is too short to live in struggle and strife.

Sounds good, right?

Then hit reply and let me know that you want to participate in the free live webinar.

Cheers,

Martin

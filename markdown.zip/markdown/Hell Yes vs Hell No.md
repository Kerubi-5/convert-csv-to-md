---
title: Hell Yes vs Hell No
status: draft
datePublished: '1522849705'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/04d9f8da-da63-4a04-a356-fc9c76431dec.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/04d9f8da-da63-4a04-a356-fc9c76431dec.jpg" data-file-id="4835613" />One of my attitudes in life is “If it’s not a hell-yes, it’s a no”.

Makes everything so easy: plans, decisions, people, meetings, projects… whatever it is - if I don’t feel a clear hell yes about it, it ain’t gonna happen. (Most of the time. It’s a hard rule to live by).

But I realise that the hell-yes approach is only the first level of deliberate living.

To really create your own life, and have the mental and emotional clarity and space that enables you to thrive, there’s a next level:

Hell no.

It’s (fairly) easy to say hell yes to what you want (unless things like self-sabotage are in the way, in which case I might be able to help).

It’s far more difficult to say no to things. When you’re able to do that, and not give in and do the things you don’t want anyway (people-pleasing, anyone?), that’s when you’re playing the game of life and living with intent at a ninja level.

So, what’s in your life that when you think of it, actually, it’s a clear and decisive hell no?

And, want to do something with that?

Cheers,

​Martin

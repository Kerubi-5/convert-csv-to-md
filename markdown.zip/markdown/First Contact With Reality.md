---
title: First Contact With Reality
status: draft
datePublished: '1497545593'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/2a6ade98-0b9c-490d-8642-4114f750c886.jpg" width="197" height="350" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/2a6ade98-0b9c-490d-8642-4114f750c886.jpg" data-file-id="4834709" />They say that no plan survives first contact with reality.

And that goes for second contact, and third and fourth contact as well, and keeps up as you go along.

Or as John Lennon said it: Life is what happens to you while you’re busy making other plans.

So you carefully craft a plan, mapping out each step of the way, and before you know it:

Something unexpected comes up, something you hadn’t accounted for.

Used to be, I’d instantly throw the plan in the bin, and proceed to fly by the seat of my pants.

Slowly though, over time, I learned that plans being incomplete or in need of adjusting isn’t a problem - it’s a blessing.

It’s the way things have to be, it’s natural.

A seed sprouts, a root starts to grow, and the very moment it emerges from it’s husk, its plan - dig into the earth, shortest way possible - fails.

It might be too high on the ground, there might be a pebble in its way that it has to curve around, an insect or worm might push it aside just as it enters the ground - there’s just no way that the default plan could ever work.

And the default plan is not meant to ‘work’.

What’s meant to happen is that the system - and you are also a system - effortlessly and fluently adapts to the circumstances that present themselves.

Took me a long time to come to terms with that.

But these days, I’m better at it.

I make the plan, get into action, see it fail - and then I adjust and retry.

Pivot and proceed.

Because of that, changing plans no longer frustrate me - instead, they enable me to stop, assess the situation, and adjust.

In that sense, I’ve become agile, and it makes for a whole different way of dealing.

It has - yes of course - become a habit for me to alter and modify the plans, and it makes all the difference.

Might want to try it for yourself.

Or try with my help if you want - so just hit reply if you want some of that.

Cheers,

Martin

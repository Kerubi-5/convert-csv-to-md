---
title: I Give Up
status: draft
datePublished: '1519903315'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

[caption id="attachment_20293" align="alignleft" width="300"]<img class="size-medium wp-image-20293" src="http://martinstellar.com/wp-content/uploads/2018/03/MartinStellar_Illustrations-giving-up-to-give-in_calling_artist_osmiroid-300x300.png" alt="" width="300" height="300" /> <br />"Reading man drinking coffee". Saw him when I had one myself on a terrace. The pen btw is an Osmiroid with a Copperplate nib - my favourite fountain pen of all times, and I've tried a LOT of them. It's got a nice scratchy feeling on the paper, and the tines are long and springy, which I love for the variation in line thickness it gives. The brand no longer exists, but you can get these on Ebay for a few bucks.[/caption]

I give up resisting.

(This one may be about me, but there’s an important message in it for you, so do keep reading).

I give up resisting, and I give in, to being (becoming?) the artist I have always had to be, but never allowed myself to.

Does that mean I’m going to stop coaching? Yes. At exactly the same moment I draw my last breath, and I hope that ain't gonna be today.

But aside from the beautiful bread&amp;butter coaching practice, I can no longer escape what, I have to say, is a calling.

Oh I know, I’ve always called myself an artist. After all, making a suit by hand is an art in itself. And I play the guitar, I had a funk band way back when, I’ve exhibited photos and written a few poems people said were quite good, and more artistic explorations…

But it’s always been surface level stuff - a name but not a practice.

While in reality, there’s always been this pull. A desire, a drive, a (hideously ignored and resisted) deep-seated NEED to create things.

The fact that I tried at least a dozen times in the last 30 years to draw says enough.

But the inner critic always stopped me, and when he didn’t it was my own resistance. Excuses, procrastination, spectre-like wrong priorities…

And I’m done. So very done. So I give up.

I give up my resistance, which has always been so very strong.

I am SO GOOD AT RESISTING! (Just ask my coach!)

And as with any deficiency, this resistance has a flipside, a positive side if you can see it.

In fact, my ability to resist is what enabled me to get through 12 hard years in a monastery. My resistance is what enabled me to sail past a horrendous bankruptcy a decade ago.

But I’m no longer going to let this resistance stand in the way of my doing what I have to. And that is to create, and play, and make stuff. God, I miss making things.

So this weekend, my artist’s date is to clean out my guest room and turn it into *gasp!* a studio.

I’m going to play with charcoal, splash paint on kraft paper for the fun of it, I’m going to sketch and re-string my guitars and toy with epoxy resin, and I’m going to draw hundreds and hundreds of boxes, cylinders, and spheres. Good practice, I’ve noticed.

I’m going to have SO much fun, and maybe I’ll make things that I love. Who knows. Probably.

Now, the reason this matters to you:

You very likely have your own flavour of resistance.

And let me tell you: resistance is futile.

When you resist, one of two things will happen:

You’ll either resist your calling all your freaking life and end up regretting you did, which is a sad way to go...

or…

Your calling will, in the end, win the fight.

And if it isn’t your calling that you resist, it’s things like stepping up to the business-plate, and turning pro (see my recent articles for more about that), and doing the boss-man or boss-lady things that get your work out into the world.

Either way, you can resist all you want, for as long as you want…

But I ask you: to what end?

What benefit is there to resisting?

Don’t skip over that last one, because it’s an important coaching question.

What benefit do you derive from resisting the things that deep-down, you know are calling to you, pleading and begging for you to finally give in, and do them?

Once you figure that out, you can move forward. Because once you know what benefit there is, you can start looking for other ways to give yourself those same benefits. There’s more than one way that leads to Rome.

Anyway, I’m done resisting.

Are you?

If so, drop me a line. Maybe it would be good to have a conversation…

Cheers,

Martin

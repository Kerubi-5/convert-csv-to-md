---
title: Loathe Being Sold To
status: publish
datePublished: '1513350858'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - How to sell your work
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/f1666b43-603c-42b8-a5ea-93fe1ff734e5.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/f1666b43-603c-42b8-a5ea-93fe1ff734e5.png" data-file-id="4835285" />If you look at the amount of money that gets made each year at times like Christmas, you might think it’s simply because of the aggressive, pervasive, inescapable advertising and marketing that gets thrown at us.

But that’s not really why.

The real reason so much stuff gets sold, is that people love to buy.

A book, shoes, a holiday, education and training: each time you decide to spend money on something, it’s because you want to.

You’re willing to part with money so as to have that thing that’s on offer.

But at the same time, we loathe being sold to, and we notice that especially at seasons like these, when we’re bombarded with ads and discounts and sales.

So people love to buy, but loathe being sold to - where does that leave us, the friendly, non-pushy business owner?

Don’t make the mistake of thinking that just because you’re nice and your product or service rocks, clients will find you and show up to give you money, all by themselves.

I used to think that, and it cost me a small fortune and a tailoring company. You do need to get out there and find the buyers.

But people don’t like being sold to, so what can you do?

It’s simple, really really simple.

If you want to sell your work and you don’t want to be pushy or manipulative - but you do believe in your work and you know that people would benefit from buying…

Then make it your job to facilitate the purchase.

Be the trusted advisor.

Position yourself as someone whose interest is in the world and benefit of the buyer, instead of making money in your pocket the primary interest.

Yes of course you want to get paid, but if someone wouldn’t be happy with their purchase… do you really want their money? (If the answer is yes, I’m afraid you and I don’t have a lot in common).

Everyone else here, who does really want the buyer to be happy, remember this:

The trick to ethical, non-pushy sales, is to facilitate the buying process.

Turn yourself into a helper, whose job is to assist the buyer in making the right decision.

Even if that decision is to not buy at this point.

When you’re willing to lose a sale if that’s the best choice for the potential buyer, you’ll have achieved something essential for a healthy business: the other person will know - feel - that you’re not just in it for the money.

Or to borrow a quote from Maya Angelou: “I've learned that people will forget what you said, people will forget what you did, but people will never forget how you made them feel.”

And how does it feel when someone does not force a sale on you, but has the grandness and fortitude to let you walk away? It feels awesome! And you bet people will remember that.

And that means that even if you get a no, you’ll still have a healthy relationship with that person. Which makes it far more likely that they’ll come back at some point, compared to someone who walks away feeling like they made a narrow escape.

Never forget: if people love to buy, the best thing you could possibly do, is facilitate the buying decision.

&nbsp;

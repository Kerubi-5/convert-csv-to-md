---
title: Any Leads In Your Pipeline?
status: publish
datePublished: '1659079464'
categories:
  - Business and systems

---

<img class="size-medium wp-image-28319 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/12/MartinStellar_Coaching_Illustrations-Any-leads-in-your-pipeline-300x225.jpeg" alt="" width="300" height="225" />

How often do you ask yourself that?

"Do I have any leads in my pipeline?"

Because the difference between a coach or consultant who struggles, and one who thrives and lands clients and earns great money, really comes down to one thing:

Working the pipeline.

As in:

A recurring habit of reviewing the people in your world - your leads, or candidates, or prospects - and asking yourself a few simple questions.

Like:

"What needs to happen for this deal to close?"

Or:

"What action can I take to move this deal forward?"

In an ideal world, each working day, you open up your list of opportunities - be it a spreadsheet, or a CRM, or a little black book of names if you want - and you review the people and deals there.

Then you ask yourself a few simple questions, you take appropriate action, and each day you do the things that keep your deals moving through your pipeline, and your sales closing.

But it's not an ideal world.

And in my speaking with hundreds upon hundreds of coaches and consultants over the years, I've found one single recurring mistake that nearly everyone makes:

A reactive, haphazard way of treating a list of people and opportunities.

At best, we open our CRM or spreadsheet a few times a month - or worse, we do it at a point where we're short on money or sales or leads.

"Ooh! Business under pressure! Must dive into my CRM!"

And so you dive in, you see a bunch of stale deals; a bunch of people who've stopped replying; a couple of micro-managing people; a handful of bargain hunters...

And the next thing you know you're spending the morning on Facebook or LinkedIn, calling it "marketing".

And this problem - not working a pipeline in a constant, intentional way - is so rampant, it's not even funny.

So what about you?

Do you check in on your pipeline and your deals on a daily basis?

Because if you want to generate opportunities, land clients, make money, and have an impact, that's exactly what you should do.

&nbsp;

<hr />

On another note:
I'm building an app that coaches you on working your pipeline, moving your deals forward - and closing them faster and at better rates.
It's called SalesFlow Coach, and we're scheduled for beta-release in June 2022.
Register <a href="https://martinstellar.com/salesflow-coach-launch/">here</a> to be notified when it goes live.

&nbsp;

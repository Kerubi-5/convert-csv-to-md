---
title: Leaning Into Discomfort
status: draft
datePublished: '1544180018'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21141" src="http://martinstellar.com/wp-content/uploads/2018/12/MartinStellar_Coaching_Illustrations-Leaning-into-discomfort-1024x768.png" alt="" width="351" height="263" />Part of us knows what must happen in order for change or success or well-being to show up.

On some level, we’re super-clear on what’s required of us.

And when we’re not?

Then the solution is extraordinarily simple:

Do the thing you most resist.

It’s there, where you’ve “reasons” for not doing them, that you’ll find key insights, and breaktroughs.

I’ve seen it so many times, with friends and clients:

A suggestion to do thing X gets put off for yonks, because /reasons.

So many excuses, so many cat pics to see first, so many new and cleverly inventive ways to procrastinate…

All in service of not doing that one thing that will actually make a difference.

If you want change in self&amp;results, you can either resist until the cows and a full Noah’s ark come home, or you can adult-up, and do the thing that you on a gut-level know is going to work, and that your mind reasons away, or your emotions try to brush under the carpet.

Choice is yours…

Lean into the uncomfortable… or stick your head in the sand?

If you (like most people and yours coachily included) are prone to go with the latter, remember this:

The thing that your guts knows will make the difference is not going to go away, no matter how much you pretend it’s not what you need right now.

And the sooner you stop resisting and give into it, the sooner things will improve.

Cheers,

Martin

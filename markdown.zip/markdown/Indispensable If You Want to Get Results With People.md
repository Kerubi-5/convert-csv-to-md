---
title: Indispensable If You Want to Get Results With People
status: publish
datePublished: '1599007846'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-21772" src="http://martinstellar.com/wp-content/uploads/2019/06/MartinStellar_Coaching_Illustrations-People-results-and-connection-1024x768.jpg" alt="" width="348" height="261" />If you’ve ever driven on the Boulevard Périphérique (the ring road around Paris), you’ll know that the Parisians have a… well, very special way of driving.

It’s sketchy, sometimes aggressive, very unpredictable, and requires that you pay very close attention.

And when it comes to lane closures and merging traffic, you’ll know how hard that can be.

No matter how long your signaling light is on, or how much you try to nudge your way into the other lane, it seems people just don’t give a damn.

But a while ago, in what some consider the worst possible city for driving, magic happened:

I had to merge to the right, many cars were passing by, and nobody let me in.

But then I leaned forward and to the right, and looked at the driver next to me - he saw me, nodded, and instantly slowed down to create space for me.

Why did he do that?

Eye contact.

Connection.

One human signaling to another, and the other picking up on it - because we’re hardwired to connect with those who petition a connection.

And that’s where we often fail to get results with people: we don’t signal a connection request. We don’t connect our humanity to the other person.

But once you do, and the other person reads ‘I see you’, everything changes.

So if ever you’re trying to get results with someone, be it selling or getting collaboration or having someone hear you out, and it’s not working, ask yourself:

Are you trying to push your own agenda, or are you seeking to connect?

No matter how right you are, or how good your idea or product or service:

Connection is indispensable if you want to go places with others. Connect first. The rest follows from there.

How to create those connections, and move forward with people - and yes: land more clients - is something I can show you in a <a href="http://martinstellar.com/leap-ethical-selling-framework/">10-week training on ethical selling</a>.

&nbsp;

<span style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen-Sans, Ubuntu, Cantarell, 'Helvetica Neue', sans-serif;">Cheers,</span>

Martin

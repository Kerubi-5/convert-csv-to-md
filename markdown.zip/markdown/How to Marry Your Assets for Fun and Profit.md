---
title: How to Marry Your Assets for Fun and Profit
status: draft
datePublished: '1522331946'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft size-medium wp-image-20348" src="http://martinstellar.com/wp-content/uploads/2018/03/MartinStellar_Illustrations-Leveraging-assets-for-fun-and-profit-300x225.png" alt="" width="300" height="225" /> Both for myself and with my clients, I give a lot of thought to the concept of assets.

Especially assets we have, but don’t use.

And we all have ‘em.

And, I have some interesting experience in leveraging assets.

For example: about a decade ago, my tailoring company went bankrupt, and I was in debt.

I moved to a different town to try and reboot, but I realised that it would take time to build up a network. Meanwhile, I had rent and bills to pay.

What to do?

I took two assets, put them together, and whoopti-doo: I was self-sustaining in 6 months, profitable in about 12, and I was taking home aboug $5K a month.

How I did it?

Simple: I had studied marketing and sales quite a lot while trying to build my company, and I had always been a capable writer.

Two assets: writing chops, and sales knowledge. Together, that made for Martin the copywriter, and I started hunting and getting jobs online.

Fast forward a decade, and I’m a business coach who works with artists and other types of creative professionals.

And a client - a realism painter named Richard Hall - mentions the dirty secret of the art-world: that every artist (EVERYONE) has unsold inventory.

So I propose that we leverage the most important asset he has: his list of subscribers.

So we design a 5-day online sales strategy, we create a series of simple short emails, and last Halloween he pushed launch.

The result? An astounding total of $18K in sales of original artworks.

Just by combining assets: his list, and my copywriting background (which is one of the many reasons it’s a great idea to work with me: you get my expertise in copywriting to advise on how to write yours, but I digress).

Over to you: what assets do you have, that you could leverage?

Could be relationships with a community (online or offline)

Could be a relationship with an influencer, or a potential mentor

But think outside the box:

Previous work experience?

A hobby from the past you gave up but could include in your business somehow? (why yes, why not sing your sales letters? Might just work)

Unsold inventory, another important asset. How else could you put it to work, aside from trying to sell it?

What about a natural ability you have, but never considered special or usable - for instance quick empathy with people, or deep listening skills?

Making people enthusiastic?

Hey, and here’s a good all-round one: your intuition. Because if you properly listen to it, that’s an asset and advisor to reckon with.

Anyway, you get the point: there are elements in your life and business that, if used, could lead to results.

Identify them, adapt for use in your operations, and make life easier and more prosperous.

And if you want to discuss the assets you have, and how to leverage them, I’m here.

Just answer a few questions here, and we’ll talk: <a href="https://martin283.typeform.com/to/v7Dsh8">https://martin283.typeform.com/to/v7Dsh8</a>

Cheers,

​Martin

---
title: Do You Spend Other People's 'Currency'? Might Want to Check...
status: draft
datePublished: '1564133336'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/4a342d8a-e4c2-4c25-b7b9-4241ccac67a6.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/4a342d8a-e4c2-4c25-b7b9-4241ccac67a6.png" data-file-id="4835813" />

I can’t be sure, but there’s a good chance you too spend other people’s currency.

It’s a human, social thing - but it’s wise to avoid, and if you don’t it will have consequences.

Here's two recent examples of ‘spending other people’s currency’, so you know what I mean.

Two of my friends were meant to come over for dinner a while ago.

But the day before, one was wavering on their decision, so the other friend texted me to ask whether they should both come, or only one, or nobody.

Fair play, things change. But this text reached me right in the middle of deep work, pulled me out of my concentration, and had me thinking about an issue that wasn’t mine to resolve - it was something they needed to figure out, so asking my help or opinion really made little sense. No big deal of course, but an example of how I suddenly found myself spending 'currency' (in this case: thinking-time) because of something sent to me - and it was something I couldn't do anything to resolve.

The other example: in my mastermind group, one of the guys once asked if we could move our weekly session, so that he could watch a football match.

Again: no big deal (though in my world, football ain’t nowhere near important enough to, well, change any appointment. I just don't like football. Also: I am the king of euphemisms - can you tell? But anyway).

When my buddy asked, that meant two other people (me and our 3rd mastermind member) had to think about accommodating the change. Spending mental currency.

And to accommodate the request, in my case would have meant changing two appointments, which would have further implications for the people whose appointments would get changed - and the same thing would apply to the world of our 3rd mastermind member).

In other words: a small action on our part can have a lot of domino-type ramifications for other people, and not only the first-line people get affected. It affects their people as well.

Even something as small as the difference between an email that states a bunch of things and then just ends, compared to the same email, but ending it with a clear type of Call to Action or next steps, will make a big difference on the currency that the recipient will need to spend.

Email 1 turns your ‘problem’ into somebody else’s problem, because they now have to decide on what action to take next. Email 2 is far better, because it already suggests a next action for the reader, and they don't have to also take the action of thinking about the next step. So none of their currency gets wasted.

Now, you might that these things don’t matter all that much. That I’m making a fuss over trifles.

But nope. This stuff really matters.

Because you and I and everyone, we know the people who spend other people’s currency.

They are the ones who always seem to need something, always seem to need help or guidance, always bring things into your world that aren’t yours to deal with but now suddenly you find yourself thinking about it, people who blindly delegate whatever they’re not in the mood for dealing with, to whoever happens to be in the line of fire…

They are the people that always cause a sigh or a grunt when they show up. Because they never arrive without a complication, or problem, or some sort of cost. For you to pay.

It’s not that these people are bad, don’t get me wrong.

But MAN is it annoying to have people spend your currency!!

Therefore, don’t be that guy or gal.

Don’t spend other people’s currency, don’t make your problems their problems.

I invite you to spend this week looking at your communications and decisions, to see in what way you might unwittingly spread around bother in the world of others - the bits that are small and subtle is what we’re trying to uncover here.

You just might find that paying attention to this will very fast, almost magically, improve your relationships… even those who are already quite healthy.

Have a look, see what you discover… and let me know how you go.

Cheers,

Martin

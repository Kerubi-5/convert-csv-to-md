---
title: Delaying My Book, but Don't You Dare Delay Your Prosperity
status: draft
datePublished: '1490177063'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

So this book I’m writing, The Prosperous Artist... I’ve had to delay things a bit.
			My plan was to submit the manuscript by April 1st, but I can’t.

			For starters, the book is behemoth. It’s long and big. In fact when I sent my publisher
			the outline, I think the poor guy must have had a minor heart attack.

			But also: there’s been so much going on that I won’t be able to get it all wrapped up on
			time.

			Public speaking gigs, Joint Ventures with other entrepreneurs... meeting a number of
			exceedingly kind, interesting and influential people...

			And all that takes time.

			Of course a logical decision would have been to stick to my truth: Stay focused, say no
			to anything that takes away from reaching your goal.

			But I chose not to, because for one thing, public speaking is something I want to get
			into.

			My phrase for the year is ‘let’s take it to the stage’, and when the opportunities
			arise, I must take them.

			Also, last fall I realised I needed to upgrade my network. I knew many wonderful and
			lovely people, but not enough people with a big ambition.

			And these days, that’s exactly the kind of people that I’m meeting.

			So yeah. Book delayed. Good things happening.

			But while The Prosperous Artist might appear a few months later than planned, don’t
			think that means you get a raincheck on working on your own prosperity.

			The book will help you lots once you read it, but you already have tools and resources
			and underused assets that you can put to use.

			So, may I invite you to get with the game, and get serious about becoming prosperous?
			Step one: understand that prosperity isn’t just about money.

			It means ‘to do well’ and that means it is about doing well in all kinds of ways:
			Socially, professionally, emotionally, intellectually, spiritually, and yes:
			financially.

			So if the cash isn’t there yet, or there are other things lacking in your life, start by
			looking at the elements in which you are prosperous, and start building from there.
			Right, I need to prepare for my talk next week. Catch you tomorrow.

			Oh and: if you want my personal help in becoming more prosperous, hit reply.

			Cheers,

			Martin

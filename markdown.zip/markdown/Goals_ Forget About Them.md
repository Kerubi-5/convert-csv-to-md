---
title: Goals? Forget About Them
status: draft
datePublished: '1513680943'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/c7916e72-41fc-4a9e-83d2-b13ab773c01c.jpg" width="350" height="350" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/c7916e72-41fc-4a9e-83d2-b13ab773c01c.jpg" data-file-id="4835293" />Also: don’t even THINK about making New Year’s resolutions.

Wait, what? Is this the same Martin who wrote about plans for the new year, yesterday?

Yep, same dude.

And I’m not joking.

Let’s do this one quickly.

Resolutions are known to fail, and lots. Only 10% of them actually make it.

And the big problem is that if you don’t stick with it, you have an excellent reason to beat yourself up over it.

There’s better ways - for example, a quick search showed me the WOOP strategy.

W: a wish

O: an objective or goal

O: recognisings possible obstacles, and most importantly:

P: a plan to overcome the obstacle.

Sounds a lot better than resolutions, right? Right.

And as for goals, the best thing you can do with them is set ‘em and forget ’em.

If you want to climb a mountain and your goal is the summit, are you going to focus on that goal all the time?

Of course not. You’d walk off a cliff, or get eaten by a bear, or you’d lose your way.

And that applies to any goal you could set.

Focus on the steps, the roadmap, the plan. Focus on what you’re doing to reach the goal.

Trust me, you can safely forget about the goal itself, once you’ve set it and made a plan.

Every couple of weeks or months you review your progress and adjust as needed, and on you go.

Because here’s the problem when you’re constantly occupied with the goal:

It will always seem like it isn’t getting any closer!

If you’re looking at the goal (especially the big ones), it’ll soon start to feel as if you’ll never get there.

So focus on the path. The steps.

Progress, not the end result. That’s what you always want to keep looking it.

Right? Good.

And if you want help picking a goal and creating a plan, just let me know.

Cheers,

​Martin

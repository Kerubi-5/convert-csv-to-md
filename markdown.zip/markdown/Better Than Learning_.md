---
title: Better Than Learning?
status: publish
datePublished: '1515759852'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/c01056bc-c839-46f4-9e49-55f70bf948da.png" width="350" height="277" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/c01056bc-c839-46f4-9e49-55f70bf948da.png" data-file-id="4835369" />I often hear entrepreneurs complain about how hard it is to keep up with all the information.

The courses, trainings, webinars and blog posts… just so much to take in!

Whenever I hear something like that, my first thought is always: do you actually NEED all that information?

Because don’t forget: 99% of the people in the information business leverage the basic human fear of missing out, in order to persuade you that you really need this or that bit of information.

When in reality, you probably don’t. In reality, it’s very likely that if you put yourself on an information diet, and go all-out into creating and taking action, you’ll feel more relaxed and produce much better results.

So if you are struggling to keep up, consider this:

There’s two kinds of learning: “mile wide, inch deep” and “inch wide, mile deep”.

The first gives you a broad, intellectual understanding of things and the laterally connected topics. Useful when, for example, you want to go from running a bricks&amp;mortar store to opening an online retail channel.

In a case like that, a broad general understanding is required. You need to wrap your head around all that goes into it.

The second kind of learning, that’s what they call ‘just in time learning’.

That’s when you take one particular topic, and you dive deep into it. It’s when you set out to become masterful, or expert, and one particular thing.

For me, broad learning happens every day: 30 minutes of reading in the morning, on whatever happens to interest me.

The ‘just in time learning’, I do that only when necessary. Usually a few hours of reading articles and PDF’s is enough to get me ready for… wait for it:

Action.

Because while I’m a lifelong student and a proponent of learning, there’s nothing as effective and important as taking action.

And that’s where the risk of learning shows up: it’s very easy to stay stuck in learning mode, always wanting to discover the missing link, the piece of info that will make all the difference, and not take the action that will produce results.

The biggest problem? Learning from books or trainings will only get you so far.

No matter how much information you cram into your head, it will never be complete learning until you put things into practice, and discover how you, and your business, and your market, actually work.

So if you feel overwhelmed with all the info, maybe your best move is to close the books. Unsubscribe from all the email newsletters, and start taking action.

Because each minute you spend on learning something that you don’t need now, is a minute you’re not putting towards building your assets and your business.

A minute spent learning what you don’t need right now, this very minute, versus a minute spent building something…

I know what I’ll choose, any day of the week.

You?

&nbsp;

---
title: How Do You Use Your Tools? (+Everything is Healing Nicely)
status: draft
datePublished: '1529919006'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/ecbbd3c0-de2a-4680-bfbb-05b769f3e682.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/ecbbd3c0-de2a-4680-bfbb-05b769f3e682.png" data-file-id="4835849" />The elbow is an enormously useful tool. Not only can it bend millions of times over a lifetime, it can also be used to jokingly rib a friend, to poke and ward off an attacker, or to lean on things like tables and windowsills.

What’s it’s not very good for though, is falling on top of, when you’re in a wipe-out on your motorbike.

I tried that the other day and I can confirm that it’s not what the elbow is made for. It works, but it's no fun.

Not that anything terrible happened btw: it was in town at low speed, and aside from a broken rib and some scrapes on my legs, I’m fine.

But it got me thinking about how weird we are.

Normally, we get protected by our lizard brain.

When we’re about to fall, our instinct tells us to drop everything and reach for that thing rushing up to meet you - usually the floor.

But I didn’t.

I did feel the urge to catch my fall with my hand - I literally noticed the order given by my lizard brain: “Drop everything NOW. CUSHION YOUR FALL - STAT!” - but I didn’t.

Watching as if in slow motion, I saw my rational mind step in and say: “Back off buddy, we don’t need your help here. This is slow speed. We can catch this bike and save everything”.

Very weird, to be aware of it in the moment.

And of course, the mind was wrong, as it always is when it argues with the subconscious.

There was no way I could catch the bike. So it fell, and I fell, and since my hand was still holding on, all I could do was land on my side, and my elbow happened to be there. Ouch (a little - I’m lucky as hell in that it doesn’t hurt much).

So there’s two lessons I’d like to draw from this for you:

1: There’s no use, ever, in arguing with the subconscious. It has a far wider knowledge and insight than the arguing rational mind, so really you serve yourself better by listening than protesting.

This applies both to everyday life, as well as instant reflex, fight or flight-type situations (though you’ll obviously have less control there).

Point is though, your subconscious knows stuff. I urge you to listen to it and assess what it says, rather than argue your point against it. You’ll never win, because when you do you lose.

2: How often do we not use our tools for something they’re not made for…?

Obviously, an elbow is not for falling on. And obviously, the mind is not for listening to when your subconscious is trying to protect you.

But beyond that:

Your joyful social presence and giving nature - are you using it to while away your time on Facebook, or do you go there to use those qualities so as to have meaningful, business-building conversations with potential clients?

The writing skill you have - do you use it only to write your journal or your morning pages - or do you also use it to brainstorm your business growth, or - even better - to send daily emails to your peeps.

That carefree joyful way of showing up to a camera, do you use that tool at all? *points at self*

And what about that fantastically powerful and utterly resourceful creative mind of yours…

Do you use it to worry and invent doomsday scenarios for the future - or do you put it to work, creating systems and habits and revenue models and what have you, that make those potential doomsday futures a thing to not even worry about?

Of all the tools you have, the mind is the single most powerful one.

Do you use it deliberately?

Do you use it for what it’s made for - meaning: creating your life, future, and reality?

Cheers,

Martin

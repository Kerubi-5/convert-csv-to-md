---
title: Of Curve-Balls and Quick-Change Artists
status: draft
datePublished: '1547740198'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21275" src="http://martinstellar.com/wp-content/uploads/2019/01/MartinStellar_Coaching_Illustrations-The-secret-to-adaptability-1024x768.png" alt="" width="350" height="263" />You spend December planning your work so as to have an awesome year, and come January something happens and jumbles all your plans.

You block out a day for serious deep work, and at 11am you get called away for something urgent and important that takes up your whole day.

You budget money for a large investment, and suddenly the taxman hits you hard, and you have to postpone your investment.

You can fret about things like that, but one of life’s jobs is to throw us curveballs, and it’s really good at doing that.

It’s our job to get good at dealing with those curveballs.

The easiest way I know, is to change suits.

You know how I like to talk about the different suits we wear - the archetypes we lean into, the psychological orientations we adapt in order to show up adequately to whatever life is having us deal with?

Sometimes you’re a mother, sometimes a mature business owner - you can be a playful creative, a listening friend, a seller, a buyer, a shoe-chooser, a negotiator, a peacemaker, a leader or victim or
fixer, a meditator or coder or poet - millions of different kinds of identity for you to lean into as per your choosing.

The more agile and quick you become at ‘changing your suit’, the easier it is to deal with life’s curveballs.

Because the biggest cause of stress in the face of changes, is leaving the wrong version of “I” to deal with it.

Your inner strategist lays out the plan, and your inner worker is tasked to execute. If the worker suddenly sees the planning messed up, he has no choice but to freak out. It’s not his job to amend or fix a broken planning - that’s the strategist’s job.

So your job when something like that happens, is to change suits, quick fast, and put on your strategist hat. You fix the planning, and then you move back into your worker identity.

Each of us, we have a walk-in closet full of identity-suits, and we’re always wearing something.

To bring your best self to whatever game or battle or challenge, it’s good to be aware of which suit we are wearing, and which one we’d better be wearing, depending on the situation you’re in.

Being adaptable to change means becoming a quick-change artist.

Because I promise: there’s no situation or challenge in life, that you don’t already have the suit for.

It’s just a matter of wearing it, and that’s always a choice.

Choose to be a quick-change artist.

Cheers,

Martin

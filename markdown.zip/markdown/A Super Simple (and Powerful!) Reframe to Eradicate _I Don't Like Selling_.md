---
title: A Super Simple (and Powerful!) Reframe to Eradicate "I Don't Like Selling"
status: publish
datePublished: '1608165901'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - How to sell your work
  - Psychology in sales and marketing
  - Relationships

---

<img class="alignleft wp-image-21555" src="http://martinstellar.com/wp-content/uploads/2019/04/MartinStellar_Coaching_Illustrations-LEAP-Sales-System_Ethical-selling-1024x768.png" alt="" width="355" height="266" />"People love to buy, but loathe being sold to..."

If the idea of selling is difficult or uncomfortable for you in any way, remember this:

People love to buy, but loathe being sold to.

And that’s exactly why I'm so excited to show you the inner workings of the LEAP framework for ethical selling, tomorrow in my Flash Training: Sales for nice people.

Because once you get that - once you understand how to make it easy for people to buy, all your struggle in selling your work will change.

And besides: I’ll bet that you have something for sale that truly makes a difference in your buyer’s life.

And - forgive me for making assumptions - you want to see people buy that product or service you have.

But, you do want to stay in alignment with your values, right?

You don’t want to coerce, or be pushy, or manipulative - because hey, you want to sleep at night, knowing that your values, your integrity, and your ethics have not been compromised.

If I’m correct in assuming these statements ring true with you, we have a lot in common.

And as an ex-monk, ethics and integrity matter MUCH to me, just like I imagine they do to you.

Which is exactly why I never ‘sell to people’.

Instead, I just have a conversation. I ask questions, pay attention, tune in to what’s going on in the other person’s world.

And, most importantly, I let people make up their own mind, on whether or not to buy from me.

The result? Fantastic conversations that people are happy with whether or not they buy, and fantastically engaged and happy customers, when they do.

So what’s my secret?

Ain’t no secret.

Other than: I show up to serve.

Specifically, serving means that I help people get the clarity they need on making the best possible decision for themselves, at this point in time.

And if that decision is a ‘no thanks, not today’, I don’t fret.

Whenever that happens, I know I’ve stayed true to my moral compass, and I’ve helped someone choose what’s right for them.

You can do the same thing, once you realise that 'selling' - or enrolling - is nothing more than facilitating a decision-making process, which in itself is an act of service.

Want to know the full scoop, learn the ins and outs, of how an ex-monk creates clients, so that you can transform your own sales process, and sign on more people, with more ease, at the rates you deserve?

Then you ought to join tomorrow's Flash Training...

Add it to your calendar for either <a href="https://calendar.google.com/event?action=TEMPLATE&amp;tmeid=NGlhYTdubHQ1Z3I0Z2txZ2V0aGd2OXNxaG8gOWVra3IwZ3Ntcms2MnFqYmE1czQxcmZwazhAZw&amp;tmsrc=9ekkr0gsmrk62qjba5s41rfpk8%40group.calendar.google.com">Google Calendar</a>, or <a href="https://martinstellar.com/wp-content/uploads/2020/12/Flash-Training-Sales-for-nice-people.ics">MacOS/Outlook</a>

See you tomorrow!

Cheers,

&nbsp;

Martin

&nbsp;

&nbsp;

---
title: 'Comparing Yourself: The Wrong Way and the Right Way'
status: draft
datePublished: '1542879832'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-21104" src="http://martinstellar.com/wp-content/uploads/2018/11/MartinStellar_Coaching_Illustrations-Comparing-yourself-1024x768.png" alt="" width="349" height="262" />Comparing yourself to others is a futile and often self-destructive exercise.

There’s always someone more successful, more famous, better connected or wealthier than you.

And when you compare yourself to those others, you give yourself all kinds of ways to feel inferior, or jealous, or insufficient.

But there’s one person you can always (should always?) compare yourself to:

The person you were yesterday.

But that’s where it gets tricky, because we’re prone to always look at what we have and have accomplished.

Is there more money in the bank today?

Do I have more prospects than yesterday?

Is my list bigger than yesterday?

Did today’s Facebook Live get more viewers than the one I put out yesterday?

This is almost as destructive as comparing to other people.

The thing to compare with isn’t what you have, or have built, or have achieved.

Because all those things are outcomes, they are the result of attitude and action.

And between the action and the outcome is a gap. Things take time to add up and yield results.

And the longer that gap is (often it’s very long) the easier it is to get disheartened.

If you’ve ever thought ‘why isn’t this working better?’, you’ll know what I mean.

The feedback (outcome and results) from your efforts takes time to show up, there’s no way around that.

But attitude and action will, eventually, bridge that gap.

So compare your attitude and actions today, with those of yesterday.

That will give you direct feedback, and it will help you keep going, regardless how long the actual results take to manifest.

Comparing yourself is good, but be very VERY careful who you compare yourself with.

As always: choices, choices. Life is made up out of choices.

Ain’t it grand?

Cheers,

Martin

---
title: Losers vs Winners?
status: draft
datePublished: '1496929551'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/596e22de-b994-4de8-bd24-1f3b2eb326a4.png" width="350" height="197" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/596e22de-b994-4de8-bd24-1f3b2eb326a4.png" data-file-id="4834673" />Ever heard of Scott Adams, creator of the Dilbert cartoons?

He said that ‘losers have goals and winners have systems’.

I don’t necessarily with the bit about goals and losers, but I do agree that systems make ‘winning’ (gah, I can’t see that word without thinking of Charlie Sheen - but I digress) a whole bunch easier.

So no, a goal doesn’t make you a loser, not at all. In fact, you’re not likely to go places unless you have one.

But if you want to go places, you’d better have systems in place to help you get there.

Because it’s easy to get lost in tasks that are rote but that take up your time, while if you make them automatic or systematic, you save time for doing the work that really matters.

Used to be I had to manually update my computer’s backup. Which means I often didn’t and when my computer crashed, I lost lots of files.

But these days I have a Time Machine backup, plus one on a second HD, and it gets updated with a program called GoodSync each time my
computer starts up.

Redundant backups, in case one of the disks fails or gets corrupted.

In other words: a system that I build and don’t need to mind, and that prevents disasters.

Another system that really works?

Creating habits, of course. Especially for the important stuff in your business, the things that move the needle.

You want to have them set up as systems and habits, so that they keep getting done, even if busywork threatens to overtake your day.

And the best system? One where you make it a habit to create habits.

Yes, it doesn’t get any meta than this.

But man that stuff works.

And that, to become a habit-building machine, is the aim of my new Habit--&gt;Path coaching programme.

It’s short: only six weeks.

But it’s damn intense, and by the end of it your days and you mind (and the peace of it) will be VERY different.

In a good way, of course.

So get in touch if you want a piece of that.

Cheers,

​Martin

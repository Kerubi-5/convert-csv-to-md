---
title: Let's Play Scientist!
status: draft
datePublished: '1498642334'
categories:
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/92b01f3d-eac5-4460-b536-78cc58803bf2.jpg" width="350" height="250" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/92b01f3d-eac5-4460-b536-78cc58803bf2.jpg" data-file-id="4834749" />
It's not like I can lay claim to knowing much about science, but I did spend half a year in university on Musicology, so there’s that.

Anyway, to keep things simple:

There’s this concept that if something can’t be proven, it therefore must be untrue or non-existent.

In other words: Absence of proof = proof of absence.

Which to me makes no sense, because what if we don’t have the tools to measure things and prove them?

I mean, gravity comes to mind - that existed back in our ape-days, long before the concept of proving things was even part of our psyche.

So you get what I’m saying - but then, why do so many people use this false reasoning for themselves?

It happens a lot: we try something, fail to make it work, and then we assume that it’s not possible or not within our reach.

Or we create something, offer it for sale at a good price point, and then nobody buys it, and we give up, thinking that “people just don’t spend that kind of money”.

While people spend all kinds of money on ll kinds of things.

Just 250 kms west of me, in Marbella, rich kids fly in, buy $1000 bottles of champagne, only to spray the stuff at each other on the beach. Every weekend.

So who says people don’t spend money?

What gives us the right to reason like a bad scientist?

Absence of proof is not proof of absence.

So when you’re faced with something that can’t be ‘proven’ - meaning, when something isn’t working the way you hoped, borrow a cue from the good scientists, and ask yourself this:

“Considering that this experiment didn’t work, what do I need to change in order for the next experiment to have a better chance?”

See, nothing is fixed - not us and not our world.

Anything can be tested, modified, iterated, and tested again.

And as a human being, it’s our job to test and iterate and improve, mostly in terms of how best to live life.

The marvelous experiment called ‘your life’, where no experiment ever fails, and you always get to ask “How to test again?”

Fun, isn’t it?

Get in touch if you'd like me to help you run the grand experiment called 'Your Life'.

Cheers,

Martin

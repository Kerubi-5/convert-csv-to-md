---
title: How to Prevent Headaches When Selling
status: publish
datePublished: '1557505884'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-21692" src="http://martinstellar.com/wp-content/uploads/2019/05/MartinStellar_Coaching_Illustrations-Never-sell-to-the-fearful-1024x1024.jpg" alt="" width="348" height="348" />The roadworks in my street do a great job of showing just how fearful - and deeply irrational - human beings are... and, it's a perfect lesson in who to sell or not sell to.

This town (Salobreña) is built on a rock, and the streets are steep, narrow, and bendy. And because half the pavement in the old town is tore up, normal traffic laws are suspended.

So you get two-way traffic, up and down narrow streets and around blind curves, on streets that are intended as one-way only.

Now because everyone is civil and you can’t really drive fast here, everything works. People give way, respect each other, shows respect and patience, and traffic flows in a more or less fluid way.

But some people are afraid, fearful of what’s around the corners. And so they sound their horns incessantly, constantly announcing that they’re around a bend.

Me, I never even touch the horn. If you drive carefully, and you watch out, you see who’s there, and you’re always going slow enough to break on time.

A careful driver doesn’t need a horn here. But those people, they don’t trust.

Even though they’ve managed it through life for 30 or 50 or 70 years, they don’t trust their own driving skills and ability to react.

They’re afraid, and it’s irrational.

But, fear overrules the mind, and so they make one hell of a ruckus in my neighbourhood.

Anyway, the lesson today?

Don’t try to sell to people who would sound their horn.

If someone doesn’t trust themselves enough, you’ll find you have a damn hard trying to have them trust you enough.

People who are nervous, fearful, jittery, yes you can sell them things. And sometimes your sales conversation is what they need in order to get to relax and trust (meaning: trust you, as well as  their own evaluation and decision-making).

But pay attention, and watch out for the signs of someone who isn’t going to switch and become trusting.

These are the kinds of (non) buyers who can take up a lot of your time, without ever making the big decision to work with you - which you'll agree is a major headache.

Your time is better spent with people who don’t need convincing, and who need help getting clarity instead.

Those people already trust you enough to let you advise them.

Sell to those people.

&nbsp;

---
title: Business, but Not as Usual
status: publish
datePublished: '1593045593'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - How to sell your work

---

<img class="alignleft wp-image-22849" src="http://martinstellar.com/wp-content/uploads/2020/03/MartinStellar_Coaching_Illustrations-Business-but-not-as-usual-1024x768.jpg" alt="" width="350" height="263" />

It’s fun when pundits and startups talk about disruptive industries, but right now we’re dealing with disruption on an industrial scale, and that ain’t no fun.

What used to work last week, isn’t working the same today, and that means we need to adjust, adapt, pivot.

Luckily, the internet is a massive enabler, but it’s on us to find a way to leverage its potential.

Whether your revenue is at risk because you can’t visit your clients and deliver, or because supply chains and delivery of product are delayed, or your remote clients aren’t buying your service offer because of spending freezes: if you’re going to keep going, you’ll need to adjust.

Here’s one thing that practically everyone can do:

Sell your genius.

Meaning: there’s something you do, based on your experience and skills and uniqueness, that nobody can do quite the way you do it.

That ‘genius’ is your IP - your intellectual property.

And if right now you’re stuck at home with no appointments in your calendar and uncertainty about how long your buying cycles will be, you could do worse than to extract that IP, turn it into a digital offer, and see if it would be useful to your audience.

For this exact reason, right when Spain went into lockdown, I created a system to help you quickly assess where your people are at and what they need right now.

If you follow the 9 simple steps and implement it, you can create a completely new revenue centre, and if you apply yourself, you could make that happen in two weeks or less.

More information here: <a href="https://martinstellar.com/turn-your-intellectual-property-into-a-revenue-centre/">http://martinstellar.com/turn-your-intellectual-property-into-a-revenue-centre/</a>

Cheers,

&nbsp;

Martin

&nbsp;

&nbsp;

---
title: Oh, the Things You Won't See...
status: draft
datePublished: '1512395314'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/e06fad01-470e-4011-a2a6-3cf5238e7b0a.png" width="350" height="262" align="left" data-file-id="4835249" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/e06fad01-470e-4011-a2a6-3cf5238e7b0a.png" />...if you're always moving fast, and never slow down. Let me explain:

A few hours ago, I dropped Paula off at the airport.

I believe she’s had a good writing retreat here - and the both of us have had many coaching conversations.

And as I drove home, I reflected on the changes she’s been going through over the last few months.

The biggest of which: slowing down.

See, Paula is ambitious, driven, strong, and prone to action.

(in other words: the perfect coaching client).

She’s a force of nature.

But like many people who like to get their hands dirty, she can get so stuck in action-mode, that she ends up forgetting to slow down.

In fact, when I first talked to her about the benefits of slowing down, her reply was “Have you MET me?”

And there we have the problem.

Because while a bias for action is good, you’re very likely to over-exert yourself if you’re always active and never slow down.

If you’re always ‘ON’ and you never take a moment to step back, slow down, and reflect, you might not observe the opportunities that are coming up.

And (or) you might spend a lot of time cranking through on a plan you made, but which by now needs some tweaking, given all the things that have changed since you made the plan.

Except you’re moving so fast, you’re not even seeing that the plan and course of action no longer bring you the optimal results.

In the end, she got it though.

We often talked about slowing down recently, and she got to the point where she can pull herself to a halt in a moment, and really take stock of the situation she’s in.

And that’s something you can learn as well, and I recommend you do.

Because when you stop being busy for a moment (whether that’s in terms of thinking or doing practical stuff) you notice things that you can’t notice if you’re moving at full speed.

And it’s those things, and integrating them in your plans and decisions and actions, that will have the big impact you need in order to move forward.

So do you ever feel like life is just going so fast, and you wish you’d have more clarity and insight so that you can make better decisions and get more results from your efforts?

Then maybe let’s talk. Let’s slow down and really look together at what you have in front of around you.

I bet you’ll be amazed by what you’ll see…

Want to talk? Let me know…

Cheers,
Martin

---
title: 'Empathy and Epiphany: "That''s Right!"'
status: publish
datePublished: '1565686278'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-21975" src="http://martinstellar.com/wp-content/uploads/2019/08/MartinStellar_Coaching_Illustrations-Thats-right-1024x768.jpg" alt="" width="353" height="265" />When selling something, there’s three kinds of people:

Those who fear hearing ‘no’, and get upset or frustrated.

Then there’s those who know that hearing ‘yes’ follows hearing ‘no’ a whole bunch of times.

And then there’s those who actively seek out a no, because - as the late Jim Camp taught - ‘no’ is when the negotiation starts.

But when you hear a no… what’s next?

What’s the best reply when a prospect tells you no?

According to Chris Voss, your best move is to say something that gets a ‘that’s right!’ out of your buyer.

Not ‘you’re right’, because that message basically says ‘whatever, stop talking’, but ‘that’s right!’

What happens when someone reacts that way, is that their brain registers your empathy, which instead of breaking down the negotiation, strengthens rapport and connection, enabling you to continue the conversation in a way that’s non-threatening for them.

At the same time, there’s a kind of epiphany happening: they realise that you get them, see them, hear them.

As opposed to the (stupid, arrogant and old-fashioned) tactics of trying to persuade the other person.

So what do you say exactly, how do you get a ‘that’s right!’ out of a buyer?

It’s so simple:

“Ok, so what you’re saying is that this isn’t right for you, because [insert the reason they just gave you]”.

And that’s it, that’s all there is to it.

A simple statement, and bam: you’re on the same page, ready to keep talking.

For a deeper look into ethical selling and the importance of no, have a look at the training webinar I recorded last month: <a href="https://martinstellar.com/ethical-sales-training/" target="_blank" rel="noopener" data-cke-saved-href="http://martinstellar.com/ethical-sales-training/">http://martinstellar.com/ethical-sales-training/</a>

And if you want my personal help in upping your sales game, just let me know...

Cheers,

Martin<a href="http://martinstellar.com/ethical-sales-training/" target="_blank" rel="noopener" data-cke-saved-href="http://martinstellar.com/ethical-sales-training/">
</a>

---
title: Breaking Things That Work (and the hidden dangers of learning)
status: draft
datePublished: '1543425857'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21115" src="http://martinstellar.com/wp-content/uploads/2018/11/MartinStellar_Coaching_Illustrations-breaking-things-that-work-1024x889.png" alt="" width="352" height="306" />Years ago, I used to love Twitter.

Met so many awesome people. Made friends (the real-world kind, not just digital connections), got introductions, ended up with a mentor who helped me at no charge, and even became ‘internet husband’ to a fairly famous gal.

Good times.

But then I read some teachings on how to curate the people you follow, and how to create specific lists of followees based on certain criteria.

So I set about overhauling my lists, moving people around from one list to the next, and…
In one fell swoop, I completely destroyed my Twitter experience.

Where it used to be fun and I would see the updates from people I liked, leading to all kinds of conversations, I now could no longer find my way. Stopped being fun, and I didn’t use the platform for years.

All because I thought it would be a good idea to improve something that was working splendidly, because someone said so and I thought they were right.

Instead, I broke the thing that used to work well.

I see this a lot around me:

People who have a good thing going, things are working (relationships, business, sales, hobbies, you name it) but then some ungodly idea comes in saying ‘rework, redo, overhaul’, and instantly that what worked flips on its head and breaks.

Another example?

In my tailoring days, I used to be known as one of the ‘old boys’, in that I made suits the traditional way by hand.

And I’d get high-ticket customers calling me up for fancy suits, all because I blogged and I was very active on specific forums.

In other words: I was on my way to building a pretty damn profitable business.

But then someone persuaded me to stop spending so much time online, and the whole thing crashed, losing me a total of $150K.

When things are working, you must be very careful with the changes you make.

Especially in business, which is a huge machine of many moving parts.

One change, one tweak - even a small one - can cause the entire machine to grind to a halt.

This is one of the reasons I created CRD - my system for better thinking, and making more outcome-aligned decisions.

Some decisions will only reveal themselves as sensible in retrospect, but most others can be assessed before you make them - if only you give it proper thought first.

If you want things to improve, remodeling that what works is rarely the solution.

Instead, do a thorough analysis of what works, and why, and identify one, two, or at the most three tiny changes you can make to try and make it work better.

Measure the results, and if you see a positive effect, double down your efforts on that tiny change.

The only time to do a complete overhaul is when things are already broken, because otherwise you’ll likely break what isn’t broken at all.

Cheers,

Martin

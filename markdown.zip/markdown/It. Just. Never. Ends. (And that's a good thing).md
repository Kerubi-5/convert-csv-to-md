---
title: It. Just. Never. Ends. (And that's a good thing)
status: draft
datePublished: '1493203771'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/6d58d21b-78a5-4fe6-84cc-da5fff6453fa.jpg" width="200" height="201" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/6d58d21b-78a5-4fe6-84cc-da5fff6453fa.jpg" data-file-id="4834553" />“You do realise that you’re supposed to be a work in progress, right?”

He looks at me, trying to digest and see the logic in what i just said.

For a moment, it looks like it’s sinking in, but then he tells me that at his age, and with the career he’s had, he should be further ahead by now.

Accomplished, stable - a success. And he doesn’t feel that way.

Which makes perfect sense, because success is elusive.

No matter what shape or goal goes with your definition of ‘success’, there will always be a next stage.

Something new to aspire to, something bigger to build.

And that’s the way it should be.

Because just like with learning, working towards success never ends.

You’ll never EVER learn everything, which means you get to learn until your final day. Which in my book is pretty cool.

And the day someone decides they’ve learned all they need to know, that’s the day they enter what I call the coma of life.

Same thing with success and reaching your goals.

If you reach one and consider your life complete, then either you’ve reached a rather refined spiritual state of contentment, or you’ve resigned to the here&amp;now as being the things will always be.

And last time I looked, far more people fall into the latter category, compared to the first.

You’re meant to be a work in progress.

All throughout your life.

There’s a new skill waiting for you to develop, right now.

There’s another level of accomplishment that you can go for, right now.

Be a work in progress, and be proud of it.

This mountain you’re climbing?

It has no summit, not if you don’t want it to - and that’s a good thing.

And if you want to climb and keep climbing, but as part of a team instead of on your own?

Then joining The Cabal might just be what you’ve been looking for.

More information here: <a href="http://martinstellar.com/cabal-group-coaching-action-takers/" target="_blank" rel="noopener noreferrer" data-cke-saved-href="http://martinstellar.com/cabal-group-coaching-action-takers/">http://martinstellar.com/cabal-group-coaching-action-takers/</a>

Cheers,

Martin

---
title: Are You Purchasing the Wrong Things?
status: publish
datePublished: '1617274086'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<p class="p1"><img class="size-medium wp-image-26679 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/04/MartinStellar_Coaching_Illustrations-Systems-thinking_opportunity-cost-300x225.png" alt="" width="300" height="225" />Each time we make a decision, we’re effectively looking to purchase something.</p>
<p class="p1">Either we want to add something to our lives - an outcome or a result or an asset - or we want to remove something, free ourselves from something.</p>
<p class="p1">Where we often go wrong, is in looking only at the thing we’re making a decision for (the reason for the ‘purchase’), without giving thought to secondary aspects that are bundled in.</p>
<p class="p1">For example: if you decide to get married because you want to ‘purchase freedom from being alone’, you also purchase ‘less time spent with your friends’.</p>
<p class="p1">If you decide to start hire a marketing agency, you want to purchase ‘more leads’, and while you probably factor in your capacity for taking on new clients, you’re also purchasing ‘increased cognitive load’.</p>
<p class="p1">More leads means more conversations, and that means you’ll be spending time thinking about all the extra leads and their needs.</p>
<p class="p1">That’s a good thing, but you can only handle so many mental conversations.</p>
<p class="p1">In business and marketing and sales, you need to consider the secondary acquisitions that go along with the decision to purchase this or that thing.</p>
<p class="p1">On the surface, this looks like a nothing more than considering opportunity cost.</p>
<p class="p1">But it’s actually much more powerful than that, because what I’m pointing at is systems-thinking.</p>
<p class="p1">Your business is an interacting whole of incomings, outgoings, unknowns, problems, dynamics, conversations, opportunities... and a whole bunch more things.</p>
<p class="p1">Even if your business model is simply ‘run ads to my course on Gumroad and plug all profit back into running more and more ads’, you still operate a highly complex system.</p>
<p class="p1">Niches, split testing, planning for your next course, adhering to Google’s adwords policies, payment integration, social and political dynamics that affect people’s attention and time-spend and therefore change the efficiency of your ad campaigns:</p>
<p class="p1">It’s a simple business model, but it’s still a complex system.</p>
<p class="p1">And whenever you decide to purchase an outcome, you need to not just think about opportunity cost, but also about how the additional acquisition causes a ripple-effect throughout your business.</p>
<p class="p1">Nothing is as simple as ‘if this, then that’.</p>
<p class="p1">Every decision and every acquisition is ‘if this, then that, and that, and that, and also that’.</p>
<p class="p1">It’s not enough to think about linear, short-range effects.</p>
<p class="p1">If you want your business to be wieldy, and fun, and lucrative, you also need to think top-down, as in: systems-thinking.</p>
<p class="p1">And, you want to bias your decision-making towards purchases that have as many <i>positive</i> secondary outcomes as possible.</p>
<p class="p1">Quite unlike most people’s attitude, where they know that there’s a couple of negative secondaries in there, “but hey, we can deal with that”.</p>
<p class="p1">When you find yourself saying that - when you’re making negative secondaries into ‘no big deal’, you’re about to make life worse for yourself, not better.</p>
<p class="p1">Always prioritise purchases with positive secondary outcomes.</p>
<p class="p1">Like, improving your sales skills.</p>
<p class="p1">The primary positive outcome is, of course: more clients.</p>
<p class="p1">Secondary positive: Better clients and less awkwardness in the enrollment process.</p>
<p class="p1">But then there’s more, because selling is ultimately nothing more than a communication skill - so you don’t just get more and better clients, you get better outcomes with all people in your life.</p>
<p class="p1">And you bet that translates to a whole bunch of positive secondary outcomes.</p>
<p class="p1">So if that’s what you want, <a href="https://martinstellar.com/helping-good-people-sell-more-and-generate-a-bigger-impact/"><span class="s1">dig this.</span></a></p>

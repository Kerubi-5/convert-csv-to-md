---
title: It's Not Because I've Been Procrastinating!
status: draft
datePublished: '1483720924'
categories:
  - Doing it right as an entrepreneur or creative professional

---

Honestly, it isn't.

I mean, it would be pretty lame to procrastinate on publishing a mini-course to help you stop procrastinating.

(In the end, I decided to make it an ebook, not a mini-course).

What happened is that I've spent literally days trying to get my head around how to create and design an ebook that works on Kindle and iBooks.

Pretty damn tricky, I tell you.

BUT!

It's done. It's finished. It's uploaded and ready for your delectation.

I present you with much pomp and circumstance, my latest ebook:

The End of Procrastination!

Click here to download it now... <a href="http://martinstellar.com/endofprocrastination/" target="_blank" rel="noopener" data-cke-saved-href="http://martinstellar.com/endofprocrastination/">http://martinstellar.com/endofprocrastination/</a>

Or you could put it off until tomorrow of course, in which case: Click here to end your procrastination: <a href="http://martinstellar.com/endofprocrastination/" target="_blank" rel="noopener" data-cke-saved-href="http://martinstellar.com/endofprocrastination/">http://martinstellar.com/endofprocrastination/</a>

Happy weekend, folks.

Martin

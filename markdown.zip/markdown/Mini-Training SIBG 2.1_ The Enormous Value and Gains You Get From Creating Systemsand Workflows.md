---
title: "Mini-Training SIBG 2.1: The Enormous Value and Gains You Get From Creating Systems\r\n\t\t\tand Workflows"
status: pending
datePublished: '1642588773'
categories:
  - Assets and Leverage
  - Business and systems
  - Business Growth Fundamentals

---

<img class="size-medium wp-image-28550 alignleft" src="https://martinstellar.com/wp-content/uploads/2022/01/MartinStellar_Coaching_Illustrations-Why-and-how-to-create-workflows-and-systems_Stages-and-Ingredients-of-Business-Growth-Mini-Training-300x225.jpeg" alt="" width="300" height="225" />
<p style="text-align: left;">[Mini-trainings / Stages and Ingredients of Business Growth / Pt 2.1]</p>
<p style="text-align: left;">I'm always amused when people tell me that they don't like routines and systems and habits and procedures.</p>
"It stifles me! I want freedom! Routines are boring! They kill creativity!"

Yeah, about that...

You might think that you don't have routines, but you do.

You make your tea just so.

You like your eggs over easy, not overdone - and don't make the toast too early, otherwise it'll get cold.

You put toothpaste on your toothbrush before putting the thing into your mouth (nearly 100% of the time, I'd guess).

You get the mail out of the mailbox, before you rip open the envelopes.

In short: we all have habits, routines, procedures, and best-practice sequences of actions.

We *are*, like it or not, creatures of habit.

And if you want to do do something, and you want it to result in a great outcome with as little effort or error as possible - say, run a sales process that sustains and grows your busisiness - you'd do well to be intentional about your routines.

So in the Grow-Up phase, we want to look at the different activities in our business, and identify the ones that bring the best results.

These are the ones you start automating first, because once you have a handy little checklist, workflow, or Standard Operating Procedure for them, you can perform the actions without having to spend any time thinking about it.

And that - misspent cognitive capacity - is a major reason why we don't achieve more.

Think about it:

On any given day, you might have a maximum capacity of two or three hours of real, deep thought and deep work.

The other hours, they go into meetings, housekeeping, paperwork, checking your social channels... and what's left is a small and finite budget of deep thought and work.

And you'd better allocate that resource to be spent as efficient as possible.

For instance, each day I spend between 30 to 60 minutes writing and publishing an article.

Wait... only 30 minutes, and there's an article, illustration, blog post, Twitter thread, AND a new entry in the SalesFlow Coach app

Yep. And the only reason I achieve that, is by using a very simple, step-by-step checklist - my Publishing SOP - that I follow.

It completely removes the need to think about anything at all, except the answer to

"What should I write today, and how?"

Having the routine in my task app makes it fast, easy, and ensures that I spend almost no time thinking about trivialities or anything to do with procedure.

I.e. conservation of mental energy.

That way I have more to spend on creating more content, and working out great deals for my clients and business patners.

And if that's not enough:

Once I have perfected the way I integrate new content into the app and the workflow is Ready, I can hire a VA to do all of it for me, except writing new content.

This - creating routines and systems that reliably produce quality outcomes - will make a big difference in your business.

It takes you from doing "manual labor" in your business at the expense of quality thinking and strategising, to becoming the top-level, CEO-type, strategic and creative visionary that your business requires, if it's going to grow beyond what you individually are able to achieve.

So look at your daily activities, and ask:

- Which actions produce results?
- Which of those recur daily, or weekly?
- Which of those would be kinda boring, if it weren't for having to think about doing it right?

Next, pick one of those actions or projects, and simply outline each of the steps required to get to "Done."

You don't need to put it in a todo app, like I do - though the positive reinforcement of checking off itmes to the sound of a satisfying little ping sure feels good.

Just make sure that you have a document that outlines, step by step, how that particular thing gets done.

Next, create new SOPs and workflows as you go along, and within a few weeks, you'll start seeing how your business contains all kinds of really cool, efficient, reliable processes.

And because you have them documented, you'll start doing them faster, with fewer mistakes or dropped balls, and with more energy left to do your Zone of Genius work.

Or, you can start getting team members to do them for you.

Either way:

So long as you don't formalise, structure and systemise part of your operations, your growth potential will always be limited by how much time you're able to put in.

&nbsp;

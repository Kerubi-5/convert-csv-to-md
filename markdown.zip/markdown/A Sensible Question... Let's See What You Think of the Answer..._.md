---
title: A Sensible Question... Let's See What You Think of the Answer...?
status: publish
datePublished: '1510251337'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/39a81b59-178f-4c1b-b9da-c11d3dfed9da.jpg" width="350" height="392" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/39a81b59-178f-4c1b-b9da-c11d3dfed9da.jpg" data-file-id="4835189" />Yesterday, one of my clients asked why I don’t simply put my free ebooks on a webpage, for you to download on your own.

Instead of offering the book, and inviting you to request I send it to you - which is what I do.

The reason is very simple, and very powerful:

I want to know who my readers are. I want to have conversations. I want to get to know my people.

Of course I could just send you a download link, but where’s the fun in that?

How does that trigger a conversation?

Of course you could ask why I want conversations in the first place.

After all, it takes time, and 90% of them never turn into a business relationship.

Again, a simple reason: any sale, always, happens in the context of a conversation.

But if all you do is broadcast offers, and you never end up in conversation with a potential customer…

Then you’re not going to be part of the conversation that’s going on in the other person’s mind.

But that conversation is already happening, whether you know it or not.

There’s an internal dialogue going on in the mind of the other - and you can either let that run its own course, or you can join in and have a dialogue.

Which I can tell you does wonders for business.

For one thing, because it takes the sting out of the sales process. When you centre your sales efforts around conversations, you no longer have to push or persuade.

Suddenly, you get to talk with someone, in a relaxed context, and in that context and conversation you’ll be able to identify whether someone would be a good candidate to work with you.

And on the other side is the other person, who perceives that there’s no hard sale going on, but that they’re given permission to reflect and decide in their own time.

And that’s a powerful way to run your sales process.

Another reason to do it this way?

Because it enables me to help out, with a small time investment - just a few emails back and forth with those who want some help.

So even if a conversation does not lead into a sale, I don’t mind. I’ve already ‘won’, because I was able to give some help - and doing things for others is a proven way to be happier.

So there you have it: a non-pushy, people-based, service-oriented marketing process.

Where regardless of the business outcome, everybody wins.

What’s not to love…?

You might want to steal the method for yourself…

&nbsp;

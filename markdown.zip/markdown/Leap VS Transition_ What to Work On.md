---
title: 'Leap VS Transition: What to Work On'
status: draft
datePublished: '1528883683'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/22a044f2-6855-4824-8fc7-127def046946.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/22a044f2-6855-4824-8fc7-127def046946.png" data-file-id="4835801" />We all dream of taking the leap, don’t we?

To transition into that other thing, or that bigger thing, or that next level - and then we’d like it to be dramatic, phoenix-like and transformational, and quick please.

Except things usually don’t happen that way.

When you’re stuck in corporate-land, and you want to step out on your own as an entrepreneur, for example, it’s hard to do that in a dramatic, leap-style way.

Especially if you have a family to support.

Same thing goes for quitting your business so as to try and make a living selling your art.

Or switching from one career into something completely new to you.

All those changes can be made, they just don’t usually happen as a leap, but as a transition.

It’s only people who are as crazy as me, who are willing to stop taking copywriting clients from one day to the next, in order to fully focus on building a coaching practice - and yes, the fact that I don’t have a family to support makes that a lot easier for me.

But for most people, you’ve got responsibilities to others.

And so you transition, instead of hoping that there will be a big switch one day.

Like a guy I knew in the last year of the monastery. That’s when I had a job outside our walls, for a year: maintenance of cars and buildings for a sports company in the Belgian Ardennes. (It’s when that job ended that I decided to set out as a bespoke tailor).

Anyway, whenever our cars needed tires, I’d go buy them at Paul’s tire shop. Paul was a guy who had had my job, a few years ago. And as he did his job, he started buying, selling, and mounting tires, for his friends. Boss gave him permission to use the pit, and that way he could earn some money. A side hustle.

Until the day came that his tire-hustle was running so well, it made sense to borrow money, quit his job, and open up his own tire-shop.

In other words: Paul gradually transitioned, built up his momentum in attracting clients, and once the transition to ‘sustainable’ had been made, that’s when he made a leap. But that was only a leap in terms of expanding - the ‘leap’ into being able to earn his own money had been a transition and not a leap.

Circle back to you:

What’s the next thing, or the next level, or the big switch you’d like to make?

And, if take your eyes off the prize of ‘the leap’ of it all, and look instead at transitioning…

What can you start building now, to slowly nurture and feed its growth, so as to build up a foundation that will ultimately enable you to leap?

(Hint: if it doesn’t include ‘build an email list’, you’re making life 1000 times more difficult for yourself…)

What can you create… to start or speed up your transition…?

Cheers,

Martin

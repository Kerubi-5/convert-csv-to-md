---
title: "How to destroy trust at the first point of contact (Lead generation done completely\r\n\t\t\twrong)"
status: publish
datePublished: '1631179517'
categories:
  - How to sell your work

---

<img class="size-medium wp-image-27993 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/09/MartinStellar_Coaching_Illustrations-Linkedin-lead-generation-done-completely-wrong-300x225.jpeg" alt="" width="300" height="225" />There's a new trend doing its rounds on LinkedIn, and it is something you should absolutely not do.

Here's the deal.

Somebody writes me a message saying:

“Hey, Martin, I just noticed your post, would it be possible to send me some more information about your coaching?”

And I go: “Ooh, nice, an inbound request. Yes, of course - here's some information”

And the next thing that they say is: “That’s wonderful, I love what you do, and the passion you bring. Have you ever considered turning this into a course that you can distribute worldwide?”

Seriously, people? Bait and switch?

You show up giving me the impression that you are interested in me, but that’s just a ploy to get me interested in you?

Haha, no. Go away. *clicks block*

Lead generation can be a powerful tool, but this is absolutely not how you do it.

Why? Because of trust. People don't buy things, unless they trust you.

And when you show up with a bait &amp; switch right at the start, what result do you get?

You instantly destroy any trust that anybody might have.

How utterly deceptive and manipulative, to give somebody a certain impression, and then put something else in front of them.

That's not how you do it.

People like us, who strive to operate with ethics and integrity, we show up and we lay our cards on the table.

For example: “Hey, I was looking at your website, I see that you do thing XYZ. I think that's really great, and I might be able to help you with that. Should we have a conversation?”

That way you’re doing lead generation in a way that doesn’t destroy trust, and you come out with an open, honest statement about what your intentions are.

“This is my agenda. These are my cards, right here on the table. Let me know if you're interested or not.”

That is how you treat people with respect and dignity, and without breaking their trust. And you’d be surprised how effective it is.

How to do sales and lead generation in an honest and open way, that’s what you learn in the 1 on 1 training programme, <a href="https://martinstellar.com/helping-good-people-sell-more-and-generate-a-bigger-impact/">Sales for Nice People</a>.

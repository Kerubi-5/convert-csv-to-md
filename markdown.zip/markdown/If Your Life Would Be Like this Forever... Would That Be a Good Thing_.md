---
title: If Your Life Would Be Like this Forever... Would That Be a Good Thing?
status: draft
datePublished: '1526059752'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/e127aaab-fea0-4f82-863a-a3fac258af8f.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/e127aaab-fea0-4f82-863a-a3fac258af8f.png" data-file-id="4835713" />A lot of the coaching I do - most all of it - centers around questions.

The kind of question that makes you dig deep, stop and reflect…

Because the right questions bring you insight, which goes way beyond understanding.

So here’s a question for you today:

What do you believe to be 100% true?

Can be about anything: yourself, the behaviour of others, the opportunities for someone in your line of work, the state of the world…

You might want to be very careful with what you choose to believe in (yes, it’s always a choice. Beliefs don’t just show up in your system - they are the result of experiences, thoughts, and interpretations, and you create beliefs subconsciously).

Found a quote from one of my favourite authros, Douglas Adams:

"If you don’t change your beliefs, your life will be like this forever. Is that good news?”

Especially that bit ‘your life will be like this forever’ hit me hard.

Is life as it is now finished? Ready, am I done building it?

Hell no. There’s SO much more to experience, and give, and share, and create, and change… I ain’t EVER going to stop making my life better. And very deliberately so.

And for that, I’m like a hunter, and a very vicious one:

The moment I find something I believe in, I shoot it down.

Or in friendlier terms: I am 100% committed to question, and to doubt, everything that I apparently consider a truth.

Because ‘truth’ is a very tricky thing, and there really isn’t any objective truth.

And all the things (most all, if not all) of the things you consider to be true are, in the end, a belief.

You believe XYZ or ABC to be true - but that is you doing it. That doesn’t say anything whatsoever about whether thing A or B is true or not. It’s just a belief.

And I can tell you that questioning your beliefs is a LOT of fun, and creates enormous space in your life and mind for discovery, productivity and creativity.

It’s a fun game, to question your beliefs.

Want to play?

Tell me, what belief of yours would you like us to question together?

Cheers,

​Martin

---
title: Are You Frightening the Natives?
status: pending
datePublished: '1625785466'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-21567" src="http://martinstellar.com/wp-content/uploads/2019/04/MartinStellar_Coaching_Illustrations-Pleasure-vs-pain_threat-vs-trust_sales-conversation-1024x768.png" alt="" width="355" height="266" />Everybody wants to be well, and nobody wants to be in pain.

And since some kinds of pain (or danger, a different form of pain) can be fatal, and wellbeing makes for thriving individuals and societies, evolution has built in a simple, very effective mechanism, right at the very core of our psyche.

A sort of bodyguard, always looking out for us. Always trying to drive us towards pleasure and wellbeing, and away from pain, risk, threat, or danger.

So when we want to get results with people, we need to be careful to not scare or threaten them, or even allow for some sort of perceived, imaginary threat to register in their mind - doesn't matter whether the other person is a buyer or spouse or team mate.

If you meet a shy child, you speak softly, calmly. Maybe get down on one knee, to not be overbearing.

If you see a guy or gal you like and you’d like to speak to them, you approach them gently, attentively, so as to not appear threatening or needy.

If you’re in the wilderness and you meet a tribe that’s not used to people from the modern world, you’d be doubly careful. Wouldn’t want to go home with a spear sticking out of your back.

Even with animals, you make sure your behaviour doesn’t threaten them.

All living things - and that includes buyers - have a radar for threats.

But when it comes to sales conversations, we often, inadvertently, appear threatening in some way.

Not because we <em>are posing a threat</em> - after all, we’re good people, we sell something truly useful, and we don’t mean harm nor do we want to be pushy.

But, that's making it about us, and things are never about us.

See, a buyer has a slew of thoughts, wishes, frustrations, doubts, and yes: fears.

And if we’re not careful, and we focus on ourselves instead of on them, it’s super easy to overlook their reality, and appear threatening as a result.

I.e. we scare the natives - when really, all we want to do is help!

The trick is to feel into that other person.

Show that that we care about them and their decision and results.

Use empathy and place yourself in their shoes.

Learn to see the world that they live in, and you’ll know what kind of things they need to hear or feel, in order to not feel threatened, doubtful, or untrusting.

The money that you earn as a reward for your product or service: sure. That’s about you.

But the conversation that makes people want to give it to you, that’s about them.

And the more you make that clear, the safer and trusting they’ll feel.

Selling your work? It’s about them. Always, 100%.

<a href="https://martinstellar.com/helping-good-people-sell-more-and-generate-a-bigger-impact/">Here's where you can learn how to do your selling in that way.</a>

&nbsp;

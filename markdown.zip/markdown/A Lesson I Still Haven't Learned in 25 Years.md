---
title: A Lesson I Still Haven't Learned in 25 Years
status: draft
datePublished: '1492073064'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/b1d7c4d6-772c-4921-81d3-ab9c6af8fff2.png" width="250" height="332" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/b1d7c4d6-772c-4921-81d3-ab9c6af8fff2.png" data-file-id="4834505" />Ok, I need to come clean.

Of course everyone thinks I’m 100% perfect (ha!) but I’m just as flawed as the next man or woman.

And one thing that I still haven’t learned is this:

That everyone all the time is perfect the way they are.

That doesn’t mean things can’t improve, and that people can’t change or wouldn’t benefit from change, but:

It does mean it’s not up to me to decide that change needs to happen.

And even though I’m mindful of this as much as I can, I still bang my head against the wall of “But look, if only you would try this different view/attitude/behaviour! Your life would be
so different!”

I guess it’s the flipside of being a helpful person who sees potential and possibility in people.

So today I’m giving you permission.

Whether you’re a client, future client, or reader who mails me and I try to help:

If ever you catch me trying to push anything on you, if ever I’m trying to get you to want change when you’re not asking for it: tell me. Call me out.

Because change gets made on the inside.

And nobody on the outside can or should try to get others to change.

Not even if it’s ‘a very powerful coach’.

There’s also a lesson you can apply here: if you end up in situations where someone you care about ought to change, and they’re not taking up your ideas or suggestions: drop it.

Step back, release, and let the seeds you planted grow on their own.

That way you help more than if you suffocate the saplings by trying to push someone forward. This much I’ve learned.

Cheers,

Martin

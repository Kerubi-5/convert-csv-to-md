---
title: Helping the Helper Getting Helped
status: draft
datePublished: '1510742521'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/223d1576-e069-48c2-b0dc-feaccee6e869.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/223d1576-e069-48c2-b0dc-feaccee6e869.jpg" data-file-id="4835205" />“Don’t be ridiculous Martin. My flight leaves at 7AM - you’d have to get up at 4 to get me there on time. I’ll just take the night bus - gets me there at midnight, and then it’s just a few hours’ wait”.

Such a lovely friend, always unassuming, never demanding. But in situations like these, sometimes a bit too modest.

After all, I LOVE getting up early. The earlier the better.

And by committing to drive her to the airport, I force myself to go to sleep early, and get up early - what’s not to love?

She understood and gratefully accepted.

And me? Well it’s 8AM, I’ve returned and cleaned my house and I’m ready for a workday, with my daily email half-written. What’s not to love?

She thanked me - but in reality, she’s the one who did the biggest favour.

She enabled me to commit to a decision that is good for me.

But very often, we don’t allow others to help.

Maybe because we believe we’re strong and supposed to do everything on our own.

Or maybe because we really don’t want to burden anyone.

But it’s not a burden to the one offering help, not if it’s genuine. In fact, allowing someone to help you is doing them a favour.

If only for the fact that helping someone makes the helper feel good.

That’s why in certain Buddhist traditions, where the monks and nuns go out to beg for food as part of their spiritual practice, it’s the villagers who say thank you - it’s they who owe a debt of gratitude.

Because the monks and nuns went out of their way to offer the villagers a chance to do a good deed.

The world upside down?

That’s for you to decide. Definitely food for thought, though:

If you don’t want to accept help for your own sake… what if you’d accept some… for the other person’s sake?

Change your perspectives, change your decisions… and your relationships too... and everyone gets better.

Cheers,

​Martin

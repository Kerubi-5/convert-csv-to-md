---
title: Go for Bigger Problems
status: publish
datePublished: '1521464707'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/ebacec58-e209-4c6c-9036-6dd9fe75a795.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/ebacec58-e209-4c6c-9036-6dd9fe75a795.jpg" data-file-id="4835557" />Came across a quote this morning, by Carl G. Jung, one of the most influential psychologists of our time.

Says he: “The greatest and most important problems of life are all in a certain sense insoluble…. They can never be solved, but only outgrown….”

Ah, so THAT’s what I’ve been trying to say last week.

You know, how you keep running into the same problems and flaws, as you proceed on your personal evolution?

You’re meant to struggle with them. They’re supposed to show up over and over again.

Right up to the point that you realise you’ve outgrown this kinda thing.

The moment when you’re ready to leave behind childish things.

That’s when you level up your personal evolution. At that moment, the problem stops being a problem because at that next level you, it simply isn’t a relevant problem any longer.

This is in line with one of my favourite attitudes: To no try and confront every problem or flaw head-on, but instead to just let it solve itself.
Oh I know, this flies right in the face of what the therapists and the self-help gurus say.

“Gotta face our demons! Gotta do battle with ‘em. Can’t allow problems to go unaddressed!”

Actually, that last one might be exactly what you ought to do. To just let the problem be the problem, and not bother with it.

Not to ignore it or pretend it doesn’t exist, but to not feed it any of your mental and emotional energy.

Instead, spend that energy on things that create growth, or inspiration, or momentum.

If you keep doing that (acknowledge the problem, stop dealing with it, and focus on increasing that what’s already working or positive) you’ll quickly find yourself getting bored with the old problems.

And then you find that there are new, greater, more serious problems to deal with, which means that you did indeed leave behind the kid’s stuff, and you’ve levelled up.
Does this ever end?

Nope, it doesn’t. It goes on as long as you do.

And that’s the fun of it, but only if you persistently move away from smaller problems, and into having bigger ones.

That right there is personal evolution.

Moving from trifling problems that seem like a big deal, into bigger problems that you know you can actually handle.

&nbsp;

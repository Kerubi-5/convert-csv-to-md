---
title: Giving Yourself Some Talking To
status: draft
datePublished: '1501607289'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/5be5953d-1939-4d1a-af4c-45b2151bf93c.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/5be5953d-1939-4d1a-af4c-45b2151bf93c.jpg" data-file-id="4834865" />Do you ever talk to yourself?

Ok, it’s a trick question, because we all talk to ourselves, all day long - it’s the internal monologue that we all have.

But some people actually think - or talk - to themselves, as in, consciously. Some people even do it out loud, which I’ve always found odd.

Odd or not, it turns out that there’s an actual benefit to talking to yourself - but you need to do it in third person.

I just read an article about how, if you do it right, self-talk can help you calm down or regulate emotions.

Research, machines that measure the brain, controlled studies, etc etc:

If you talk to yourself in third person, apparently that calms you down. Like so:

“Looks like Martin is a bit stressed today”.

Does it work?

I don’t know, but it I’m going to try it.

It makes sense that it would work, because if you think about yourself in third person, you create distance between the I that experiences the emotion, and the I that observes the first I.

(I know, you’d think they’re the same, but if you deliberately separate them by using linguistics, you can experience them as separate.

And that’s powerful stuff. Take it from someone who’s been experimenting with his mind for 25 years).

And it doesn’t just apply to stress or emotions.

Tasks, plans, todo lists, things that are bigger than you think you can handle: you can  use third person self-talk for anything you want.

“Martin wants to start getting up early again”.

“Martin is taking himself very seriously these days, isn’t he?”

“Martin, why don’t you just get over yourself and do it?”

“Martin, what do you really want to to at this moment?”

You get the point.

Does this seem silly? Maybe, but who cares so long as it works.

Can it get you locked up? Maybe, if you do it out loud and in public.

Does it explain the duck-billed platypus? Sorry, no.

Does it help you get more done, be more focused, make better decisions and enjoy your life and work more?

You bet.

So, give it a try.

Martin says: cheers.

---
title: I Hope I'll Never win the Lottery
status: draft
datePublished: '1545391712'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21182" src="http://martinstellar.com/wp-content/uploads/2018/12/MartinStellar_Coaching_Illustrations-Ownership-vs-lottery-1024x1024.png" alt="" width="349" height="349" />… and you might want to wish the same for yourself.

And not because I’m a Grinch or anything like that: I honestly wish you all the well-being and happiness, and yes, all the money you could ever dream of.

But if money gets thrown into your lap, it’s statistically almost certain that you’ll lose it all, quick smart.

I didn’t make that up: it’s what happens with most people who win the lottery.

Nearly all of them end up exactly where they were, and often with bad outcomes, such as damaged relationships, addictions, or other big problems.

Buying a yacht is fun, but paying for moorage once the money runs out is disastrous. And dammit, where am I going to store my jet?

A bigger problem though, it the attitude.

Hoping you’ll win the lottery is like expecting angels to magically make your life amazing and awesome.

And even if angels did exist, I promise you they’d do nothing of the sort, unless you’d be showing them that you’re putting in the effort.

Rolling up your sleeves, doing the work.

Creating your own awesome life or fortune or whatever it is you wish for.

Hoping for a big win is a victim’s game, where you’re the patiently waiting beneficiary. Don’t buy into it.

Much more effective (and fun, and rewarding) is challenging yourself to make the most out of all that you have at your disposition.

And that’s not a little.

Between your life experience, ability to learn, creative resourcefulness, network and support, and a fount of energy that renews itself daily, you can do awesome things.

But, only if you’re the one in charge.

One of the things I enjoy when coaching people is identifying all the assets and potential available, and then helping a people create ways to leverage those.

Each time I play that game with people, terrific things happen, not the least of which is the sense of agency and control in the other person.

Want some of that?

Let me know…

Cheers,

Martin

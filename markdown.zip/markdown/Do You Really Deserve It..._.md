---
title: Do You Really Deserve It...?
status: draft
datePublished: '1493661944'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

Trick question? You bet.

			Because most all of us, on some level feel undeserving.

			Oh sure, we deserve the appreciation we get, and the love from our friends and
			relatives.

			And we deserve to get paid for our work - we even deserve to get paid well.

			So far so good.

			But beyond that... beyond the basics...

			Do you actually feel that you deserve everything that could come your way, if you were
			to let it in?

			Think before you answer, because if you would REALLY open the door, you’d be drinking
			from a firehose of bounty and abundance.

			And maybe... just maybe, you don’t feel deserving of that much.

			Do you?

			Because I know I don’t.

			Oh sure, on a rational level I know I’m deserving.

			On an emotional level too. Sure thing, let it come.

			But on a deeper, more fundamental level...?

			Well, I’ve had to face the fact that some time in the past, I put a cap on how much I’m
			supposed to deserve.

			Which has caused me to sabotage my success, stymie my growth, waste a fairly large
			inheritance trying to build my tailoring business, and to this day it causes me to keep
			abundance at a safe distance.

			And that just won’t do. Silly stuff.

			Do I deserve only 5 minutes of sunshine a day? Only one glass of water? Only one friend?
			Of course not. I, you, and everyone else: we deserve whatever goodness life throws at
			us.

			From now on, I’m letting it in.

			What about you?

			Cheers,

			Martin

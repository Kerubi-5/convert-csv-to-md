---
title: Anxiety, Terrible Driving, and Making Sense
status: draft
datePublished: '1545216490'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img class="alignleft wp-image-21173" src="http://martinstellar.com/wp-content/uploads/2018/12/MartinStellar_Coaching_Illustrations-Anxiety-and-making-sense-1024x768.png" alt="" width="351" height="263" />It’s mid-nineties, and a young novice monk named Martin is in the passenger seat of an old Land Rover, on his way with his brothers to a retreat in the South of Spain.

And he’s petrified, just absolutely mortified and anxious, because of the way the driver handles the wheel.

Sloppy driving, edging up close to cars ahead, not signalling, braking later than necessary or prudent…

Young Martin is very afraid - almost convinced - that nobody will make it to the border, much less to Spain.
This went on for hours, and I sat there biting my tongue, severely not enjoying the experience.

Until at some point, a moment of reason set in:

This guy driving, he’d had his license for years.

And for all his sloppiness, he’d never been in an accident.

That didn’t change the fact that his driving was terrible, but it was nowhere near as dangerous as I was telling myself it was.

And the moment I realised this, my fear and anxiety were gone, and I was able to relax quite a bit.

Behold the problems that arise from our human condition of irrationality.

I’d created an entire world of gloom and doom, based on my opinions, judgements, and thoughts on someone else’s behaviour.

But the moment a rational thought (“He’s done this safely for years”) set in, all that panic was gone in a puff of rationality.

I’ve said it before: humans are incredibly irrational beings, and unless we acknowledge our own irrationality and try to bring SENSE into the picture, we either live in anxiety and fear, or we keep making decisions that just don’t make any sense, with all the bad outcomes that come from that.

Want a calmer, more fulfilling and happier life?

Start making sense.

Want better outcomes from your decisions?

Start making sense.

Want some help in making the best, most sensible decisions for your business in 2019?

Talk to Martin.

Cheers,

Martin

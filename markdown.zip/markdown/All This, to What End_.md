---
title: All This, to What End?
status: publish
datePublished: '1549276233'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21353" src="http://martinstellar.com/wp-content/uploads/2019/02/MartinStellar_Coaching_Illustrations-Purpose-and-meaning-1024x768.png" alt="" width="349" height="262" />Sometimes it’s difficult to stay motivated, to stay on task, to keep moving forward.

What usually happens is that we start beating ourselves up, and we use our goals as the stick we do it with.

Want to write that book. Have to pay those bills. Need to find more clients. Must get this project done for once and for all.

Telling ourselves all the things we ought to be doing, should be doing - shoulding all over ourselves, and it rarely works.

The reason why those goals don’t motivate, is that they’re not the real, the actual goals.

They’re only milestones, markers of an effort or an accomplishment. But behind them, there’s another goal, and another one behind that, and then one more, and so on.

The why of your doing things always has another why behind it.

So when you find yourself struggling to keep your momentum, it can be very useful to ask yourself what is the why behind the why. And the one behind that.

The one grand question to ask them all: all this, to what end?

The best thing you can do, is figure out what’s the why behind the why behind the why.

Find your ultimate, over-arching motivation, and I promise:

Making money isn’t it. Free time isn’t it either. Becoming famous, or an authority in your niche, or the best at thing X - they’re only milestones. They’re the consequence of action, and an indicator of results - but they’re never *it*.

Meaning is it. A purpose in life. A reason why.

Running your life or your business with a clear search for meaning, or dedicating your efforts to the meaning once you found it: that’s what motivates.

It’s like a magnet that pulls you along, which is a lot easier and more fun than having to push the boulder up the hill all the time.

So what’s your purpose, what gives meaning?

In your life, what’s the answer to ‘all this, to what end?’

---
title: How to Build a Runway
status: publish
datePublished: '1614072355'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<p class="p1"><img class="size-medium wp-image-26593 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/02/MartinStellar_Coaching_Illustrations-Bootstrap_how-to-build-a-runway-300x225.png" alt="" width="300" height="225" />I’ll bet it must feel really sexy, for a business to be looking for investors.</p>
<p class="p1">Pitch decks, meeting influential people, all the money that they could invest in you…</p>
<p class="p1">Especially at a time like this, when there’s a lot of money sloshing around.</p>
<p class="p1">A time when investors have a hard time identifying companies that they would actually want to invest in.</p>
<p class="p1">So there they go, all the startups and SaaS companies, pitching their hearts out.</p>
<p class="p1">Didn’t Andy Warhol say that in the future, everybody will get their 15 minutes of Shark Tank?</p>
<p class="p1">Oh, right. Never mind.</p>
<p class="p1">Anyway, it makes sense to look for funds.</p>
<p class="p1">A business needs to grow, invest in resources and development, it needs runway.</p>
<p class="p1">And if an investor gives you that runway, then you can finally move, and scale up. Right?</p>
<p class="p1">Yes.</p>
<p class="p1">Unless a business makes the grave mistake of ignoring the revenue potential they have.</p>
<p class="p1">Sure you can try and sell your business to an investor - but you can also sell your product to a customer.</p>
<p class="p1">If you need funds, sell something.</p>
<p class="p1">If you do that, in many cases, you don’t need no damn investor.</p>
<p class="p1">Of course it doesn’t apply to all companies.</p>
<p class="p1">But almost every day I see businesses that are looking to raise a round, completely ignoring the potential they already have, for building their own runway.</p>
<p class="p1">And that’s just stupid.</p>
<p class="p1">No matter what type of business you run, you can generate revenue with two very simple things:</p>
<p class="p1">1️⃣  Intelligent analysis and segmentation of your audience (i.e. paying, and non-paying subscribers)</p>
<p class="p1">2️⃣  Email marketing, sharply adjusted to the different segments</p>
<p class="p1">And that’s where the majority of companies leave a ton of money on the table.</p>
<p class="p1">They have no idea who their audience really is, what segments exist, and what psychological motivators for buying those people have, and:</p>
<p class="p1">They don’t do anything to engage with those people, don’t do any email marketing that’s valuable and meaningful.</p>
<p class="p1">Or, indeed, that builds up a relationship that leads to a purchase.</p>
<p class="p1">But if you do segment, and you practice email marketing?</p>
<p class="p1">Then you too, very likely, can build your own runway, bootstrapping your way to growth, without ever needing an investor.</p>
<p class="p1">That segmentation and email marketing, that’s something I’ve been doing for years.</p>
<p class="p1">And if you’d rather bootstrap than raise rounds, I can help.</p>
<p class="p1">Let me know if you’d <a href="https://calendly.com/martinstellar/30-minute-appointment-with-martin-stellar">like to talk.</a></p>
<p class="p1">Cheers,</p>
<p class="p1">Martin</p>

---
title: Choice (Best Make Sure You Make This One)
status: publish
datePublished: '1591174288'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - How to sell your work
  - Psychology in sales and marketing

---

<a href="http://martinstellar.com/wp-content/uploads/2020/06/MartinStellar_Coaching_Illustrations-Making-it-happen.png"><img class="alignleft wp-image-24773" src="http://martinstellar.com/wp-content/uploads/2020/06/MartinStellar_Coaching_Illustrations-Making-it-happen-1024x768.png" alt="" width="345" height="259" /></a>There are entrepreneurs who make things happen.

They make the plans, do the work, measure the results, and continuously iterate and optimise both self and systems, in order to reach best performance and outcome.

That’s the kind of entrepreneur who grows themselves, their business, their impact, and their revenue.

There’s also those who, instead, watch what’s happening.

These are people who do try to stay in control of things, but because they don’t plan, execute, or measure enough, they kinda stay stuck. They watch things happen, or not happen.

And then there’s those who wonder what the hell is happening.

That’s what you get when you’re aimless, trying various things, never sticking with something that works, never executing on the things that truly drive growth.

Which group you belong to is the result of a choice, conscious or not. And you'd better consciously make that choice, otherwise it's unlikely you'll be in the first group.

But that would be the group you want to be in, right?

Good. That’s why I created the Strategic Accountability Coaching programme.

Have a <a href="https://martinstellar.com/strategic-accountability-coaching/" target="_blank" rel="noopener noreferrer" data-cke-saved-href="http://martinstellar.com/strategic-accountability-coaching/">look here</a>, and fill out the questionnaire if you feel it’s for you…

Cheers,

Martin

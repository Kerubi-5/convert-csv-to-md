---
title: It's Not That I'm Hollywood, but...
status: draft
datePublished: '1535444332'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-20753" src="http://martinstellar.com/wp-content/uploads/2018/08/MartinStellar_Coaching_Illustrations-selfcare-1024x768.png" alt="" width="351" height="263" />...I do get a weekly manicure. (Which a visiting friend called 'very Hollywood')

Now for a guy, you might find this odd - but there’s a point I want you to get, something that might help you.

Right, a manicure. Do I not groom myself? Yep, I do. I comb my hair, shave daily etc etc. I do what a man’s got to do.

But come on: am I not able to trim my own nails?

Sure I am! I just find it a tedious job, which means I don’t do it often enough, which makes typing uncomfortable.

And for the longest time, I’d heard women say that a getting a manicure is such a nice thing, so I figured I’d give it a try. And it’s lovely - especially the little hand massage she gives when she’s done. A happy end, so to say. Super relaxing.

For me, this weekly 30 minutes is a moment of total relaxation (honestly, you should see her giggle when I seem to nearly pass out. What can I say? I'm a total sucker for hand massages).

Plus, it gets a job done that I don’t enjoy doing - AND my hands are in better condition than if I’d do it myself. Win all the way.

For me, moments like these fall under the category ‘self-care’. Or, as I label it in my calendar: Stellarcare.

In itself it’s nothing significant, but as a weekly stop-and-chill-the-hell-out moment, it’s brilliant.

So the notion I want you to get:

What kind of self-care could you - should you? - include in your week, and your day?

What gets you massive benefits in terms of calm, or focus, or relaxation - but you just never get round to it because there’s always business to take care of?

20 minutes of reading fiction? Playing a game? Calling a friend or your sister? Pottering in your garden? Sorting through old fotos? Walk in the park? Take your bike for a spin? Take the kids to a playground? Lay on the sofa with that beautiful music you love so much?

See, we all need things in our lives that are there for no other reason than that they’re good for us. Playful things, uplifting and relaxing things.

But no, there’s no time for that. Don’t get in my way, I’m busy adulting, I've got a business to run!

Humbug.

Life gets better when you take care of yourself. When you treat yourself to something good, simply for its own sake.

So I invite you to install some self-care in your life. 20 minutes a day, and at least an hour a week - I promise that nobody will die, and clients won't disappear, if you take care of yourself.

And: you can start today.

What will it be for you?

Cheers,

Martin

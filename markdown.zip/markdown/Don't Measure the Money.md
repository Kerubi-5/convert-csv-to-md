---
title: Don't Measure the Money
status: draft
datePublished: '1514975614'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/afcc19fb-4f4d-4d0e-87db-b8a864f127fd.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/afcc19fb-4f4d-4d0e-87db-b8a864f127fd.jpg" data-file-id="4835341" />Of course money isn’t the most important thing in the world, but if you don’t have enough, life can be hard.

And besides: money can buy you freedom - to travel, learn, create, be with friends and family.

Money matters, especially if you run a business.

But the problem with most people is that they measure the money - the financial gains or growth - and when there isn’t enough, they get frustrated.

So here’s the solution: don’t measure the money, but measure your activities instead.

Measure how consistent you are at taking action.

Two reasons:

First, money comes as a result of consistent action over time. I think we all agree on that one.

But secondly, and very importantly: seeing your own persistent action over time give you feedback, showing you that you’re doing it right.

“Hey, I’m doing this. I’m getting it right and if I keep this up, I’ll get there”.

And that will do wonders for your state, your ability to overcome procrastination, and your peace of mind. All very important, and all suffering terribly if you keep asking yourself why the money hasn’t shown up yet.

And any time there’s bills to pay and you feel the pressure?

Switch on, get busy, leap into action.

Chop chop, clock’s a-ticking.

Life can be so simple.

There’s one caveat though: Deciding which action to spend your energy on matters a lot.

So if you are the kind of person who takes action but it’s not paying off yet, you might want to adjust your decisions as to which actions are most important.

And if you’re not clear about it, let me know. I’ll help you figure out what actions in your business will move the needle the most.

Cheers,

Martin

---
title: 'Announcing: Live Training on Ethical Sales - Tomorrow 18 April'
status: publish
datePublished: '1555492063'
categories:
  - Ethics and marketing
  - How to sell your work
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-21618" src="http://martinstellar.com/wp-content/uploads/2019/04/MartinStellar_Coaching_Illustrations-Live-sales-training-1024x768.png" alt="" width="348" height="261" />If you haven’t signed up for my live training yet, which will take place tomorrow…

You might want to consider attending, and for two reasons:

First: for those who are eager to increase their earnings and the percentage of people who become a client, you’ll find the training is a major upgrade to how you handle your sales process.

Secondly, because right now, I’m in pilot-launch mode, and that comes with a spectacular bonus.

So the training itself, that’s free.

And, it’s full-on delivery of useable information. This won’t be one of those webinars where the host gives ten minutes of information, and then spends the rest of the hour trying to sell you something.

Real, actual training.

Now, where the bonus comes in:

At the end of the webinar (yes, at the end. Again, this isn’t a ‘little content, mucho sales thing), I’ll announce a new course I created, and because this is a pilot-launch, I’ll be looking for a few select people, who want to be a case study.

And that comes with a TON of personal attention for the duration of the course - should you want to take it.

But even if you don’t, you could do worse than to attend, and at least take in the ethical sales system I’ll be teaching.

Sounds good?

Then sign yer good self up here: <del>http://martinstellar.com/leap-ethical-selling-system/</del>

[Update: the event was in 2019, but if you want more information and a 10-minute explainer video of the system, <a href="https://martinstellar.com/helping-good-people-sell-more-and-generate-a-bigger-impact/">here you go</a>.
Cheers,

Martin

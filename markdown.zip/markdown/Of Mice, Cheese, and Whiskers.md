---
title: Of Mice, Cheese, and Whiskers
status: publish
datePublished: '1531758943'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/02e39f18-d0c3-48db-9ee2-8796cddade6a.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/02e39f18-d0c3-48db-9ee2-8796cddade6a.png" data-file-id="4835917" />A mouse runs for the hills when you show it a cat's whiskers.

Whiskers = danger, and you’ll never catch a mouse if thinks it perceives something threatening, no matter how docile Mr Socks might be.

Which explains perfectly why that guy who tried to pitch his programme at me got nowhere: he went straight for the jugular - not that he literally threatened me, but in terms of sales conversations, it was a threat and not an enticement.

(Kudos to Dean Jackson for the cheese/whiskers analogy btw).

No, when you want to catch a mouse (i.e. have someone buy something, or buy into an idea, or pick up a suggestion you make etc etc) you’ll get far more results if you show something that the other wants, as opposed to what the other might perceive as a threat.

In other words: show them cheese, instead of whiskers.

I’m reminded of this by an email I just received, where a reader said they’ve tried to get someone to contact me, but that other person hasn’t done so yet. Doesn’t feel they need it, isn’t ready - who knows what’s going on in the other’s head.

But trying to get someone to do something can very easily be perceived as a threat on some subconscious level. Can be something as subtle as a (perceived) threat to autonomy.

And you’d be amazed how easy it is to “threaten” someone, on subtle subconscious levels.

Like last spring, when I was at an art walk, entered one of the houses, said ‘nice work’ and was greeted with the reply: “Thanks. It’s all for sale”.

Whiskers. Run!

No, if you want someone to take a certain action (be that buying your work, putting the cap on the toothpaste, or adopting a different view on something), you’ll do a lot better if you present cheese, and let them get closer in their own time.

Point is, we’re built with a highly sensitive, always-on radar for anything that’s even remotely threatening.

And it’s extremely easy to trigger the defense-mechanism - and off goes your mouse.

Want someone to take an action that you know for a fact will be good for them?

Paint the ‘after’ picture, IF they take action XYZ.

And then let them get ready in their own sweet time.

That way, there’s not a whisker in sight, and the memory of the cheese will stay with them until they’re ready.

Another benefit: when you let someone make the choice themselves instead of being pushed into something, it means they own the decision. They’ll ‘become a customer of change’, as it’s called in therapeutic circles.

Which makes it far more likely that they’ll actually benefit from the decision.

Because an imposed ‘purchase’ very easily leads to buyer’s remorse, which won’t help that person, or the relationship you have with them.

So think: in what way do you show whiskers, when actually showing cheese would work better?

&nbsp;

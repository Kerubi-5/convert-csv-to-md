---
title: 'How to Slay the Self-Critic (Warning: Use at Own Peril)'
status: draft
datePublished: '1520946174'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/b187dbb3-0776-4728-9cd3-25c09c7b9595.jpg" width="350" height="262" align="left" data-file-id="4835541" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/b187dbb3-0776-4728-9cd3-25c09c7b9595.jpg" />Maybe you’d been seeing it coming, but to me it was quite a surprise to step into my artist identity.

Never expected that - after all, I’ve had a rather conflicted history with art in general (except for music - godly, divine, bliss-inducing music!)

It took me a few days to realise it, but here’s how it happened.

In the sessions with my coach, we’d been dealing recently with the topic of Love (the one with the big L), and I showed up with a TON of resistance.

If Steven Pressfield had been dead, he’d have been chuckling in his grave.

And my coach said: “Your inner critic is very strong”.

A few days later I was pondering that fact, and wondered what to do.

When suddenly it hit me: inner critic… resistance… and Love.

So what if instead of trying to fight or subdue the inner critic… what if I would simply decide to Love that part of myself?

Aaaand bam! The next day, I’d decided to give in, to stop resisting, to let art into my life.

I’ve said it before: the only way to overcome the demons, the negative elements in ourselves, is to starve them.

Because when you fight the demon, you just feed it and it gets stronger. You can’t bully or beat your inner critic out of your life.

But if you can love - really LOVE that this is you, and that that part of you is a natural aspect of you?

Poof… gone.

Oh he’ll be back. As per my email yesterday: the things we overcome usually show up again at a later stage.

But I’m not bothered, because I now have the most powerful weapon: Love.

And I know it works.

You can use it too, but be careful.

If you do it the wrong way, and you identify with the negative side, and in a perverse sort of way start to lean into it and let it speak, you could end up with even more resistance than you started out with.

But if you do it right?

Heh. The demon dissolves - that’s what happens in the mind when you choose Love. How amazing.

Is it easy?

Depends. Gets a lot easier when you talk to a coach…

Cheers,

​Martin

---
title: Count Yourself
status: publish
datePublished: '1605746653'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing
  - Talking words

---

<img class="alignleft wp-image-22242" src="http://martinstellar.com/wp-content/uploads/2019/11/MartinStellar_Coaching_Illustrations-Copywriting-rule_count-yourself-1024x768.png" alt="" width="349" height="262" />Yeah I know - there’s only one 'you' to count, right?

But check the way you write your business communications… emails you send to your list… replies on Messenger and Whatsapp… blog posts, your about page…

In the things that you write, how often does  the word ‘I’ show up?

Ah… suddenly there’s a lot more of ‘you’ to count…

Look, it’s natural to reference self when writing. After all it’s us, ‘I’, in dialogue with someone else, or it's 'I' delivering discourse.

But most business writing is full of self-reference and the word ‘I’ shows up so much, that the reader can’t help but feel that it’s not about them.

And then they’re lost, they stop reading, they unsubscribe, or don’t follow up on your proposal.

So to make your business writing better, remember a few ground rules:

Never start a message with ‘I’. You might be the most loving and compassionate person in the world, but when ‘I’ leads the message, the reader reads ‘self-importance’.

Following on from that: Avoid as much as possible, starting a sentence with ‘I’. Reason: see above, but cumulative.

Ok. So with that, you’ve edited and improved your missive. Well done.

But if you count self, you see there’s still a lot of ‘I’ in there… now what?

Simple:

Replace each instance of ‘I’ with ‘you’, see how it breaks the sentence, and then: rewrite the sentence so that you keep ‘you’ and it all makes sense again.

Do that with each instance of ‘I’, and you’ll be sending messages that instead of driving people away because it *feels* like it’s all about you, will draw people in to working with you, because the absence of that ‘I’ focus allows them to relate your message to themselves.

Make people feel it’s about them, and they get closer - which is pretty damn required if they’re going to buy from you.

One of the things I love doing for clients, is improve their copy for them.

<span style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen-Sans, Ubuntu, Cantarell, 'Helvetica Neue', sans-serif;">I’ve done it a lot back when I was a copywriter, so fixing something that's almost good and make it great is something I can do on the fly -  and for my clients it’s great, because they can focus on doing their work, while they get a pro to create written business communication that causes sales.</span>

It’s not that I sell that as a service, but it’s a nice bonus to give, and super profitable for my clients.

Like that series of emails I wrote a while ago, and which helped my client net almost $10k in five days.

Could be the kind of help you have in your corner.

Should we have a chat about what it would look like to get my help?

<a href="mailto:hello@martinstellar.com">Let me know...</a>

In any case, watch out for self-referencing in your writing - make sure that even if you write <em>about </em>yourself, it's always <em>for </em>the reader.

Cheers,

Martin

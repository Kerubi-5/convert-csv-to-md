---
title: How to Sell More, With More Ease... And You Don't Even Need to Know Kung Fu
status: publish
datePublished: '1609160398'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<p class="p1"><img class="alignleft wp-image-26284" src="https://martinstellar.com/wp-content/uploads/2020/12/MartinStellar_Coaching_Illustrations-I-know-kung-fu-300x159.png" alt="" width="494" height="262" />You know that scene from The Matrix, where they upload kung fu into Neo’s brain, and he opens his eyes, and goes:</p>
<p class="p1">“I know kung fu!”, and then he proceeds to whoop Morpheus’ ass?</p>
<p class="p1">There’s a reason why that matters, for your business.</p>
<p class="p1">Because once you acquire a skill on a profoundly deep level, everything changes.</p>
<p class="p1">For example - and I can’t attest because I’m not very literate in terms of numbers - I have it on good authority that when you know mathematics, a ton of things in the world get easier and make more sense.</p>
<p class="p1">Or, what I can attest to: once you have the ability to write with precision, drafting an email or an article, or whipping someone’s draft into shape, becomes something you do as a matter of course.</p>
<p class="p1">As such, some skills function as a kind of meta-skill.</p>
<p class="p1">They enable and facilitate a type of ease and effortless mastery that translates into various areas in life, and in business as well.</p>
<p class="p1">No, you probably won’t improve your business results by learning kung fu, but you’ll sure as hell see more people buying your work, once you acquire the meta-skill of communication in a way that gets people to enrol in your ideas voluntarily.</p>
<p class="p1">Enter my proprietary LEAP Framework for Ethical Selling.</p>
<p class="p1">It’s an extremely powerful mental model for how you interact with people.</p>
<p class="p1">It changes the way you communicate, and the way you show up to conversations with buyers.</p>
<p class="p1">And everyone I’ve taught it to, has seen a dramatically positive effect in their results with buyers.</p>
<p class="p1">Discretion prohibits me from sharing details, but we’re talking about many thousands of Dollars worth of client contracts that my students have raised.</p>
<p class="p1">And, bonus: the sales process became a lot easier and more relaxed for them, and for their buyers as well.</p>
<p class="p1">Which is why I highly recommend you consider signing on as a student, because hey:</p>
<p class="p1">If you’re in business, you want buyers. Right?</p>
<p class="p1">Especially if you’re a purpose-driven entrepreneur and you want your work to have an impact.</p>
<p class="p1">That impact will always be contingent on the the number of people you can serve with your work, which means you only get to make that impact, when people buy.</p>
<p class="p1">More buyers, more impact. Simple.</p>
<p class="p1">And, incidentally, that’s the impact I want to make:</p>
<p class="p1">To see as many ethical entrepreneurs as possible acquire the meta-skill of communicating in such a way that buyers sign themselves up.</p>
<p class="p1">And until January 1st, the training programme that installs the LEAP sales framework in your ethical little mind, is yours at $1500. After that, it goes up to $2800.</p>
<p class="p1">Here’s how it works:</p>
<p class="p1">? Each week, for ten weeks straight, you and I meet on Zoom for 45 minutes.</p>
<p class="p1">? You’ll be guided through the ten pillars of the system, and you’ll learn how each stacks on top of the other so as to</p>
<p class="p1">? You’ll learn how to ask questions that make your buyer feel safe, so that they develop trust</p>
<p class="p1">? You’ll learn how to gain permission for asking more and deeper questions, as well as permission to ask for the sale (because one should never sell without permission!)</p>
<p class="p1">? You’ll also learn how to get comfortable with hearing the dreaded ‘no’ - and in fact, you’ll discover how to get more people to say yes, by asking them to say no. Weird, but it works.</p>
<p class="p1">? You’ll discover how to make the sales process fun, and super-helpful for your buyers, because you’ll turn selling into an act of service.</p>
<p class="p1">? And, of course, you’ll acquire the mindset and mental model and communication &amp; messaging skills that enable you to sell more, at higher prices, so that you get to have a bigger impact as well as earn the money your work is worth.</p>
<p class="p1">If that sounds good (and I can’t imagine who would say it doesn’t), then either <a href="http://martinstellar.com/helping-good-people-sell-more-and-generate-a-bigger-impact/"><span class="s1">go here to sign up before the price goes up</span></a>, or reply to this email if you have any questions.</p>
<p class="p1">Alright?</p>
<p class="p1">Do note: this is not one of those ‘ten steps to close a sale’ or ‘the #1 strategy to convince and persuade reluctant buyers’ or ‘always be closing’ BS kind of thing.</p>
<p class="p1">That stuff is so old-school, and in many cases, not exactly ethical, or indeed, nice.</p>
<p class="p1">Instead, this is a training that changes, in a very fundamental way, how you show up, listen, message, and communicate.</p>
<p class="p1">Kung fu for selling? Sure, I guess.</p>
<p class="p1">Anyway, here’s the link, in case you’re ready to turn 2021 into the year you exponentially increase your impact:</p>
<p class="p1">http://martinstellar.com/helping-good-people-sell-more-and-generate-a-bigger-impact/</p>
<p class="p1">Cheers,</p>
<p class="p1">Martin</p>

---
title: Decision Time? (Offer Expires Tonight, Only 10 Seats)
status: draft
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img class="alignleft" src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/278829e9-da3a-493e-99c2-ac825b55e414.png" width="350" height="378" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/278829e9-da3a-493e-99c2-ac825b55e414.png" data-file-id="4836657" />Alright folks, it’s decision time.

Meaning, for the ethical sales training that almost doubles in price, tonight.

And, as per my Sales for Nice People method, which I teach entrepreneurs and that enables them to earn far more, much more easily, as proven by yesterday’s message:

It’s all up to you - it’s your choice and your decision.

And that means, maybe your best choice is ‘sometime in the future’, and yeah, that’s fine by me.

Maybe you don’t have the money to enroll in the course (split payments available, though).

Or maybe you’re not getting enough prospects in, to justify investing in your ability to enroll them and convert them into buyers.

Or, maybe the majority of your buyers simply click a checkout button on your site, and you don’t have face-to-Zoom sales conversations very often.

There could be all kinds of reasons to not buy it today - including insisting on the idea that selling just isn’t right and nice and you could never do it in an ethical way, in which case the training isn’t right for you and you should definitely not buy it.

I mean, it’s not my job to persuade you to change deeply held erroneous beliefs, or stop you from arguing for your limitations. Sorry to say it, but if you don’t <em>want</em> to change the way you see selling, I can’t help you ?‍♂️

If you do want to change your view on sales though, and also change the way you handle the process of selling, <em>and </em>you also want to increase your conversion rates, then yes, this course is exactly made for that.

Until tonight it’s $1500 for ten weekly training sessions, and because it’s personal, 1 on 1 sessions with yours truly, there’s only 10 seats left.

<strong>This is what’s in the tin:</strong>

? 10 weekly 1-on-1 sessions: 25 minutes of training, 20 for Q&amp;A

? Personalised homework and exercises, specific to your business and sales challenges

? First session: 2 hours, enabling me to customise your training for you

? Ongoing email access for feedback and questions

? Bonus: a two-hour Customer Re-activation Session in week 2, to quickly get you new sales from past buyers

And, more importantly than the features:

<strong>This is what it will get you:</strong>

✅ You’ll enroll clients with more ease than you ever thought possible

✅  You will be able to sell your work while staying 100% true to your moral and ethical values

✅ Sign on clients without ever having to worry about compromising your integrity

✅ You’ll have sales conversations that are fun and 100% free of pushiness or manipulation

✅ You’ll learn how to inside the mind of your buyer, so that they'll see you as a trusted advisor instead of a seller they need to fend off

✅ You’ll end up having sales conversations that create clients exactly because the conversation itself is an act of service

✅ You’ll reduce objections and build trust automatically (no “objection handling” required)

✅ You’ll increase your conversion rate

✅ You’ll be able to sell your work at higher fees

✅ Tl;dr: You’ll enroll more clients, have more impact, and earn more money

And if this is what you want and if your choice is ‘yes’, then<a href="http://martinstellar.com/helping-good-people-sell-more-and-generate-a-bigger-impact/" target="_blank" rel="noopener noreferrer" data-cke-saved-href="http://martinstellar.com/helping-good-people-sell-more-and-generate-a-bigger-impact/"> go here to enroll. </a>

After checkout, you’ll be redirected to my calendar instantly, to schedule your first, 2-hour session.

Have a lovely end-of-year celebration, be well, and see you on the other side…

Cheers,

Martin

&nbsp;

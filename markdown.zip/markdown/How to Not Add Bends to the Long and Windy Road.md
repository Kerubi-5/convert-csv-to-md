---
title: How to Not Add Bends to the Long and Windy Road
status: draft
datePublished: '1539250446'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-20974" src="http://martinstellar.com/wp-content/uploads/2018/10/MartinStellar_Coaching_Illustrations-Beliefs-and-straight-paths-1024x768.png" alt="" width="355" height="266" />Yesterday was an interesting day: I figured that my little rant against the spiritual supermarket would decimate my readership, but nope: only a few people left.

Looks like you all are pretty smart and sensible.

I did receive a question though, from a reader who asked ‘who’s to say that looking at an astrology chart won’t help someone turn inward?’

Well, think of it like this:

If you want to go somewhere, and you get in your car, and you look in your rearview mirror, you will not arrive at your destination. Guaranteed or your money back.

Similarly, looking outside of yourself for the cause or the solution of things, isn’t going to help you turn inside to look for answers.

If you’re lucky, you’ll someday end up realising that your attention is better put inward than outward, and then you’ll actually get the insights and clarity and results you want.

But meanwhile, you might spend years in confusion, or getting unwanted outcomes.

So to me, astrology or any of the other ‘spiritual’ things people try to sell us (or sell us on), that’s just a way to postpone actual insight.

It’s a diversion, a detour.

Can be fun, might feel good, but won’t speed you up.

And why would you waste time?

If life is a path to travel, it comes with plenty of curves built in by default. Why would you add in extra curves, and slow yourself down?

To bring back yesterday’s topic: spirituality (and life, and business) get easier and more real the more things you eliminate.

And I think we would all like to ‘keep it real’.

There is no straight line to get to wellbeing or wealth or awesome relationships.

But you can straighten the path to your outcomes, and the more you eliminate - especially beliefs - the less curvy the path.

This is exactly why Calibrate Reality Dojo is built on two tenets:

1: Inside = outside. Perception equals reality

2: Question everything, especially your beliefs.

So with that said, final call to get on the guest list… just let me know.

Cheers,

Martin

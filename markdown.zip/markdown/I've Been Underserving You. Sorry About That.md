---
title: I've Been Underserving You. Sorry About That
status: draft
datePublished: '1519810178'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/19668428-844e-4bba-85a1-92108660224b.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/19668428-844e-4bba-85a1-92108660224b.png" data-file-id="4835501" />Do what I say, not what I do… don’t you just love it?

Me, I don’t.

And yet, I’ve been giving you the wrong example.

Here’s the deal: these emails coaching emails I send each day, they serve a series of purposes.

* It’s a public service - a free virtual coaching experience for those who benefit from it

* It’s therapeutic for me: it forces me to stay on track with my business goals, and it’s a daily return to performing an act of service, which is ultimately what each business is about. To serve a customer (and please, don’t ever say that you ‘service’ your customers. They’re not a car, but I digress)

* It’s a way to show you how email marketing is done

* The list goes on, but I’ll end it today with: it’s a fantastically fun and effective way to create clients

But here’s the rub: The last half year or so, I’ve been doing it wrong.

Meaning, I’ve been showing you how not to do it.

Why? Because I’ve stopped including a daily call to action (CTA) which is ultimately what will get you the buyers.

Oh I use CTA’s frequently, for example when I ask you to reply, to read a certain book, to implement something in your life and so on.

But, that happens to benefit my business because of a certain set of circumstances, unique to me and my business and my audience.

And, it’s showing you a wrong example.

So yeah. Sorry.

This became clear to me yesterday, when I saw a client send one of her own daily emails, where her CTA was ‘Click the link to share this email’.

Which isn’t bad as a CTA, but clearly you are more likely to get a share than a buyer.

After all, when you ask someone to do thing A, they’re probably going to do that thing, and not thing B.

But when you want to sell something, shouldn’t you be asking for the sale? Shouldn’t you be inviting people to consider buying from you?

Would you like another rhetorical question?

So if I want you to grow your business and leading by example is the name of the game, it’s only normal to show you how it’s done.

Now that doesn’t mean that you need to turn every email into a hard sales pitch. In fact, don’t do that. It would decimate your list.

But there’s nothing wrong with being in business, and if you want to sell, there’s nothing wrong with *looking* open for business.

And no, talking about your art or your book or your massage therapy isn’t enough.

Showing it isn’t the thing.

I mean, are you a museum or a gallery? Are you a library or a book store?

If  you want to sell it, say so.

Not in a pushy or aggressive way, that’s not necessary. Don’t be a used car salesman or telemarketer, except in writing.

Be a trusted advisor, whose interest is for the buyer to make the right decision for themselves, even if that decision is to not buy (today).

How that’s done?

Like so, for example:

A coach is someone who makes it safe for you to look in the mirror.

Someone who guides you through a process where you do the things that need to be done, in order to get you the results you want.

It’s fun but it requires commitment.

It’s effective, but only if you’re willing to do the work, so it will only work for a specific type of individual.

Is that you?

Then hit reply, and let’s talk.

Now, that didn’t hurt, did it?

95% content - designed to serve, engage, inspire, educate or a mix of these - and 5% pitch.

You can do it too, and you’ll see sales go up if you do.

Cheers,

Martin

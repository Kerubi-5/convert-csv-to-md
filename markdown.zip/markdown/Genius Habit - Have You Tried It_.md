---
title: Genius Habit - Have You Tried It?
status: draft
datePublished: '1497368865'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/f307e237-e90d-49b8-ac28-35e22dfd1b57.png" width="350" height="376" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/f307e237-e90d-49b8-ac28-35e22dfd1b57.png" data-file-id="4834689" />Interesting confluence: right as I’m writing this series of emails about habits, I see people like Jamie Smart and Brian Clarke riff on the same topic.

Makes me think they’re taking cues from me, but then that’s what an arrogant bugger like me is wont to think.

Anyway, habits. Love ‘em or leave, the more you work with them the better things get.

And the best habit, to start building before anything else?

That just might be the habit of spending time in your zone of genius.

You know, that activity that nobody does quite the way you do it.

Because it’s so easy to get lost in the busy-ness of things, and that way you never take the time to do your most important work.

Meaning, the top-level work that distinguishes you from the competition. The stuff that moves the needle forward.

And for some of us (most of us? definitely for me) that can mean simply doing nothing whatsoever, other than watching your thoughts roll by and create ideas, while taking notes.

Because if you’re a creative person of any kind, it’s really important to allow time for creative thinking about business and how it interacts with life.

But when’s the last time you did that?

How often do you actually sit to contemplate where you’re at, where you want to go, and allow your mind to feel its way through the different options, obstacles, and opportunities?

If you’re like most of us, that only happens when you’re on holiday or about to fall asleep.

I say plan time for it, every day. 10 minutes if that’s all you *think* you can afford, but I’ll bet that if you give it an hour, that’s time that pays itself back before too long.

So I challenge you: why not spend 30 minutes a day, for a full month, doing nothing except thinking and taking notes…?

You might be surprised at what it does for you and your mind and your business.

And if you want to step into my habit-building machine and get me to coach you one on one, let me know.

Cheers,

Martin

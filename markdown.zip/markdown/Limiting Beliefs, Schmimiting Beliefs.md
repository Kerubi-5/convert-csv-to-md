---
title: Limiting Beliefs, Schmimiting Beliefs
status: draft
datePublished: '1530115606'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

It<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/29c1b025-1d94-42ef-98c2-5b9299a48980.png" width="350" height="262" align="left" data-file-id="4835865" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/29c1b025-1d94-42ef-98c2-5b9299a48980.png" />’s the hot new thing, these days. Limiting beliefs are the new black. Everywhere you look, on every streetcorner and social media feed, coaches and therapists and biz growth gurus are poised to identify and point out any limiting belief in your thoughts or words.

I call *meh*.

Let’s take it up a notch, and do it right:

Every belief is a limiting belief.

Ooh yeah… I went there.

Let me show you why all beliefs are limiting, starting with a conversation with a friend last Friday, after my little accident.

Sofia: “But you must see a doctor! There might be internal damage!”

Me: “I phoned a friend who’s a doctor. Told her I feel fine, am mobile, not in pain… I even hung the laundry an hour after the fall. Doc said to call back if I’m still having trouble in three weeks”.”

Sofia: “But I’m worried. You need to worry too.”

Me: “What use is worrying though, really?”

Sofia: “What? But we have to worry!”

Whoops. Big limiting belief, right? Obvious one. A belief that pre-reserves part of your thoughts for worry-warting around in your mind. And, limits what amount of mental resources you’ll have left to use.

(And MAN you’d be amazed how many people actually do believe that worrying is useful and good).

But back to the topic: it’s not only negative beliefs that are limiting.

Every belief limits you.

Problem is that we all think (in effect: believe) that we have positive, enabling beliefs, but you’ll have plenty that are, in fact, not positive or enabling.

They’re easy to spot too: just look at the behaviour you display.

Overthink stuff, over and over again? Then there’s a belief that says worrying is useful.

Frantic, panicked, unguided activity each time money gets low? Then there’s a belief saying activity (any kind) beats clarity and focus.

Not been to the gym in 20 years? That means there’s a belief that says (big one here) that you’re immortal - that for all eternity, there’s always going to be a tomorrow.

Same thing with procrastinating on important tasks. Always a tomorrow waiting for you.

Easy to get angry at people? Comes from a belief that you’re more right, or better, or more entitled than others.

Do you argue when your coach suggests you raise your prices? Behind that is a belief that says someone like you ought not to earn that much for the kind of thing you do.

See what I’m doing here?

If you’re really honest with yourself, and if you dare to dig all the way to the root, you’ll always find there’s a larger, deeper, belief at work behind every negative in your life.

Have a look at your own life… what negatives are there?

What do they say about the things that you - deep down - fundamentally believe?

Cheers,

Martin

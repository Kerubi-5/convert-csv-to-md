---
title: 'How to Generate Leads: Numbers Game or People Game?'
status: publish
datePublished: '1662966388'
categories:
  - How to sell your work

---

<img class="size-medium wp-image-28241 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/10/MartinStellar_Coaching_Illustrations-How-to-generate-leads-People-game-vs-numbers-game-300x225.jpeg" alt="" width="300" height="225" />
<div>

When you're in business, you obviously want clients.

</div>
<div>

Broadly speaking, you can either do that with marketing, or with lead-generation.

</div>
<div>

And if the latter is your method of choice, there's two fundamentally different ways of doing it.

</div>
<div>

The first and most common one is when people play a numbers game.

</div>
<div>

That's when you get those messages in your LinkedIn inbox.

</div>
<div>

“Hey, I have this thing that I know will really help you. Shall we talk?”

</div>
<div>

Another message to "just check in!", and then another, and another, and you know:

</div>
<div>

You’re in somebody’s funnel.

</div>
<div>

Somebody is playing a number's game, and you're one of the numbers.

</div>
<div>

It’s not that it’s wrong, but in my opinion, it’s not right either.

</div>
<div>

I mean: it’s automated, impersonal, mechanical.

</div>
<div>

It doesn’t feel nice, to be in that kind of funnel, I don't consider it a nice way to treat people.

</div>
<div>

Now, I’m not a lead generation expert, but I’ve spent many (many!) hours figuring out how to play a ‘people-game’, as opposed to a numbers game, and generate leads for myself.

</div>
<div>

How do I do it?

</div>
<div>

I simply carefully, manually, review people that I think I can help - before I get in touch.

</div>
<div>

I study their website, their social channels, I look them up on Youtube, I try and get a picture of who that person or business is or might be.

</div>
<div>

In other words, as per my dictum: I try to ‘learn people’, before I ever send a message.

</div>
<div>

The consequence is that once I do show up with a message, I can say things that prove that I’ve invested time in them.

</div>
<div>

They cannot possibly think “Gah, more automated stuff”, because I’ll be saying things to them - about them, about their business, their copy or their website - that <em>prove</em>, at the very first point of contact, that this is actually personal, and not automated.

</div>
<div>

The result?

</div>
<div>

Instead of negative reactions (or none at all), I get appointments, reactions, feedback, clients, and even people saying “Thank you for doing this absolutely cold outreach”.

</div>
<div>

And yeah, it’s a costly process, to review dozens of websites a day, to only find one or two people I should be talking to.

</div>
<div>

Is it worth it, though?

</div>
<div>

Don’t know, you tell me:

</div>
<div>

One result was someone who signed up for my ethical sales training, who then became a coaching client, who referred another coaching client, and who now is a revenue share partner.

</div>
<div>

That week that I spent, to find just a handful of leads, with one gem in there, was very lucrative, and is now - two years later - still paying dividends in term of hard cash.

</div>
<div>

Of course, results like that are not typical, and it takes a long time to get good at learning people from a distance.

</div>
<div>

But as a business owner who truly cares, I would much rather play a people game, instead of a numbers game.

</div>
<div>

What about you?

</div>
<div></div>
<div>

&nbsp;

</div>

<hr />

On another note:
I'm building an app that coaches you on working your pipeline, moving your deals forward - and closing them faster and at better rates.
It's called SalesFlow Coach, and we're scheduled for beta-release early May 2022.
Register <a href="https://martinstellar.com/salesflow-coach-launch/">here</a> to be notified when it goes live.

&nbsp;

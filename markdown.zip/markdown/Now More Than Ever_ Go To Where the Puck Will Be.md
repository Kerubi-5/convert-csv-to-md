---
title: 'Now More Than Ever: Go To Where the Puck Will Be'
status: publish
datePublished: '1591865362'
categories:
  - Business and systems
  - Doing it right as an entrepreneur or creative professional
  - Hope&amp;Survival
  - How to sell your work
  - Psychology in sales and marketing

---

<a href="http://martinstellar.com/wp-content/uploads/2020/06/MartinStellar_Coaching_Illustrations-Go-where-the-puck-will-be.png"><img class="alignleft wp-image-24797" src="http://martinstellar.com/wp-content/uploads/2020/06/MartinStellar_Coaching_Illustrations-Go-where-the-puck-will-be-1024x768.png" alt="" width="356" height="267" /></a>Spoke with the owner of a transport company a while back, after Spain had come out of full lockdown.

You know: the people who made sure we have food in shops, regardless of crisis or lockdowns or whatever happens.

Pretty essential workers, but it's an industry that’s under massive pressure.

Regulations, middlemen, corruption, clients who insist on the lowest prices - and of course, the drivers end up getting the short end of the stick.

And it’s only going to get worse for them: in a few years we’ll have self-driving trucks on all roads, and algorithms will enable large companies to create hyper-efficient delivery routes - and let’s not forget automated drone delivery.

In other words: transport is an industry that’s breaking, and very fast too.

Now you might not be in transport, but there’s a lesson for you as well.

It’s said that you need to ‘skate to where the puck is <em>going to be</em>, not to where it is now’.

That applies to anyone in business, because while right now the world is changing fast than ever, it’s only going to change faster and faster.

Which means that if you try to fix what broke, you’ll endlessly be chasing the puck, and you’ll never reach it.

But if you take a wider perspective, and ask yourself ‘if this continues…’ you end up with a vision of the future that might not be how the future will pan out, but you’ll be much better positioned to deal with the new and surprising changes that we’ll all be facing.

Yes: things have broken, nothing is the same, business is unusual.

So instead of trying to catch up, see if you can get ahead.

If this continues… where will your industry be in 6 months, in a year from now?

What will your buyers need, what kind of new or different problems will they face that you can solve for them?

Go there.

Those who benefit and grow when things break, are the ones who take the time to project into the future: they envision where the puck will go, and they position themselves to knock it out of the rink once it arrives.

Put differently:

The entire world has been hit with entropy.

I say don’t try to fix it, but build something new instead.

Cheers,

Martin

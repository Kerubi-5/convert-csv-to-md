---
title: Non-Attached to the Outcome
status: draft
datePublished: '1509641808'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/aa275ed6-1954-4f48-8bd3-cd8a9aade7c1.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/aa275ed6-1954-4f48-8bd3-cd8a9aade7c1.jpg" data-file-id="4835169" />Ever tried to hold on to being happy?

To being in love?

To that dream you almost remember, just when you wake up?

Yeah I know. It doesn’t work like that.

Things come and go, and the more you try to hold on to states you experience, the faster they’ll disappear and go.

Same thing with trying to become happy: you can’t get there from here.

Just like you can’t hold on to a state by trying to hold on to it, you can’t get to happiness by trying to find it. There’s no direct connection.

Trying to be happy is fruitless, because happiness comes as a consequence of other things, not as the result of effort.

(Pro tip: if you really want to become happy, try placing yourself in the service of others, and see what that does for you. Altruism of various sorts
keeps proving itself a powerful tool. And my own experience confirms that).

Anyway: clinging. Clutching. Holding on. Frantically trying to create an outcome. Being attached to it.

All of that, mostly pointless.

Instead, let go of any attachment to outcome you may have.

Give the effort your all, be scrupulous and diligent in your work, and then let life itself show you whether or not you got it right.

And then look at the correlation between efforts, decisions, and results, and adjust as needed.

But for goodness’ sake, please don’t get attached to the outcome. Misery lies in that direction, and frustration and disappointment.

See, attachments are only good when you’re sending emails. Beyond that, being attached to things won’t help you.

And that’s not just something from the world of spirituality, or for people with a spiritual orientation in life.

Attachment is a basic human error, one which has a negative effect on anyone who is not free from it.

You want to be happier? Stop trying.

Want better results? Stop thinking about them and focus on the actions to get you there, instead.

Want great outcomes?

Then work your hardest (effectively a contradiction in terms, since letting go isn’t something you can ‘do’ or ‘work on’, but hey) to let go of your attachment to them.

Much better to put your mind to those things that get you good outcomes, wouldn’t you say?

Exactly.

Let me know if you want to talk about the outcomes you wish for, and the actions and decisions you’d like to make to get them. Without attachment.

Cheers,

Martin

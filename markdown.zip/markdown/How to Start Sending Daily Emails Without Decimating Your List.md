---
title: How to Start Sending Daily Emails Without Decimating Your List
status: publish
datePublished: '1628158428'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<p class="p1"><img class="size-medium wp-image-26623 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/03/MartinStellar_Coaching_Illustrations-Daily-email-pt2-300x225.png" alt="" width="300" height="225" />Yesterday I told you that if you do it right, and you treat your list well, you can send daily emails that inspire, entertain, educate, and yes:</p>
<p class="p1">You can, without risk or adverse consequences, send daily emails that sell your work.</p>
<p class="p1">And, that keep your unsubscribe rates low.</p>
<p class="p1">So I imagine the idea might appeal to you, but you’re concerned:</p>
<p class="p1">“People only got the occasional email from me. If I suddenly start mailing daily, I’ll decimate my list!”.</p>
<p class="p1">This might be true.</p>
<p class="p1">And if that happens, it might be a really good thing.</p>
<p class="p1">Because those who don’t leave, they are the people who actually <em>want</em> to hear from you every day.</p>
<p class="p1">I.e. an engaged audience.</p>
<p class="p1">But, I understand that for most people, the risk and uncertainty are too great.</p>
<p class="p1">So, what about an experiment?</p>
<p class="p1">Two options:</p>
<p class="p1">Option # 1</p>
<p class="p1">Take a random section of your list - say 5% or 10%. (You’ll want at least 100 recipients, in order to get a correct reading on the response of your audience).</p>
<p class="p1">Start sending dailies.</p>
<p class="p1">Make sure to tell people in the first one that from now on, you’ll be sending daily, and that you’re ok with them unsubscribing.</p>
<p class="p1">Initially, you’ll see a high number of unsubscribes, especially in the first week or so.</p>
<p class="p1">But don’t panic: so long as your emails are <em>about</em> them, and <em>for</em> them, and they educate and entertain and aren’t straight up sales pitches, you’ll see unsubscribes level out after 5 to 10 days.</p>
<p class="p1">You’ll likely also see more engagement, higher open rates, click rates, and more replies.</p>
<p class="p1">Run these dailies for a couple of weeks, and if you do indeed see more business coming in, then the choice is to make daily emails default for your entire list.</p>
<p class="p1">Option # 2</p>
<p class="p1">Send an email to your entire list, and say:</p>
<p class="p1">###</p>
<p class="p1">Hey, I’m going to start an experiment, sending a daily email.</p>
<p class="p1">Reason being: I have it on good authority that it’s great for business, but also that it’s a really powerful way to serve my audience.</p>
<p class="p1">And serving you is what I’m here for.</p>
<p class="p1">So I want to try, and see if it’s the right thing to do for the both of us.</p>
<p class="p1">For now, it’s a 30-day experiment, and if you want to receive these short daily articles, <span class="s1"><span style="text-decoration: underline;">click to sign up here</span>.</span></p>
<p class="p1">###</p>
<p class="p1">So before sending, you add a new segment to your list, and you only send your 30-month dailies to those who opt in to them.</p>
<p class="p1">That simple, and no risk that your list will fall apart.</p>
<p class="p1">Either way:</p>
<p class="p1">If you’re not sending an email a day, you’re underserving your audience, and you’re leaving money on the table.</p>
<p class="p1">But now you have a solution for both those problems.</p>
<p class="p1">Give it a try, let me know what happens…</p>
<p class="p1">Cheers,</p>
<p class="p1">Martin</p>

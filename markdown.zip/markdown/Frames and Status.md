---
title: Frames and Status
status: publish
datePublished: '1573637072'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-22257" src="http://martinstellar.com/wp-content/uploads/2019/11/MartinStellar_Coaching_Illustrations-Frames-and-positioning-1024x768.png" alt="" width="352" height="264" />For some reason, I enjoy watching blacksmiths on Youtube.

No, not because of their manly physique and bulging muscles - I just happen to like relaxing while watching a master craftsman at work.

At the end, he says: “Thanks for watching”.

Wait, what? No dude… thanks for making!

Now, I get his gratitude. I too am grateful for my readers (hey you! :)

But in terms of framing, he’s not helping his business.

You might thinks it’s trivial and in this context it is: whether he says thank you or something else will make little difference to his bottom line.

But consider:

In every human interaction - whether in person or across the digital divide - people have different status. In a social sense, economically, experience, age, education, network… everyone relates to others in terms o

We always relate to others who are either ahead of us, or behind. This isn’t qualitative - it says nothing about a person’s worth, just in the way a university professor might be ahead of a welder (or indeed, a blacksmith), but is not a better or higher quality because of his education or status.

It’s just status, and we all have one, and always in relation to others.

What mr Blacksmith got wrong is minor, but it’s a fact that by saying thanks instead of something else, he’s taking the lower status, or smaller frame, position.

Here’s a dude who just posted a well-made, carefully edited, highly entertaining and educational video for free… that means his status is that of generous, consummate, expert... and mine is that of a humble student and grateful viewer. It’s I who should be grateful.

By positioning, or framing, himself as needy of views, he takes the smaller frame.

And we do that all the time, and it’s terrible for business.

For example: I once landed a copywriting client - a very successful C-suite female executive, in a fiercely male niche.

When you’re talking to a buyer, you’re a doctor, inventor, problem-solver, expert, strategist, or whatever it is you do. That’s a huge frame.

You’ve got something and you know it’s super valuable.

And it’s for the buyer to discover whether or not they see it as just as valuable.

In other words, you get to be confident in having expert status, and the buyer gets to assess you.

Meanwhile, as the seller, you get to assess the buyer, to see if they’re right for you, and if you’re right for them. Expert status, again.

Problem is, we often inadvertently let a buyer take the lead, and drive the conversation.

That means they take your status, when in reality as a seller it’s your job to guide the conversation. After all, you’re the expert, right?

So I’m inviting you observe your interactions, and those of others.

See what messages people send - what body language, remarks, replies… which frames and statuses do you see in your world?

And, in what way do you yield your own status, in moments when actually you shouldn’t?

Cheers,

Martin

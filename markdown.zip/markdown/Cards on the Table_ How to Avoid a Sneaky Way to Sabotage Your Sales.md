---
title: 'Cards on the Table: How to Avoid a Sneaky Way to Sabotage Your Sales'
status: draft
datePublished: '1499166343'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/e2a54aad-364c-4f1a-aed7-4e5aac0c8dc0.jpg" width="350" height="264" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/e2a54aad-364c-4f1a-aed7-4e5aac0c8dc0.jpg" data-file-id="4834769" />
Ever feel that selling is icky, or that you don’t want to rush or force people?

That might be a sign that you’re one of the good eggs.

But, it can also mean that you yourself are to blame for sabotaging your sales.

Because when you are in business, you need to look open for business.

Which in terms of relationships and conversations means that you shouldn’t try to hide the fact that you’re looking for clients.

When you do try to hide that fact, and you steer away from talking about a purchase, or you pretend to not care, you trigger distrust.

Think about it: When someone talks to you about buying your course or your therapy or your art, they KNOW that you’re hoping they’ll
buy.

It’s the context of the relationship at that moment: they, the potential client with money in their pocket, and you the business owner, hoping to earn some of that money.

But if you then make it seem as if you’re not a business owner, you muddle the relationship and the interaction.

You confuse the buyer because the *expect* you to be interested in them doing business with you. And then you signal that you’re not - what gives?

In the mind of the buyer, this causes confusion, and confusion leads to distrust and without trust there’s no sale.

I’m not saying you should walk around with a big ‘for sale’ tattoo on your forehead, but you should definitely not try to hide the fact that you’re IN business and OPEN for business.

When you clearly define the relationship, your potential buyer will know what’s what and who’s who. Your cards, on the table.

And when that’s your attitude it becomes so much easier to actually ask for the sale, because your prospect is expecting that question anyway.

Yesterday an artist told me that very often at a show, someone will say the art is fantastic, they’re a big fan.

And then they walk away. Without buying.

That’s happened to me, and it’s probably happened to you as well.

So instead of letting people walk away, why not ask: “Hey if you like it, do you want me to ring it up for you?”

Nothing wrong with that. Nothing pushy. Just a friendly question, and you’re open to the yes as well as the no.

Asking for a sale isn’t brazen or forward: it’s what is expected from you as a business owner.

Just ask.

Like so, for example: Want to work with me and get powerful 1 on 1 coaching?

Then here’s a few questions to get you started: <a href="https://martin283.typeform.com/to/v7Dsh8" target="_blank" rel="noopener" data-cke-saved-href="https://martin283.typeform.com/to/v7Dsh8">https://martin283.typeform.com/to/v7Dsh8</a>

Cheers,

Martin

---
title: 'Agendas and Framing: How to Start a Sales Conversation'
status: pending
datePublished: '1653039613'
categories:
  - Sales conversations everyone enjoys

---

<img class="size-medium wp-image-28289 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/11/MartinStellar_Coaching_Illustrations-Agendas-and-framing_how-to-start-a-sales-conversation-300x225.jpeg" alt="" width="300" height="225" />

When you’re starting a sales conversation with a buyer, one of the most important and powerful things to do - right at the start - is set an agenda you both agree on.

If you don’t, it’s going to be really hard to get to a good, satisfying conclusion to the talk.

After all: if you don’t have a well-defined end-point, how are you going to make sure you reach one?

Well, you define it at the start, is how.

There’s two basic ways to do it, depending on the context and background of the meeting.

The first is when it’s clearly understood that this is a sales conversation, and we’re here to figure out whether or not it’s the right choice for the other person to buy.

In which case, that then is something you can say straight out:

“So before we get started, just to set the stage: We’re here to talk about your challenges, and whether or not our solution is the right choice for you. Does that sound right?”

If the buyer agrees, then you have a shared, agreed-upon agenda, and you both know what you’re working towards.

If they don't agree, it'll be because it didn't sound "right", and they'll likely proceed to tell what *is* their goal.

Meaning: you gain intel on where they are at in their buying process, and you'll be able to avoid making an offer, or pitching your work, to someone who isn't ready for that.

The other situation is when someone books an intro call, strategy session, exploration or discovery call, or anything similar.

That’s not a sales meeting: that’s discovery.

In which case, a really good opener is:

“Before we get started, can you tell me what would be an ideal outcome for you, in this conversation?”

When you do that, you take the pressure off - you remove the buyer's inherent concern that you might try and sell them on something.

And, you give the buyer autonomy: you’re letting them decide what they want to focus on.

And because they’re there knowing that you’re a provider and you’re open for business, in most cases they’ll state something very closely related to figuring out whether or not they want to buy.

Of course there are many different openers, and you need to find your own 'languaging', but never forget:

If you're here to serve your buyer, then that service starts when your conversation starts.

<hr />

On another note:
I'm building an app that coaches you on working your pipeline, moving your deals forward - and closing them faster and at better rates.
It's called SalesFlow Coach, and we're scheduled for beta-release early May 2022.
Register <a href="https://martinstellar.com/salesflow-coach-launch/">here</a> to be notified when it goes live.

&nbsp;

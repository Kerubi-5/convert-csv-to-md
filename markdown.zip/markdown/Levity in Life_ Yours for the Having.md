---
title: Levity in Life? Yours for the Having
status: draft
datePublished: '1544782837'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21157" src="http://martinstellar.com/wp-content/uploads/2018/12/MartinStellar_Coaching_Illustrations-Levity-in-life-1024x768.png" alt="" width="356" height="267" />Last week I gave a coaching session to a Canadian artist - something I do on occasion, when I meet someone who comes in with the right attitude and mindset.

A few days later, she writes an email saying this:

“Thank you again for an amazing 2 hours last Friday. I feel like a new person. It's Sunday, and I feel like I am still maintaining the same energy from when our call ended. A weight has been lifted.
~ Zoey Zoric”

And that - a weight has been lifted - that’s exactly the outcome I like to help people reach.

Because yes, life is meant to be lived with effortless mastery.

But you can only get there if you’re willing to look in the mirror, and have the guts to drop those ‘safe and comfortable’ (they actually aren’t - they’re nothing more than self-made prisons) beliefs and viewpoints that make life heavy.

And when you’re willing to do that?

Then your life changes.

You experience creative resourcefulness, you get the outcomes you want, and you become far more effective and efficient.

So, can you identify with Zoey, in that: you want to drop what weighs you down, and you’re willing to work with the notion that the only change that will make it happen is the change that happens in you, your mind, and your way of thinking&amp;feeling?

If that’s you, I’m curious what ‘weight’ in life you’d like to drop, and what your goals or ambitions are.

Drop me a line, let me know…

Cheers,

Martin

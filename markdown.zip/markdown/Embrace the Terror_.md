---
title: Embrace the Terror?
status: publish
datePublished: '1531250677'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/1aba07eb-c097-4969-b471-3ba5a1f3ff00.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/1aba07eb-c097-4969-b471-3ba5a1f3ff00.png" data-file-id="4835901" />Normal people hear ‘life is about learning to be comfortable with that what’s uncomfortable’ and realise that things can be easier, if you decide to see them as easier.

The explorer/adventurer kind, the people who start a business despite whatever the hell friends and family may advise (Get a real job! It’s too hard! Where’s the security!) realise that embracing the challenge is what differentiates the wantrapreneurs from the entrepreneurs.

In itself, quite an upgrade.

But there’s another level, and I invite you to step up to the challenge.

To upgrade your attitude to that level.

It’s because of a quote I heard yesterday, listening to one of James Schramko’s podcasts.

In which he said:

“… celebrate the terror of building something epic”.

Because yes: going all out on building something that truly matters is scary as can be.

And that doesn’t mean you have to be working on SpaceX size things.

Your legacy can be more subtle, your impact more modest.

Epic isn’t about being the biggest or best of most world-famous.

Building something epic is about a committed, relentless pursuit of performing at the highest possible level you can.

Being the best version of yourself that you can possibly be. And getting there one step at a time.

The attitude that says: ‘I’ve done a lot, come a long way, grown a lot.

“And, I KNOW there’s more in me.

“More potential.

“More growth.

“More than I probably think is possible to achieve, and I’ll get there come hell or high water.

“I’m petrified, and...

“LET ME AT IT!!!”.

That’s embracing the terror of building something epic.

Because there’s nothing more epic than someone who dies having squeezed every last drop of potential out of the life and self they were given.

Is that you?

Do you dare to embrace the terror…?

&nbsp;

---
title: Nobody is Crushing It?
status: draft
datePublished: '1543926783'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-21129" src="http://martinstellar.com/wp-content/uploads/2018/12/MartinStellar_Coaching_Illustrations-chrushing-it-1024x768.png" alt="" width="355" height="266" />That is correct. No matter what picture of success and wealth and awesomeness someone paints for us, it’s never the whole picture.

Nobody is crushing it.

You might think it’s all roses and money in that person’s life, but I guarantee there’s also consequences that ain’t all that fun.

But we only get shown the fun parts.

The bit below is from a reply I gave to one of my clients, who saw others - apparently - make lots of dosh with almost no effort.

And I don’t believe that story.

My (edited) reply to my client, who asked if those people are misrepresenting things:

###

Yep, because that's how crooks and wannabe's swindle people into buying stuff.

I'm not saying that everyone who shows success is a crook, but we are NEVER shown the full story, or the history behind it.

Literally everyone had to work for their success, most of the time at great expense (money, health, happiness, wellbeing).

It took them decades to become an overnight success. Always.

And the more successful someone is, the bigger the doubts become (am I worth it? am I an impostor and will get found out? Will it last? Can I make payroll? Will the investors come through? Is my business solid enough to survive my competitors?)

So no, literally nobody is crushing it the way it’s being shown.

And the more people show it that way, the more we need to protect ourselves from being gullible.

Never believe the showreel unless you've been present at the behind-the-scenes.

###

Success is earned, not given.

And no matter what someone wants us to believe about their earnings or their success or whatever looks sexy and accomplished: they either paid the price to earn it, or - and run for the hills if you even remotely sense it - they’re simply conning people.

Like I said the other day:

Comparing yourself to others is pointless and disappointing.

Instead, compare yourself, to the person you were yesterday.

That’s how you earn your own success.

Cheers,

Martin

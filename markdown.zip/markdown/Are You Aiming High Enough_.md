---
title: Are You Aiming High Enough?
status: publish
datePublished: '1655364984'
categories:
  - How to sell your work
  - Psychology in sales and marketing

---

<img class="size-medium wp-image-27996 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/09/MartinStellar_Coaching_Illustrations-Are-you-aiming-high-enough_-300x225.jpeg" alt="" width="300" height="225" />

Pointy question for you today:

Are you aiming high enough?

Meaning: in terms of the people that you’re aiming to enroll in your work - are you sure you’re not playing too small a game?

Here's what what I'm talking about:

A while ago I went through my database - the list of people that I have spoken to or that I've made a proposal to or who have inquired about my work over the past number of years.

And I realised that for the longest time, really I was aiming way too low.

Far too often, I was looking to work with people who - I realise now - were not qualified to work with me, for all kinds of reasons.

In some cases, it's because they work in an industry where you just don't make the kind of money that enables you to hire a coach.

In other cases, it was people who had a completely dysfunctional, fundamentally broken mindset when it comes to money.

Sometimes, it was people who are more of a wantrepreneur than an actual entrepreneur - people who were playing at being in business, but they were not really a business person.

Or, they did have the entrepreneurial gene, but they were really starting out, when my sweet spot is entrepreneurs who have a functioning, established business.

And so as I went through all these names, reviewing my notes and the conversations that we've had, I realised:

The majority of all the people that I used to engage with, were just completely not the right kind of people for working with me.

Not that there’s anything wrong with them - in nearly all cases they were wonderful people doing a great thing with their work, but for all kinds of reasons they were just not the right match.

I was aiming much too low.

Instead of looking for savvy, investment-minded entrepreneurs, I engaged with people who were trying their hardest - but who needed someone to pull them up, instead of someone to bring out the best in them.

It was the difference between teaching someone to walk, or helping a walker become an excellent runner.

The result was: a lot of conversations that didn't go anywhere, and a lot of time lost.

But once I started aiming higher, I enrolled far more people, at far better prices, than before.

Changing my aim at more advanced entrepreneurs upgraded my status, the value and quality of my clients, and dramatically improved everything in my business.

So what I'd like to leave you with today, is the question:

Are you, actually, aiming high enough?

Are you playing a big enough game?

If you're not getting the clients and sales you think you should be getting...

Is it because you're not talking to the right people?

&nbsp;

<hr />

On another note:
I'm building an app that coaches you on working your pipeline, moving your deals forward - and closing them faster and at better rates.
It's called SalesFlow Coach, and we're scheduled for beta-release in June 2022.
Register <a href="https://martinstellar.com/salesflow-coach-launch/">here</a> to be notified when it goes live.

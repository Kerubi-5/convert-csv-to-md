---
title: And Then This Happened...
status: draft
datePublished: '1505830347'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img class="alignleft wp-image-19948 size-medium" src="http://martinstellar.com/wp-content/uploads/2017/09/Show-opening-The-Cabal-Creative-300x277.jpg" alt="" width="300" height="277" />Yes I know, a week of silence from me. Almost like I’ve been on vacation, except I write every day even when I’m away.

But this week has been… special. And not a little.

Four women, almost the entire Cabal (Salley couldn’t make it) has been staying in my town.

We walked, hugged, talked, laughed, laughed some more and then some, and oh yeah:

We opened our show!

Which for readers who aren’t artists might not be that big a deal, but hold on a minute:

Whether you’re an artist, a yoga teacher, an engineer or a florist:

You’ll find that once you team up with people and do work together, something special happens.

Because when there are two or more people together, the combined power and intelligence and potential becomes greater than the sum of the parts.

This is why people create mastermind groups and it’s why I created the Cabal.

And it’s why the tagline for our little group is “Collective Forward Momentum”.

And, as it happens we don’t just talk about it: we actually show it.

Just consider:

How on earth do you pull off an international art exhibition, from idea to launch to inauguration… in just 6 weeks? That kinda stuff doesn’t happen!

Except it did. And all because we combined forces. And without that, I would never have sold three drawings (woot!)

So while this email is the first after my lapse (I won’t do it again, promise), there’s a real important message in it:

Get help. Get a group, a mastermind - anything that gets you amongst peers who share a view and mission and no-BS attitude.

That is called a dream team, and yes: it enables you to do things bigger, and faster, and better, than you could on your own.

Me I don’t take the credit for all this: it’s the group who did it. The group that is now almost an entity of its own.

And in the coming months, you’ll see that group open up, and, if you want, we might invite you in - whether you’re an artist or not.

So… want more and better? Then the single best thing you could do today is google what a mastermind is about, and start looking for people to start one with.

Or, just hang in there for a while for when we open the doors.

Cheers,

Martin

---
title: I Have No Idea What I'm Doing - Full Steam Ahead ⛴ (build in public)
status: publish
datePublished: '1611053049'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<p class="p1" style="text-align: left;"><img class="size-medium wp-image-26484 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/01/MartinStellar_Coaching_Illustrations-Build-in-public-300x225.png" alt="" width="300" height="225" />If you look at people around you, it’s easy to think others have it figured out.</p>
<p class="p1">The earnings, the fame, the success.</p>
<p class="p1">But everyone, in the end, is just an infant in an adult-shaped suit.</p>
<p class="p1">Trying to make it work, best as can.</p>
<p class="p1">Even the successful ones, all you get to see is the showreel.</p>
<p class="p1">And I promise that their behind-the-scenes is messy as hell.</p>
<p class="p1">In my case, I generated many thousands of dollars in sales for clients in just a few days, just by sending a few emails.</p>
<p class="p1">I’ve shown people how to triple their consulting fees.</p>
<p class="p1">I’ve helped a co-working space reach $25.000 in monthly revenue in less than a year.</p>
<p class="p1">I ran a little introduction campaign for a software engineer, which ended up with his application becoming the goto platform in a huge niche.</p>
<p class="p1">But for myself?</p>
<p class="p1">Well, if I look at this cutting-room floor, there’s a ton of deleted scenes.</p>
<p class="p1">Especially last year, when I should have been one of the people who pivoted and grew his business because of, not despite, the upheaval in the business world - but nope. Pretty tough year.</p>
<p class="p1">What can I say? It’s the cobbler’s kids who don’t have any shoes to wear.</p>
<p class="p1">So I’m going to try something different - what the young ‘uns on Twitter call ’build in public’.</p>
<p class="p1">Which means I’m starting a project, to ultimately build a web-app.</p>
<p class="p1">And, I’m going to be sharing my progress publicly.</p>
<p class="p1">I have no idea what the roadmap is, or what stages I’ll need to go through, or indeed what challenges I’ll be facing.</p>
<p class="p1">But damn the torpedoes: full steam ahead.</p>
<p class="p1">All I know is that I have a methodology that is extremely profitable for my clients, and I want to make it something hands-off, automated, and ultra affordable.</p>
<p class="p1">In these emails I’ll be sharing some of the progress, but if you want to see the full story unfold including all the gory details, <a href="https://twitter.com/martinstellar">follow me on Twitter</a>.</p>
<p class="p1">And with that said:</p>
<p class="p1">Anchor up!</p>
<p class="p1">Cheers,</p>
<p class="p1">Martin</p>

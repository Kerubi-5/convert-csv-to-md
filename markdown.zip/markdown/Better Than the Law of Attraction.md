---
title: Better Than the Law of Attraction
status: draft
categories:
  - Doing it right as an entrepreneur or creative professional

---



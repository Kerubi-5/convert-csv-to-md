---
title: Calibrate Reality, Anyone? Dig THiS
status: draft
datePublished: '1536056354'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-20777" src="http://martinstellar.com/wp-content/uploads/2018/09/MartinStellar_Coaching_Illustrations-Calibrate-Reality-Dojo_feedback-1024x1024.png" alt="" width="349" height="349" />So this Calibrate Reality Dojo training I’ve been rapping on about…

Which, I hope, you want to ask me “But when will it be READY, Martin?”

Yeah sorry for the delay. I’ve been working like made to make it really, really, really good.

To give you something that will actually show you how to change, and calibrate your reality.

So I’ve been going through the slides, over and over again, to get everything right.

At the moment, it’s in the very capable hands of my designer, and yes: once I get it back, I’ll go over the content again.

But here’s the kicker: a few weeks ago, when I had *just* completed the first outline, the most roughest draft, I ran the training by my friend Paula Mould.

And apparently, it stuck with her. Just won’t leave her alone.

This is what she sent me yesterday, to use as a testimonial:

<em>“Mind bending. Reality changing. This is the effect of the Calibrate Reality Dojo on anyone who's ready to untell their stories and ready to really upgrade their lives.</em>

It's been a month since I experienced the webinar presented by Martin Stellar and I am still feeling the effects every day.

We all build walls around ourselves, defining how things are and how they have to be.

Martin's webinar shows you how to see the walls and how to tear them down effortlessly.

I highly recommend the Calibrate Reality Dojo if you're ready to see clearly and take massive action.”

Woah, right?

And that’s just from the rough, unpolished version, which I delivered in a clunky and stumbling way.

And yet, this is the impact it had. Caveat: it must be said that as a client, Paula already had long-term experience with the methodology in Calibrate Reality, but never in a such a structured and action-oriented way.

In other words: maybe I am indeed building something good. I've never seen her resonate with my work this much.

Right, so I’m thinking the webinar will launch in about two weeks.

And if you raise your hand, I’ll put your name on the guestlist.

That will get you some interesting perks, which I’m still working out. But for one click of the mouse, you’ll find it worth it, I promise.

CRD Guest list, yes/no?

Clickity…

Cheers,

Martin

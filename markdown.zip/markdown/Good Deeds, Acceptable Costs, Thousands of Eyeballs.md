---
title: Good Deeds, Acceptable Costs, Thousands of Eyeballs
status: publish
datePublished: '1568111079'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing
  - Relationships

---

<img class="alignleft  wp-image-22048" src="http://martinstellar.com/wp-content/uploads/2019/09/MartinStellar_Coaching_Illustrations-extra-miles-surprise-and-delight-1024x768.jpg" alt="" width="349" height="262" />It’s always fun having visitors from abroad - never a dull moment.

“Martin I injured my knee, can you make an appointment with your fysiotherapist?”

I make the call, and: first option is ten days from now. Clearly not ideal, when someone is in pain, but that’s life.

“That’s a pity - could you recommend someone else, where we might be able to get an earlier appointment?”

She thinks for a moment, and I can almost hear the names going through her head coming out of my headset, and then she says: “Sorry, I couldn’t tell you”.

Which is fair enough, but it’s not how you create great relationships with your customers.

If she were to recommend a few people, I’d really appreciate that - and why wouldn’t she? It’s not like the clinic is empty, so… why not?

So far for good ideas on treating customers.

But if you want your people to have a stellar treatment?

Then you take their number, you call your friends and peers in the industry (whether you’re a fysio, coach or designer), and you set an appointment for the client.

Not only will the client love it, you’ll also have created a stronger bond with your peer, who will be more likely to refer work to you if ever they need to.

Does it require guts to do this?

Does it make people love you and talk about you?

Does it require a bit of faith in humanity?

Does it require that you choose wisely who to refer to? (givers and matchers only - there’s no point in giving to takers)

Yes to all the above.

Does it pay dividends over time?

You bet.

Doing things that make people talk about you is enormously profitable, even if there’s a cost or a client buys elsewhere.

Consider this story, where a bride called FedEx, because her wedding was the next day, but her wedding dress had not yet arrived.

Turned out, a routing error had landed the dress in a different city.

The FedEx operator arranged for a private plane to fly the dress in on time (literally going the extra mile), and guess what:

Not a single person at the wedding did not hear the story - easily 100 to 200 people, many of whom would relate the story to others afterwards.

And because it’s such an awesome story, it has real selling power in terms of having at least some of those people choose choose FedEx instead of a competitor, next time they want to send something.

Multiply by the lifetime value of a typical customer, and the cost of a private plane suddenly becomes very acceptable indeed. And you even get guys on the internet talking about it in articles.

One good deed. One cost. And thousands upon thousands of people who hear about it in articles, word of mouth, podcasts, mentions in books, and training materials.

Next time you have a chance to do something wildly loveable for a client, even if you’re concerned about the cost or loss of it, you might be well off doing it.

Cheers,


Martin

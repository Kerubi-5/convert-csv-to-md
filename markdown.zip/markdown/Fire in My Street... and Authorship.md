---
title: Fire in My Street... and Authorship
status: draft
datePublished: '1515073106'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/ddeaa490-f372-458d-ae69-228b75438a75.jpg" width="350" height="350" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/ddeaa490-f372-458d-ae69-228b75438a75.jpg" data-file-id="4835345" />A few weeks ago, some dimwit decided to set fire to a car in front of my house in the early morning hours.

Since I’m an early riser I was the first to see the flames, which meant that afterwards I was asked to go to the police station and give an eye-witness report.

Turns out, the Spanish word for perpetrator is ‘autor de los hechos’ - and with me being a word-fanatic, I found it fascinating:

Autor de los hechos - author of the acts (or deeds or doings).

Instant reframe on what life is: you are the author of the deeds in your life, you’re the one writing your own book of acts.

It wasn’t a brand new concept to me (which you’ll know if you’ve been reading me for a while) but it really drive home the point.

When we’re unaware of this, we tend to take life as a way to react to things that come at us. An opportunity, a problem, a conflict, a change that presents itself… and then we react.

But if you consider yourself - not just philosophically, but in every thing you do and decide - to be the author of your life, you go from being a reactor, to being a creator.

And suddenly, you’re in control, you call the shots… it’s YOU writing your book of acts.

When you’re a reactor, you have little power, because life will always throw curve balls at you. (Duck!)

But as a creator, you see them coming, because it’s almost as if you threw them yourself.

Which is why one of my favourite coaching questions (for myself as well as for clients) is:

What would you like to create?

And I’m asking you now: In this life, this business of yours, this day and this hour:

What would you like to create?

Cheers,

Martin

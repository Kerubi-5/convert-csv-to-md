---
title: "Does your content work as hard as it could? (And folk like Chris Brogan, Jay Baer or\r\n\t\t\tMichael Stelzner - do their opinions matter to you?)"
status: draft
datePublished: '1526916564'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/a089a227-f1de-4f92-a676-1dcb8813bb80.png" width="350" height="262" align="left" data-file-id="4835733" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/a089a227-f1de-4f92-a676-1dcb8813bb80.png" />How much content do you tend to create? And, how much result does it get you?

I’m asking because it’s staggering to see how under-utilised most of our efforts tend to be.

For example: I have over 1000 articles on my blog, which are all very nice and good - but because of the volume, lots of the older ones don’t get read.

That isn’t a big deal in my business, because I don’t write for the web: instead, I write these articles for you, my subscriber.

Still, all those articles aren’t doing any work for me, but they could…

For instance, I could easily compile the articles by topic, and turn them into ebooks that I could sell or give away. Simple (though laborious, which is why I’ve not done it yet) way to leverage the content I created.

See, doing work for your business, creating content and assets, is one thing.

But most of the time, we stop there. Promote it a little, and then move on to the next creation.

Problem is though, making new stuff all the time does you little good if you don’t also make that stuff work for you.

More making will never solve the problem of insufficient promotion, or under-utilised potential.

And very often, making use of inherent potential can be really easy, once you stop to think about it.

For example, a webinar can be turned into an ebook or PDF - or vice versa.

Or a set of awesome articles can be bundled in a PDF, and offered to your readers as a content upgrade (google it, it’s a pretty good strategy).

Other options?

Plenty of them. You can use one keynote presentation at different venues - nobody would create a new one each time.

Turn your ebook into a course. Or create a workbook to go with it. Or create a summarised version of your course and turn it into an auto-play webinar, to introduce newcomers to your work and invite them to join your list.

Or expand a 5-point checklist into a mini-course, or turn a customer testimonial into a case-study.

All kinds of options, different ways to leverage the content you create for more and better results.

In other words when you repurpose your content, it gives you more return on your investment.

And one of the best systems I’ve found for that, recently?

Content Boomerang.

It’s a course that shows you how to re-purpose your existing content, in order to drive traffic to your site - made by the extremely knowledgeable Ana Hoffman of Traffic Generation Cafe.

I bought it myself a while back when she did a beta-launch, and I can tell you: it’s good. Really extremely good - with checklists, screenshots, thorough explanations…

But it’s not just me saying so: Jay Baer, Michael Stelzner, Chris Brogan: they all give it a thumbs up - and well-deserved too.

Enrollment opened today, and is open only until Wednesday.

So if you want to finally get enduring returns from the content you create, AND you want a carefully planned, step-by-step system to show you how, this link is where you get access:
<div>

 <a href="https://ContentBoomerang.Training/affiliate/idevaffiliate.php?id=104" data-cke-saved-href="https://ContentBoomerang.Training/affiliate/idevaffiliate.php?id=104">https://ContentBoomerang.Training/affiliate/idevaffiliate.php?id=104</a> (Obligatory disclaimer: Yep, affilliate link (in case you missed it :) )

</div>
Now, it ain’t cheap, but it’s worth it. Definitely.

But here’s the kicker: even if you don’t buy the course, you can still make use of Ana’s ideas - you’ll just have to do the homework she’s done.

Point is: if you create content once and then create more, you create more work than you need to - UNLESS you also have a simple way to repurpose. And you can do that with or without Ana’s course.

Just start with this question: With the content and material I already have, what is the easiest, simplest way to repurpose it for increased visibility?

With a google search for ‘repurpose content’, what ideas jump out at you?

Yeah. Welcome to the rabbit-hole… (and if it seems like a great idea but it feels like an overhwelming endeavour? Then Ana's Content Boomerang system takes you through the entire process, step by step).

Either way: don't let your hard work under-serve it's purpose - give it a re-purpose.

Cheers,

Martin

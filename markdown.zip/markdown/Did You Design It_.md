---
title: Did You Design It?
status: publish
datePublished: '1575450924'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21969" src="http://martinstellar.com/wp-content/uploads/2019/08/MartinStellar_Coaching_Illustrations-Design-is-everything-1024x1024.jpg" alt="" width="350" height="350" />I’m a complete sucker for good design.

Whether it’s a car, coat, pen, keyboard or the kerning (letter-spacing) in a book: when something’s been designed well, it’s a joy to see or use.

The flipside of loving design, is that it’s almost painful when something’s designed badly.

That kitchen gadget that slips out of your hands when they’re wet, a black website with white text, or the way Mailchimp has designed its user interface:

Bad design is unpleasant and frustrating, and can easily lead to lost time.

So then why do we so often omit to design our work?

Procedures, routines, or even simply the way we plan our day: don’t things get better when they’re designed well, with intention, and with usability in mind?

Of course they do.

So if you ever find that your days are too short, or your work doesn’t progress the way you want it to, or you have trouble staying on task, maybe ask yourself:

Are you spending enough time each day, to organise, plan, and *design* your day?

If you're not satisfied with the results of any given day... did you design the day beforehand?

If your efforts aren't getting you the results you want... did you design a strategy for reaching goals, and one for implementation?

Cheers,

Martin

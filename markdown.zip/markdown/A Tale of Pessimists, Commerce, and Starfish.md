---
title: A Tale of Pessimists, Commerce, and Starfish
status: publish
datePublished: '1573145192'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft  wp-image-22239" src="http://martinstellar.com/wp-content/uploads/2019/11/MartinStellar_Coaching_Illustrations-social-enterprise-complaints-and-doing-the-right-thing-1024x768.png" alt="" width="349" height="262" />Met an old acquaintance a while ago, at an outdoor concert here in town.

Asked me what work I do these day, so I tell him - and I tell him that I like working with people who are trying to do something useful.

Says he: “What difference does it make!? The world is a mess, the oceans are dead, corporations and governments exploit everything they can… do you really think a regular company can do anything to make a difference?”

Yeah, that was about the end of the conversation - because following on from yesterday’s email, here’s one thing that really gets my goat - something I just won’t put up with: Bitching about how bad things are.

Because no matter how bad things are, nothing ever gets better from bitching about it, and I refuse to deal with people who self-righteously complain, but do nothing to make a chance.

Besides: Even if his arguments hold true, does that mean we should try nothing and let out-of-control capitalism ruin life?

Oh, it makes no difference if we try?

Well, if 1000 starfish wash up on the shore, what difference does it make if you throw one back into the sea?

Answer: it made a difference to the one you threw back. That’s the difference.

And if someone thinks that that isn’t worth the trouble, they either have such a big ego that they think they’re above helping out with small problems, or they might be depressed and in need of therapy. Dunno, ask a psychologist.

The point in all this:

Commerce drives a lot in society. Whether it does good or harm depends on how we use the tool, a tool which is in itself agnostic of morals, right&amp;wrong, or what capitalism should or shouldn’t be.

Business is a tool. You either use it for gain, or for good (and as a bonus, that will get you gains).

Where do you stand?

Cheers,


Martin

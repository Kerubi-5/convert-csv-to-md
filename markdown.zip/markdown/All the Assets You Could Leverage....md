---
title: All the Assets You Could Leverage...
status: publish
datePublished: '1661502853'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img class="size-medium wp-image-22025 alignleft" src="https://martinstellar.com/wp-content/uploads/2019/09/MartinStellar_Coaching_Illustrations-Asset-Leverage-300x225.jpg" alt="" width="300" height="225" />

"You really like your business, don't you? You're always smiling, and singing, and cracking jokes with the customers..."

He turns on the coffee grinder, lays is early-morning eyes on me, and says:

"Yeah I do, but: it's hard work. Many long hours, always on my feet. To be honest, I'm glad there's only 6 years left till I retire".

I like this guy. Each days he gets me my coffee while I work on my laptop, way early in the day, after my morning walk and before the sun comes up.

And I love how much he cares about his people and the quality they receive.

"Well", I say, "with what you've built up here, you know you could sell the business. You could semi-retire and go do something else".

"True", he replies. "But I want my kids to own the business some day".

So I tell him:

"Here's what you do. Provided your kids want to own the place, sell it to them now, and have them pay you the price on a monthly basis, spread out of over ten years. They already know how to run the business, and they can each work 3 days per week, with the same employees that you have now, and keep any profit above the purchase price they pay you in monthly installments."

He looks at me and says: "I really like that idea!"

I smile, and say: "Well, have a chat with your kids, see what they think".

"I will. Coffee?"

"Yes please".

It's such a simple idea, and if things play out well for him, he could technically stop working in a few months from now.

But his problem was that he saw his cafe as a place where he goes to work and earn a living until retirement - not as an asset that you can leverage, in this case by selling it.

And so it is with all of us.

We have assets that we could deploy, and leverage, and profit from... and we don't even know it.

Your methodologies can be codified into playbooks and trainings for licensing.

Your network can be put to use in order to get introductions or visibility.

Your hobbies have taught you skills that you can deploy in your business.

Your digital assets like articles and videos can be repurposed to be offline or print deliverables, and vice versa.

And it's in the soft assets, the ones that aren't physical or that can't be shown in a spreadsheet, that you have a lot of opportunity.

Relational assets, intellectual capital, values, (because they are an asset too), methodologies and models and frameworks: you have many assets in your business and your world.

And it pays dividends to look at the assets that you've built and grown all these years, and ask yourself:

Which one should I leverage and deploy, to get more yield and ROI out of my business?

Next: once you have one identified... send me an email and I'll try and help you find a way to leverage it, without having to invest a ton of time or money in doing so.

&nbsp;

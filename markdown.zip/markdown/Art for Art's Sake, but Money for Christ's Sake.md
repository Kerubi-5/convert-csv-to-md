---
title: Art for Art's Sake, but Money for Christ's Sake
status: draft
datePublished: '1494920196'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/68ec5a44-161d-4d2b-9664-b22c5d0a2693.jpg" width="292" height="320" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/68ec5a44-161d-4d2b-9664-b22c5d0a2693.jpg" data-file-id="4834605" />For the sake of argument, let’s call anything that you make a form of art.

(Which is in fact my view on things: life itself is art and whatever you make out of it too. But that’s just me).

Anyway, I read a quote, apparently by the actor Ollie Silver:

Art for art’s sake, but money for Christ’s sake.

I like it. Because yes, the pure and unadultered way of making art (or anything you passionately want to do really well, from listening to teaching to coding to baking pies) is a
brilliant starting point.

But you do need to feed the family and pay the bills.

Reminds me of a friend a while back, an artist who said that when creating art, money is not allowed to be anywhere in or near your mind.

I don’t know. Is that true?

Again, I’m being inclusive here, I’m not just talking about pure art.

Art, like anything else you do or make, has the potential to change people and/or their lives.

And you deserve to earn well for it. Pretty much a prerequisite for being able to continue doing it.

So what’s the difference between an artist and any other kind of (ethical) professional?

You all get to do something that moves people, that has an impact.

You get to make a difference.

Earn some money for it, for Christ’s sake.

And if you’re a believer and you feel this is me blaspheming, that’s not how I mean it (and I don't mean to offend)

Getting paid for doing good work means you value yourself. And I think Christ would agree with that.

And if you agree too, and you want to earn better, maybe I can help.

I gotta whole bunch of common sense, clever strategy, and sensible money-think I can share with you.

Let me know if you want to talk.

Cheers,

Martin

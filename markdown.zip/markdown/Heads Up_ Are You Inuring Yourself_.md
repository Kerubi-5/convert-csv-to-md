---
title: 'Heads Up: Are You Inuring Yourself?'
status: draft
datePublished: '1538556354'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-20956" src="http://martinstellar.com/wp-content/uploads/2018/10/MartinStellar_Coaching_Illustrations-Inured-to-horror_perception-bias-1024x768.png" alt="" width="357" height="268" />6.30 AM and the bar has just opened.

I sit down on the terrace and bring out my notebooks, while the owner brings me water and a super-short espresso.

I like this time of day, just at the start of my morning walk. Some quiet time for journaling.

Except when Juan is on one of his rants. Then it’s not quiet.

Juan is nice enough, but damn he’s a sourpuss.

“Crooks! Thieves! Liars! World going to hell!”

On and on he rants about the sorry state of the world.

And I don’t disagree, but I just don’t pay much attention to it all.

For every crook, there’s a (or probably: many) gold-hearted individual doing right by people. So I’d rather look at the good.

But not Juan.

He reads the papers, watches the news, and he’s constantly on Facebook, taking in yet another story about how awful everything is.

Completely blind to the fact that Facebook itself is a crook, what with the way it deliberately feeds you the things it knows hook your attention.

And so poor Juan constantly pollutes his own worldview, with an endless daily stream of confirmation of how bad things are.

In other words: Juan is inuring himself to the stress-inducing, happiness-killing experience of bad news.

Where ‘inure’ means: “To habituate to something undesirable, especially by prolonged subjection”.

Sounds horrible, right?

But it’s far more common than you think, and the advertising industry (of which FB and the news are slaves) exploits it masterfully, laughing all the way to the bank.

It’s no longer enough to have perception bias (that thing which, once you know it exists, you see everywhere) - we now also have to contend with scientifically optimised corporations that imprison us in an ongoing experience or being horrified.

I say break out of the prison.

Wake up, disconnect, think for yourself, and be aware that there’s a choice:

You either inure yourself to experiencing awfulness by allowing others to control your attention, or you bless yourself into well-being by deciding for yourself where you put your attention.

Simple choice.

Which one will you make?

Cheers,

Martin

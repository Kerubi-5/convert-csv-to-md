---
title: 'Client Filter: Battle Scars Required'
status: pending
datePublished: '1662025376'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img class="size-medium wp-image-28279 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/11/MartinStellar_Coaching_Illustrations-Client-filter_battlescars-required-300x225.jpeg" alt="" width="300" height="225" />

Some clients are just a dream to work with:

They show up on time, they do the work, they say “Ok, how?” instead of “Yes, but”, and coaching or consulting them is fun and effortless.

Others are a pain: they argue for their limitations, they sabotage their efforts, or they blame everybody but themselves.

Or, they constantly put up a fight, trying to convince you of why their wrong ideas are right.

Would be nice to know, before they hire you, which of the two kinds a new buyer is...

But how can you tell?

After all, very often, you don’t discover a client’s true nature and manner of operating, until you’ve started the process of working together.

So here’s a simple filter, a question to ask:

Do they have battlescars?

As in: Is this their first business?

Are they new to the game of being an entrepreneur - are they just starting out?

Because if they are, and they’re all excited and motivated and naïve to the realities of being in business, you might be in for a long and arduous struggle in trying to get them to success and results.

A salty dog however, a seasoned business owner with failures and challenges and struggles behind them, that’s usually a far more workable type of individual.

They bring humility, a student’s mindset - and they tend to work <em>with</em> you, instead of <em>against</em> you.

So if you want better clients and get more results for them, ask yourself:

This new buyer I’m talking to…

Is this their first rodeo?

Do they have battlescars?

&nbsp;

<hr />

On another note:
I'm building an app that coaches you on working your pipeline, moving your deals forward - and closing them faster and at better rates.
It's called SalesFlow Coach, and we're scheduled for beta-release in September 2022.
Register <a href="https://martinstellar.com/salesflow-coach-launch/">here</a> to be notified when it goes live.

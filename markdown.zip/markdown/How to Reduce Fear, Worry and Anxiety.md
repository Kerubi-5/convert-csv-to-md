---
title: How to Reduce Fear, Worry and Anxiety
status: draft
datePublished: '1486544880'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

Let’s see if I can kick up a stir today.

Here goes:

You don’t need the news.

Or, in the words of Paul Simon:

I can gather all the news I need on the weather report.

I can already hear people rearing up: But we need to know what’s going on in the world!

Do you though?

Sure it’s good to be up to date on current affairs, but believe me:

You won’t know what’s going on in the world if you read the news.

Becaues the news tells you what they think is going on, and what they think about it.

In other words: it’s biased, always.

The media don’t tell you what’s going on in the world - they tell you what they want you to think about what’s going on in the world.

In other words: propaganda.

Besides: even if you’d read all the newspapers, you’d only know a slice of all that’s going on.

The things that you need to know, you’ll find out about them anyway.

But more poignantly: if you keep up with the news, you can’t escape becoming worried and fearful and stressed.

Because while I’m not going into politics and stuff, I can tell you that the media deliberately try to scare us.

Some more than others, but there’s not one media outlet that states the facts without layering on some fear-mongering.

Like they say in journalism school: if it bleeds, it leads.

Good-news newspapers have been tried, and they’ve all failed.

Don’t let a company with interests in politics and shareholders keen on payout tell you how to feel and what to think of the world.

Unfollow the people who keep posting scare stories on social media.

Cancel your newspaper subscription.

Stop watching the news.

I mean come on, you get a reporter at an empty parking lot by a mall talking to the camera, saying: “So far, no shoppers have yet shown up in droves”.

And that’s news?

No, that’s manipulation.

The news manipulates, even if some reporters and journalists do try to be truthful.

Their bosses decide what eventually gets published.

It always gets framed in such a way that it serves whatever political or commercial interest the media outlet has. Always.

So if all the recent events and politics and disasters have begun to way on your mind and your emotions, this is the trick:

Get your news from the weather report, and be done with all the rest.

&nbsp;

---
title: How to Not Put Such Enormous Pressure On Yourself
status: draft
datePublished: '1508860395'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/94213116-1d35-4c08-9050-5d7073e181c7.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/94213116-1d35-4c08-9050-5d7073e181c7.jpg" data-file-id="4835129" />A client wrote in yesterday, asking about nervousness and perfectionism when performing live.

“I'd just like to be great in all of it. Not just good but unforgettable. Not putting big expectations on my self, just a great impact, you know? Am I being too hard on myself? I can't tell.”

Woah, yeah. Definitely too hard on ye olde selfe.

Just consider: if a teacher would talk like that to your child, would you put up with it?

Of course not! You’d give that teacher a firm talking to, and put them in their place.

That kind, that amount of pressure?

Totally out of order.

And yet, it’s how many of us talk to ourselves.

And I have my own troubles in that area… but where it comes to showing up live and delivering a good performance, I’ve found a few tricks.

In the context below, we'll deal specifically with showing up live to an audience, but if high expectations and pressure of self are a problem for you in other areas, then you'll find that the attitude described is a very effective cure for that too.

Behold how I avoid that high-demand problem for myself:

(and get pretty nice performance results, too boot)

I resolve beforehand to prepare as best as can.

I resolve to not fret, but to focus on preparing instead. This includes practice, dressing for the occasion, eating well, getting a good night’s sleep, and everything else that makes me thrive.

Important: conscious breathing. Nerves and performance anxiety are on thing, but physical tension and shallow breathing make everything worse, INCLUDING performance.

Finally, I resolve: to show up as the best possible me that I can be in that moment.

Then, just before it’s curtains up, I tell myself the secret word.

Under my breath: “It’s showtime!”

And with that, I let go of all demands, worries or nagging thoughts, and I plunge myself into the moment.

Because, after all, it’s showtime. I’m here to do a stellar job and fretting sure won’t help.

I give it my all. That’s the only thing I can control.

Whether it’s good or not, whether people are blown away or not, I can’t control that. All I can control is trying to be my best self.

This by itself gives me enormous satisfaction afterwards, because I know I did the best I could.

And, it frees me from self-doubt and recrimination, and that opens me up to taking in feedback, and learning how I can do better next time.

And as for that feeling of nervousness?

Here’s a fun and effective hack for that.

Because (courtesy of Paula Mould) there is no difference between excitement and nerves.

It *seems* like there’s a difference, but that’s only in perception.

To the brain, there’s no difference between nerves and excitement.

So when you’re overcome by nerves, tell yourself:

“Man this is exciting! I’m so excited about all of this!”

And with that, you go in and face the crowd.

Showtime!

Martin

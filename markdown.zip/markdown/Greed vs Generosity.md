---
title: Greed vs Generosity
status: publish
datePublished: '1547463025'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - How to sell your work
  - Psychology in sales and marketing
  - Relationships

---

<img class="alignleft wp-image-21260" src="http://martinstellar.com/wp-content/uploads/2019/01/MartinStellar_Coaching_Illustrations-Greed-vs-generosity-1024x1024.png" alt="" width="349" height="349" />A while ago I ran into a local acquaintance, who hosts retreats and events.

“Hey Martin, do you still coach people?”

Told them that yes, I sure do.

“Well, if ever you want to work together, our premises are available”.

Ooh nice, I thought: collaboration!

“As in, organising a retreat together, you mean?”

And then they hit me with probably the biggest turnoff ever:

“No, as in: you bring us the people, and we host a retreat for them”.

My jaw dropped at the staggering and blatant greedy selfishness of it.

They expect me to do their marketing for them, because what - I’m such a nice guy?

To make this even more painful, this person is rather well-connected to an up-market audience, has a huge following, and is actually world-famous in a niche that isn’t very small.

In other words: they have everything in place to draw in a crowd.

And yet, they have this idea that other people should do the heavy lifting for them.

I’m still baffled by how clueless it all was.

In the past, I used to like this person, and have often considered programmes we could run together.

After this though? I no longer consider them. No longer part of my world. Bye.

Not that I expect them to care - after all, I’m just a dude who does a thing, and there’s 100s of dudes and lasses like me, here on the coast.

But in terms of marketing, what they did was display greed - the greatest sin you can imagine in business, sales, and marketing.

When you want to enroll people (whether in an idea, a collaboration, or indeed into paying you money for something), give first.

When you do that, you make it about them, which is a powerful way to enable people to trust you.

And without trust, people don’t buy.

Instead of being greedy and selfish, be generous.

Serve people with your marketing.

&nbsp;

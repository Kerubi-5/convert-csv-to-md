---
title: >-
  If Money Prevents Your Buyer From Buying, Explain: They'll Either Pay Up, or
  Put Up
status: pending
datePublished: '1644234761'
categories:
  - How to sell your work

---

<img class="size-medium wp-image-28046 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/09/MartinStellar_Coaching_Illustrations-If-money-prevents-a-sale_ask_pay-up-or-put-up-300x225.jpeg" alt="" width="300" height="225" />

Isn't it just one of the most annoying things?

Everything lines up:

Your buyer needs your work, they like you, they trust you.

They have the budget, there's an eagerness to get started, there's urgency and an actual, true need.

You've even made a proposal, and they like it, but...

Then they start hemming and hawing.

“It’s a large investment…”

“Your consulting programme is exactly what we need, but that $30.000 is the budget we’ve set aside for a new site and traffic campaign…”

"Our budget is only half of that amount".

All valid concerns, of course.

Whenever you end up in a situation like that, where your price-tag becomes the reason a deal gets stuck, you need to give your buyer the "put up or pay up" message.

Which means:

If your buyer has a problem, they're going to be paying, one way or another.

They either pay you to make the problem go away...

Or they pay the cost of keeping the problem - or, what I refer to as "problem-cost".

They'll either pay up and remove the problem, or they'll have to put up with it, and also with the consequences of keeping it.

This is a massively powerful tool for getting deals unstuck, because it re-centers the conversation on what actually needs to happen.

In some cases, what needs to happen is for the buyer to wait.

Wait until it's the right time, or wait until they're finally fed up with the problem, and ready to move forward and buy.

Not only is the "pay up or put up" message useful for your deals and opportunities, it's also an act of service.

Because if there is budget, but money still is the obstacle, then either your buyer's problem isn't big or urgent enough to make it go away...

Or, the two of you have not yet adequately explored the true cost, ramifications, or implications of keeping the problem.

And the "pay up or put up" message is a fantastic way to do that.

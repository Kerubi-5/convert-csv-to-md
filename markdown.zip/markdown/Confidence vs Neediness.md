---
title: Confidence vs Neediness
status: publish
datePublished: '1566916746'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img class="alignleft  wp-image-22003" src="http://martinstellar.com/wp-content/uploads/2019/08/MartinStellar_Coaching_Illustrations-Confidence-vs-Neediness-people-pleasing-and-approval-seeking-1024x768.jpg" alt="" width="350" height="263" />It makes no difference if I ask for sandpaper, or a screwdriver or a tube of instant glue: she never gets it ‘right’.

A hardware store down the street from me, and the lady who works there always comes back out of the storage area with something different than what I asked for.

Like that scene in the Muppet Show, where Simon Soundman asks for a trumpet by making the sound of a trumpet - and the shopkeeper comes out the back room with a violin? That’s pretty much it.

The first few times I didn’t mind, and explained what I actually needed.

Then I started getting a little annoyed, and over time, kinda cross: “Why doesn’t she just listen? I barely get to finish my sentence, and she’s already off inbetween the racks, looking for something different than what I’m trying to ask for. How annoying!”

But the other day - when I asked for snap-off blades, and she pointed me at a range of kitchen knives ,I realised something: it’s not that she doesn’t listen…

What happens is that she’s simply very keen to be helpful, and probably wants to be perceived as smart as well (a pretty common combo of attitudes).

Put differently (and harshly, I admit): people-pleasing + approval-seeking.

Lesson #1 is that knowing this, there’s no point in being annoyed. That feeling just came from my own judgment and opinion, and I can change that.

The second lesson is more useful to you, and it’s about sales:

Being helpful is good, but if you get too close to people-pleasing, you’ll be perceived as desperate and that breaks trust.

Combine that with an attempt to be liked and approved of, and you have the perfect reason for a new client to back out, right at the moment that they’re getting on board with buying from you.

Help if they ask for your help, and before that: give them space to tell you what they need and want. Don’t be overly eager to offer your help, it sends the wrong message.

As for the approval part of it: who cares about approval?

You’ll get far more mileage from respect - for you, your status, expertise, authority in your field and so on.

And how do you get respect?

Show the confidence to not act needy, and you’ll be well on your way.

Cheers,


Martin

---
title: I Was Sold to SO Hard - And I Love Every Minute of It
status: draft
datePublished: '1549887613'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing
  - Relationships

---

<img class="alignleft wp-image-21378" src="http://martinstellar.com/wp-content/uploads/2019/02/MartinStellar_Coaching_Illustrations-Emotions-and-humour-in-sales-and-selling-1024x768.png" alt="" width="355" height="266" />A little lesson about the psychology of effectively selling things for you today, in a way that allows you to live with yourself:

It’s an early Spanish morning, first Saturday of the month - the day when there’s a rummage sale in the park.

I saunter to and from the stalls, say hi to friends walking around, feast my eyes on all the bits and pieces people have out for sale.

Looking at some books, I’m interrupted by an older English gent.

He picks up a suit jacket and holds it out for me:

“Look at this, it’s perfect, it’s your size, mint condition - here, try it on”.

A little smile on his face, a big glint in his eye.

Evidently, an individual with a lots of humour, and people skills too.

I smile, decline the offer, explain I have plenty of jackets, but he won’t have it:

“Only two Euros, it was made for you, here I’ll hold your backpack. Here you go”.

Starts tugging at the backpack’s shoulder straps, making a big fuss out of being servile, playing the part of overly invested tailor or butler with great flair.

I can’t help but laugh, crack a few jokes back, and within minutes the situation escalates into an impromptu improv comedy thing. Hilarious.

Meanwhile, he literally leaves me no room to breathe, and very deftly sells me (hard!) on trying the jacket on, and then paying two Euros for it - in a way that literally leaves me no choice. Pretty much coerced me into a sale.

It was the hardest sale I ever experienced, and believe me, I’ve had some hard sales pitches thrown at me.

This guy though?

Beats them all, and here’s the thing: I loved every minute of it!

As I walk home, endorphins and dopamine rushing through my system, I reflect.

There’s a definite feeling of glee and even mild euphoria, despite having been forced into buying (an admittedly nice) thing that I didn’t need.

He did exactly what you should never do when you’re helping a person decide to buy from you or not.

And yet it worked, and I’m even grateful for the experience.

Now, nearly everyone has either objections to sales and selling, or has unresolved subconscious limiting beliefs about it, or both.

And if that’s you and you own a business, remember this:

The explanations, the features and the rationale for buying your thing, that’s not what causes the decision.

It’s how someone feels, once all the rational considerations line up.

The emotion triggers a purchase decision, always.

If you want people to buy your thing, make them feel good.

Smart people have said that nobody buys from a clown, so I don’t recommend you make a spectacle out of yourself the way my English vendor did, but a bit of tastefully placed humour will have a very good effect on the outcome of your sales conversations.

Be authentic and not manipulative, but make people feel good.

That’s what causes people to want to buy from you.

Smile, nod, listen, ask, say something funny if appropriate, listen a whole lot more - you already know how to have a fun conversation. Why would you give a buyer anything less?

If ever you and I end up talking about working together, you’ll experience firsthand how much fun and relaxed a ‘sales conversation’ can be.

Best of all, it’ll change the way you gain your own customers.

Cheers,

Martin

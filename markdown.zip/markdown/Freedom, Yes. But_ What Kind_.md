---
title: 'Freedom, Yes. But: What Kind?'
status: draft
datePublished: '1488794536'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

We all want freedom.

			Freedom from oppression.

			Freedom from poverty.

			Freedom from inequality and judgment and other people’s opinions or toxic influence.

			But does that really work, when strive to be free from things?

			A desire to be free from something implies that there’s a negative in the mix. Something
			you don’t want, that you act against.

			And as soon as there’s a negative involved, things turn into a tiresome struggle.

			Which is why I much prefer a different approach.

			Me, I don’t need to be free FROM anything.

			Because for me, it’s far more fun and far more effective to be free TO do something.

			Free from vs free to... do you see the difference?

			Think about it. Think about how you think.

			Is your goal to be free from, or free to...?

			Cheerio,

			Martin

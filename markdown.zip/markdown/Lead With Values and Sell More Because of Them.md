---
title: Lead With Values and Sell More Because of Them
status: publish
datePublished: '1597020203'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - How to sell your work
  - Psychology in sales and marketing
  - Relationships

---

<img class="alignleft wp-image-22806" src="http://martinstellar.com/wp-content/uploads/2020/03/MartinStellar_Coaching_Illustrations-Values-experience-USP-1024x768.jpg" alt="" width="347" height="260" />When I talk about ‘solving the good egg problem’ - meaning: helping good folk sell more because of their values and not despite of them -  that means there’s quite a bit of variation in the kind of businesses that I've worked with.

Over the years, I've worked with coaches, consultants, ghostwriters, designers, architects, startups, healthcare, web developers and yoga teachers and SaaS founders: I’ve worked with all kinds and sizes of businesses.

On the surface, that looks like bad marketing, because if I am 'for everyone in general', my marketing would say ‘I’m not for anyone in particular’.

Except I’m not for everyone.

Sure I like working with coaches and consultants and people in tech - but I don’t necessarily think in terms of ‘niche’ or ‘industry’ or ‘demographic’.

What you do as a business owner can be whatever you want - but I can only work with you if and I have shared views on items such as values, integrity, and truthfulness…

And, very importantly: the idea of running a business that does something useful.

That’s my ‘niche’ - the psychographic make-up that you and I have, and whether or not we’re aligned in how we see certain things that matter a lot to us. Like values, and stuff.

That's who I'm for: people who see business and service and money and marketing in a way similar to me: a force for good, to be used strategically and with purpose and intent.

Here’s why this is useful for your own marketing:

Your values, or those that your company embodies, influence the experience your clients have with your business.

When you then lead with those values, in all your marketing and sales efforts, you’ll start to attract the kind of people who seek a provider who has certain values in common with them.

So when I work with clients to grow their business, an important job is to figure out what experience your customers have had, what that says about your values, and how that informs the communication (i.e. marketing and sales) you should be putting out in your messaging.

Because when you have the right values in common, the sale is already half closed, before you even talk to a new customer, because you’ll already have a lot of rapport.

That's why I believe an ethical, for-good business should always lead with values.

Makes the entire process of marketing and selling so much easier - and, you'll consistently end up talking to people you love dealing with.

If all this rings true, and you want to enroll more of the opportunities available to you:

I'm re-launching the LEAP Framework for Ethical Selling - a 10-week 1 on 1 training programme, designed to help you create sales without ever having to go against your values.

<a href="http://martinstellar.com/leap-ethical-selling-framework/">More information here.</a>

Cheers,

&nbsp;

Martin

&nbsp;

&nbsp;

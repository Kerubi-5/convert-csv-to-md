---
title: Much, Much Better Than New Year's Resolutions
status: publish
datePublished: '1578484397'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - Psychology in sales and marketing

---

<img class="alignleft  wp-image-22459" src="http://martinstellar.com/wp-content/uploads/2020/01/MartinStellar_Coaching_Illustrations-Implementation-intention-1024x768.jpeg" alt="" width="351" height="263" />Now that the holidays are over and all the talk about the new year and resolutions has died down, let’s talk about something that actually works for creating change and growth:
Implementation intention.

Because if you’ve ever had another slice of pie, whilst telling yourself that come January, you’ll be on a diet, you’ve probably noticed that resolutions don’t work. I mean: no gym is as full in use in January, as the number of people who sign up for membership in December. QED etc.

The problem with resolutions is that they go against the way our brain works.

When you eat now and decide to diet later, you’re giving your future self a problem. Today hedonism, tomorrow diet…? Hell no. And thus, making the resolution is in itself a way to ensure you won’t keep it. You can try to enforce today’s decision on the person you are tomorrow, but the moment you do that, your subconscious rebels.

Implementation intention though is different. And it’s simple, elegant, and effective.

And to put it to use, simply take some time in the morning, and reflect on what you want to do today, what might get in the way, and what you’ll do if that happens.

In other words: you visualise the best-case scenario, and then the worst-case scenario, and then you build solutions into your plan, for when things go wrong.

And the simplest way is to use the IF / THEN format that pogrammers use.

In other words: simple process-rules.

IF: it’s a new day
THEN: take some time to reflect and plan, before jumping into work

IF: planning is done
THEN: close FB, IG, mail, airplane phone &amp; set a timer for 20 or 40 or 60 minutes ofuninterrupted execution

IF: I’m feeling tired and tempted to go onto Facebook
THEN: close laptop and go for a walk/call a friend/do a few pushups/make some tea

IF: listed tasks are done
THEN: review calendar and todo-lists - and then take a break

See how simple and powerful it can be, to pre-define triggers, the actions that they cause, and solutions for when things break down?

Now obviously, planning your implementation intention doesn’t mean you’ll automatically get everything done. Sure you wrote the ‘programme’, but you’re not a computer, and you won’t always follow your own rules.

But once you have them, and you know what the rules are, you have a course, a compass, by which you can measure your performance.

And if you find that you deviated or slacked off, you can go back to your rules and re-commit, or revise them.

IF: didn’t stick with the plan
THEN: stop executing, sit down, review &amp; improve plan

Right?

So here’s where implementation intention differs from resolutions.

A resolution is a decision you make once, and then it’s meant to keep you on track ongoingly, based off that single decision.

But for any change to happen, any order or discipline or progress to be made, decisions need to be made again, and again, and again.

You don’t ‘go on a diet’ - you decide each day, and with each delectable morsel that shows up in your day, to stick with the diet. Decision, decision, decision, over and over again.

You decide - with intentionality - on what you’ll implement and how, and you keep deciding over and over.

So, now that you’ve seen your resolutions dissolve like a whisp of smoke the way they always do… implementation intention is what will actually get the results.

Good luck, and let me know if you need any help.

Cheers,


Martin

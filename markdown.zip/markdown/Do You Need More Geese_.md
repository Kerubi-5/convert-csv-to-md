---
title: Do You Need More Geese?
status: publish
datePublished: '1581698257'
categories:
  - Business and systems
  - Doing it right as an entrepreneur or creative professional

---

<img class="alignleft wp-image-22659" src="http://martinstellar.com/wp-content/uploads/2020/02/MartinStellar_Coaching_Illustrations-You-need-more-geese-1024x768.jpg" alt="" width="348" height="261" />It’s great when something starts to work, when we get noticed, when we start to land more clients.

Suddenly, things start to flow: it’s like you found the goose that lays the golden eggs!

For example: tenacious, persistent, dogged commitment to quality. If you keep that up long enough, sooner or later word of mouth will start working for you… look, there’s my goose!

But what if that’s your only source of new clients?

What if you don’t have marketing and visibility and traffic… and for some reasons, that word of mouth slows down…

Then what?

Success is awesome, but it can cause complacency, and you can’t afford to be complacent in business.

You can’t ever omit to build systems and assets that work for you, should there ever be something wrong with your goose.

So if right now things are working and your goose is laying golden (or even silver) eggs…

Should you be ‘building more geese’?

If yes, let me know, and let’s see what you can add in to your marketing and sales…

Because yes: you need more geese. We all do.

Cheers,

Martin

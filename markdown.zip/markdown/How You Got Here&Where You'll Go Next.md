---
title: How You Got Here&Where You'll Go Next
status: draft
datePublished: '1539853125'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-20993" src="http://martinstellar.com/wp-content/uploads/2018/10/MartinStellar_Coaching_Illustrations-Choices-and-decisions-1024x1024.png" alt="" width="353" height="353" />Your here&amp;now, this current you and the situation you’re in, is the result of choices.

You might be tempted to blame yourself for not having done better or decided differently, but what’s the point?

You can’t un-make a decision, so why beat yourself up for decisions that at the time you made them, were the best you could make for the person you were back then?

Oh I know: it’s easy to dismiss notions like that as pseudo-spiritual feelgood babble, but there’s a psychological truth in it.

Which is the fact that you can only affect the future, and you do so every single moment of your life.

What you think, what you choose to feel (yep, you get to choose feelings, how cool is that?), and what you decide, that’s what determines what life will look like in the future.

Not happy with your current station in life, business, or relationships?

Then ignore the future, forget about the past, and look at the right here, right now.

What are you thinking? Doing? Feeling?

What do you want tomorrow to look like?

What do you want to have done by the end of today - check off tasks, or take that long walk in nature instead?

Right here, right now, is where you get to make a decision on what ‘next’ will look like.

You get to decide, every moment of every day.

So ask yourself: are you making the decisions that benefit you and make you thrive?

Think…

Decide…

Implement.

In that order.

Which is, incidentally, the working modus of the Calibrate Reality framework (free intro webinar on October 25th).

What will you decide today?

Cheers,

Martin

---
title: Blatant Self-promotion
status: draft
datePublished: '1522421878'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/65633080-1725-4465-815c-5c5516d50e1c.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/65633080-1725-4465-815c-5c5516d50e1c.jpg" data-file-id="4835601" />Two things for you to consider today: The first is something that we all need to do to some degree, at certain stages, and most of us don’t do enough of it.

Which is: self-promotion.

Not in a boastful “Just LOOK at how frigging AWESOME I am!” kind of way though.

No. Not nice.

More in a sense of “Got something here. It’s REALLY meaningful to someone I know, who might be just like you. You might like it. Look”.

And that bit ‘someone like you’, that’s crucial - in all your marketing and communication, really.

Think about it: if someone you LOVE working with is happy with what you do, don’t you want more people, just like that?

Exactly.

Furthermore: before someone buys…

They want to have the trust and confidence that it’s the right purchase…

… FOR THEM.

And what’s a better way to have the buyer judge that, than to have them consider another happy buyer, and wonder if they’re sufficiently similar?

Right, so with that out of the way: Thing #2:

Consider if you will, taking a small step towards massive change.

Consider what your life could be like, and imagine yourself taking the first step towards making it so.

What step?

Hold on, first we need to see if, perhaps, you’re like Robbie:

“Martin Stellar’s coaching was the compass I needed to guide me in my career and life.

I showed up as an eager yet somewhat jaded artist/entrepreneur and not only did he help revive my career, he realigned me, on so many levels, with my purpose.

His no-nonsense way of coaching inspired me to be the best version of me, which affects everything I do.

I am eternally grateful to be a student of Martins’, to receive the gifts from his expertise, coaching and wisdom.

He is a great facilitator of creating change within and throughout.

~ Robbie Kaye - RobbieKaye.com”

So the question is: Can you identify with Robbie, and her story and her goals and her findings?

Does it *feel* ‘like you’?

And, do you want to get the guidance and alignment purpose and best version of yourself that she found?

Then the first step to making it so, is clicking reply, and writing:

Martin, let’s talk.

Next, I will send you a short questionnaire, and a link to schedule a call.

That call will not be a sales talk, but a coaching conversation, where I coach you on whatever’s most important to you. I’ll support you in any way I can.

At the end, if we both find that there’s a ‘click’, you will be able to choose an ongoing coaching relationship, but this is not an expectation. Up to you.

And, you don’t need to be an artist - I help all kinds of people: From CEOs to architects and from designers to therapists. And artists, obviously.

So, consider:

1: More self-promotion in your work, for instance in a way similar to how I just did it - but always by answering the question ‘for who is this perfect?’ so that people can identify, and:

2: Your first step towards creating lasting change in your life and/or your business…

It’s simple.

Just tell me “Martin, let’s talk”

Cheers,

​Martin

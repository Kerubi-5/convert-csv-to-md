---
title: Are You Selling Them a Problem? (part 1)
status: pending
datePublished: '1660088147'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img class="alignleft size-medium wp-image-20519" src="http://martinstellar.com/wp-content/uploads/2018/05/MartinStellar_Coaching_Illustrations-selling-a-problem-300x225.png" alt="" width="300" height="225" />

A while ago I spoke to a guy in Malaga, who was looking to sign up franchisees for his business.

“Martin, I have the hardest time recruiting people for these franchise opportunities. What do you suggest?”

I had him explain his process to me, and when he was done, I told him:

“Stop trying to sell people a problem”.

Obviously he was confused, because what he’s selling is actually a great opportunity.

But an opportunity for whom, and at what cost?

Because when you start a franchise, even if the cost to entry is $0, it means that you’re taking on a huge, enormous, all-consuming ‘problem’.

If you're an entrepreneur, you know this: Building and growing and running a venture is HARD work, and will be so for many years.

To 99.99% of the population, that’s a "Hell no!" kind of problem.

It takes a special kind of crazy to start a business, it's only for a very particular kind of person.

The kind of person who LOVES working, ongoingly, on solving big hairy complex 'problems'.

An entrepreneur is someone who doesn’t just accept the ‘problem’ of being in business - people like us, whether consciously or not, we love problems, and getting our hands dirty, and constantly tinkering with our business and marketing and sales process and so on.

So for this franchiser, his solution is simple: go present the option to just that kind of person.

Don't talk to anyone who is the employee-type, and not the entrepreneur-type of person.

Because anyone who doesn't have the entrepreneurial gene, all they'll perceive is a big problem, and that'll block them from seeing the opportunity.

The guy I talked to, he can make his life easier and his numbers go up, by only having conversations with the right kind of person.

But what about you?

I’ll assume your work is excellent, worth the money, solves problems, and yet… why are not more people buying your thing?

Could it be that, in the buyer’s perception, buying your stuff somehow represents or causes or includes some sort of problem?

Think about it: what, in your offer and your marketing, could be problematic for the buyer, in some way?

Are you, somehow, 'selling them a problem?'

In what ways might you, unwittingly, be 'selling a problem'?

Some attached consequence, that they'll have to deal with if they buy from you, and that has a cost for your buyer?

It's easy to think that your great PR package is mighty attractive - but your buyer will have to get portrait photos made, write up a bio, dig up links to previous appearances and so on...

And no matter how attracted the buyer is to the outcome you promise, they'll be blocked if the accompanying problem is too big.

So when a deal isn't working out, ask yourself:

Which problem does my buyer perceive here?

Next, ask your buyer: "If you were to buy this, what complications, implications, or problems, would you face as a consequence?"

That way, you get to help your buyer overcome or alleviate the problem that stands inbetween them and the sale.

<hr />

On another note:
I'm building an app that coaches you on working your pipeline, moving your deals forward - and closing them faster and at better rates.
It's called SalesFlow Coach, and we're scheduled for beta-release in June 2022.
Register <a href="https://martinstellar.com/salesflow-coach-launch/">here</a> to be notified when it goes live.

&nbsp;

---
title: I'll Be the Last to Tell You Building a Business is Easy, but...
status: publish
datePublished: '1487326882'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

...that doesn’t mean it has to be difficult.

It gets more difficult the more complicated you make it.

One way of complicating things is by thinking and acting in ways that are detrimental.

So to give you the simplest possible way to look at a business, look at it this way.

To grow a business, there are three elements you need to create, measure, and optimise.

1: The number of potential buyers who find out about you

2: The percentage of potential buyers who do business with you

3: The amount of money people spend with you and the number of times they buy

That’s it, that’s the basic model that goes for every single business.

Use these as your benchmarks when you want more results.

Results as in: your financial bottom line at the end of the year.

Because there’s ‘success for you as an entrepreneur’, and there’s financial returns, which is part of that success concept.

And for a business to be healthy, revenue needs to be high enough. And for a business to grow, revenue needs to grow up.

Separately from whether or not you’re satisfied in your work, or successful in ways that can’t be measured.

So if your income isn’t where you want it to be, use the three points as a benchmark.

Do enough people know about you? Are there enough potential buyers?

If not, find ways to show for more people.

But if you have a large number of candidates and the percentage who buy from you is low, then you need to work on that, and see if you can increase conversion rate.

And finally: if you have prospects and you have customers, what else can you offer your customers that makes them want to do business with you again?

Remember, it’s easier to get a repeat sale than a new buyer.

There you have it: A dead-simple, three step analytical tool that you can use to build and grow your business.

And here’s the kicker:

Email marketing helps you improve all three areas.

When you write daily emails and post them to your blog, you get more SEO value on your website which helps you get found by more people.

Daily emails help you stay top of mind with your subscribers (your potential buyers).

And, they help current or previous clients stay up to date with you, increasing the chance that they’ll come back for more of that awesome product or service you sell.

&nbsp;

---
title: Does Humour Belong in Selling?
status: publish
datePublished: '1648111536'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img class="size-medium wp-image-26515 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/02/MartinStellar_Coaching_Illustrations-Humour-in-sales-300x225.png" alt="" width="300" height="225" />

Early in the last century, an advertising pioneer by the name of Claude C. Hopkins, famously said:

“People don’t buy from clowns”.

Well, I think this is a fine day to disagree with an authority figure.

Not that I recommend you clown around when talking to a buyer - though there might be situations where that’s the best thing to do, it all depends.

What I do mean to say is:

Humour very definitely belongs in business, and in sales, and even in the money conversation.

Especially in the money conversation.

And even more so when what you’re selling has a high price tag.

That doesn’t mean you should stop the talk and tell a joke, necessarily.

But a bit of self-deprecating humour, or saying something slightly outrageous or ballsy or left field?

Yes, why not.

See, a sales conversation often becomes more tense, the closer you get to the final yes.

Especially the part around money and budget:

They want the outcome you promise.

You want the gig.

But they need to think about pros and cons, the timing, investment vs returns, and so on.

So there’s tension, and it kinda creates distance, right when you’re meant to be getting closer.

If at that moment you can break the ice and get a chuckle out of your buyer, that tension dissipates.

It feels good.

It brings you closer together.

It brings a conversation that started to get tense, back to something friendly and open.

So yeah, a bit of humour does wonders.

A little quip, a dad joke, or something left-field and funny?

Absolutely, go for it.

&nbsp;

Meanwhile, if you decide to <a href="https://calendly.com/martinstellar/20min" data-cke-saved-href="https://calendly.com/martinstellar/20min">click this link</a> to book a time to talk about growing your revenue and business, I may or may not end up saying something funny, who knows...

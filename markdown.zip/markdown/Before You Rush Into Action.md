---
title: Before You Rush Into Action
status: publish
datePublished: '1578998527'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft  wp-image-22496" src="http://martinstellar.com/wp-content/uploads/2020/01/MartinStellar_Coaching_Illustrations-Think-it-through-1024x768.jpg" alt="" width="349" height="262" />Thinking gets a bad rap - and in many cases, justly so. This when we get stuck up in our heads and start overthinking things.

But if you want to do or build something, it’s good to spend time thinking it through.

After all, as my former abbot likes to say: “Humans are profoundly irrational creatures”.

For example, there’s a tricky hairpin turn in my street, and right between the two directions, there’s a 1-foot high little brick wall. A few times a year, a driver takes the turn too narrowly and drives over the wall, leaving broken bricks and rubble. A few days later a worker shows up to dutifully repair the damage, until before too long, history repeats itself.

All it would take is a little thinking: “Huh… apparently people don’t SEE where the little bit of wall is. What if we’d build that wall a few feet higher? Or, what if we put a simple pole on the end of it - that means people can’t avoid
seeing it, and it would guarantee people won’t take the turn too narrowly!”

But apparently, town hall has a budget for rebuilding damage, but not for actual practical thinking.

What about you? How often do you leap into a project, only to find out later that had you given it some thought, you’d have done it differently, or later, or not at all?

Helpful questions, when you’re about to do something and you want to make sure you’re getting it right:

What’s the opportunity cost of this?

Have I proven before that I can do this, or is my passion only based on optimism and confidence? (Also known as ‘uninformed optimism’ - the realm of rabbit holes and red herrings).

Should I talk to someone and get a reality-check?

What, actually, would my plan look like from the outside?

If I were employed and I’d present this to my manager or CEO, would they OK my plan?

What attitude is required of me, in order to make this work?

Which skills will I need, that I don’t have yet? Can I learn them as I go, or would it slow everything down?

Do I have enough time, patience, and grit, to see this through to completion? (unfinished projects are super costly).

If this goes wrong or doesn’t work, what would be the first, second, and third culprit?

If it’s me who screws this up, in which ways would I do that?

Which assumptions am I making about the work involved and the results I’m projecting… should I challenge these assumptions? (Hint: if anything is being assumed, the answer is always: Yes, challenge the assumption).

If I execute on this plan, will I get demotivated because of elements I’ll try to avoid at any cost - in fact I’m even avoiding thinking about those things right now?

Note that I’m not recommending you start overthinking: what I’m getting at is spending some time - and 10 minutes is often enough - to properly, coldly, logically, think through something.

And then, once you’ve challenged assumptions and thought about worst-case scenerios, and adjusted your plan to make sense… that’s when you launch into execution with all the passion you’ve got.

When you work, do it from the heart.

When you plan, it’s best done from the mind.

Holler if you’ve got a plan or project, and you want to talk to figure out if you’ve got it built properly.

Cheers,


Martin

---
title: How to Make Selling Your Work 10 Times Easier
status: publish
datePublished: '1629284367'
categories:
  - How to sell your work

---

<img class="size-medium wp-image-27932 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/08/MartinStellar_Coaching_Illustrations-dollar-vs-dimes_high-ticket-clients-300x225.jpeg" alt="" width="300" height="225" />One simple decision can make all your lead generation and all your selling 10 times more effective, more efficient, and 10 times less costly in one go.

Of course it's a bit of hyperbole - it doesn't actually work out to 10 times, precisely.

But consider this:

Most people would rather have 10 dimes instead of having $1.

But if you want to land 10 clients at a low price, you're going to have to do all your marketing efforts, your degeneration, your sales conversations 10 times over to get to your $1.

And then you have to deliver your work 10 times.

Whereas if you go and look for one client who is worth 10 times as much - i.e. a dollar-client, instead of ten dime-clients, you only have to do all of that once.

So that sounds a lot more efficient, if I'm not mistaken.

But then people say: “Sounds good, but it's easier to sell at a lower price”.

Actually, that’s not true.

People who are looking to buy at a lower price, they are looking at cost. They are there looking to make a decision about and expense.

That is very much not the kind of buyer that you want to be dealing with, especially if you sell a very high impact service or product.

Instead, you want to be dealing with people who are looking to create an impact and to purchase something that has a very impactful outcome.

Meaning: people who are not thinking about an expense, but who are thinking about making an investment.

Those people are much less concerned with price and much more concerned with the value that you deliver.

So if you want to make your marketing and your selling, and your product delivery, a lot more fun and easy and lightweight:

Go for the high ticket buyers.

You'll find that these are very different people, they micromanage far less, and they are much more interested in what you can actually provide - the outcome, the impact of your work - then they are in the actual cost of the thing.

How to pivot your positioning and messaging and targeting, to work with that kind of buyer?

I’ll show you.

Pick a time <a href="https://calendly.com/martinstellar/20min">here</a>, and let’s chat.

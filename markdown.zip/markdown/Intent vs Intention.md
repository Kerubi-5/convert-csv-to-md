---
title: Intent vs Intention
status: draft
datePublished: '1486633400'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

When it comes to building the business or the relationships or the life you want,
			there’s different ways to go about it.

			These days, things like the law of attraction are often mentioned, but I think that
			model isn’t ideal.

			You don’t get your dreams fulfilled just because you pray for it to happen.

			You build your dreams into reality, which is why I much prefer the law of creation.
			Another thing that gets peddled a lot is intention.

			But intention isn’t magic, and it’s far, far less powerful than intent - which you
			happen to have built-in.

			In the monastery, they taught me a very simple, very handy  model to look at the human
			being.

			It helped me tons in getting over myself, and these days it’s super useful in my
			coaching practice.

			The model sees the human being as comprising four parts.

			There’s our physical reality, the body we live in and the world in which it lives.
			There’s mind, which means our rational faculty, as well as our ability to be aware of
			things.

			Next, we have the emotional realm: feelings, fears, dreams, wishes - and those are only
			the ones we’re aware of. 99% of our emotional world is subconscious.

			Finally, we get to intent.

			And intent is where the magic happens.

			Intent is when a smoker says ‘DONE with this’ and never touches tobacco again.

			Intent is ‘I start losing weight NOW’ and the person starts a diet and goes to the gym,
			and gets back on the wagon each time they fall off.

			Intent is pure creative power.

			It is the strongest force we have, and it beats intention every time.

			Because intention is a feeling, it’s a wish - it’s part of the world of emotions and
			those are fleeting, changeable, and subject to influence.

			Intent however is there, it’s untouchable, and it doesn’t change.

			Problem is, you can’t think or feel your way into intent, that’s not how you get there.
			Not that I know the secret to mustering up intent - I still struggle with it.

			But I’ve experienced its effects.

			A few years ago, the intent surfaced to serve my readers by writing an email every day.
			And I did and I do and the effects are wonderful.

			I get to show up and give something in the hope that it helps you.

			Hello.

			So how do you go beyond intention and reach intent?

			Hard to say, but the first step is to ask yourself:

			In order to reach this or that goal... who do I have to BE to make that happen?

			Think about it, let me know what you come up with.

			Cheers,

			Martin

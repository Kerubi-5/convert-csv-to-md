---
title: FOMO and the Inefficiency of Convincing (Where Marketing and Sales Go to Die)
status: publish
datePublished: '1607042344'
categories:
  - How to sell your work

---

<img class="alignleft wp-image-21758" src="http://martinstellar.com/wp-content/uploads/2019/05/MartinStellar_Coaching_Illustrations-feed-a-hungry-crowd-1024x768.jpg" alt="" width="350" height="263" />It makes no difference what problem your business solves: there are people who want a solution now, and those who don’t, not yet.

And if you want your sales process to be effortless and easy, you’ll do well to focus on the ‘hungry crowd’, and feed them.

But most business owners try to target everyone, and waste tremendous amounts of time and energy trying to convince people.

But, look at the diagramme:

Don’t you agree that the top of the pyramid is where you’ll have the biggest chance of converting prospects?

Of course.

The reason that we waste time with people below that level, is FOMO: fear of missing out.

Because of course, yes: in the ‘lower’ levels, there are also people who might become a buyer.

But the question to ask yourself is: how much work will it be for you to turn those people into buyers?

The answer is: lots of work, because you'll have to convince them that they have a problem, and/or that it needs solving...

And convincing is a always tiring, and usually not very successful.

And so we churn through prospects, running into one ‘no’ after another, and we get frustrated that things aren’t working better. That more people aren’t buying our thing.

Now, I understand that it’s not just FOMO.

After all, we’re good folk, we do actually solve problems, and we don’t want to do a disservice by ignoring people who may, or may not, be ready to business with us now.

How to solve the conundrum?

It’s simple: the people who aren’t quite ready yet - you serve them by creating content.

You educate them on the consequences of not solving their problem, and the different ways they can solve it - with or without your help, depending on how fast they want to move and how ready they are. Up to them.

You get to choose how you do it: a daily email, instagram stories, videos on Youtube, publishing ebooks or publishing on Medium or Substack… share as much as you want.

That way, you’re serving people who may become a client later on, and you’re casting a net for the small percentage who are ready to change their mind and are ready to go from ‘not ready’ to ‘yeah, actually, I want that solution’.

And the people in the top level?

Make them an offer.

After all, they’re actively looking for a solution, and guess what: that solution is exactly what you sell.

And that’s how you turn your marketing and selling endeavours into something that’s efficient, fun, and effective.

Want to jump an call with me, and get clarity on exactly which people are in that top section?

<a href="https://calendly.com/martinstellar/30-minute-appointment-with-martin-stellar" target="_blank" rel="noopener noreferrer" data-cke-saved-href="https://app.acuityscheduling.com/schedule.php?owner=11652475&amp;appointmentType=544906">Book a time here, no cost </a>(and no sneaky sales pitch either... If you know you have a problem, and you're looking to solve it, I trust you'll let me know).

Martin

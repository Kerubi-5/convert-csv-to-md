---
title: Choices, Decisions, and All Those Good Things
status: draft
datePublished: '1509016336'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/cda3a0c4-c815-4409-a304-3d782b52001a.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/cda3a0c4-c815-4409-a304-3d782b52001a.png" data-file-id="4835137" />The gent who used to be my abbot has a saying: “Life is made up out of choices”.

Which is so self-evident, it might as well go without saying.

Except that in many cases, we make decisions that don’t serve us (or others).

In which case it makes a lot of sense to stop and consider what the decisions we make actually are.

Learn more when sales are lacking? Might not be the best choice.

Unless you don’t know how to find prospects and create clients. In such a case, it makes more sense to learn more about psychology and communication (which is what sales are made of - pushiness not required or appreciated).

Other examples: Fritter away time on social media, thinking that we’re ‘networking’ when in reality we’re having random conversations that have nothing to do with the actual work we’d like people to buy. In such a case, it’s a useful decision to “only engage in conversations where I get to help people and demonstrate the value of my work”.

Or, here’s a decision that I tend to fall prey to: get involved with projects and people because I see a chance for future payoff… when in reality it means a long-term investment of time, without any guarantee whatsoever.

So, to cut through the clutter and make decision making easier, try this:

First, ask yourself what is your ultimate, most important goal.

Very likely, this will be big and seemingly impossible to achieve.

If so, break it down into milestones.

If your ultimate goal is, say, “Buy a villa and start an academy”, you can’t get there from here.

But if you break it down into steps, one of the milestones will be “create 1000 true fans”.

Far more attainable, right? But still big.

So, break it down further: “Create 100 clients”.

Easy? Maybe not. Doable? Of course.

Ok, so your first ‘most important’ goal is 100 clients. Check.

Next, the fun part: decision making.

Use the goal as a benchmark for your decision.

With every opportunity, activity, task, or project, ask yourself:

Does this directly contribute, in a measurable way, to reaching my 100-client goal?

If so, go for it, and go all in.

If it doesn’t?

Then I challenge you to boldly say no.

Because when you choose various things that are interesting but don’t directly contribute, you’ll disperse your energy, you’ll see little progress, and you’ll end up frustrated. Or worse: you might end up feeling you’ve failed.

And failing is not an option or a reality.

One person will close bankruptcy a failure… where another will call it a priceless learning experience.

And you get to - wait for it - choose how you perceive things.

Because yes: life is made up out of choices.

And I’d take it one step further: everything is a choice. Even not making one.

So… what can you eliminate, in order to have every task, conversation and project… be aligned 100% with your primary goal?

Let me know if you want to talk and create clarity on making the best choices.

Cheers,

​Martin

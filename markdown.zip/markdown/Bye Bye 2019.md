---
title: Bye Bye 2019
status: publish
datePublished: '1577818184'
categories:
  - Relationships

---

<img class="alignleft  wp-image-22425" src="http://martinstellar.com/wp-content/uploads/2019/12/MartinStellar_Coaching_Illustrations-Bye-Bye-2019-1024x768.jpeg" alt="" width="359" height="269" />A day can make a big difference - or a year, or a decade, or 5 minutes.

Every moment in any life can be a moment of complete inflection.

And obviously, a calendar date makes no real difference - except if you assign a specific meaning to that date, when you give it its significance.

If for you that’s New Year’s then today’s your day and all the power to you.

Just remember that it’s always you who gets to chose the point of inflection and significance - and that you get to choose it whenever you want.

Today, tomorrow, next week: you assign significance to a moment, in service of an inflection you desire.

Change happens all the time, and the change you want happens continuously, by repeatedly choosing, and it starts whenever you want it to start, and the best moment for it to start is whenever you’re ready.

Pro tip: if you want to be ready for change, chances are you already are, whatever the date.

All it takes for change to happen is to make a decision - but you’ll need to make that decision over and over again, until it sticks.

Anyway, such are my year’s end thoughts for you. It hope it’s been a good year for you and that your next one will be even better.

Love &amp; luck,

Martin

---
title: Life is Too Short...
status: publish
datePublished: '1504202919'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/127bfe0d-4c84-4bf5-a0ef-20e8ba9c4156.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/127bfe0d-4c84-4bf5-a0ef-20e8ba9c4156.jpg" data-file-id="4834973" />… too put up with things that don’t belong in your life.

And yet, most of us have far too many things in our life that should be far gone, far away.

So to make life easier and to turn you into someone more balanced, with more energy, and better able to weather the ups and downs of being an entrepreneur, ask yourself this:

Which people, places, things and habits, are there in your life that cost you energy?

Next, ask yourself: What are the benefits of keeping them?

And then: what is the cost of keeping those energy-drainers in your life?

Finally: If the cost is too high… what reasons (or should I say: excuses?) are there to keep them?

Do the math, and make your choices…

I’ve never met anyone who regretted getting rid of those people, places, habits and things, that cost more than we’re willing to pay.

Tough choices, perhaps. But worth it.

Because life is too short to keep stuff you don't need.

&nbsp;

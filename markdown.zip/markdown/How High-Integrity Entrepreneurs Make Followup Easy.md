---
title: How High-Integrity Entrepreneurs Make Followup Easy
status: publish
datePublished: '1659470446'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - How to sell your work
  - Psychology in sales and marketing
  - Relationships

---

<img class="alignleft wp-image-22213" src="http://martinstellar.com/wp-content/uploads/2019/10/MartinStellar_Coaching_Illustrations-How-ethical-entrepreneurs-take-the-sting-out-of-followup-1024x768.png" alt="" width="349" height="262" />

What do you do when it looks like a sale is going to close, your buyer says yes, you send the contract... and then nothing?

Of course you follow up, right?

Actually, the more of a good egg you are, the bigger the chance that you don't follow up, and wait for the next opportunity.

I get that. It used to be the same for me.

When an opportunity broke down, I just moved on.

But if you do that, you're leaving money on the table.

As they say: the fortune is in the followup.

And sure, then you get the gurus telling you that you must follow up because it’s your moral and ethical duty to make sure that the right buyer gets his stuff from you and not from someone else - but fat lot of good that does.

Knowing that it's your duty doesn’t make it any easier to do followup - especially if you're a person who sticks to their values, and you treat people with respect, and you don't want to be a nuisance.

So then, how do ethical people do sales and followup?

What made the difference for me is simple, and it could work for you as well:

You make followup easy by improving your buyer's experience *before* the followup.

In other words:

Make every buyer interaction a moment of joy, service, and helpfulness.

Have fun talking to your customers, serve them, be yourself, be light.

You’re not there to be all dry and professional - or indeed, salesy - because who wants to talk to someone who shows up like that?

Instead, make the interaction about connecting, and learning that person, and figuring out what’s real and/or challenging for them.

When you do that, you leave people with a feeling of "Yeah, I feel respected by you. This was nice, helpful, fun. I’ll talk to you again".

Do you see where I’m going?

When you have conversations people enjoy, they’ll be open to hearing from you again.

They'll welcome you following up - they'll thank you, even.

Once I got this, following up with folk became as natural to me as calling a friend.

So the question isn't "how do I follow up?", but:

"How do I engage with people in such a way, that they'll welcome my followup?"

&nbsp;

<hr />

&nbsp;

&nbsp;

On another note:

I'm building an app that coaches you on working your pipeline, moving your deals forward - and closing them faster and at better rates.

It's called SalesFlow Coach, and we're scheduled for beta-release in June 2022.

Register <a href="https://martinstellar.com/salesflow-coach-launch/">here</a> to be notified when it goes live.

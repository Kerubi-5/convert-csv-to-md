---
title: Going Martial Arts on Your Mind
status: draft
datePublished: '1490292099'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

Yesterday on the Cabal group coaching session, someone asked how we can change the stories we tell ourselves, when we notice that we have a story that doesn’t help us.
Point is though, that’s not how it works.
It’s really hard to ‘change the story’.
Because the story you tell yourself is something that you believe to be true.
So if you go in and try to change it, your subconscious will fight, it will perceive it as a threat to its beliefs.
Beliefs which are there to help and protect you.
So clearly, it will be hard to replace one story with another.
Much more effective, and more fun, is to kind of play Jiu Jitsu with your stories.
Lots to be learned from martial arts, especially if you put it into practice.
So take for example the story that ‘I need to be worth more before I get to earn more’.
Pretty damn limiting story, because if you start out that way it’ll be a long long while before you get to feel you’re worthy enough.
So instead of telling yourself a different story, do martial arts on it.
The story has its momentum, in how it causes you to continue thinking, and the actions and decisions that follow.
So you take that momentum, and instead of fighting it you go with it, and give it a different direction.
Like so:
“If it’s true that I need to feel more worthy first, then what can I do right now that will help me feel more worthy, even a little bit?”
If the story is “I’m not meant to have success like Famous Person X, it’s just not for me”, then the judo move is: “Interesting thought, but what about folk like Tony Robbins or Oprah Winfrey? Didn’t they come from poverty and misery?”
And if the story is “Yes but they are different”, then the move is: “And am I not? When was the last time I met a copy of myself? I too am different.”
See, some things need to be fought.
Other things - many things in fact - will change much more easily if you play with it.
There’s only so much fighting we can do.
And with things of the inner world, very often the fight only makes the demon stronger.
Play. Dance. Be elegant and fluid.
You’d be amazed how much power you have when you stop trying to exert it.
Twas a fun session. The women in the Cabal really bring out the best in me.
Want to join us, and be part of a small elite team of ambitious female entrepreneurs? (women only group)
Then click reply, and let’s see if you and the group will be a good match.
Cheers,

&nbsp;

Martin

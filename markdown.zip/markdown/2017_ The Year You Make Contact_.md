---
title: '2017: The Year You Make Contact?'
status: draft
datePublished: '1483346054'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

The correct answer is of course: yes.

But, you gotta do it right or else it backfires.

Here's the deal:

Seems like the world is finally catching on to the idea of email marketing.

Over the last few weeks I’ve been getting emails from all kinds of companies and entrepreneurs, that never used to send emails at all.

A fabrics seller for example, where I used to by cloth back in my tailoring days a decade ago.

And you’d think I’d be happy: after all, I’m the guy who’s trying to get everyone on the email marketing bandwagon.

Except nearly all of the companies are doing it completely wrong.

They never email me, and when they start, the only thing they have to say is:

“It’s us! We’ve got stuff to buy! Buy from us!”

To which my reaction is, of course:

“Screw you and the ADSL connection you rode into town on”.

Yes, I’ve been clicking the unsubscribe links a lot, lately.

So for anyone new to me, or in case you didn’t get the memo:

Email marketing is good, it’s useful, and it helps your business.

BUT!

It only works if you make your email missives valuable in and of themselves.

Whether you educate, entertain, inspire, or whatever you do, make that the first order of business.

Your emails are an act of public service, by merit of which you earn permission to offer people something for sale.

Where ‘service’ is the key concept.

Make your email marketing something that in theory, you could charge money for.

And if you’re not clear on how that would work, just look at my emails.

Sure I’ll pitch working with me, but only after I’ve made it a point and my mission to give you something that hopefully helps you.

And technically, I could charge money for getting access to these - in fact, people like them so much that sometimes they ask me when I’ll start charging for them (which I don’t think I ever will).

Get the picture?

Send people emails that are worthy of their time, and you can send one every single day, and gratitude and clients will be yours.

Alright?

Ok, so consider making email marketing your mission this year.

It’ll do your people and your business a lot of good.

And if you want to but you’re not sure you’ve got the writing chops to do it right, I’ve got a mentorship program that teaches you how.

Each week I’ll analyse one of your emails, and give you detailed, line by line feedback on how to improve.

Three months of that, and your email marketing will be a force to reckon with.

And, you're very likely to see people buying from you.

More information here: http://martinstellar.com/starship-mentorprise-writing-coach/

Cheers,

Martin

---
title: I Don't Usually Drive 1000 Kms to Meet a Woman. Much Less One Who's Married
status: draft
datePublished: '1496642736'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/4d9d4c35-b8af-4037-a320-8f1115662d9b.png" width="350" height="197" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/4d9d4c35-b8af-4037-a320-8f1115662d9b.png" data-file-id="4834657" />Then again, it’s not for romantic motives that I was so keen to meet Maria Brophy, who's currently walking the Camino de Santiago de Compostela.

Nor because I have any serious pilgrim ambitions.

Ok, I’ll come out with it right now: I’m using her visit to Spain as an excuse to have a little time off.

What? Don’t I get to live a little?

Truth is, I don’t travel much. It’s often hard to fit into my schedule, and it’s just not something I create space for.

So when I saw on her Instagram that she would be in my country, I decided right then and there: I’m going to meet her.

Because we’ve spoken a few times over Skype, and each time I came away feeling that I’d met a great being. And to have that in person, while walking in the mountains?

Yep, I’ll drive a day for that.

So here I am in the breakfast room of a hotel.

In an hour or so we’ll meet and walk, and I do admit I feel out of place.

All around me I see Very Serious Pilgrims, with all the gear and paraphernalia - and I’m sitting here typing out this email to you.

Like I said, I’m not much of a pilgrim.

Anyway, time to go walkies for your little Stellar.

Catch you on the other side of the hill.

Cheers,

​Martin

P.s. The bread here is to die for.

P.s.p.s. Maria is an art licensing consultant with a whole bunch of experience, so there’s a real chance we might end up creating a programme together. That's another reason I wanted to meet. If a program like that ends up happening, you'll be the first to know.

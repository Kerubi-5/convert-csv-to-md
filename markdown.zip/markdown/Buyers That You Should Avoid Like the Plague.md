---
title: Buyers That You Should Avoid Like the Plague
status: publish
datePublished: '1638534238'
categories:
  - How to sell your work

---

<img class="size-medium wp-image-27956 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/08/MartinStellar_Coaching_Illustrations-Buyers-you-should-avoid-like-the-plague-300x225.jpeg" alt="" width="300" height="225" />There's three kinds of people that you could try and sell to:

There's the qualified buyer, the unqualified buyer, and then there's the buyer you shouldn't touch with a ten-foot pole.

How to recognise the third kind?

By the way they look at spending money.

This was illustrated a while ago, by a comment someone left on my LinkedIn post about pricing your work based on the value of the outcome, instead of the time you spend delivering said outcome.

Here’s the gist of his message:

“I just spent 100 bucks to have somebody come out to my house and put together a sofa that I bought. It took him 20 minutes - and it was money well spent, because it would have taken me a whole day.”

That mindset right there, that is the kind of person that you can sell to, even if there other factors that make them unqualified for now.

That is the kind of person who understands that there is a difference in the value of time, compared to the value of money.

Time is not replenishable.

It runs out, it’s a finite, scarce resource.

Money, however, is something you can replace, right?

You spend a dollar, you make another dollar. Not that difficult.

If you spend an hour however, that hour is gone forever and you’re never getting it back.


Many consultants and coaches then try to sell to third other kind of buyer - the one who would say:

“100 bucks for 20 minutes of work!? Outrageous! I’ll do it myself!”

But that is the kind of person you shouldn't even try to engage with.

Don't try to contact them, sell to them, engage with them - don't even put them your CRM and don't consider them a prospect, because this person is thinking incorrectly about the value of money, and the value of time.

Which puts you in the position of having to explain, and convince, and then try to have them see the sense in making the investment.

And that’s a tough job, because they have their reasons for seeing things the way they see them.

And believe me, your smart argumentations are going to achieve very little, trying to argue against a lifetime of beliefs, opinions, experiences, habits…

A buyer is a person - a world onto themselves - and I’m sorry to say that your puny argument about how wise and sage it would be to invest with you, doesn’t stand a chance against that world.

We’re talking about the kind of person who doesn't realise that if they spend a day putting together a sofa, they just lost out on an entire day of productive work that could grow their business or earn them money.

They didn’t save themselves $100 - instead, they lost themselves anything from $100 to who knows how much a day’s work can be worth.

The difference, in one handy quote (don’t remember where I saw it):

Don’t spend time to save money. Spend money to save time.

So, look to engage with people who agree with that, and stop trying to convince people who don’t get this simple, and sage, and sane, principle.

Engage with people who consider paying you an investment, not a cost.

Much easier sale for you, much more fun and efficient lead generation process.

Meanwhile, if you happen to be looking to invest in improving your lead generation and your sales, you know where to find me.

In my calendar, for example: <a href="https://calendly.com/martinstellar/20min" target="_blank" rel="noopener" data-cke-saved-href="https://calendly.com/martinstellar/20min">Book a call</a>.

Martin

&nbsp;

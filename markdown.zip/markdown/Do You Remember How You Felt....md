---
title: Do You Remember How You Felt...
status: draft
datePublished: '1517568274'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/71799cf9-78a4-42de-ad96-2b36f4fc6948.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/71799cf9-78a4-42de-ad96-2b36f4fc6948.png" data-file-id="4835425" />… say, when you got up this morning? Or yesterday at noon?

Do you remember how you felt last Monday?

Or September 2016?

When you were 21 years old?

Interesting, isn’t it? We don’t remember our emotional states…

Oh sure, you remember how you felt when you got married, or graduated, or bought your first car or house.

And yup, you remember how awful you felt when a relationship ended or you got fired, or someone dear passed away.

But between those peaks and troughs… all the emotional realities… where did they go?

Why can’t we remember, pinpoint, an experienced reality or our emotional state?

Maybe it’s because emotions aren’t all that important.

Oh I know this will put off some people.

How can my emotions not matter! They’re my feelings, it’s part of who I am!!!

Sure, yes. But in the West, we put an enormous importance on how we feel, we treat emotions as if they’re something sacred.

But they’re not.

An emotion is nothing more that a VERY fleeting experience, and it’s the consequence of thoughts.

Thoughts create feelings.

Like so:

“I’ve tried so hard to make this work, to no avail. I can’t do this”. Next up, you feel deflated or you feel like a failure.

“No matter what I do, that other person just won’t co-operate with me”. Next, you feel like trying another approach is pointless.

“Everywhere I look, I see artists struggling and starving. You just can’t make a living as an artist”. Followed by the feeling that even trying just is no use.

You see how it works? You tell yourself a story about something, and then that story (thoughts) generate an emotion.

A few minutes later you have different thoughts about something, and hoopla: your entire emotional state flips or gets shifted. That’s how fleeting emotions are.

That doesn’t mean feelings aren’t relevant, because they are.

But only as an indicator of how you think. They’re a consequence, not a starting point for making decisions.

With the distinction of gut-feeling or instinct: that’s a different kind of state and it’s one that is very useful for making decisions.

Most people consider their feelings and then let that be their guide.

I say do it the other way round: consider your feelings, and use them as a barometer of how healthful your way of thinking is.

Practice this, and you’ll discover some very interesting things about how your mind works.

And then the fun begins: you can start to change the way you think, which will change how you feel.

And as always, if you want help in going through this process, I’m here to help.

Cheers,

​Martin

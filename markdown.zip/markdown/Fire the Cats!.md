---
title: Fire the Cats!
status: publish
datePublished: '1496234127'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="" src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/86d9bd56-4f8e-4b94-8953-fabbc319536a.png" width="419" height="236" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/86d9bd56-4f8e-4b94-8953-fabbc319536a.png" data-file-id="4834649" />Yesterday a client said she felt overwhelmed.

Pushing a boulder up a hill, this whole running a business thing.

“It’s like herding cats”.

And yep, I can relate.

Sometimes, there’s just so many balls you need to keep an eye on, and so many plates to keep spinning and fires to put out and emails to follow up on and stuff to learn and and and...

If you also feel this way, might I recommend you fire the cats?

I mean, most of the items in your calendar and things on your todo list are there because you  put them there.

And sure they all seem necessary and important and urgent, but it only works if the totality of it doesn’t cause you to feel overwhelmed.

And if it does:

Simplify.

Reduce.

Declutter.

If you take the bold and brave step to reduce your business operations to a small, manageable, minimal system, you’ll have so much more control.

You’ll be able to measure and iterate on the system.

You’ll have more time in your day and more space in your mind.

And most importantly: it’ll be you running your business, instead of the business running you.

Because the latter, that just ain’t no way to go through life.

So do you dare?

To simplify, eliminate, reduce?

Cool. Get set, fire the cats.

&nbsp;

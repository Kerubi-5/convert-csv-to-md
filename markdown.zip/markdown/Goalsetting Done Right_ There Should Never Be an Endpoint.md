---
title: 'Goalsetting Done Right: There Should Never Be an Endpoint'
status: publish
datePublished: '1503507333'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/9bdf63a4-f36a-48da-add8-75965bad0912.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/9bdf63a4-f36a-48da-add8-75965bad0912.jpg" data-file-id="4834945" />There are two kinds of goals, and the results you get from choosing one over the other can be dramatically different.

Most people work with achievement goals:

A certain level of income, a type of client, paying off debt or buying a house…

All these are good and worthy points of focus.

But, never make them into end points.

Because an end point is that: the moment when something stops.

And what kind of life would we live after that?

When your big goal is the end point of something, and you reach it… what then? What next?

You wouldn’t be the first to miss out on all the joy and satisfaction that could be yours to have… and only because you didn’t set your sights high enough.

“Living off my art”, the goal that one of my clients has: that’s brilliant, beautiful, a worthy goal to strive for.

But that’s nothing compared to the next goal beyond it.

Say, for example: to be internationally renowned.

That would be a nice next goal, wouldn’t it?

Yes, but if the big goal is to pay the bills, there’s a real risk that the second goal won’t be ever be reached, nor the first one.

Because the thing with goals is that we rarely reach the all of it, in the way we wish for it.

Most of the time, we reach some or most of the goal, but not all. And that’s fine.

Because if you have a next goal, a “from here to the next stage”, it won’t matter that you didn’t completely reach the first one.

When your aim is high enough, reaching goal 1 will be less important the closer you get to it, because the nearer you get, the more you’ll already be looking for the next one.

So goals shouldn’t be seen as end points.

Instead, think of all the goals you have as milestones.

And just like a runner wouldn’t dream of stopping halfway through, you too can keep on going.

Because what does a runner do when he’s completed his marathon?

He signs up for the next one.

And that’s how you keep moving forward.

This is why personally, I don’t care much about achievement goals.

I get a lot more fun, and speed, and mileage, out of progress goals.

So here’s the homework for today: what achievement goals do you have, and which of these should be replaced by progress goals?

&nbsp;

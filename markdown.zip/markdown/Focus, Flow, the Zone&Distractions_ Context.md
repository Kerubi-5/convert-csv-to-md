---
title: 'Focus, Flow, the Zone&Distractions: Context'
status: draft
datePublished: '1493308280'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/280dd9e1-d050-415c-a796-0d431cc008a6.jpg" width="200" height="266" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/280dd9e1-d050-415c-a796-0d431cc008a6.jpg" data-file-id="4834557" />Lately, I’m spending Thursdays at my friend’s co-working place in Malaga.

Not that I need to rent office space: I’m rather happy working from home.

But I’m helping my friend and I’m meeting interesting people, so I’m happy to take the 1-hour drive once a week.

Today we were talking about focus and productivity, because let’s face it:

On any given day, you could likely achieve more than you did.

Sure works that way for me.

And one of the best and most effective ways to increase your output?

Create the right context for it.

As in: turn off distractions. No notifications on your phone or PC.

Put on the right music, or switch it off if you prefer silence.

Brew your favourite tea or coffee. Stretch.

Light incense if you like.

Prepare your workspace, but above all: prepare your mind.

And yes, manipulating your surroundings is one of the best ways to do that.

Whatever ritual or context works for you, take some time to create it, before you get to work.

Because few things are as destructive for your productivity as a messy space or a messy mind.

Context and preparation are why I have a three-hour morning routine.

It’s why I’ve played the exact same playlist every day for almost two years.

And it’s why my days are good, no matter how well or how badly they go.

Whether I achieve a lot or little, get setbacks or wins: my days are generally good or even quite good.

Things affect me less, because each day I’m deliberate and purposeful about the context in which I do my work.

So, I fully recommend you think about what context works best for you, and how to build it into your work every day.

And if you want a social context, with fellow entrepreneurs who get what you’re trying to do?

Then my new Cabal group might be just what you need.

Info here: http://martinstellar.com/cabal-group-coaching-action-takers/

Cheers,

Martin

---
title: Create Your Own Dopamine Drip, Steal Back Your Attention
status: publish
datePublished: '1532428994'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/4934bc0e-f730-4ff3-8696-4265de2cc598.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/4934bc0e-f730-4ff3-8696-4265de2cc598.png" data-file-id="4835949" />They say we live in an attention economy, but that's the euphemism of the century.

What we actually live in, is an addiction economy. And it's sinister.

The attention you pay (and I mean ‘pay’ in a literal sense) is worth money to companies.

When your attention is on Facebook, or Instagram, or Pinterest or Youtube, someone somewhere is making money.

Can be by selling a product or service, or simply by showing you advertisements. People make money when ads get displayed, and when they get clicked on.

In itself that’s nothing bad (though a business model based on nothing more than revenue from advertising is a pretty lame thing IMO), but there’s a seriously insidious side to it.

In that, the attention (I mean: addiction) economy preys on one of the most basic, fundamental, primordial survival instincts.

Meaning: the need to not miss out. Because back when we were primitives (I’m not actually sure if we haven’t become more primitive than millions of years ago, but hey. Topic for another day),  we HAD to make sure that we got
fed and didn’t get killed.

We could only survive by noticing opportunities and threats.

The sound of a breaking stick in the shrubbery could mean a predator was about to leap on you, or it could be an animal you could hunt and eat.

And while that primal need is gone, the instinct is still in us.

The addiction economy makes clever use of that, by constantly making us feel that if we don’t buy this thing, read that book, watch that video, or install this [random thing] in our lives, we’re missing out.

And while you’re an evolved, intelligent, thinking person, the lizard brain in you doesn’t reason.

It reacts to whatever potential threat or opportunity it notices, and tells your mind: “Oooh, look there!”

And the scuzzy scammy side of the marketing industry has developed its methods to scientific perfection. Literally.

Because, again, when you pay attention to something, someone somewhere makes money.

And the best way to get someone to pay attention?

Make ‘em feel good. Put ’em on a constant dopamine drip.

Endless scrolling on social media, Youtube presenting you with one delectable video after another…

Cat videos, ‘3 MUST HAVE tricks for XYZ’ headlines… attention attention attention. Money money money.

Sick, isn’t it?

Because in the end, you don’t grow or benefit from that excessive attention-paying. Others do.

This is why I deleted my Whatsapp account (I did WHAT???).

The thing nags at me every second day to turn on notifications, when I actually had a limited set of notifications switched on - just enough for me, but not for Whatsapp. Because I wasn’t paying attention to the thing enough. So, out with it. Plenty of other ways to communicate. Especially given how the app is engineered to keep users addicted to using it.

Now, I want you to be aware of how deep this goes. How desperately companies need your attention, and how deep and evil it gets into manipulating you into paying attention.

Into, literally, making you addicted to dopamine.

(Which, incidentally or rather: intentionally, lights up like a christmas tree the same brain centers that light up as a result of taking cocaine. Think about THAT for a moment).

And, I want you to know there’s a better way to feel good and to get your dopamine drip.

It’s real simple too.

Every morning, make a list of small, ultra achievable but useful tasks. Preferably on paper.

As you go through your day and execute on them, check them off.

Each time you do, you are rewarded with a little dose of dopamine.

Simple neuroscience: set a task, do it, mark it as done - instant positive feedback.

You might think it’s an insignificant thing to add into your life, but you’ll find that it’s a MUCH more pleasant, rewarding, and helpful way to feel good  - while also making sure you get better at executing on the things that make your life and your business better.

Because really, life is too short to pay attention to the things that make some a**hole company, which uses you as a product and not a client, better.

Cheery stuff today, no?

Well, put my recommendation to use, and watch how quickly you’ll end up feeling cheery, instead of that horrible hollow feeling you get after wasting away an hour on Flakebook.

Or not, your choice.

But I’ll make my own dopamine drip any day of the week. And it makes me a pretty damn cheery person.

Cheers, cheerio, and cheery,

Martin

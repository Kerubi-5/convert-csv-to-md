---
title: >-
  Assumptions Blind, but Hypotheses Guide: Treat Everything Like a Test or
  Experiment
status: publish
datePublished: '1576754521'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - Psychology in sales and marketing

---

<img class="alignleft  wp-image-22406" src="http://martinstellar.com/wp-content/uploads/2019/12/MartinStellar_Coaching_Illustrations-Assumptions-blind-hypotheses-guide-1024x1011.jpg" alt="" width="359" height="354" />Assumptions blind, but hypotheses guide: treat everything like a test or experiment

It’s impossible to not make assumptions. We all do it, all the time, and we should thank our subconsciousness for feeding us assumptions - after all, it’s what has kept humanity alive for a long long time.

But, it’s a mistake - and often a very serious mistake - to let to treat an assumptions as fact.

When you do that, your actions are based on untested data about the world, the market and your audience, and that means you might well end up moving in the exact opposite direction of where you want to go.

“I’ll just put ads on Facebook for my business, and then I can scale up”.

Maybe. But you’re basing that on success that others have had, you assume that you can replicate that success in your own way and for your own audience, and you assume that Facebook actually shows your ad to the right people.

That’s a lot of assumptions behind your strategy, and if you then also assume that ‘more ads’ will lead to ‘better results, in the end’, then poof: gone is your advertising budget.

Instead, treat everything like a scientist would:

“My hypothesis is that Action X will produce result Z”, and then you test whether or not the hypothesis holds ground.

Measure results, adjust the strategy (meaning: use a new hypothesis), and run the next experiment.

I’m not a scientist, but it seems that’s how scientists go about things.

After all, proof is a lot more useful than assumptions, and testing hypotheses is how you establish proof.

So if ever you try something and it’s not working, the first action is to ask yourself:

Which assumptions did I hold as true?

Where did that divert me from taking the actions that get me the results I want?

Cheers,


Martin

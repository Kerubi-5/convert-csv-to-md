---
title: Excellent Servant, Terrible Master (How to Get Out of Your Head Quick Smart)
status: draft
datePublished: '1533027555'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/1d9bc1f9-62e6-456d-b44e-37ae058533eb.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/1d9bc1f9-62e6-456d-b44e-37ae058533eb.png" data-file-id="4835969" />A mind is a wonderful thing to have. It can remember things, create ideas, think through problems and solve them, design goals and the plans to get them to manifest… lovely stuff.

Not quite as lovey though, is its tendency to dominate.

Like a dictator, ready to stage a coup any moment it gets a chance.

One moment you’re happily doing your thing, feeling good, and bam: suddenly a thought pops up that spins your thoughts out of control. Doomsday scenarios, rehashing old conversations and things you ought to have said, banging your mind against problems you’ve already and unsuccessfully tried to solve a 1000 times before, and before long your good mood and happy creative state is gone.

Thing to do, is to learn how to work with your mind, instead of letting your mind work you.

Because the mind is an awesome and powerful servant, but a terrible master.

Which you know from experience: when you let it run wild, it can take you all kinds of horrible places. Avoidance and procrastination being one of the first stations.

Cat videos, Facebook, Netflix - ANYTHING to move your mind away from what it seems to have bitten into like a pitbull.

But there’s a more fun and more productive way:

Writing.

Or more specifically: using a pen and paper for intelligent reflection.

That’s quite different from journalling or writing morning pages, btw. Those might be fun, but intelligent reflection is a whole different level.

It’s kinda like taming the mind, and it’s real simple.

Step 1: Identify a problem, unresolved question or other issue that keeps your mind occupied.

2: Formulate it as an open-ended question and write it at the top of the page.

3: Brainstorm the living daylights of that puppy! Jot down any idea, no censorship, doodle and diagram and just put black on the page.

Before long you’ll have discovered something useful, or interesting, you’ll have created clarity, and you will find that - magically! - your mind no longer needs to cling to the topic for the moment.

Peace at last.

Note: for this to work, it’s got to be pen and paper. Brain science shows that longhand writing has a different effect on the brain, and you just can’t get the same level and depth of poking around in the subconscious if you write on a keyboard. Trust me on that one.

Note 2: If you REALLY can not bring yourself to write longhand, the next best option is to go for a long walk/soak in a bathtub/drive, and record yourself while you talk yourself through the brainstorm. But really, writing is MUCH more powerful, because your eyes are getting instant positive feedback from the things you’re writing down.

I discovered this last winter, when my coach had me buy a quality notebook, and he started feeding me writing prompts, always in the form of a question.

And as the good little student I am, I took it seriously and journaled on all the prompts he gave me (obviously: if I pay a guy to give me the best tools and methods for moving forward, it makes no sense to not do the homework).

And the results over the last 6 months have been massive. So much clarity. So much better decision-making.

All from a daily habit of asking myself a tough or complex question, and allowing my subconscious to flow out through my pen.

For example, I spent weeks *thinking* about what my Calibrate Reality training should do for people. Couldn’t get clear on it.

Until I wrote the question down, journalled on it for 30 minutes, and bam: I knew precisely what it would do, who it would be for, and I had the starting point of the whole programme.

So. Stuck in your head much?

Create a question, write it down, brainstorm on it.

And if you’re stuck on something and you don’t know what’s the best question to ask yourself, send me an email and tell me what you’re facing. I’ll do my best to give you a writing prompt that will help you break through it.
Cheers,

Martin

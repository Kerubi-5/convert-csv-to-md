---
title: >-
  How to Get Things Done and Not Torture Your Future Self (Don't Be a Victim of
  Temporal Myopia)
status: publish
datePublished: '1654602312'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21409" src="http://martinstellar.com/wp-content/uploads/2019/02/MartinStellar_Coaching_Illustrations-Temporal-myopia-1024x768.png" alt="" width="353" height="265" />

We procrastinate until the last moment, because we keep thinking our future self will simply deal with that backlog in a massively efficient and productive way, because future self is just such a hero.

We spend money we don’t have, because hey:

With all the work we’re doing these days, we’re bound to have plenty of money to pay off debts soon - right?

We riff off a shoddy first draft or mockup for a client deliverable, because 'tomorrow-me' will have nooooo trouble at all, knocking that puppy into shape.

In each of those cases, we leave it up to our future self to deal with whatever thing our present-self isn’t willing to deal with.

We torture our future self, or at the very least: make things difficult for him or her.

So logically, very often, future self shows up to the mess, says ‘screw this’ and goes off to procrastinate.

This inability, to see yourself experiencing the consequences of your current actions and decisions, is what psychologists call ‘temporal myopia’, and we all have it to some degree.

If you want to get stuff done and reduce procrastination, you’ll do well to stop treating your future self like some heroic fixer-of-everything-workslave, and instead treat them like a dearly loved one.

Someone you care for, someone you want to be happy and comfortable and stress-free.

Subconsciously, we think of that future self as if it were another person, and we saddle them with the consequences of today's slagging off.

But future self is not another person.

Future self is you.

If you want to reduce stress, worry, anxiety and procrastination, and get more done:

Make it a habit to make life easier for your future self.

&nbsp;

<hr />

On another note:
I'm building an app that coaches you on working your pipeline, moving your deals forward - and closing them faster and at better rates.
It's called SalesFlow Coach, and we're scheduled for beta-release in June 2022.
Register <a href="https://martinstellar.com/salesflow-coach-launch/">here</a> to be notified when it goes live.

---
title: Careful With Other People's Problems...
status: publish
datePublished: '1576488567'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft  wp-image-22398" src="http://martinstellar.com/wp-content/uploads/2019/12/MartinStellar_Coaching_Illustrations-Careful-with-other-peoples-problems-1024x1024.jpg" alt="" width="348" height="348" />It’s good to be compassionate and caring, to look out for others and help when you can.

But there are certain types of people you need to be careful with, especially if other people’s wellbeing matters to you greatly.

The first type of person is the Taker (as opposed to Givers and Matchers - see Adam Grant).

Takers only receive, and don’t give back nor do they pay forward - and you can deplete yourself completely, dealing with those people.

Then there’s the people who don’t realise that their problems are affecting others.

These are the people who always create drama, who amplify problems, who blame and rant and rave and complain bitterly - and consistently leave you worse for having dealt with them.

Avoid those people.

We all have problems, and only those who own their problems end up solving them.

Those who don’t dare look in the mirror don’t benefit from our help.

Because ‘helping’ someone who doesn’t take ownership isn’t helping - instead, it’s enabling their destructive behaviour.

I suppose it’s related to ‘misery loves company’, and so you get dragged down to their level of misery. Their problems - Somebody Else’s Problem, or SEP as Douglas Adams called it - become yours.

And you’ll agree that this doesn’t help them. And, if it leaves you worse off because now you’re saddled with someone else’s problem, you’re less able to properly help those who do take ownership, and who want actual help instead of enablement.

So to make sure you perform and help and serve as best as can:

Never let an SEP (Somebody Else’s Problem - kudos to Douglas Adams) become your problem.

If you’re going to help, help those who’ll benefit. It’s the only way to give people your best and have it actually have an effect.

Cheers,


Martin

---
title: 'Actor vs Perceptor: Bring Out the Popcorn'
status: draft
datePublished: '1496143941'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/ac160110-b7ba-482f-917a-7d435e6b628c.png" width="400" height="251" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/ac160110-b7ba-482f-917a-7d435e6b628c.png" data-file-id="4834641" />In a few days from now, my uncle will arrive for an extended stay. (Well he’s not really an uncle but he used to visit the monastery way back when, and my girlfriend and I shared a house with him when we moved to Spain a decade ago. He’s practically family).

Anyway, he’s an extremely interesting and inspiring guy.

Retired photographer, highly intelligent, takes no BS from anyone, and a truly caring individual.

I’ve learned a lot from him, and of the lessons is to see your life as a movie.

Which is very similar to what our abbot used to teach us: to be the perceptor rather than the actor.

Or, as the Sufi’s would have it: to be IN the world, but not OF it.

It’s a brilliantly powerful way to see things.

It helps you not be swept away by events and it gives you the distance to observe objectively, rather than experience everything as directly affecting you.

I can go into the whole psychological explanation about ego and Id and the difference, but really it’s just something to experience for yourself.

No explanation necessary.

Try it, right now.

You’re here, in your body, reading this email.

Now get up mentally, step back, and out of the scene you’re in.

Look at yourself sitting there, reading. As if you’re watching an actor in a movie or on a stage.

Yes, bring out the popcorn if you like.

This state, where you are the observer rather than the doer, is fortitude and clarity in practice.

After all, it's a miraculously magical experience to be alive - IF you want to see it that way. And being the perceptor helps you with that.

And it will help you live one of my favourite concepts: Why so serious?

So I say, practice this, and make it a habit throughout your days.

You just might be amazed at how it can change the way you experience life.

And the same is true if you decide to work with a coach - and if that’s what you want, I’m only one email away.

Cheers,

Martin

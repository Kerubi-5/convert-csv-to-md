---
title: Making People Happy? Yes, but What About the Money? 🤔
status: publish
datePublished: '1651535538'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - Ethics and marketing
  - How to sell your work
  - "Psychology in sales and\r\n\t\t\tmarketing"
  - Relationships
  - Values

---

<img class="alignleft wp-image-23228" src="http://martinstellar.com/wp-content/uploads/2020/04/MartinStellar_Coaching_Illustrations-Making-people-happy-want-the-money-1024x768.jpg" alt="" width="345" height="259" />

Sane and ethical business owners don’t just want the money:

They also want their buyers to be happy for having bought.

But wanting happy buyers isn’t enough.

You also have to want the money - and there's nothing wrong with that.

If you don’t have financial goals for your business, and you only measure how happy people are, or how many of them you have, you’re working to reach a moving target.

How much happy? How many people happy? How scalable is their being happy, if you’re not looking at the financial goals that enable you to re-invest, scale up, reach more people, make more people happy?

I meet a lot of wonderful people, committed to serving their clients and doing stellar work for them.

But everyone I meet who only wants happy customers, and does not also want to reach specific money goals, struggles.

And you don’t have to struggle.

All you have to do is want the best of both worlds:

Want happy buyers, and:

Want the money.

<hr />

On another note:
I'm building an app that coaches you on working your pipeline, moving your deals forward - and closing them faster and at better rates.
It's called SalesFlow Coach, and we're scheduled for beta-release early May 2022.
Register <a href="https://martinstellar.com/salesflow-coach-launch/">here</a> to be notified when it goes live.

&nbsp;

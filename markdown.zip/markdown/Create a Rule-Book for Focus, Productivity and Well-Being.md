---
title: Create a Rule-Book for Focus, Productivity and Well-Being
status: publish
datePublished: '1536910349'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-20899" src="http://martinstellar.com/wp-content/uploads/2018/09/MartinStellar_Coaching_Illustrations-Things-to-say-no-to-1024x768.png" alt="" width="352" height="264" />I walk into the hall and smile: it’s just as I expected.

Beautiful art on the walls. Lots of visitors, Spanish as well as foreigners.

Drinks, tapas, and a bunch of my artist friends, looking their finest and happily chatting with each other or the visitors.

I meander for a while, chat with a few people, see the art.

And then, just as I expected, I find myself on my own, with everybody else being busy serving drinks or getting called away or saying hi to newcomers.

I meander some more, have a few more conversations cut short, and about 20 minutes after arriving, I leave.

On the way home I reflect: it’s like this every single time. I just don’t like the kind of event, where no conversation lasts more than 3,5 minutes.

I like supporting my friends, but show openings, and network events and that kind of thing - if there’s no chance to actually connect with people I don’t like it and I always leave early.

So I decide: no more social events like that - unless I go there with a friend to chaperone me.

Just no. No more.

Felt good, too. Made me call a friend a few weeks later who went with me to another event and we had a great time.

And I decided (because hey, everything comes down to decisions, right?) to create a ‘No-List’.

Things I’ve said no to.

On it are such diverse things as:

- Takers. People who take but never give back or pay forward. You know what they look like: a black hole with legs under ‘em.

- People who eat my mind. That you keep pondering about because of something unfinished, some sort of open loop and your mind keeps churning on it.

- “Fixing the printer” - i.e. small jobs that I’m not good at, are not in my ‘zone of genius’ (google it) and that I can get done for a couple of bucks.

- Projects that are unrelated to my core business activity (obviously: coaching, and currently: launching my Calibrate Reality course).

And a bunch more, which are too personal to share here.

It’s nice to have a list like that, and damn useful too.

A mini rule-book for keeping Martin happy, focused, and productive.

Big contribution to my recent productivity, I can tell you that.

So maybe create your own no-list?

It’s bound to keep the crud out of your life and make you focus on what truly matters, in terms of people, your state, and your business growth.

&nbsp;

---
title: How Did I Miss That?
status: publish
datePublished: '1568024978'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft  wp-image-22044" src="http://martinstellar.com/wp-content/uploads/2019/09/MartinStellar_Coaching_Illustrations-How-did-I-miss-that-the-problem-with-heuristics-1024x768.jpg" alt="" width="355" height="266" />It’s staggering, the amount of information coming at us - and if we were able to perceive the right things and not the noise, we’d have super clarity all the time.

Your gut tells you whether you should turn left now, or at the next corner.

Your fridge contents tell you what might be for dinner.

Your list of todos is dying to tell you what’s most important and most urgent, right now.

Your list of potential customers to follow up with clearly tells you who’s the best person to connect with, today.

Each potential customer tells you, literally (though not always explicitly), why they would want to buy, why they wouldn’t want to buy, and what problems or objections they’re contemplating.

But in all the examples above, we don’t get it. Don’t see what’s there. Don’t hear the message that’s being sent.

Why? Because Heuristics. Wikipedia says heuristics is:

“...any approach to problem solving or self-discovery that employs a practical method, not guaranteed to be optimal, perfect, or rational, but instead sufficient for reaching an immediate goal”.

That practical method, in terms of the billions of signals and thoughts and emotions that we are present to throughout a day, works like this:

Your brain automatically, and blazing fast, filters through the multitude, and select a tiny tiny portion - that’s the bit that shows up in your conscious awareness, because the 'immediate goal' is called 'keeping you alive', and it can only do so if it makes fast decisions about people, things, feelings, thoughts, and events.

All the rest, the stuff that your subconscious guesses isn’t crucial, goes straight to the recycle bin, unnoticed and not leveraged or used.

That fast-filtering process is the heuristic technique we use to navigate a complex, confusing, and potentially dangerous world, and it works rather well for keeping us alive.

But it also has a cost, because between all the noise that your brain filters out and tosses in the trash, there’s also gems in there.

It’s the ‘god how did I miss that!’ stuff.

It’s when a client makes a passing comment about a secondary outcome they want, one that they think isn’t all that important or urgent, but would be nice to have at some point.

For example: maybe you build websites, and one of your add-on packages is SEO.

While talking, a potential buyer says they need a site now, and casually makes some half-finished comment about ‘some SEO in the future, after XYZ is done.

If you hear it, you have a chance to upsell.

If you miss it, you lose out on potential revenue - and don’t think this doesn’t happen.

You’d probably be the only person in the world who never said ‘how did I miss that’ or ‘man, I should have replied XYZ to that’.

Heuristics are handy, but don’t let the assumptions your subconscious makes about the world be taken for true and factual.

If you do, your mind will conclude ‘solved!’ and stop looking, and that’s how we get to be blind to the knowledge and insight that staring us right in the face, amidst the noise and clutter, 24/7.

What you need to know, decide, do or say is visible to you, right now.

If you don't see it, it's because

How to see it?

Well, you can get all philosophical about the nature of reality and the role our perception plays, but it can be easier and more fun (after all, trying to convince yourself (or others) that how you (or they) see the world is different from how the world really is, is a pretty pointless exercise. I've tried both).

Your subconscious might make incorrect assumptions about what's important or not, but it's also smart. If you ask yourself the right questions, it'll answer them as the faithful servant it is.

The best question to ask, for bringing into view things that are important?

"What am I missing?"

No matter how sharp your vision, how astute your grasp on reality, you will, always be missing something. So ask yourself what that thing, the important or crucial missing bit, is.

"What are you missing?"


Cheers,


Martin

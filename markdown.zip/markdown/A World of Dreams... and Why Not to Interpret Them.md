---
title: A World of Dreams... and Why Not to Interpret Them
status: draft
datePublished: '1493029347'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/429cae6a-6cb0-4a51-b0d5-3c109119b2b2.png" width="200" height="266" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/429cae6a-6cb0-4a51-b0d5-3c109119b2b2.png" data-file-id="4834541" />I’ve never been too big on dreams.

People get themselves all worked up over the meaning of this or that symbol, assign importance to specific elements, interpret and collocate...

But what really do we know? For one thing, even if we remember lots of one dream, is that all that happened while we were asleep?

I don’t think so. In my years of meditating and learning shamanic voyaging, I’ve spent countless hours exploring the subconscious.

And let me tell you: it’s big. You may think that a mountain is big, but the world underneath the surface of our daily mind is enormous. Bigger than any mountain you can think of.

And what our little mind remembers from a dream is just a tiny tiny fraction.

And whatever we interpret or explain is nothing more than an abstraction of that small thing.

So to me, dreams can be fun, but they only paint a very tiny picture, and that’s why I think it’s better to not interpret dreams, but rather treat them as questions.

It’s not what the dream tells you - you’ll get far more out of not trying to assign meaning or interpretation, but instead asking ‘what else does this mean? What else does that tell me?’

That way you keep open the door to more insight, instead of closing it down by saying ‘Well that’s what it means, now I know’.

There’s always more. Keep asking, keep looking for ‘what else?’ and never be satisfied with any given answer.

Now I wanted to tell you this and then smoothly transition into reasons why you might want to join my mastermind coaching group.

But it looks like it’ll be a rickety segway, at best.

So I’ll just give you the link where you can find out more about Cabal Membership: <a href="http://martinstellar.com/cabal-group-coaching-action-takers/" target="_blank" rel="noopener noreferrer" data-cke-saved-href="http://martinstellar.com/cabal-group-coaching-action-takers/">http://martinstellar.com/cabal-group-coaching-action-takers/</a>

Cheers,

Martin

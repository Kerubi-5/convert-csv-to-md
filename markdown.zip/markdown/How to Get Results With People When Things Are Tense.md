---
title: How to Get Results With People When Things Are Tense
status: publish
datePublished: '1627472151'
categories:
  - Talking words

---

<img class="size-medium wp-image-27873 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/07/MartinStellar_Coaching_Illustrations-Labelling-emotions-300x225.jpeg" alt="" width="300" height="225" />Let's talk about communication.

You know, that thing humanity always does all the time - we're always communicating something, but very often we don’t communicate very well.

So here's a very quick fix to help you get better at communication and get better results with people.

The other day, a friend sent me a message to call me out on something. I had promised I would do a thing, but then life got in the way and I didn't do it, and I didn't update him.

And so he had a right to be upset, and he was completely justified in calling me out.

But in the text exchange, he ended up calling me names - nothing serious, but it was not necessary, you know?

So while he was working towards a solution, he actually got the opposite of what he wanted.

It turned into a bit of a standoff, and it became a thing that had to be resolved.

We had a goal and everything got resolved and everything is fine, but he could have gotten completely different result if he had used this one little trick.

Instead of telling me that he feels I'm this or that, he could have said:

“I feel really angry right now”

Or “I'm really frustrated”, (or annoyed upset or what have you).

When you do that - when you label your own emotions - you remove any opportunity for the other person to feel offended, or upset, or attacked.

And so you don't trigger any reactance - you don't trigger any negative response.

Because you're making it about yourself, pointing at your own state, and then the other person is invited to consider your point of view.

And that is a very open, very friendly way to move through conflict or standoff or anything that needs to be resolved.

Very often we get this wrong.

Instead of putting the situation on the table and saying “This is how I feel”, we end up inadvertently making the other person feel attacked, or hurt, or defensive.

The simple, powerful solution that nearly always creates a breakthrough in a conversation of any kind?

Label your emotions.

Hey, and if you want to learn how that - and much more - works in the context of your sales, <a href="https://martinstellar.com/helping-good-people-sell-more-and-generate-a-bigger-impact/">have a look here</a>.

---
title: "How to Benefit From the Holiday Season Without Having To Run a Single Ad or Offer a\r\n\t\t\tDiscount"
status: publish
datePublished: '1606727946'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<p class="p1"><img class="alignleft wp-image-26027" src="https://martinstellar.com/wp-content/uploads/2020/11/MartinStellar_Coaching_Illustrations-Sell-a-cork-300x225.jpg" alt="" width="355" height="266" />Yay. It’s the season. The season when everyone and their donkey is mailing out offers.</p>
<p class="p1">Discounts, special deals, time-limited offers, promotions… what a time to be alive, right?</p>
<p class="p1">You may or may not have wondered why I don’t jump on the season’s sales bandwagons.</p>
<p class="p1">After all, I do marketing. Run a business. Have things on offer. So what gives?</p>
<p class="p1">Well, in my opinion, you don’t need all that stuff.</p>
<p class="p1">Sure it can work, and sure you can rack up sales.</p>
<p class="p1">But if you get your people, and you know their problems and desires and urgencies, you can do a lot better without all the noise and hype, by simply presenting people with offers that are highly specific to the solutions they’re already looking for.</p>
<p class="p1">When you do that, you stand out from the crowd.</p>
<p class="p1">Because let’s face it: most sales campaigns are spray &amp; pray.</p>
<p class="p1">Blast an offer out to a list, see who picks it up, close the sale.</p>
<p class="p1">Which means you waste a bunch of people’s time, because those people weren’t looking for your offer. Also means you get unsubscribes from people who’d eagerly pick up another offer at another time.</p>
<p class="p1">So instead of blasting all those jolly season’s sales campaigns, why not offer people something that you, with a high degree of certainty, know certain people will want?</p>
<p class="p1">Enter: Hidden Revenue Opportunities.</p>
<p class="p1">This is a system I designed with my business partner Antonio, to analyse your past buyers, to figure out which segments in that customer list might want which product or service, and to present a pitch that’s designed to be highly attractive to just that segment.</p>
<p class="p1">Because these here are business facts:</p>
<p class="p1">A past buyer is the most likely individual to give you money for something else</p>
<p class="p1">Your customer list holds value - monetary value</p>
<p class="p1">Segmentation and targeting enable you to make highly desirable offers to the right people</p>
<p class="p1">And that’s why we built the Hidden Revenue Opportunities service:</p>
<p class="p1">To enable a small or medium sized business, to generate upsells by re-activating past customers.</p>
<p class="p1">Because the money is in the list - but, how do you get that money out of the list?</p>
<p class="p1">By analysing, segmenting, and making offers.</p>
<p class="p1">And that’s what we do.</p>
<p class="p1">Currently and until further notice, this 4-hour service is available at $1500 launch price.</p>
<p class="p1">In the new year, that will change and the price will go up.</p>
<p class="p1">Until then, you can get our help to surface money ready to be made, in a list of customers you already have.</p>
<p class="p1">No hype or season’s sales required.</p>
<p class="p1"><a href="http://martinstellar.com/download/25970/">More information here.</a></p>
<p class="p1">Cheers,</p>
<p class="p1">Martin</p>

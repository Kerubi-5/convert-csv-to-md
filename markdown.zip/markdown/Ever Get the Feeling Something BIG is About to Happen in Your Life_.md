---
title: Ever Get the Feeling Something BIG is About to Happen in Your Life?
status: draft
datePublished: '1511780142'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/bdc712e3-bf9e-473c-9a9b-08b57966d984.png" width="350" height="336" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/bdc712e3-bf9e-473c-9a9b-08b57966d984.png" data-file-id="4835229" />That there has got to be something else, or something more… for you in store?

Do you ever get that auspicious, portentious, pregnant feeling - as if there’s something big and beautiful so very close, but you don’t know what it is or what you can do to reveal it in your life?

I think we all get that to some degree, at different times.

And this time around, I don’t have any answers. I don’t know what that is.

Except, maybe it’s our selves - our ego - trying to break out of its confines.

Because for all that an ego can accomplish in life (create a family, build an airplane, launch a company, write a book, change someone else’s life), there’s a definite size limit to the ego. No matter how big it is.

And it’s only happened a few times in my life, during meditation, that I could experience being - but without the Martin-sized container that limits existence down into manageable perception-bites.

So maybe the feeling of portent we get, maybe that’s simply a call, a beckoning… for us to dare let go of the ‘I’ that limits us, and step into a less confined way of experiencing life.

l lived with that feeling for years, back in the monastery. A constant feeling as if the curtain was just about to be torn aside.

But it never was, and that was ok.

Because I got used to the feeling, and instead of waiting for the magic to happen, I learned to roll with it, to listen to that feeling, and I learned to use it as a kind radar.

That feeling that something’s just about to happen, it can help you be more present, more aware, and more perceptive to opportunities.

And all it takes is for you to get used to it. Ease into it, just like a hot bath.

Sit with it. The feeling is there to help you, so long as you listen to what it tells you.

Out there?

Maybe.

But definitely part of the human psyche.

Question is: what will you do with it?

Cheers,

​Martin

---
title: Dull Axes and Boxes of Unused Stationary
status: draft
datePublished: '1535962041'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-20771" src="http://martinstellar.com/wp-content/uploads/2018/08/MartinStellar_Coaching_Illustrations-Secret-Weapon-Holding-it-wrong-1024x768.png" alt="" width="351" height="263" />Back in my tailoring days - before the bankruptcy hit me - I had a lot of decisions to make.

Should my website run on Joomla, or Wordpress?

Should I advertise, or blog, or network? All of the above?

Some decisions were bad: for an end-user, Joomla really isn’t a handy platform to use - but I was sold into it, and each time I had to publish a blog post, it was a struggle.

Other decisions were good: to start blogging, and to interact on forums. Got my name out, built trust, and got me clients.

And then there were terrible decisions. For example, I knew I needed stationary. So I debated: do I get a quality printer and print at home - or do I buy in bulk from a professional printer’s?

I decided the latter - which was pretty dumb, because ‘best price’ meant ‘1000 letterheads and 1000 envelopes’. Cost me almost a grand, and guess what:

When my company finally tanked a few years later, I hadn’t even used 5% of the stuff.

Because honestly: if a suit takes me 80 hours to make, and there’s another 20 hours of business operations, travel, and marketing to spend for each suit, how many invoices would I be sending each year?

Exactly. Just a handful -  certainly not 1000. If I’d bought a good printer, I’d have saved a lot of money.

But, I didn’t think it through. Tried to, but ended up making an irrational decision.

Have you ever made decisions that brought you wasteful or unwanted outcomes?

Ok, silly question. We all do.

But there’s a solution, and it’s called rational thought.

And you’re perfectly capable of that - AND of making sensible, logical decisions.

Just means you need to sharpen the axe.

Supposedly, Abe Lincoln said “If I have 6 hours to cut down a tree, I’ll spend the first 5 sharpening the axe”. So sensible, right?

Yeah I know. So here’s sense for you:

Sharpen the axe that’s called ‘your mind’.

Which is surprisingly easy.

Step one: stop to think. Don’t rush.

2: Watch for assumptions and guesses. Question them.

3: Write stuff down. Journal, brainstorm, doodle. Don’t try to do it all in your head - even mathematicians and chessmasters use chalkboards, and there’s a reason for that.

4: The big one: only decide if, and when, you’ve reached logical, rational clarity. And even then, consider your ‘best choice’ decision a hypothesis to be tested, not a ‘this is it!’ answer to everything.

5: Adjust your plans, actions, and decisions as results come in - instead of clinging to what you thought was the right choice but is turning out to be imperfect.

Repeat, over and over again.

Of course there's more that goes into sharpening the axe called 'your mind'. But without at least these steps, you'll just continue guesstimating, throwing spaghetti at the wall to see if it stick. And getting the outcomes you've always gotten.

Change your ways, maybe?

Choices, choices...

Cheers,

Martin

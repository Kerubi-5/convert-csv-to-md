---
title: 'Foundations of a Healthy Business: Two Questions You MUST Ask'
status: publish
datePublished: '1660890431'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-22593" src="http://martinstellar.com/wp-content/uploads/2020/01/MartinStellar_Coaching_Illustrations-Why-should-people-do-business-with-you-USP.png" alt="" width="349" height="226" />

It’s the most fundamental question in any business, and yet: it’s one of the questions easiest to skip over (scary how often people have no answer to it!):

Why should people do business with you, instead of someone else?

In other words, why you? What’s unique about you? Why are you the best choice for specific people, or put differently:

What’s your Unique Selling Proposition?

Until you know the answer to that, you’ll find it real hard to land clients.

And no, “Because my training rocks”, “Because I have credentials”, or “Because I’m awesome” are not correct answers.

The only correct answer to ‘why you?’ is what your buyers tell you is the answer. No matter what you may think the reason is, you're only right if you heard it from the horse's mouth.

The second question to ask yourself:

Why should people do business with you now, instead of later?

What distinction is there, between the people who want you to solve a problem now, and those who'll get to it some day?

Asking that question helps you identify the people who have urgency, so that you can focus on them and ignore the people who have a someday-problem.

If you want buyers, focus on people who have a now-problem.

Talk to your buyers to figure out why they chose you, and ask them what made it a now-thing to invest with you.

With that info, you'll be able to focus on people like them, and not waste time on people who aren't the right fit.

&nbsp;

<hr />

On another note:
I'm building an app that coaches you on working your pipeline, moving your deals forward - and closing them faster and at better rates.
It's called SalesFlow Coach, and we're scheduled for beta-release in June 2022.
Register <a href="https://martinstellar.com/salesflow-coach-launch/">here</a> to be notified when it goes live.

&nbsp;

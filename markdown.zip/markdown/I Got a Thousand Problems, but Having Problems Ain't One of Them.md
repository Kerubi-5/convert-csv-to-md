---
title: I Got a Thousand Problems, but Having Problems Ain't One of Them
status: draft
datePublished: '1495731515'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/79539206-eee7-4e56-b8d1-ed7e7bded7ea.png" width="350" height="197" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/79539206-eee7-4e56-b8d1-ed7e7bded7ea.png" data-file-id="4834613" />Had enough yet?

Hey look, we all have things to deal with. Issue to sort out, problems that show up.

But you do get to choose whether or not things are A PROBLEM or not.

Because yes: that’s a choice. An attitude that follows a decision.

Like a client of mine, the other day.

Decided to simply be done with having problems. Had enough.

And boom. Life changed.

That doesn’t mean problems disappear.

And it doesn’t mean you ignore them either.

All it means is that you let whatever problem you may face, be what it is, without paying all that dramatic attention to it.

Sure you can worry and fret, but does that help?

It’s about focus.

Instead of spending your energy on what’s wrong, why not focus on what’s right, and make it even better?

9 out of 10 times, problems solve themselves, and you know it.

And the more you stop being so busy dealing with problems, the easier they will do that.

Me I’ve not had a single problem in years.

And this client has stopped having them too.

What about you? Had enough yet, of having problems?

Cheers,

Martin

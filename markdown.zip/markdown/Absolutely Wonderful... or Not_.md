---
title: Absolutely Wonderful... or Not?
status: publish
datePublished: '1588932172'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - How to sell your work
  - Psychology in sales and marketing
  - Relationships

---

<a href="http://martinstellar.com/wp-content/uploads/2020/05/MartinStellar_Coaching_Illustrations-ideal-clients-and-hell-no-clients.png"><img class="alignleft wp-image-23593" src="http://martinstellar.com/wp-content/uploads/2020/05/MartinStellar_Coaching_Illustrations-ideal-clients-and-hell-no-clients-1024x768.png" alt="" width="354" height="266" /></a>Some people are just a dream to work with. They show up on time, they ask ‘ok but how’ instead of saying ‘yes but’, they take ownership of change, and they make it exceedingly fun to be in business.

“THIS is why I’m my own boss!”

Others though, are a struggle to deal with, cost way too much energy, and make the process of serving them hard on you - and on themselves as well.

This is why every business owner needs to know who is their ideal customer.

But, that’s not enough.

You also need to know exactly who are the people that you do not want to work with.

Otherwise, you’ll be looking for the ideal client, and you’ll miss the signals that this or that potential client is going to be a major pain in the sitting apparatus.

And once those folk come through the door, dealing with them and serving them is going to be a hassle and a struggle.

So:

Make a ‘hell no’ list, of all the things that a client should NOT have or be, for working with you.

Then, spend some time thinking about what signals those markers to you.

For example, in my business, I can’t work and won’t work with anyone who doesn’t take full ownership of change. My clients need to own their problems. Otherwise, it’s a hard no.

So in the application questionnaire they fill out, one of the questions is: “What’s the biggest obstacle that stands in your way?”

If the answer is anything other than a clear signal that they themselves are the cause, it’s a no.

(There’s a bunch of other markers I look for as well, but this one is one of the biggest).

So make your ‘hell no’ list, and identify the different ways in which people could signal to you that they are people you ought not work with.

Next?

Better clients, more fun, less hassle.

Oh, and if you ARE the kind of person who takes ownership, and <a href="https://forms.gle/CKeNWg9c5ivi1jDF8" target="_blank" rel="noopener noreferrer" data-cke-saved-href="https://forms.gle/CKeNWg9c5ivi1jDF8">you want to upgrade your business and revenue, here is that questionnaire. </a>

No cheating on the crucial question though…

Cheers,

Martin

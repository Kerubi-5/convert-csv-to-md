---
title: Do We Even Know How to Think?
status: draft
datePublished: '1504283667'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/73f532ba-7525-4311-bf64-1565176ee32c.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/73f532ba-7525-4311-bf64-1565176ee32c.jpg" data-file-id="4834977" />I don’t know why, but it seems that in our culture, we’re not taught how to think.

Proof abounds: whoever you talk to, you’ll always hear things like “that would never work” or “I can’t” or “it never been done before” and similar nonsense.

So let’s play a game.

It’s called “limitless thinking” and it goes like this:

Step 1: what would you like to do, build, or create?

Step 2: what reasons does your mind give you, reasons why it can’t or won’t work?

Step 3: imagine none of those obstacles existed… as if there’s no limitations to what you can accomplish…

Now for the fun part, step 4: in a world without any obstacles or limitations…

What would you do to make that dream a reality? What action would you take?

Final part of the game: do the thing that most closely resembles that action, but adapted and adjusted to the world we live in…

Watch what happens after that (especially watch what happens to your inner state)… and then ask yourself: what can I do next?

If you keep this up, you won’t magically transform the world into a place where everything is possible, but:

You will, most definitely discover that there are more possibilities than you imagined.

So… want to play?

Cheers,

​Martin

&nbsp;

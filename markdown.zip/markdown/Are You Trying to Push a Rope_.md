---
title: Are You Trying to Push a Rope?
status: publish
datePublished: '1596415282'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-21790" src="http://martinstellar.com/wp-content/uploads/2019/06/MartinStellar_Coaching_Illustrations-When-you-seem-to-be-pushing-a-rope-1024x768.jpg" alt="" width="352" height="264" />Further to last Friday’s article about 'units of you' and prioritising growth-driving activities in your business…

What if you try with all your might, and results just won’t show up?

Instagram, Facebook, outreach, proposals, trade shows, networking… you know you’re doing the right things, and things should be working and improvements (or at least: promise of results) ought to manifest, and yet… it’s like you’re treading water?

As if you’re trying to push a rope...

When things aren’t working, it’s easy to get disheartened and conclude that it just isn’t going to get better.

And when you reach that point, it’s easy to stop trying, give up on your efforts, and go back to the day-to-day activities that give a false sense of achievement. It’s happened to me, and you’ve probably had it happen as well.

But what if you step back for a moment, and look at your activities (the ones that aren’t getting you the results you want), and analyse the results that you do get?

There’s nothing you can do that does not have some sort of effect.

But because we expect Activity A to brings us Result B and that result isn’t showing up, we nearly always ignore the small results that are showing up. The progress indicators, the 'metres clocked' on your marathon.

And yeah, those probably don’t bring clients through the door… yet.

But they are an indicator of what could happen if you intentionally try to amplify those small, easily overlooked, results.

That holds much more promise than pushing on, trying to push a rope - or, by contrast, cancelling your efforts, throwing the baby out with the bathwater, and going with the next shiny object.

There are times when you need to take stock, and radically reinvent and replace your strategy.

But those moments are rare, and in most cases, all you need is a clear hard look at how results and indicators measure up to effort; and make subtle, strategic adjustments to your strategy and/or approach.

There’s a difference between doing the right thing, and doing the right thing correctly.

Small changes and strategic shifts can have a big effect on your outcomes, but dropping your growth-driving activities will likely cancel all the positive outcomes you’re working towards.

This is why I created the Strategic Accountabiliy Coaching programme: to help smart, driven entrepreneurs stay focused on, and executing on, those activities that will ultimately cause you the hard-number results you want.

<a href="https://martinstellar.com/strategic-accountability-coaching/">Check it out here...</a>

Cheers,

&nbsp;

Martin

&nbsp;

&nbsp;

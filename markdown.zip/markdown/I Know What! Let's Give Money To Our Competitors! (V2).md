---
title: I Know What! Let's Give Money To Our Competitors! (V2)
status: draft
datePublished: '1623200095'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - How to sell your work
  - Psychology in sales and marketing

---

<a href="http://martinstellar.com/wp-content/uploads/2020/05/MartinStellar_Coaching_Illustrations-Stop-giving-money-to-your-competitors-1.png"><img class="alignleft wp-image-24697 " src="http://martinstellar.com/wp-content/uploads/2020/05/MartinStellar_Coaching_Illustrations-Stop-giving-money-to-your-competitors-1-1024x1024.png" alt="" width="352" height="352" /></a>Of course, you wouldn’t say that.

Nobody in their right mind would give money to the competition.

Except, pretty much every business does it.

How?

By not showing up to the people who need you.

Consider:

Someone out there has a problem, and you happen to be supremely qualified to solve it.

That makes it your job - your responsibility - to connect with that person in such a way, that they’ll say:

“Love it. Here’s money. When do we start?”

And if you don’t do that?

Well, then in lots of cases, that person is going to go to your competitor, who actually does do the work of showing up and enrolling the person who has the problem, and who is looking for a solution.

And thus, by not marketing and selling your work, you effectively give money to your competitors. Ouch.

Of course you could argue that people know you exist, and that they'll let you know when they're ready.

And yes, that's probably true.

But while you're waiting, sitting on your hands, your competitor is actively engaging in conversations with buyers - and therefore they are the one who gets the sale.

Want to earn well, serve people, get the deal and have the impact?

Don't sit and wait:

Get out there and talk to people.

And if you're uncertain about how to do that, or you're not comfortable with it:

<a href="mailto:hello@martinstellar.com">Let me know</a>, because that's exactly the kind of thing I can help you get around.

&nbsp;

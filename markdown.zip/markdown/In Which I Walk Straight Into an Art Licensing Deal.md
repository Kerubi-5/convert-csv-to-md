---
title: In Which I Walk Straight Into an Art Licensing Deal
status: draft
datePublished: '1496770354'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/ae3080a9-2d07-4dc2-8a5d-3064cc33560e.png" width="350" height="197" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/ae3080a9-2d07-4dc2-8a5d-3064cc33560e.png" data-file-id="4834661" />
Ok Martin, not so fast.

Or, as we say in Holland: you don’t sell the skin until you shoot the bear. I didn't actually get a licensing deal... but maybe, at some point, I just might.

Still, this meeting with Maria Brophy yesterday, was absolutely stellar.

What a gal. What a heart, what a mind.

Surprised me too, because I often find myself in a coaching position with people because, well, I can’t help myself - but she turned the tables and gave me some of her coaching in return.

Totally worth the drive, getting up here and meeting her.

Anyway, I mentioned that perhaps she and I would create a programme together.

And while I didn’t expect her to be in the mood for discussing it, what with being on a pilgrimage and all, we ended up talking about it, and we made a deal.

A pact, if you will.

I can’t tell you the details yet, but it just might turn out something really very cool.

And it involves licensing art.

And if it comes to fruition, and we decide to launch it, it’s going to be very very interesting for all my readers who are artists (and I know that’s a lot of you).

So stay tuned. Things might get very interesting.

Cheerio,

Martin

---
title: 'Mini-Training SIBG 2.0: The Grow-Up Stage'
status: pending
datePublished: '1642507025'
categories:
  - Assets and Leverage
  - Business and systems
  - Business Growth Fundamentals

---

<img class="size-medium wp-image-28545 alignleft" src="https://martinstellar.com/wp-content/uploads/2022/01/MartinStellar_Coaching_Illustrations-Stages-and-ingredients-of-business-growth-mini-training_Grow-Up-phase-300x225.jpeg" alt="" width="300" height="225" />

[Mini-trainings / Stages and Ingredients of Business Growth / Pt 2.0]

So you've gone through the exercises of defining your USP, your Customer Avatar, and your Goto-Market Strategy:

Congratulations, you've now Set Up your business, and it's time to Grow Up.

Where, to remind you, the Set Up stage is where you turn a business idea into a revenue-generating set of actions, rules, and principles, and you prove that it's viable.

Meaning, people are willing to pay you money.

With that, you can now start to systemise and automate things.

Now to some people, that sounds like the death of all fun - I mean, we don't want our business to become a dreaery slog of repeating actions, right?

No, not at all - and that's precisely why you should systemise and automate things.

Not so that you become a robot-operator in your business, but so that you can start engaging the help of others, to do things that are below your pay-grade, so that you can focus on the fun, challenging, innovative and creative things that light you up.

Think of it like this:

Systemising and automating is like installing an engine on a cart that so far, you've been pushing by hand.

Essentially, it means you look to fire yourself from all activities that aren't strictly in your Zone Of Genius (see: Gay Hendrix, The Big Leap).

That way, you can work exclusively on those things that are.

So in the grow-Up phase, there's three core areas of focus:

1: Create systems and SOPs

2: Define metrics and set up measurement

3: Outsource or delegate

Once you go through these three, what you end up with is a business that could - in theory - be replicated at another location, turned into a franchise, or indeed: sold as a standalone, profitable venture.

And while the majority of my readers might not be looking to branch out, franchise or sell, it's a good idea to build a business that would enable it.

Because once a business is at that stage, you get to play the scaling up game, where you invest dollars into profit, with things like ads, content campaigns, or hiring team members.

But let's not get ahead of ourselves.

We've just finished setting up, now we need to grow up - and to help with that, tomorrow lands Chapter 2.1 of Stages and Ingredients of Business Growth:

Creating systems and SOPs.

See you tomorrow!

&nbsp;

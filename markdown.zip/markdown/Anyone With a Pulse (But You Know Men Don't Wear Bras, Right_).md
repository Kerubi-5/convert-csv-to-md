---
title: Anyone With a Pulse (But You Know Men Don't Wear Bras, Right?)
status: publish
datePublished: '1607646811'
categories:
  - How to sell your work

---

<img class="alignleft wp-image-21736" src="http://martinstellar.com/wp-content/uploads/2019/05/MartinStellar_Coaching_Illustrations-Anyone-with-a-pulse-1024x768.jpg" alt="" width="356" height="267" />

Anyone with more than two fingers of forehead would know to not try and sell bras to men.

(Yes, I know: it can be argued that the size of my man-boobs warrants me wearing bras, but if you must have that argument, kindly have it with someone other than me - thanks)

Kids don’t buy cars.

(Most) men don’t wear bras.

Heavy metal fans mostly don’t listen to Bach.

You’ll never sell a steak to a vegan.

Someone with arachnophobia will never buy a subscription to Spiders Monthly.

Makes so much sense, and yet:

The majority of business owners make hardly any effort to find out which kind of person is most likely to buy.

“If they’ve got a pulse, it’s a potential client” is how the thinking goes.

I’ve literally had people answer my question “Who is your ideal buyer” with “Anyone who has money”.

Sorry, no, doesn’t work.

See, there’s a market for everything, literally.

Furbies, trash novelettes, t-shirts with bizarre prints, tattoos of famous people… art, cars, yoga, smoothies, you name it.

I’ve yet to come across something that nobody will ever buy.

But whatever it is you make or do, there are people who are absolutely not interested, and people who are super-keen to get their hands on it - in other words:

The hungry crowd.

So if you find that you’re not closing enough of the sales opportunities that you have, there’s a big chance that you’re not being specific enough, that you’re trying to attract all and sundry, instead of the hungry crowd.

The result: low sales, too little revenue, wasted time, frustration, low return on your efforts and investments…

Marketing means figuring out who is the hungry crowd.

And, ethical selling means directing yourself exclusively to those people who really want, and need, what you offer.

Add in empathy, and you’ll be able to create messaging and conversations that cause people to qualify and select themselves.

The result: more sales, with less effort.

Want to get clarity on who is your hungry crowd, and discover a completely ethical method for enrolling people?

Then join me on Friday 18 December, for a full (and free) training:

<a href="https://martinstellar.com/free-training-on-ethical-selling/">How good people sell more - not despite, but <em>because</em> of their values.</a>

Cheers,

&nbsp;

Martin

&nbsp;

&nbsp;

---
title: In Love With Life and With Your Business
status: draft
datePublished: '1525105825'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/9ea074bc-c6c5-4216-8b04-5f7d0a48d7b9.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/9ea074bc-c6c5-4216-8b04-5f7d0a48d7b9.jpg" data-file-id="4835677" />Artists will know what I’m talking about:

Imagine you’re drawing a portrait.

It all looks good enough: the eyes and mouth are in the right place, nose too&amp;not upside down… shading is correct… it’s all there.

And yet, there’s something missing. Something is not right - it seems unalive, off, not quite lifelike.

So, what if your life feels that way?

What if it’s all nice, and good, and you manage life’s tribulations fine and you have nothing to complain about, but it just doesn’t feel alive - doesn’t make you *feel* alive?

If it’s about art, the solution is simple: learn more, practice more. Probably 10% learning and 90% practice.

With life, you get to practice every day on how to best live it, so you’ve got that going for you.

That leaves the question of what to learn.

Of course, you’re already on the case: you read the books, watch the videos, go to the retreats and workshops….

But who’s going to show you what, for your case specifically, you ought to practice?

Which book will give you the exact recipe - the prescription, if you will - for coming alive, living to the fullest… where will you find the exact practices that you need in order to be utterly in love with your life and your business?

Truth is, you can’t find those in books or trainings - not in a specific way, tailored to your station in life, your vision, and to those things that make you come alive.

So who then will show you how to practice and what to practice, in order to live better?

The Cabal could show you…

My private coaching group - a very intimate, very powerful team of seasoned creative entrepreneurs.

You don’t just get coaching from me, but you also get the entire group unleash its shared compassion and wisdom on you.

And you better believe that it’ll change your world.

Membership is by invitation and interview only though - this isn’t your typical ‘open to all’ coaching group.

That’s why I hand-pick new members, to make sure that the match in terms of experience and personality will work for the group, and for the individual members.

For more info on how the group works, see here: http://martinstellar.com/cabal-group-coaching-action-takers/

Cheers,

​Martin

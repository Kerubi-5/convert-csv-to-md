---
title: 'Edge vs epicentre: why the self-help industry is broken, but you are not'
status: draft
categories:
  - Doing it right as an entrepreneur or creative professional

---

<p class="p1"></p>
<p class="p3">If your car won’t start, would you try and wash the windscreen, see if it would help?</p>
<p class="p3">Of course not.</p>
<p class="p3">Windows, mirrors, seats: those are at the edge of the car.</p>
<p class="p3">At the centre of starting and running is the engine - that’s where you start.</p>
<p class="p3">begin.</p>
<p class="p3">But in business, we very often try to remedy things that are on the outside, the fringe.</p>
<p class="p3">More site traffic, better filing system, tweaking your website.</p>
<p class="p3">Nice, useful, necessary even - but that’s not where improvement and higher revenue starts.</p>
<p class="p3">Higher revenue, more sales, higher prices: that starts at business operations.</p>
<p class="p3">But those, too, are on the edge.</p>
<p class="p3">Because at the epicentre of your business is you.</p>
<p class="p3">Optimise that, and improvements follow through in all areas.</p>
<p class="p3">You probably know this - and the self-help industry plays into that perfectly, which is why it’s generally broken and corrupt.</p>
<p class="p3">With few exceptions, most self-help sells you on the idea that so long as you <i>feel</i> that you’ve improved, you actually have improved.</p>
<p class="p3">But you may feel like a god, a king, or Richard Branson himself - and yet, somehow that doesn’t make it so.</p>
<p class="p3">Catharsis, that go-to attractive incentive of the self-help industry doesn’t change you.</p>
<p class="p3">Doesn’t improve you, your business operations, or indeed your sales and revenue.</p>
<p class="p3">Which is why <i>so many</i> of the people addicted to self-help stay stuck and hopelessly spin their wheels.</p>
<p class="p3">In many, many cases, the self-help industry tries to sell us a lie.</p>
<p class="p3">What <i>does </i>improve you however, is deliberate, intentional practice.</p>
<p class="p3">Because look, you already know what you ought to do. How to show up. That you should plan, and take time off to recover, and do outreach, and publish attractive content. You know all that.</p>
<p class="p3">But until you practice and develop the habit of doing all those things that they tell you, nothing changes, not really, not in any significant way.</p>
<p class="p3">No, if you want real change, and real money and the impact and wealth you deserve for your work, then there’s only one thing that’ll do it:</p>
<p class="p3">Action, on exactly the right things: those things that drive results.</p>
<p class="p3">I coach people daily on doing exactly those things, and while that’s normally a very intensive affair at a significant investment, I can also help you at a much lower cost.</p>
<p class="p3">Strategic Accountability Coaching.</p>
<p class="p3">It works.</p>
<p class="p3">Are you the kind of person ready to do the work, and are you fed up with just the good feelz, but not seeing the good money for all your efforts?</p>
<p class="p3">Do you want to fix not the edges, but the actual epicentre of your business?</p>
<p class="p3">I.e. you, and the way you operate?</p>
<p class="p3">Then I can help.</p>
<p class="p3"><span class="s1"><a href="http://martinstellar.com/sac">Click here</a></span> for more information on the programme.</p>
<p class="p3">Cheers,</p>
<p class="p3">Martin</p>

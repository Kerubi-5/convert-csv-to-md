---
title: Be a Bigger Ear
status: draft
datePublished: '1540984224'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21053" src="http://martinstellar.com/wp-content/uploads/2018/10/MartinStellar_Coaching_Illustrations-most-important-organ_success_perception-1024x1024.png" alt="" width="354" height="354" />You might think you’re this person thing, with a history and values and relationships and all…

But really all that is just props for enabling you to be what you really are:

A perception engine.

(inaccurately illustrated in this piece as an ‘ear’. But you get the picture).

What you are, at your most fundamental level of being human: built to perceive.

It’s what you do, it’s what you’re for.

In that sense, the entirety of ‘you’ is your most important organ.

But there’s a funny thing connected to perceiving stuff: it becomes memory.

And even funnier: you choose what kind of memories the experiences become, built specifically to perceive.

If you want to change or grow or become enlightened or wealthy (and/or, actually), the best thing you can do is become a better perceptor.

Learn, really learn on a ruthlessly honest level of self-awareness, how you are at every moment colouring and filtering your perception.

Next you choose to change your perception, and then you get the wonderful outcomes like flow and fulfillment and ease.

Not by trying to change the world around you, not even changing yourself.

Just the way you perceive: get better at choosing what kind of memories get stored up, by being deliberate about what you perceive and how to interpret it.

Because nothing, ever, is the thing you think you’re perceiving.

So become a better perceptor. Become a bigger ear.

Cheers,

Martin

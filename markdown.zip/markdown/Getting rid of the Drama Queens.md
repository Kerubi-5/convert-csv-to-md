---
title: Getting rid of the Drama Queens
status: draft
datePublished: '1499345933'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/bb6093ce-5899-4e84-9eb6-ec8540a9a688.jpg" width="350" height="207" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/bb6093ce-5899-4e84-9eb6-ec8540a9a688.jpg" data-file-id="4834777" />Some people, they just can’t live without drama.

Sometimes, I’m like that. Or rather: I used to be like that.

I remember once, talking to my abbot, he said: “You seem to have a need for problems. You skip work, or you break something, or upset someone, and then there’s a problem.

“And when there’s no problems, and everything is going fine, it’s as if that means there’s something wrong.

“And then you create a problem, and everything is alright with the world”.

Yep, smart man. Saw right through me: back then I was my own version of a drama queen.

And in business, drama-queens are something you need to watch out for.

Whether it’s employees, or clients, or people in your private life: always avoid drama.

Fire clients who give you grief, and choose the ones who want positive solutions instead.

Employees who keep tripping you up, or themselves, or your company? Have a heart to heart with them and hash it out. Get them on
board with your mission and purpose.

Family members constantly causing havoc that keeps you from your work or that makes you feel bad? Talk to them.

Because problems and drama will always occur - and it’s communication that can help you solve them.

Anyway: drama can be addictive and it can be contagious.

Don’t put up with it, least of all from yourself.

And if you’re done with drama and you’re ready for growth, then get in touch.

Because I can’t coach anyone who is stuck in creating drama - but once you’re free of that?

Could be you and I could work miracles.

Want to find out?

Cheers,

​Martin

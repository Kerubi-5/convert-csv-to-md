---
title: Green Eggs and Constraints
status: draft
datePublished: '1534838465'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

I<img class="alignleft wp-image-20726" src="http://martinstellar.com/wp-content/uploads/2018/08/MartinStellar_Coaching_Illustrations-Green-eggs-and-constraints_free-of-the-need-to-feel-free-1024x768.png" alt="" width="353" height="265" />n 1960, the founder of Random House publishers challenged Dr. Suess, saying he wouldn’t be able to write a children’s book using only 50 words. The bet was $50, and once ‘Green eggs and ham’ was written, Dr. Seuss had won the bet.

If that doesn’t tell you that constraints are good and not bad, I don’t know what will.

Oh but we want to be free. Free to use all the words in the dictionary (don’t try - writing gets worse the more flowery it gets), free to use all the crayons in the box.

And we listen to jazz soloists, thinking that they have no boundaries, no constraints. But they do: they can only sound so crazy free because they play their solos inside mathematically defined tonalities and scales.

It’s inside rigid constraints that we, just like Dr. Suess, get to explore the most extreme depths of our creativity.

And it’s our creativity that creates beauty, art, change, growth, success, wealth, you name it.

This is exactly why the monastery was so beneficial to me, because there I lived with a set of extraordinarily restrictive vows that I had chosen to take. Celibacy, poverty, obedience, the lot. Can’t get much more restricted than that.

But what that did to my mind was super-effective, and will serve me the rest of my life.

And what did it do to my mind, to live that way?

Essentially, in short, I taught my mind how to behave.

Because like I said the other day, the mind is a terrific servant, but a terrible master.

And unless you learn how to work with your mind, instead of having it work you the way it’s naturally inclined to do, you’ll find it real hard to create change in your life.

And as for that ‘must be free!’ thing that’s so popular these days?

That in itself is a prison.

Me, I’m free of the need to feel free, and that’s a wonderful thing that I recommend everyone.

I happily create restrictions and constraints. For example, a few weeks ago I decided on a very simple rule: Zero communications during my deep-work, maker time.

No checking emails, no responding to Slack, no seeing why my phone beeped - nothing but single-pointed attention. Full focus. Restrict those hours to nothing but executing on the important work.

The result? I’ve been more productive and effective than I have been in years.

So if you want to build things, create your success, live the good life, ask yourself:

Where are you allowing for ‘freedom’ (which is actually a form of childlike shirking ownership&amp;responsibility), where in fact imposing some restrictions or constraints would get you to your goals much much faster?

Cheers,

Martin

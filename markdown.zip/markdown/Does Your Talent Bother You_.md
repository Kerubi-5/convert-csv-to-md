---
title: Does Your Talent Bother You?
status: draft
datePublished: '1501668189'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/11a4d699-57dc-4dd3-a85e-9e58e9f4103e.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/11a4d699-57dc-4dd3-a85e-9e58e9f4103e.jpg" data-file-id="4834873" />Mine doesn’t. Does yours?

Before you think I’m being conceited: I’m not. This isn’t

Let me explain:

A close friend of mine likes to say: “Mi talento no me estorba”.

Or: My talent doesn’t bother me.

Which might sound like a quip, a funny Spanish colloquialism - but the more I thought about it, the more I realised that there are many people whose talent bothers them.

Except not in a conscious way - that would be silly.

No, I’m talking about how sometimes we hold ourselves back.

We know that we’re made for grand and fun things, that our abilities or talents ought to give us good things like appreciation, wealth, or renown.

(Yes, wealth is a good thing, so long as a wealthy person isn’t corrupt, greedy, or selfish).

But we’re unable to let our talent come to fruition, we hold back, we play small - in other words: we sabotage ourselves.

As if our talent is something to be afraid of, or hide, or something that needs to be tamed.

I call BS. If you have a skill, a talent, or anything that brings you good things and helps others, then live it out loud.

Let that puppy grow, feed it, get it out there.

Don’t ever let your talent bother you.

Cheers,

​Martin

---
title: Freedom (And Perceived Threats)
status: publish
datePublished: '1565770718'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img class="alignleft  wp-image-21979" src="http://martinstellar.com/wp-content/uploads/2019/08/MartinStellar_Coaching_Illustrations-Psychological-reactance-in-sales-1024x768.jpg" alt="" width="355" height="266" />One moment you’re talking to a potential client who seems really on board, ready to work with you…

And the next, they seem to have disconnected, tuned out, run into a problem.

Gone is the ‘same page’ feeling, evaporated is the harmony and resonance, and you wonder what went wrong. Weren’t they getting ready to buy? What happened!?

In many cases, it’s because you’ve triggered what psychologists call reactance: a natural reaction to the feeling that our freedom is being limited or threatened.

But why? How? Surely you want what’s best for them, and you’re definitely not being pushy, so what are they reacting to… something you said?

Maybe yes, maybe no.

Point is, what you did or said isn’t nearly as important as what is going on in their world.

And what’s going on is that somewhere on the evolutionary level of their psyche, a warning sign lit up.

Somehow, for some reason, their lizard brain senses a threat: “I’m being pushed” and while that might be entirely not what you’re trying to do, their subconscious thinks differently.

When that happens, step back.

Ask questions.

And, very importantly: be quiet. Give people space to think.

Lots of sales conversations break down simply because the seller talks too much, preventing the buyer from sorting through their thoughts (which, in itself, is a way of limiting freedom).

And ask yourself: in what way could they have perceived me or my words in a way that threatens their freedom to choose, their agency and autonomy?

Cheers,


Martin

---
title: 'Lessons From the Ultra Successful: Who Do You Need to Be?'
status: publish
datePublished: '1525769886'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/4b680aa1-f8f9-4746-868f-3d8bfdefa17e.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/4b680aa1-f8f9-4746-868f-3d8bfdefa17e.jpg" data-file-id="4835697" />When you look at someone like Bill Gates or Warren Buffet or Oprah Winfrey - the kind of person who has it made - do you tell yourself they’ve got something you don’t?

They don’t, you know.

Of course, in terms of assets: they’ve got teams, funds, operations and infrastructure - but on a human level, the part where it’s more about what you are instead of what you have…

They’re just like you.

168 hours in a week, put trousers on one leg at a time, an operational brain+capacity to learn, communication skills… they’re humans, just like you.

Then what makes the difference? What gets people to their level of success?

The money to invest? The teams that run operations for them?

Would be nice to have that, right? Make everything easier.

Except those assets came from who they are and how they show up to their life and their business. Not the other way around.

Point is, no athlete ever won a race by half-assing it. They play to win, or they won’t win. Simple.

Same thing with famous artists, captains of industry, best-selling authors:

Unless you show up as the committed, consummate professional, who does the important work and controls his mind and procrastination, you won’t win any races.

It’s about turning pro: going from wishing for the results, to actually getting your hands dirty and building them.

And yep, that’s hard work. Best roll up your sleeves. Again, you don’t win a marathon by sauntering down the track. If you want to win, you gotta earn it.

Leading and successful people show up as the CEO, the hero, the worker, the strategist, the holiday-maker, the learner, the tough-decision-maker - exactly the way they need to show up, given whatever time or situation they’re in.

That’s what distinquishes the successful from the wishful thinkers.

And yes, that’s harsh. But you can’t wish together a successful life or business and then expect it to come to you. It won’t. I tried.

You have your dream, your goal.

And in your heart, you know how you need to show up in order to get it.

You know, full well, who you need to be.

Question is, are you ready to be that best version of yourself - to act and think and decide and operate like your role-models?

To wear the suit that goes with the job description - which means living it, leaning into it... to BE the person you need to be?

&nbsp;

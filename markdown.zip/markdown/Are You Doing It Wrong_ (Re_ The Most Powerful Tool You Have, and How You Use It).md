---
title: >-
  Are You Doing It Wrong? (Re: The Most Powerful Tool You Have, and How You Use
  It)
status: draft
datePublished: '1511436408'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/7e5e1c44-1073-4694-b311-a9707b423d5b.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/7e5e1c44-1073-4694-b311-a9707b423d5b.png" data-file-id="4835221" />In a few hours from now I’ll be at the airport to pick up my client Paula Mould.

She’s coming over for a writing retreat to get a book finished.

Should be a lot of fun because Paula is exceedingly coachable.

She’s eager for change, hungry, driven to create change - and, she’s not afraid to look in the mirror.

She knows that meaningful change happens on the inside, and comes from developing self-awareness.

Looking in the mirror and seeing yourself as you are, without excuses - that’s what makes for a happy and successful life and/or business.

But, you’ll also need to use your mind, the right way.

Because the mind is just a tool, and as with any tool: If you don’t use it right, you won’t get the right results.

A hammer can be used to create a wide variety of things - or it can be a deadly weapon, depending on who uses it.

The mind is the same: it can create a reality for you that goes beyond your wildest dreams, or it can be a hindrance and the source of endless frustration.

See, your mind works best when it has a driver.

It needs someone to be in control.

Because if you don’t control your mind, it will do what it’s used to: seek the path of least resistance.

Unmanaged, the mind reverts to simply rehashing what you normally think anyway.

It’s a habit, to think the way we tend to think.

And if we tend to think things that aren’t positive, or helpful, inspiring or motivating, then we’ll constantly be telling ourselves those things.

The result is lack of clarity, less than optimal emotional states, procrastination, you name it. Lotsa bad stuff.

And all you need in order to avoid that, is get behind the wheel.

You need to drive that thing, that tool in your head. Because without a destination, without someone in control, you can end up anywhere.

Tell your mind where to go. You’re the boss in your mind, so don’t let your mind grab control.

Use that magnificent tool for building something, instead of just letting it run amok.

Make sense?

And, are you also unafraid to look in the mirror?

Then you too might be coachable.

Want to find out?

Then hit reply, and let’s have a conversation.

Cheers,

​Martin

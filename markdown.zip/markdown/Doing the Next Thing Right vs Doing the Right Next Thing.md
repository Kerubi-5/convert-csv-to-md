---
title: Doing the Next Thing Right vs Doing the Right Next Thing
status: publish
datePublished: '1597190085'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - How to sell your work
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-22363" src="http://martinstellar.com/wp-content/uploads/2019/12/MartinStellar_Coaching_Illustrations-Doing-the-next-thing-right-vs-doing-the-right-next-thing-1024x768.png" alt="" width="346" height="260" />When choosing what to do, there's a difference between doing the next thing right, and doing the right next thing’.

Of course, it’s always a good idea to do the next thing right. Kaizen, improvement, measurement &amp; iteration… if you want to go places, it’s important to do things right.

But that ‘doing the next right thing’ - that’s a really astute way to describe what my work is about:

Helping entrepreneurs do the right things, and in such a way that everyone gets better and money gets made.

That’s what an ethical business is about, if you get to the heart of it: doing the right things.

Making things better.

And that’s why I so much love doing this ethical sales coaching work.

Because once you figure out what is the next right thing, and you’re able to select the next <em>profitable</em> right thing, that’s when buyers enroll themselves.

Because if you make ‘the next profitable right thing to do’ a returning issue in your business, everything will get infused with not just the idea or intention, but the actual action of doing the right things.

And people can tell.

You'll causes massive change - in how you operate, how your team treats their work, the way your buyers respond… it’ll shift things, across the board.

Make ‘the right thing’ your goal, and all the right people will start to fall in love with your brand.

And if you choose the profitable right thing to do, they’ll give you money as well.

It’s fun, and it’s perfect for people who live and operate by values, and who are in business in order to make things better.

And if you want to grow your business and want to figure out which things you should do that are the both the right and the profitable thing, <a href="mailto:hello@martinstellar.com">you know where to find me</a>.

Cheers,

&nbsp;

Martin

&nbsp;

&nbsp;

&nbsp;

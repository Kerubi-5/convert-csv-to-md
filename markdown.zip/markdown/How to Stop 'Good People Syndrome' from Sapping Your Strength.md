---
title: How to Stop 'Good People Syndrome' from Sapping Your Strength
status: draft
datePublished: '1540894494'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/77d6f522-9fe0-4e38-800e-0880d8db3cab.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/77d6f522-9fe0-4e38-800e-0880d8db3cab.png" data-file-id="4836221" />Being liked makes a lot of sense.

Whether your POV is business, evolution, sales, society or relationships:

Being liked is worth a lot. It's good to be 'good people'.

Opportunities, connections, sales, mentors and helpers: we tend to give a lot to those we like.

In addition, helpfulness, altruism and a giving attitude are fantastic ways to raise your own state of satisfaction and well-being. Researchers can literally see the brain get happier, when test subject do favours for others.

What makes zero sense though, is sacrificing your own well-being and productivity to the god of likeability.

Yet we fall into the trap with ease: a little yes here, a bit of help there, an urgent thing they need your support for… and before you know it, you spend your days putting out other people’s (usually small) fires, and are left feeling depleted, with hardly anything checked off your own todo list.

When that happens, you’ve entered the land of people-pleasing, where everyone likes you, but nobody respects your time.

The obvious solution is to say no. A bit of healthy self-care (not selfishness), making sure you put your own oxygen mask on first etc.

But what if you can’t? What if helping others is one of your core values, and - for better or worse - you’re not able or willing to start saying no… does that mean you’ll spend your life depleted and helping others while your own results suffer?

Fortunately, no.

There’s a third option, between the default ‘yes’ or the decisive ‘no’.

It’s called ‘later’.

See, helping people is good. Society needs it, and you need it.

The trick is to say no to dropping everything the moment a request shows up, because that instant switching from ‘working on my own stuff’ to ‘something for someone else’ - that is the big problem.

Helping someone is fine, but not if you let it cut short your own plans or progress.

(When that happens, there’s a good chance you’re using your value of charitability as a way to procrastinate. Ruminate on that…)

You don’t need to do more less of being helpful… just make sure you chunk it.

There’s research that suggests people feel better about themselves by spending a block of time (a morning a week, for example) being charitable, instead of constantly sprinkling helpfulness on others.

So you can stay true to your values, keep being helpful and supportive, but without the constant drain on your energy, with just one word: later.

Set aside a few hours a week for being helpful, and chunk all the requests that reach you into that block of time.

And when someone asks your help, tell them ‘later’. “Sure! I’ve got some time reserved on Friday for requests like this. I’ll get back to you”.

Not only will you have more peace of mind, knowing that you’re not violating your values, you’ll also gain respect from the other person, for being mindful of your time.

Obviously, some common sense is in order here: there’s a set of requests that should never be honoured, like people asking for free work.

But anything that’s reasonable and not greedy, and something you want to help with?

Chunk it. It’ll even give you the feeling that you have more time in your week (which it literally does, because you won’t lose energy by constantly switching between ‘for you’ and ‘for them’).

Cheers,

Martin

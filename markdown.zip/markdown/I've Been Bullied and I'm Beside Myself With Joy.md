---
title: I've Been Bullied and I'm Beside Myself With Joy
status: draft
datePublished: '1499073432'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/10fced6d-9917-4987-b7a6-657238f9ff68.jpg" width="350" height="222" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/10fced6d-9917-4987-b7a6-657238f9ff68.jpg" data-file-id="4834765" />
I haven’t told you this yet, but in September I’m hosting a Cabal retreat here in Spain.

And much as I’d like to sell tickets and have you join the fun, I can’t.

Because this retreat is exclusively for the people in my Cabal Mastermind group.

Which doesn’t mean I’ll never host a larger, open-access retreat, but this one is for the inner circle only.

And you won’t believe how excited I am!

I mean seriously: there will be people flying in from the USA, Canada, maybe even the UK and Dubai, if all goes well.

How cool is that? People flying in to come see me!

Truly humbling, I’ll tell you that.

So yea, I’m thrilled. Even though they bullied me.

Because as we were hatching plans, the idea came up to host a group exhibition (all current members of the Cabal are artists).

And then someone said: “And you have to show your art as well, Martin. Your photographs as well as your drawings”.

To which the whole group cheered in agreement.

In other words: my clients bullied me into being part of their group exhibition - and I can’t thank them enough.

I honestly never thought my drawings would find such a warm welcome - I just had some fun communicating with images, but it seems people really like them.

And to have my clients - actual proper artists with a whole career and body of work behind them, unlike me - insist I show my work... well obviously I'm overjoyed.

Just goes to show what can happen when you don’t take yourself so seriously, and you learn how to play.

Because whatever shortcomings I may have, taking myself seriously isn’t one of them. And I know how to play.

Which is the lesson for today, in two parts:

1: Play. Like you mean it. It’ll change your life.

2: Don’t take yourself too seriously. You’ll change other people’s lives.

And, as always: if you want me to come out and play with you, I’m only an email away.

Cheers,

Martin

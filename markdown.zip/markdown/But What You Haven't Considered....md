---
title: But What You Haven't Considered...
status: draft
datePublished: '1503661651'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/f0f201c0-be00-4021-8d98-54bf48233e44.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/f0f201c0-be00-4021-8d98-54bf48233e44.jpg" data-file-id="4834949" />… is probably, pretty much, everything else.

Hang on, I’m not saying this to beat up on you. You’re not doing anything wrong.

What I mean is that as humans, we have this fundamental handicap.

Or more precisely: we have this particular strength that also works as our Achilles’ heel.

Because every strength can work for you or against you. Just depends how you use it.

In this case: we’re programmed to look for patterns, draw conclusions, and then make on-the-fly decisions, of the kind that keep us alive.

And that’s good, because the result is that you’re still around. (Hi there!)

But the downside of concluding one thing, is that you shut down your perception of other options or other interpretations.

Simple logic: when you look at one thing, you’re not seeing other things.

So when your mind looks at one thing (thinking about it, or contemplating, or drawing conclusions) you’re automatically not looking at all the other options or possibilities.

Saying (i.e. interpreting) that something is such and so closes you off to seeing what it could also be.

And that’s a pity, because nothing is ever just one thing.

A table is furniture, and handiwork (or factory stuff), and molecules, and an obstacle, and the cause of the bruise on your hip, and the place where you and your loved one first connected, and and and… many different things, all at the same time.

So here’s a fun and simple game I like to play, and it might help you a lot. It sure helps me.

Whatever thing appears in my life (people, events, conversations, objects, struggles, blessings - literally everything) I try to not take it at face value.

To accept and then bypass the obvious, first-off “well THIS is what it is” conclusion.

And instead, ask myself one of the fundamental coaching questions:

What else?

What else does this mean? What else does it represent? What other function could it have in my life? What else is this telling me?

What else, aside from my initial conclusion, IS this?

And whatever answer comes up, ask the same question: What else?

Doing this is not just fun: it’s very useful, because it removes the boundaries my mind puts on things.

And it’s not just an academic or philosophical exercise either: it’s highly practical.

It goes far beyond reframing or re-interpreting: it’s a way to explore our reality, and how we interpret it, and in doing so, we explore how our mind and our perceptual biases work.

And once you learn that last bit, you’ll find yourself living in a very different world.

A world where you meet fewer limitations and far more possibilities.

Tell me that doesn’t sound good.

So, play the game with me?

The rules are simple:

Counter every conclusion or interpretation with a resounding, repeated:

What else?

And let me know what you discover…

Cheers,

​Martin

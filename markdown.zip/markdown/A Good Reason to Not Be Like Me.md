---
title: A Good Reason to Not Be Like Me
status: draft
datePublished: '1536132392'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-20780" src="http://martinstellar.com/wp-content/uploads/2018/09/MartinStellar_Coaching_Illustrations-Better-not-be-like-me-1024x1024.png" alt="" width="350" height="350" />This notion of living with effortless mastery, how come it took me 12 years in a monastery and the better part of a decade afterwards, to reach it?

And, how can I claim that ‘you can develop effortless mastery in business in life *without* having to spend 12 years in a monastery?’

The reason it took me so long is that I was stubborn, headstrong, and yes: foolish.

I remember telling my abbot way at the beginning that “I’m not the kind who needs to learn through trial and error. I can learn from teachings”.

After which I proceeded to try, and err, for two decades. Whooptidoo.

So, you know: don’t be like me.

There’s teaching all around, and if you commit yourself to a) learning a method and b) doing the (home)work, you can save yourself a ton of time, as well as errors.

So the question is: do you want to go it alone, do it your way, and get better by and by?

Or, are you unlike I was back then, and willing to learn from teachings - the way those teachings are intended?

There’s no easy answer to this, mind you. It’s easy to think like I used to, and just as easy to be mistaken about it.

What you can do though, is look at the state your life and business are in:

Have you created the outcomes that you want?

If not, can you identify where that’s because you neglected or ignored instructions?

Outcomes point back to decisions.

And not making a decision (about things like making an investment, doing the work, learning a method, eliminating time-drainers and so on) is in itself a decision.

What decisions have you made, if you look at your current outcomes?

And: time to make some new, overdue decisions, perhaps?

Cheers,

Martin

---
title: A Life as Beautiful, Rich, Creative and Giving-based as Mine? Become a Surgeon
status: draft
datePublished: '1532963871'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/4e3a37d2-2c7e-4e8b-921c-2e00a6abdc3c.png" width="350" height="350" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/4e3a37d2-2c7e-4e8b-921c-2e00a6abdc3c.png" data-file-id="4835965" />Took a long time, hard work, and lots of tough choices, but life has become rather swell for me over the years. Pretty damn perfect, in fact.

(Side note: like that photo here - I had just written my email, went to the beach for a plate of fish, and it just so happened that the waitress was wearing the perfect illustration for today. Gotta love synchronicity)

Like they say: Tough choices = easy life. Easy choices = tough life.

So if you want a life that's as rich, peaceful, beautiful, creative and giving-based as mine, there's only one way to create it:

Become a surgeon.

Think about it:

If the goal is 'a healthy patient', a surgeon will ruthlessly remove anything that jeopardises that goal.

It's the only way.

If your goal is whatever version of 'perfect life' applies to you, then there's two steps to take:

1: Excise with extreme prejudice everything (people, places, things, habits) that in anyway obstructs your progress, or negatively affects you state - your calm and you ability to think clearly. .

2: Once done with that (or you're in the process of it, &amp; you're noticing how goddam awesome life is starting to become), it's time to level up:

Excise with extreme prejudice anything and everything that does not directly, and at no disruptive/damaging cost, contribute to your goal for life.

Yes, this can be hard. It means sacrificing things you care about (or maybe: are attached to?).

But ask yourself: if you want a 'perfect life', how badly do you want it?

If it's important enough, are the sacrifices not worth it? Also: are YOU not worth it?

You can either live a 'nice life' which includes a bunch of stuff that you've resigned to, or you can live a 'perfect life', in which the space previously taken up by crappy things and people, gets filled by awesome things and people.

Oh, and if you think it's selfish to design your life and your happiness this way, ask my friends and my clients how liberally I share, give, do charity, support, and help wherever I can.

The happier, more free, and more relaxed you are, the more others will benefit from your well-being.

Worth it? I'll say.

I've made my choice.

Have you?

Cheers,

Martin

---
title: And Suddenly...
status: draft
datePublished: '1506340019'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/45f934df-b413-4066-87e9-55d237e4d563.jpeg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/45f934df-b413-4066-87e9-55d237e4d563.jpeg" data-file-id="4835033" />...and quite unexpectedly… I have a family.

No, not because I got married while you weren’t looking.

I’m talking about the Cabal members who visited the last two weeks.

What an amazing time. What a fantastic group. What beautiful individuals.

And last night at our final dinner (squid cooked in its own ink, yay!) and I asked everyone what had been the biggest change for them, the question was thrown back at me.

And when I answered, I realised: for the first time in my life, I feel like I actually have family.

Ok, I have my mother and that’s beautiful family, but that’s all. My dad’s gone, I have no siblings, and other members of my family are far away in many respects.

But now that I’ve spent live time with these wonderful clients I previously only knew from Skype, and who were already friends, I realise:

We’re beyond the point of friendship. Way beyond. This is now my family.

It’s beautiful and I’m so grateful.

That so many people came from so far. That everyone showed up just as themselves, without inhibitions. That everyone was so fully accepted, no matter what differences.

For me, it’s the start of a new phase. After a whirlwind episode of finally really getting to know each other properly.

So what is Martin going to do with his new life, the one where he finally has family?

More of the same of course!

More writing articles for you. More drawing. More art shows. More coaching.

And, yes, more Cabal groups.

Because what we experienced here (not to mention weekly over skype for the past year) is almost magical.

And if you want a support group that holds you with open hands, drives you on, holds up a mirror for you to look in, and provides a setting where you get to solve problems and create change, joining one of the new groups might be just the ticket.

If you’d like to know if it’s for you, all you need to do is answer a few questions here, and we’ll talk: <a href="https://martin283.typeform.com/to/Tu3zmZ">https://martin283.typeform.com/to/Tu3zmZ</a>

Cheers,

Martin

---
title: Also, Don't Forget This...
status: draft
datePublished: '1513957882'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/aac49c5f-6ac1-4225-bd84-e7c297b16390.png" width="350" height="350" align="left" data-file-id="4835305" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/aac49c5f-6ac1-4225-bd84-e7c297b16390.png" />Today, there’s only one thing I want to tell you.

Yes, it’s another ‘your next year just might be your best’, here’s what to do.

What can I say? It’s the season to pause and reflect.

Here’s the one thing today:

Now for this year, and basically from here on out, you’d do yourself an enormous favour if you’d pick one thing (see what I did there?) to put the majority of your attention and effort into.

One thing, hard as that might seem. Because there’s always so many things that you could go for, work on, develop.

Things that seem interesting, great opportunities, profitable, or lots of fun.

But the more you have going, the more you spread your energy.

So please, pick one thing, the most important.

Avoid everything else, as long as the question ‘will this significantly contribute to my one thing’ is not yes.

And hey, you might wonder if it’s a good idea, this approach.

Well, I used to be a monk. I know a thing or two about focus and one-pointed attention.

Including how to use extreme focus to create business success - started two companies that worked really well - one as a copywriter, one as a coach.

So I’m not just making it up.

Focus. It works.

There’s an awesome book about this kind of thinking, called - you guessed it, The One Thing.

Good read, I recommend it.

And obviously, I'd be more than happy to help you figure out which one thing to pick.

Cheers,

Martin

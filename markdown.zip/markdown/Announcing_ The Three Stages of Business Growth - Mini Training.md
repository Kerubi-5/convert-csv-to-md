---
title: 'Announcing: The Three Stages of Business Growth - Mini Training'
status: publish
datePublished: '1634895215'
categories:
  - Business and systems
  - Doing it right as an entrepreneur or creative professional

---

<img class="size-medium wp-image-28249 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/10/MartinStellar_Coaching_Illustrations-Announcing_three-stages-of-business-growth_mini-training-300x225.jpeg" alt="" width="300" height="225" />Yesterday I told you about three different stages that a business - every business - goes through <a href="https://martinstellar.com/blog/the-three-stages-of-building-a-stress-free-profitable-business/">the setup, grow up and scale-up stages.</a>

I got some good feedback, so I decided I'm going to release a series of videos and articles addressing the different ingredients and mindsets that go into each of these stages.

Now, before you think “That’s not for me because we're already grown up, we're about to start scaling up”, or “Things are really scaling up and we don't have any need for any set-up or grow-up thinking”…

You might want to reconsider that.

Why?

Because when things change in your business, you need to be able to go back to adopting a previous stage mindset, so that you don’t inadvertently break things that are work.

For example:

Maybe you’ve got your systems in place, your Standard Operating Procedures, your team communication, your software tools, and documentation, and everything is running on all four cylinders.

And you go:

“Let’s go for this new vertical, open up another market!”

Good plan, good timing.

But, when doing that, you’re back at the set-up stage of figuring out which ingredients and processes are required for you to successfully address that market.

For instance, your old messaging, which worked for the market that enabled you to consolidate and grow up, is 99% certain to not work as well for that new market.

So, you need to think ‘set up’ and explore and discover and research what adjusted messaging is needed to appeal to that new market.

So to help you get your head around set up, grow up, scale-up, this Monday I’m starting a mini-training on how to do that.

If you’re not subscribed yet, do make sure you sign up here on the right, or with the box below, so you'll automatically get them in your inbox.

Thanks!

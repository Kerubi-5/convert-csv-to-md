---
title: "Business Fundamentals, pt 1: Who, What, How (Why You Must Do Things in the Right\r\n\t\t\tOrder)"
status: publish
datePublished: '1615540927'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<p class="p1"><img class="size-medium wp-image-26635 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/03/MartinStellar_Coaching_Illustrations-Business-fundamentals-pt1_do-things-in-the-right-order-300x225.png" alt="" width="300" height="225" /></p>
Would you add butter, only after the eggs are fried?

Of course not.

You know that things work, when done in the right order.

And yet:

You too might be have some things out of sequence.

So let's thread some business fundamentals in the right sequence.

Here we go. ?

Working in the wrong sequence is one of the worst things you could do.

It can literally cause bankruptcy.

Or, cost you to lose vast amounts of money.

Example:

Spending money on ads, before you've gotten laserlike focus on your most lucrative niche, and the messaging those people need to hear.

Boom, gone is your ad budget, and all you got was this lousy t-shirt from Facebook that reads "gotcha, sucker".

So the first thing you want to do, is answer the questions Who, What &amp; How.

Most people start with the How part: this is how I can help people solve problem X.

And then they go out looking for people who might want that problem solved.

But then you become a solution looking for a problem to solve, and that’s a long, arduous, very windy road - you’ll see why in a minute.

Instead, you want to start with Who.

Who are the people that you want to work with?

What about them makes them a good fit?

What do you know about them?

And most importantly: what do you not know about them?

Because that brings you to part 2: What.

What is it like to be in their shoes?

What annoying, pesky, costly problems do they deal with?

And, which of those problems do they actually want to solve?

And, literally the million-dollar question:

Which of those problems are so costly or painful that they actually want to pay to get them solved?

Because that last one is the only problem that you should try to solve.

That’s the only solution you should try to sell.

Anything else won’t be considered important enough, and/or they won’t want to pay for a solution.

See now why the order of things is so important?

If you start with a solution (the How) and you try to sell it, you might well be selling something people won’t buy.

Or, you might be using messaging that just doesn't work for those people.

That’s why you start with Who, followed by What, and only then do you move on to How.

That’s how your marketing and sales become lean, efficient, and measurable.
<p class="p1">If you’d like help answering the questions of Who, What and How, feel free to <a href="mailto:martinstrella@gmail.com">drop me a line</a>.</p>
<p class="p1">We’ll take 20 minutes on Zoom and I’ll do my best to help.</p>
<p class="p1">After that, we can see about working together.</p>
<p class="p1">Sound fair?</p>
<p class="p1">Let me know…</p>
<p class="p1"></p>

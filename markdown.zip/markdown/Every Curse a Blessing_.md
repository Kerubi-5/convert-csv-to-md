---
title: Every Curse a Blessing?
status: draft
datePublished: '1528710370'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

I<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/06e98161-cf8e-46f0-8e23-f17f36f5aed1.png" width="350" height="262" align="left" data-file-id="4835789" />t’s a daring way to live, but for some people (myself included) it works.

To consider everything that’s wrong or not right, as an enabler.

To take the baseline, default attitude, that everything holds a gift or insight of some sort, or that whatever happens or exists is intended to drive you forward, no matter how weird and counterintuitive it might seem.

For example: what if you have ADHD?

It’s easy to consider that a curse. But once you learn to work with, and make use of, the fact that your brain operates in a different way, your ADHD can become a powerful tool.

Or maybe you’re broke, and yep: that sucks.

But broke means hungry, and hungry means that you get to tap into thousands and thousands of years of evolutionary psychology, finely tuned to help you survive and even thrive. ‘Broke’ becomes a tool.

It’s useful to flip things on their head. Shows you that how you view a thing is only one of many possible viewpoints.

Bonus: you get to choose what viewpoint you want to adopt, for whatever there is in your life.

Your viewpoint on things is always a choice. But only always.

One of the best points of view that I know of?

That every talent can be an Achilles’ heel, and vice versa.

That every curse may just hide a blessing.

It’s not so much that bad stuff is, or can be, a ‘blessing in disguise’ - because it’s never about the thing itself.

It’s about you, your attitude, and very importantly: the view you choose.

And for that, questions are very helpful.

For example: “What strength of mine is called into play, given that bad thing X happened?”

Or: “What skill can I learn to improve relationship XYZ?”

“What does this teach me about my resilience?”

“What decision do I want to make?”

Or, very simply: “If bad thing X were actually a really good thing - what would I do with it?”

See what you can find…

And remember: whatever blessing you find, the best ones are always those you find inside yourself…

Cheers,

Martin

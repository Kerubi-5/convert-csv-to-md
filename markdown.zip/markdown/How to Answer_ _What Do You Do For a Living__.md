---
title: 'How to Answer: "What Do You Do For a Living?"'
status: publish
datePublished: '1660001186'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing
  - Relationships
  - Talking words

---

<img class="alignleft wp-image-22074" src="http://martinstellar.com/wp-content/uploads/2019/09/MartinStellar_Coaching_Illustrations-How-to-answer-what-do-you-do-1024x768.png" alt="" width="348" height="261" />
<div class="workspace-leaf has-pane-relief-label mod-active">
<div class="workspace-leaf-content" data-type="markdown" data-mode="preview">
<div class="view-content">
<div class="markdown-reading-view">
<div class="markdown-preview-view markdown-rendered node-insert-event is-readable-line-width allow-fold-headings show-indentation-guide allow-fold-lists" tabindex="-1">
<div class="markdown-preview-sizer markdown-preview-section">
<div>

Most people answer that question by not answering it:

</div>
<div>

“I’m an author” or “I’m a massage therapist” or “I own a design agency” or "I'm a leadership coach".

</div>
<div>

Those are not answers, because they say what you <em>are</em>, not what you <em>do.</em>

</div>
<div>

And people are a lot more interested in the thing we <em>do</em> that makes us different, than they are in the label we put on ourselves.

</div>
<div>

After all, they asked what you do, not what you are.

</div>
<div>

For a terrific and inspiring example, consider Seth Godin's reply, when asked during an interview:

</div>
<div>

“I notice things for a living, and then I try to point them out to people”.

</div>
<div>

Wonderful, isn’t it? So perfect for what Seth actually <em>does.</em>

</div>
<div>

When people ask what you do, you need to know what message to convey in just a few words, that has them see the change you make.

</div>
<div>

That's not the same as your 'elevator pitch' - instead, it's simply a verb-based reply to a question.

</div>
<div>

"I build websites that make you look like a million bucks."

</div>
<div>

"I help family businesses thrive, and business families stay together", which I want my business partner to use.

</div>
<div>

"I get your team to perform like a finely tuned performance engine."

</div>
<div>

"When your business finances aren't in order, I create that order and highlight where you can save or make more money".

</div>
<div>

Simple statements, based on verbs, that simply explain what change you make.

</div>
<div>

My reply, when asked what I do, is: "I help nice people sell more".

</div>
<div>

Which means: People who consider themselves good eggs, and who don't have limiting beliefs or mental blocks around selling, business or making a profit - and who simply want to get better at enrolling people without feeling awkward.

</div>
<div>

So what about you?

</div>
<div>

What is it that you <em>do</em> for a living?

</div>
<div>

Not what you are, but what do you do, that someone else might value so much, they’d pay money for it?

</div>
<div>

What value do you create, what change do you make, what does your work do for others?

</div>
<div>

What is it... that you <em>do?</em>

</div>
<div class="embedded-backlinks">
<div class="nav-header">
<div class="nav-buttons-container">
<div class="nav-action-button" aria-label="Collapse results"></div>
</div>
</div>
<div class="backlink-pane">
<div class="tree-item-self is-clickable is-collapsed" aria-label="Click to expand"></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="workspace-split mod-horizontal">
<div class="workspace-leaf has-pane-relief-label">
<div class="workspace-leaf-content" data-type="markdown" data-mode="preview">
<div class="view-content">
<div class="markdown-reading-view">
<div class="markdown-preview-view markdown-rendered node-insert-event is-readable-line-width allow-fold-headings show-indentation-guide allow-fold-lists">
<div class="markdown-preview-sizer markdown-preview-section">
<div class="embedded-backlinks">
<div class="backlink-pane">
<div class="tree-item-self is-clickable is-collapsed" aria-label="Click to expand">
<div class="tree-item-inner">---</div>
<div>

On another note:
I'm building an app that coaches you on working your pipeline, moving your deals forward - and closing them faster and at better rates.
It's called SalesFlow Coach, and we're scheduled for beta-release in June 2022.
Register <a href="https://martinstellar.com/salesflow-coach-launch/">here</a> to be notified when it goes live.</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

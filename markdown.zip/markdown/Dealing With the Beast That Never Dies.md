---
title: Dealing With the Beast That Never Dies
status: draft
datePublished: '1493804070'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/f78080b4-0631-4aa3-b4f6-f671f322bccf.jpg" width="294" height="220" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/f78080b4-0631-4aa3-b4f6-f671f322bccf.jpg" data-file-id="4834569" />I don’t want to write this post. I don’t want to send it.

But if I’m human and you are, then what’s happening to me right now very likely happens to you, at times.

(Sorry to discriminate against robots and aliens. This one is for homo sapiens only).

Ok, out with it: I’m feeling sorry for myself.

Not in a grand ‘woe is me’ kind of way though.

No, after many years of meditation and personal development, it’s become more subtle.

But it’s still there.

Because the monster that is at the root of literally every negative state and emotion - self-pity - never dies.

Anger? Disappointment? Frustration? Sadness? Despair? Jealousy? Grief? Guilt? Shame? Fear?

Self-pity is at the source, but only always.

Doesn’t look like that in most cases, because if someone wrongs you and you get angry, you have a right to be angry. Right?

Maybe, yes. But if you dig deep enough, and you keep digging, you’ll always end up at the core origin: self-pity.

The notion that life or the world aren’t giving you something that part of you feels you deserve.

I know, it’s hard to accept this as truth. And I’m not saying you should, but if you consider it and accept it, it will help you A LOT. As it did me.

My abbot never entertained any complaints, from me or any of my brothers.

Instead, after hearing me, he’d remind me that self-pity is at the root, and then suggested I go on with my work.

And I’ve found that SUCH a constructive way to go about things.

So you feel a state or emotion, and it’s a bother.

Alright, accept it. It’s there, it’s part of you, and it’s there for a reason.

But instead of zoning in on it the way most kinds of therapy do, or getting swept away by it the way many of us do (and I used to be really good at that), why not just leave it as is, and go about your business?

Because here’s the key to dealing with the monster that never dies:

The more attention you  pay to it, the more you feed it. The energy you spend on trying to fight it, or solve the problem, the stronger it gets.

In my experience, it’s much better to simply accept it, and then proceed to starve it of the food it needs - i.e. deprive the monster of your attention.

Over the years, this has helped me transform my monster of self-pity.

It used to be a kind of military dictator, ready at any moment to stage a coup and determine my state and experience and thoughts.

These days, it’s more like an oversized kitten. Still something to be wary of, what with its fangs and claws, but essentially powerless. Unless I give it power.

And I don’t. Self-pity rears up its ugly head?

"Oh hello. I remember you. Have a seat over there, I’m busy."

Thing is, working on yourself is tricky, because when you think you’ve solved something and its gone from your life, it often comes back later, in a different or more subtle way.

And then you think you’re a miserable loser, because after all the hard work, you’re STILL dealing with the same old sh*t?

Yep, you are. And that doesn’t matter.

Because what matters is that you get better at dealing with it. In subtle, yet important ways.

My self-pity? It’s parked over there in the corner, while I’m here taking care of stuff. It doesn’t need my attention.

If you keep coming back to states and emotions that don’t help you, remember that self-pity is at the root of it.

Accept it as is, and proceed to go about your business.

Just let the monster sleep.

Cheerio,

Martin

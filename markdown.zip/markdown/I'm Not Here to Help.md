---
title: I'm Not Here to Help
status: draft
datePublished: '1503922816'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/436b20bc-0af5-419f-9195-ffca7669cc0d.jpg" width="350" height="400" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/436b20bc-0af5-419f-9195-ffca7669cc0d.jpg" data-file-id="4834957" />Because to think that I can help someone else would be a form of arrogance.

It’s an ego thing, plain and simple.

People help themselves, that's how it works.

That doesn’t mean I wouldn’t be able to help you, nor does it mean that you can’t help others.

But for me to think that I can help others, because I happen to see their problems and the reasons, and solutions: that’s just my inflated ego.

And that’s also why it’s so damn hard to help people unless they ask for help - which I’m sure you’ll have noticed in your life.

Used to be, I’d carry my help on a silver platter, offering it to anyone. “Here, take this idea - it’s really good! It would help you so much!”

And then nothing.

So I gave up trying to help, years ago.

These days, I’ll help anyone who asks - but only if they ask.

I’ll make it known I’m available, and I’ll extend an invitation if I feel there’s an implicit request to get some help - but otherwise, I keep quiet.

Because I’m not here to help. Because at the deepest level of human interaction, the best kind of help (possibly the only real help) is the kind that enables another person to help themselves.

Because in the end, it’s always us, ourselves, who help ourselves.

Sure someone else can assist and sometimes that necessary.

But in the end, you’re always the one doing the helping.

And the function of a coach is to facilitate that process.

So: I’m not here to help. Instead, I’m here to help you help yourself.

So if that’s what you want, all you need to do is ask.

Cheers,

​Martin

---
title: IF Drift, THEN Draw (Productivity Hack)
status: draft
datePublished: '1567425004'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img class="alignleft wp-image-22020" src="http://martinstellar.com/wp-content/uploads/2019/09/MartinStellar_Coaching_Illustrations-If-drift-then-draw-beyond-procrastination-1024x768.jpg" alt="" width="353" height="265" />I can’t be sure if this will work for you, but in my day it’s proving a great way to get past procrastination. (Note that I said ‘get past’, instead of ‘beat’ or ‘combat’ procrastination - the less energy you feed the thing, the better. That’s why using this ‘hack’ means you’ll be bypassing procrastination, instead of making it into an issue).

The story so far: recently I noticed that I had started procrastinating more than usual.

Normally, that would cause me to review and adjust my systems and processes, apply a little grit, go for a walk, come home and apply more grit, and that typically gets me into gear again.

Not this time though: more and more often, I started to notice a tendency to procrastinate.

So I flipped things around. If opening Twitter or a news site used to be a signal that I’m ‘doing it again’ and using it as a trigger to grit up and apply some discipline, I started using it as a trigger to do the opposite: step back from work.

Been experimenting with it for a week, and what really works for me, is to go draw a bit. Not art, but more mind-mapping combined with visual thinking.

In other words: when I notice I'm 'drifting' away, the solution is to draw. Like a micro computer programme: IF drift, THEN draw.

Wonderful. So effective. So refreshing.

Ten minutes doodling stick figures, boxes and arrows, and I have a clear head, a nicely fired-up creative engine, and a friendly, non-disciplinary zest for getting some work done.

While I can recommend doodling and visual thinking, it might not be your thing - maybe you prefer reading, or calling a friend, or writing some fiction or gardening or looking up a nice recipe for dinner tonight.

Whatever your thing is, maybe a short playful session of calm and/or creativity is the thing that gets you to procrastinate less. Sure works for me.

Cheers,

Martin

---
title: 'CRD Pillar 5: Habits & Systems'
status: draft
datePublished: '1542109530'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21082" src="http://martinstellar.com/wp-content/uploads/2018/11/MartinStellar_Coaching_Illustrations-Calibrate-Reality-Pillar-5-1024x1024.png" alt="" width="352" height="352" />On the surface, life as a human seems haphazard, erratic, and often chaotic.

In reality though, life is a superbly organised, utterly reliable mix of habits and systems.

The fact that it seems chaotic, that’s only because the entire system of living as a human is so enormous that we can only observe a tiny portion of it all.

The trick then, is to do two things:

First, start gaining insight in your own habits, because you’re a creature of habit, whether you want to be or not.

Bring your habitual actions and reactions into sight. Create insight.

Next, start getting deliberate about creating and/or modifying your habits.

Especially your habitual patterns of thought - the majority of which is an ongoing unconscious process.

How you think, and how you think about your thinking, determines what you will feel and do, and is the strongest causation of the results you get in your life and business.

And it’s not that hard to create that insight. Nor is it hard to change habits - once you get clarity and insight.

Especially if you make it a habit (ha) to journal in the way I recommend in the CRD system.

But then, inevitably, someone tells me that they don’t want to have habits, because it inhibits their freedom.

Which is silly because a) you can not not have habits, and b) the notion of wanting to be free is a prison, and c) thinking that you don’t want habits is in itself a habitual thought (head spinning yet?).

And as for the actual limitation that habits and systems cause?

Sure! Of course a habit and a system causes a limitation, but that’s only good.

Because you create habits and systems around the mundane, the rote, and the relatively inconsequential.

And when you do that, you buy yourself an enormous amount of cognitive energy to do what actually matters, i.e. operate in a resourceful and creative way. And that creativity is severely reduced when lacking habits cause your experience of life to be chaotic and erratic.

That’s why habits and systems are a core element of Calibrate Reality Dojo.

Your life might appear chaotic or unpredictable, but you’ll grow to perceive all kinds of structures and patterns, the more you actually start getting intentional and deliberate about the habits and systems you already have.

And again: the best habit to start with if you want to remove chaos and create clarity:

Create outcome-oriented, agency-based questions around issues in your life, and journal your way through answering them - as a habit, each day and each time you get stuck on something you can’t seem to resolve.

You’ll be amazed at how your (perception of) reality will change…

Cheers,

Martin

---
title: Are You SURE You're Wearing the Right Suit? (This One REALLY Matters...)
status: publish
datePublished: '1508495846'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/dc94e911-1fda-4b36-83f0-bc8963ecb26e.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/dc94e911-1fda-4b36-83f0-bc8963ecb26e.jpg" data-file-id="4835121" />Ever feel like you’re stuck in a rut, and the tools and attitudes you have at your disposal for dealing with life and work are ‘just not right’?

Well, then why not wear a different suit?

After all, we’re the ones who get to chose how we show up in the world. Today, this afternoon, tomorrow… at any moment, we get to decide how we will be.

Most of the time though, we simply default to what we’re used to.

But you get to choose, you know?

It’s like wearing a suit. You can wear the suit of the warrior, or the worrier, or the helper, or the victim, or the creator, or the spiritually minded, or the CEO…

All these are actual and chooseable attitudes, and each of these will bring its own unique consequence in your day.

And that way you can steer your life and day and business in a specific reaction.

But only if you’re deliberate about it. Only if you choose.

Which many people simply don’t.

We default to what we’re used to - be that the worrier or the chief or the confused puppy or whatever.

But for every not-positive attitude that you might ‘suffer from’, there’s another one that works around that. And all you need to do is choose.

If your default is to worry, then why not wear the suit of massive action? Good chance that being hard at work will reduce your worries. Or at least take your mind off them.

If your default is to be confused and indecisive, then maybe more learning will help.

If your default is to be indecisive despite having learned so much, then maybe the berserker suit will help you: make a choice however arbitrary, and then run with it.

If your default is to think top-level and not get into action, then maybe the worker’s cover-alls are what you need to wear.

If your default is to fret when money is low, then why not wear the suit of the salesperson (where I must note that ‘selling’ is not a matter of being pushy, but of connecting with people, and inviting the right people to buy. In case ‘selling’ would cause you to wrinkle your nose etc. We all like it when people buy our stuff, and when we’re not pushy, people tend to like buying from us).

If your default is to blame others, what would happen if you wear the suit of responsibility (i.e. “I’m the one to make change, I own the situation, I’m taking charge of what I can do and I’m going to bypass whatever someone else did or didn’t do”).

If your default is to observe others and feel like you got the short end of the stick, then maybe wear the suit that says “I’ll act as if, and do the work to get to the other person’s level”.

What matters is this: we’re all used to going with a default attitude.

So when you notice things ain’t working or running smoothly, ask yourself:

As who am I showing up? What suit am I wearing here?

Next, realise that you can wear any suit you want. Remember, we’re talking about attitude here. Attitude is something you can adopt, experiment with, and get better at.

Finally, pick a suit - an attitude - that will move you forward.

Don that sucker, and wear it with pride.

And watch how your state and day and results change, the more you practice this exercise.

&nbsp;

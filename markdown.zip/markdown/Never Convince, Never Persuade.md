---
title: Never Convince, Never Persuade
status: pending
datePublished: '1658387789'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img class="size-medium wp-image-28041 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/09/MartinStellar_Coaching_Illustrations-Empathy_perspective_sales-300x225.png" alt="" width="300" height="225" />There's a lot of talk about persuasion - books, lectures, research...

But if you're a good egg and you need to sell your work, you don't need to convince, or persuade - and in fact, you shouldn't.

Why?

Because "persuade" and "convince" are code for:

"I'm right, you're wrong, and you need to see my point of view."

And nobody likes to be made wrong, or to be told what's best for them.

Instead, use perspective-taking.

Put yourself in their shoes, try and see the world through their eyes.

That will automatically get the two of you developing a worldview together, which automatically gets your buyer to see your point of view, and then all you need to do is ask:

"Does this make sense? Do you like what you see? Do you want it? Are you ok with the price? Should we move forward with this?"

Zero persuading or convincing required.

Persuading is an uphill battle. Taking the buyer's perspective and having a conversation is a helpful, joyful experience.

You get to choose which experience the two of you will share in.

&nbsp;

<hr />

On another note:
I'm building an app that coaches you on working your pipeline, moving your deals forward - and closing them faster and at better rates.
It's called SalesFlow Coach, and we're scheduled for beta-release in June 2022.
Register <a href="https://martinstellar.com/salesflow-coach-launch/">here</a> to be notified when it goes live.

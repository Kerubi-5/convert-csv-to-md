---
title: Getting Ready to Launch SalesFlow Coach App... BUT
status: publish
datePublished: '1640167824'
categories:
  - Assets and Leverage
  - Business and systems

---

Build in Public update:

Getting ready to launch SalesFlow Coach, later today.

But.

There's a problem.

I do want to publish the app itself, &amp; give everyone access to it, and ask for feedback.

Seriously would love to just throw this thing into the arena and see what happens.

Butbutbut.

A few weeks ago, I showed and early version to some 5 or 6 people, and it was absolutely fascinating to see them use it, and see their reactions.

Taught me SO much, and it was a really fun experience both for me and the other person.

We just got on Zoom, I gave them control of my screen, and said:

"Here, click around".

Just amazing, to see someone interact with a thing I built!

Problem is:

If I just publish the link to the app, many of the people I would LOVE to talk to directly, will have already tested the app, before a call would even take place.

And then I don't get to see that first-impression reaction.

And worse: that removes my opportunity to learn what I should change or improve.

And so:

Yes I'm launching today.

But:

I'm not sharing the link outright - instead I'll be inviting you to a short call.

Or, what my developer-friend Binny points out, is called a soft launch.

We jump on Zoom, I'll pull up the SalesFlow Coach app, give you control over my screen, and you can click around and see if you would use the app.

Because that is the single question that needs answering right now:

Yes, I'm turning my process and methodology for landing clients into an app...

But... would people actually use it...?

Would you...?

More news, (hopefully) later today.

&nbsp;

---
title: Habits Out the Window... Or Maybe Not?
status: draft
datePublished: '1506593233'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/fe144dc6-6cd8-43f9-aa3f-2d3ccbd0ea21.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/fe144dc6-6cd8-43f9-aa3f-2d3ccbd0ea21.jpg" data-file-id="4835049" />These last few weeks, all my habits and routines went out the window. All of them.

Up to the point of missing several days of sending you my daily email.

Logical, given that I had all these people visiting, and that we clocked almost 1800 kilometers in two weeks.

Now for most people, dropping a habit spells disaster.

And I used to be like that (secret: in some ways, I still am).

But to an important degree, I learned to get over the feeling that I’ve failed and that it’s useless or impossible to get back to my habits.

Because while I’ll never tire of preaching the importance of habits and routines, the fact is that it’s almost inevitable that they’ll break at some point.

The trick, the secret that keeps me balanced and going back to my routines?

Kindness, permission, and forgiveness.

The default reaction for most people, when we break a habit?

Self-recrimination. Blame. Feelings of guilt, insufficiency, and general doom.

These days, I try to avoid that.

I try to be kind to myself, and not beat myself up when I break a habit. There’s always tomorrow, isn’t there?

I give myself permission to break a habit, in those cases when circumstances (external or internal) make me drop a habit.

And I forgive myself  - not just for breaking the habit, but also for the automatic negative self-talk.

It’s all normal, human, understandable. So why would Martin beat up Martin over it?

Who gets better when that happens?

I certainly don’t.

And it’s exactly that element of permission and forgiveness that make it easy to get back into the habit.

Because when the subconscious starts complaining and blaming, that’s when you trip up and are very likely to postpone getting back to your habit.

So. If you like habits and you have trouble keeping them going or getting back to them, remember this:

It’s alright. There’s tomorrow, and there’s nothing wrong with you.

You may have fallen off the cart, but that thing will keep moving without you.

All you need to do is decide to jump back on.

Just like I did this week once everybody left: I’m back to my miracle morning routine, and it’s wonderful.

And I wish the same for you.

Hit reply if you want to know what my morning routine is like, and why it’s so effective for me.

Cheerio,

Martin

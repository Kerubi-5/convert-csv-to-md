---
title: 'CRD Minicourse, Pillar 3: Done Any Critical Thinking Lately?'
status: draft
datePublished: '1541583373'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21067" src="http://martinstellar.com/wp-content/uploads/2018/11/MartinStellar_Coaching_Illustrations-Thinking_making-sense_journalling-1024x768.png" alt="" width="349" height="262" />Oh I know, ‘mind’ is only part of the equation - what about feelings?

Are those not the true measure of what matters, isn’t it emotions that reveal truth?

Sure, yes. Emotions matter.

Especially if you consider evolutionary biology: the areas in the brain related to emotions and intuition are much bigger, and much much older than the frontal lobes where thinking happens.

Even so, thinking is highly underrated. Underpracticed too, in fact.

What most people call thinking, is nothing more than rehashing some thoughts that we’ve thought a hundred times before, slapping on a few emotions that say ‘yes, feels good’, and off we go, making yet another decision that doesn’t stand a chance of getting the outcome we want.

Real thinking on the other hand, is a matter of logic and reason.

Actual proper thinking asks ‘does this make sense’?

And that’s where most of us go wrong.

Because the moment we ask that question and the answer isn’t ‘yes’, emotions step in and say ‘But it feels good’ or ‘but I really want it’ or ‘the price is right’, or any of the many different excuses we throw in the mix.

The remedy is to actually stop and take some time to sort out your thoughts.

Separate thinking from desires and wishes and emotions.

Give a cold hard look at your thought process, and whether or not it actually makes sense or not.

Very often, you’ll find that you’re lying to yourself, or making excuses, or using strawman arguments to convince yourself.

None of that helps.

So instead, take pen and paper, identify the issue you want to solve or decision you want to consider, and turn it into a question.

Next: write. Answer that question for yourself. Keep writing and when you get stuck, create another question to prod you along, and keep going.

Before long, you’ll find that you’re actually making sense, on that paper of yours.

There’s a number of massive benefits here:

For one thing, taking time to think means you get clarity, which means you won’t be ‘stuck in mind’ nearly as much as you’re used to.

Which I believe is something we all long for.

And, if you first think and then decide (instead of the more common ‘looks good, let’s do it and think later’, you’ll actually be getting the outcomes you want.

So that rounds up section 1 of the CRD system.

Tomorrow, we’ll look at section 2: managing your state.

Stay tuned…

Cheers,

Martin

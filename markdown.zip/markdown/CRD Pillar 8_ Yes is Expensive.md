---
title: 'CRD Pillar 8: Yes is Expensive'
status: draft
datePublished: '1542275064'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21089" src="http://martinstellar.com/wp-content/uploads/2018/11/MartinStellar_Coaching_Illustrations-Yes-is-expensive-1024x768.png" alt="" width="355" height="266" />Any time you say yes to something, you’re saying no to everything else that’s not that thing.

Even if you believe in multitasking (which doesn’t exist - there’s only task-switching)

And saying yes is the source of many problems: depletion, lack of clarity, overwhelm, disappointing results, to name but a few.

Saying yes carelessly is the opposite of saying yes to what’s essential, and only that what’s essential is important enough to bring into your life.

Why would you want a life or a business overflowing with non-essential, mostly trivial stuff?

But we say yes to all kinds of things that actually deserve a hard no.

Say yes to hoarding, and your house clutters up.

Say yes to being active on all social media platforms, and your head is filled with other people’s conversations, and your own creativity suffers.

Say yes to spending time with people who nag, and your state suffers.

Say yes to a decision you didn’t think through, and you’re very unlikely to get the result that decision was supposed to bring you.

Say yes to all the ‘don’t miss this!’ crap that marketers send you, and you’ll have little time left for doing actual work.

Say yes to learning things you don’t need to know right now, and you won’t have time to actually execute on the things you already learned.

Here’s the truth:

Saying yes indiscriminately is the behaviour of those who believe in scarcity.

I don’t know enough, so I need to learn more. I don’t have enough followers so I need to be everywhere. I’m short on money so I need to take on that time-wasting, micromanaging, complaining client. I don’t have enough time, so I need to cram more todos into my day.

In each of those cases, saying yes means that something suffers, all because you think there’s not enough of something.

But if you use what you already know, you create momentum and results.

If you engage with more people on one or maybe to social media platforms, you’ll get more followers.

If you refuse that bad client, you’ll have time and energy to search for someone better and more fun.

If you keep your todo list realistic, you won’t be overwhelmed and you’ll perform better in the short time you have.

People who want the best for themselves and their clients, say no.

No to anything that’s not essential, not fulfilling, not based in true service.

Which is why saying no is pillar 8 in the CRD system.

And it’s why I have a ‘no-list’ that I review and update frequently. Anything that doesn’t make things better for myself and/or others goes on there, and I live by its mandate.

Brings a lot of space for doing work that matters.

So, question for you:

What have said yes to (consciously or not) that you should actually give a cold hard no to?

Cheers,

Martin

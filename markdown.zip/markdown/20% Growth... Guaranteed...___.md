---
title: 20% Growth... Guaranteed...???
status: publish
datePublished: '1590398522'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - How to sell your work
  - Psychology in sales and marketing

---

TL;DR: Register for a free live training session this Thursday, where you’ll learn how to increase your revenue by 20% or more, without raising your ad spend. Here’s the signup page: <a href="http://bit.ly/LEAPbyMartin" target="_blank" rel="noopener noreferrer" data-cke-saved-href="http://bit.ly/LEAPbyMartin">https//bit.ly/LEAPbyMartin</a>

<img src="https://mcusercontent.com/f05dc59f4bf8170c301679377/images/c2ba1790-7310-4557-a79d-6ec6580a5f44.jpg" width="350" height="262" align="left" data-file-id="4837481" data-cke-saved-src="https://mcusercontent.com/f05dc59f4bf8170c301679377/images/c2ba1790-7310-4557-a79d-6ec6580a5f44.jpg" />It’s something I’ve not mentioned much here yet, but I run a marketing implementation programme, that guarantees that my clients raise their revenue by 20%.

And very often, people ask how I can make such a promise.

Good question too.

After all, there’s so many moving parts, so much uncertainty, so much to figure out.

So how, Martin? How do you guarantee 20% growth?

The answer is surprisingly simple, because this marketing system is based on leveraging marketing assets that you already have, but aren’t utilising.

But if you do leverage your marketing assets, generating 20% more revenue can be pretty easy.

Especially if a) you use a tried and tested system, and b) if that system is based on the fundamentals of business and marketing.

See, the trick is to look at the synergy between metrics. (do people still talk about synergy? Anyway).

Most businesses who want to grow, make 'more sales' the goal.

But increasing sales by 20% is a pretty tall order.

And, more sales usually also means 'more cost'.

So yeah, how do you reach 20% growth without increasing cost?

Business fundamentals, and looking at three metrics for growth:

1: The number of leads you generate: how many people do you enter into conversations with?

2: Conversion rate: How many of those convert into paying customers?

3: Purchase value or customer account value: how much money does each client spend with you?

These three all influence revenue.

So here's a thought exercise:

Could you, conceivably, raise your leads by 10%?

Probably yes, right?

And conversion rates - could you crank that up 10%?

Bet you can.

And having a buyer spend 10% more?

Not too difficult in most cases.

And now it's going to get fun:

What if you raise each of these by 10%?

Then you get exponential growth, raising your revenue to 33% in total.

And that, my friends, is why - for the right kind of company - I yes, absolutely, guarantee 20% revenue growth.

Because literally every business has assets that aren’t being put to use - from expertise, to network, to intelligent messaging to different segments of your database of past, current, and potential customers…

There’s a LOT that can be done, when you use a systematic approach and base your growth efforts on data and metrics, and you allow those underused assets to drive your growth.

And this Thursday, at 7PM CEST / 1PM EST, I’m giving a live training, hosted by Helena DeMuynck, founder of Oxygen4Leadership.

You’ll get a training on a tried and proven system, showing you exactly which steps to take and in which order, to get all you can out of everything you’ve got.

Registration is here: <a href="http://bit.ly/LEAPbyMartin" target="_blank" rel="noopener noreferrer" data-cke-saved-href="http://bit.ly/LEAPbyMartin">https//bit.ly/LEAPbyMartin</a>

See you on Thursday!

Cheers,

Martin

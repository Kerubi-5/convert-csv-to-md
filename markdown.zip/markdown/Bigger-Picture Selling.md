---
title: Bigger-Picture Selling
status: publish
datePublished: '1617352454'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<p class="p1"><img class="size-medium wp-image-26683 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/04/MartinStellar_Coaching_Illustrations-8mm-drill-bit-vs-8mm-hole-in-the-wall-300x225.png" alt="" width="300" height="225" />For someone to consider you the best option - the one outstanding provider of a solution - they need to trust.</p>
<p class="p1">Not just trust that you will show up and do the work as promised: they also need to trust that getting the solution will get them the final result that they’re looking for.</p>
<p class="p1">And that’s exactly where a lot of coaches and consultants miss the mark.</p>
<p class="p1">Because while your solution obviously solves their problem, the solution they buy is only a stepping-stone to a bigger outcome.</p>
<p class="p1">For example, at the moment I’m looking to hire someone to fix things on my website, to make it faster and to rank it better in search engines.</p>
<p class="p1">What I’m asking is “can you speed up my site and fix my SEO?”</p>
<p class="p1">But what I’m looking to obtain is ‘more subscribers and more inbound leads’.</p>
<p class="p1">So the person who proposes to solve my problem has two choices:</p>
<p class="p1">Option one: Tell me that they’ll fix speed and SEO.</p>
<p class="p1">Option two: tell me that they’ll fix speed and SEO - AND tell me that split testing would be a good idea, as well as installing analytics, and point at design flaws that can be improved, so that I’ll get the highest possible yield out of the increased number of visitors.</p>
<p class="p1">The second option is of course best, because it will tell me that they get me, that they understand what ultimate result I’m going for.</p>
<p class="p1">It will make me feel understood, and seen, and it’ll give me the feeling that this person isn’t just a do-er of things, but also a person who thinks along with me.</p>
<p class="p1">Guess which pitch will be most appealing to me?</p>
<p class="p1">So whenever you’re talking to a buyer and you’re laying out your proposal, make sure that you don’t just address the solution people are asking for.</p>
<p class="p1">You need to also demonstrate that you understand how that ties in with their further business goals.</p>
<p class="p1">There’s enormous power in showing people that you get them, and giving them the feeling that they’re seen and understood.</p>
<p class="p1">You’ll see your conversion rates go up dramatically, the more you make an effort to show people how your work ties in with the bigger picture.</p>
<p class="p1">Like they say: nobody goes to a hardware store to buy an 8mm drill bit.</p>
<p class="p1">What people buy, is an 8mm hole in the wall.</p>
<p class="p1">Sell people that hole in the wall.</p>
<p class="p1">And yes, of course you’ll learn how to do that with the <a href="https://martinstellar.com/helping-good-people-sell-more-and-generate-a-bigger-impact/"><span class="s1">Sales for Nice People training. </span></a></p>

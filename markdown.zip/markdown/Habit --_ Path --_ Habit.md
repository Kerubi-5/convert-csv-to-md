---
title: Habit --> Path --> Habit
status: draft
datePublished: '1495011443'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

It’s quite the thing in the world of success and business, these days: habits.

Ask around, and you’ll everyone and their donkey say that habits are crucial, quintessential, if you want to get from A to B.

And obviously, I’m no stranger to habits, what with having been a monk etc etc.

And I agree: habits are the trick.

Habits fix your mood, insecurities, productivity, progress, impatience... choosing the right ones will do wonders for you and your life.

So I’m creating a new coaching programme, built specifically to get you on the path of living with habits.

After all, I know a thing or two about them: which ones to choose, how to implement them into your life, and above all: the workarounds to help you keep up with them, and not fall off the wagon. Or to get back on it when you eventually do fall off.

Because here’s the secret: It’s impossible to keep up with all your good habits, all of the time.

But it is always possible to reboot and start them again.

And when you learn how to do that, working with habits and routines becomes a path, a way of living - which in turn becomes a habit.

Hence the circular, upward spiral nature of habits.

Habit --&gt; Path --&gt; Habit.

I kinda want to call the programme that.

Catchy name, whaddaya think?

Anyway, I’ll tell you more about the details soon.

But a little teaser: this program will enable you to work with me 1 on 1 at a far lower price point than a full-scale coaching programme.

Stay tuned...

Martin

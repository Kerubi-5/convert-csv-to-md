---
title: Fruit or Seed? (In which I bow down)
status: draft
datePublished: '1496077618'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/2a77eded-37b0-45bb-9235-7c243fb4fc05.jpeg" width="300" height="169" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/2a77eded-37b0-45bb-9235-7c243fb4fc05.jpeg" data-file-id="4834629" />As a coach, part of my work (and one of the most powerful coaching events you can imagine) is flipping things around, turning stuff upside down.

Showing a client that Thing A can also mean the complete opposite.

Like the other day, I had a session with an entrepreneur who has a company and staff.

And while it’s a really good thing that there’s a horizontal structure there instead of a hierarchy, the consequence is that he keeps getting interrupted about small things.

Which means he doesn’t get to doing the important work, the zone-of-genius stuff that would really scale the business.

At first sight, that’s a problem.

But then I told him that it’s a really good thing he doesn’t get to doing those things and making the business grow fast.

Because if he did, while having the problem that he keeps getting interrupted and doesn’t get to do the important stuff, fast growth would effectively kill his business. Death by success.

Suddenly, there would be more invoices, more customer stuff to deal with, more problems to solve - while his staff doesn’t allow him the time to attend to all of that.

“You should be grateful you don’t get to the big important things”.

Boom. Mind blown.

Today though, it’s my turn to have my mind blown.

Email from a client, who tells me she had her first big sale.

Brilliant of course.

But then she says: “It’s a beautiful seed to grow from”.

Not “I’m glad the seeds I planted are finally bearing fruit”.

No, other way round: The first sale as the seed - how cool is that?!

I just love love love it, when a client suddenly gets it.

Want me to help you get it too?

Could be a real fun ride, you know...

Let me know

Cheers,

Martin

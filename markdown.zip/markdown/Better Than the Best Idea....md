---
title: Better Than the Best Idea...
status: publish
datePublished: '1512985636'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/36644bea-799e-415a-b3a8-31eb4f7ad941.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/36644bea-799e-415a-b3a8-31eb4f7ad941.png" data-file-id="4835269" />... Is an idea that actually gets put to use.

See, I often come across people with interesting - or even brilliant - ideas.

And in my dealings with entrepreneurs, I meet a lot of people who are looking for an investor, to help them create a business out of their idea.

But here’s the problem: for an investor to give you money, they want more than just an idea.

An investor wants to know that the idea is going to create returns, otherwise he’d be risking his money for no good reason.

An investor wants proof, not prognosis of future yields.

So it always amazes me, when someone thinks that just by having an idea is enough to create a business.

But I can tell you from experience that it’s not enough.

Whether you want to find an investor or simply create your own prosperous business venture, you’ll need to DO something with you idea.

Implementation is what makes an idea valuable. By itself, an idea has no substance.

Reminds me of a guy I know who has a terrific creative mind, and comes up with ideas non-stop.

And then he expects someone else to build it into reality, and for that other person to pay him a fee for having received the idea. Crazy!

Except I see a lot of this attitude: that just having a good idea somehow entitles us, as if it should command the universe to bestow wealth and a good life on us.

To me, it’s a matter of maturity: To have an idea and expect rewards for it without working on it, is childish. Adults know that things don’t work like that.

Which is why I can only work with people who understand how the world works. People who are willing to take action on their ideas.

Because those people are the only ones who actually create something real out of their ideas.

---
title: If It Don't Fit, Don't Force It
status: publish
datePublished: '1539702402'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-20986" src="http://martinstellar.com/wp-content/uploads/2018/10/MartinStellar_Coaching_Illustrations-If-it-dont-fit-dont-force-it-1024x768.png" alt="" width="352" height="264" />Trying to squeeze yourself into a model that doesn’t fit you makes no sense and wears you out.

But it’s easy to fall into the trap, simply because some teacher or guru told us that it’s the only or the best way.

Or because you see a competitor do things a certain way, and then you tell yourself you should also do it that way.

My saying email marketing works doesn’t mean it will work for you, if you’re the kind of person who doesn’t want to commit to sending daily or weekly without fail.

Using social media for lead generation might work for your competitor, but if you loathe being on social media (which is how I feel about spending time on Facebook, and why you don’t see me there), it makes zero sense to try it anyway.

Another example: It’s all well and good, when productivity gurus preach slow&amp;steady progress, but for someone like me, that just doesn’t work.

Took me decades to figure it out, but I’m a sprinter, not a pacer.

Put me on a bicycle, and I’ll be up the hill before others have even taken off.

I’ll be completely spent when I get to the top of course, but I’ll be enjoying the view while others are still struggling at a slow pace.

What can I say - I like to sprint. I get behind a task, crank that sucker like crazy for a short while, and then I unwind.

That’s what comes natural to me, so I’ll spend 4 days putting in 12 hours or more, and then I completely disconnect for a few days. Works for me.

But for the longest time, I kept trying to get stuff done 7 days a week - with the result that I got almost nothing done and was stalled most of the time.

Trying to force yourself into a model that doesn’t come naturally to you is super costly.

It wears you out, erodes your self-confidence, and drains your funds (financially and energetically).

The trick to making things easier is in finding your mode of optimal performance, and getting better at it.

At heart, you know what’s your best mode of operation.

Question is: do you allow yourself to thrive by doing more of what you do best, the way you best do it?

Because if you don’t, and you keep trying to push a boulder up a hill by trying to force what doesn’t fit, know that you’re using a subtle way to procrastinate on getting the results you want.

Make the model fit you, not the other way around - and if you want help figuring out what exactly is your best mode of operation (i.e. the model you ought to be using), then let's talk.

&nbsp;

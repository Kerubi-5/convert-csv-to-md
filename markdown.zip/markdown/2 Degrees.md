---
title: 2 Degrees
status: draft
datePublished: '1551355324'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img class="alignleft wp-image-21432" src="http://martinstellar.com/wp-content/uploads/2019/02/MartinStellar_Coaching_Illustrations-2-degrees-course-correction-1024x768.jpg" alt="" width="351" height="263" />It’s tempting to desire big, radical, dramatic change.

To one day wake up, and man! Look at how focussed we are, and productive, and efficient, and fit!

But, I doubt you’ve ever woken up to that dramatic kind of phoenix-like transformation. I know I haven’t, and I don’t know of anyone who has. Not unless some life-changing event like say, a near-death experience, brought it on.

Normal people, we change gradually. Over time.

Which is one good reason to get rid of your dream of ‘total transformation’: our conscious mind might want it, but our subconscious knows that’s not how things go, unplugs the power supply from your motivation, and we end up not taking the actions that bring about the gradual change.

There’s a different attitude, one that’s much more effective, more fun, and easier:

Change course.

And not in the ‘radical turnaround’ sense described above, but by just a few degrees.

Think of a captain plotting a course across a sea: if his calculations are 2 degrees off, he’ll never reach the desired destination: the error amplifies, and the longer the distance, the bigger the final error.

And it can get BIG. I'm not being accurate here, but a 90-degree course from New York should land you somewhere in Portugal. But make it 92 degrees, and you'll end up in Africa. More or less.

Anyway, In our lives and our business it's the same - except it’s time instead of distance. A small course correction ends up getting you very different results, outcomes, and destination.

If you shift course by just one or two degrees, you’ll end up in a vastly different place after 1, 5, or 10 years, compared to where you end up if you don’t change course.

It’s the tiny changes in our behaviour, and decisions, and attitudes, that over time cause the big change we want.

So forget about ‘everything different’, and focus simply on ‘a little different, a little better each day’.

And the best place to start with your 2-degree course correction, is at the fundamental, grass-roots level - the place where everything starts: the way we think.

A tiny shift there will result in big changes over time.

And if you don’t believe me, let’s chat (no obligation or small print) and I’ll help you find a few simple subtle course-corrections you can apply for yourself.

Let me know if you want to play…

Cheers,

Martin

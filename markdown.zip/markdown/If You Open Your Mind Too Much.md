---
title: If You Open Your Mind Too Much
status: draft
datePublished: '1538992591'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-20966" src="http://martinstellar.com/wp-content/uploads/2018/10/MartinStellar_Coaching_Illustrations-Open-mind-vs-being-gullible-1024x768.png" alt="" width="371" height="278" />… Your brain might fall out.

It’s good to have an open mind, and be willing to accept (or try out) viewpoints that differ from what you consider to be true.

In fact, openness is one of the ‘big five’ personality traits in psychology (Along with general intelligence, they are: openness, concsientiousness, extraversion, agreeableness and stability).

People who score high on the openness scale tend to have more options in life, which enables you to make choice that cause radical change in your life or your business.

But the flipside of openness, is believing things without having any logical, reasonable grounds for the belief.

In other words: gullibility.

See, the fact that someone says thing A is true, doesn’t make it so.

The fact that you see all your friends agree on Facebook about something, doesn’t give it validity, beyond social consensus, which is fickle and SO easy to manipulate.

A manufacturer printing a brain on a bottle of beverage will only have one possible effect on your cognitive abilities: bring it down, if you believe that a drink makes you smarter.

Oh but we know this, right? We’re sane, rational, logical people, yes?

Sorry, no.

The human species is profoundly irrational, and magnificently gullible.

And if you don’t believe me, just look at the way marketers exploit gullibility in the way they present product messaging.

An asterisk referring to a footnote that says little more than ‘as proven in clinical trials’, and hoopla: sales go up*.

*As proven in numerous marketing campaigns.

So what are we to do?

You can’t close off your mind and be ultra-conservative, nor can you just believe everything people say.

If you do, you might end up like this person I know, who insists that eating is an addiction, and that a human being can live off of light as an energy source.

Because hey, they read it in a book, and there’s a fanclub on facebook saying so too!

Well, I’ve seen someone get pretty close to dying, with that belief. So no, don’t fall for that one.

But what’s the middle road?

How do you balance openness with common sense?

It’s not that hard.

Step one: think.

Use reason, and ask yourself if this thing or that thing actually makes sense.

Like, could science confirm this?

Next, tap into your feelings.

Because very often - and especially in the West where we have glorified emotions at the expense of reason - our emotions overrule simple, logical common-sense insights.

So when your gut (which is about as smart, if not smarter, as your brain) tells you there’s something that doesn’t add up, but your emotions shout louder just because the idea or choice or belief *feels* so good, know that you’re on thin ice.

You just might be able to decide something (take an action, make a purchase, adopt a belief) that makes no sense, and you’ll end up paying the price.

This, the fact that our gullibility can be so easily exploited by marketers, the church or politicians, is why I created the Calibrate Reality Dojo.

And yes, I’ve been going on about the free webinar without giving you a launch date - but this weekend I received the finished slide deck from my designer, and so:

Calibrate Reality Dojo officially launches on Thursday, 25th of October.

Mark your calendars…

Cheers,

Martin

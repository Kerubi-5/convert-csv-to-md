---
title: Oh But I'm Very Serious
status: draft
datePublished: '1484123058'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

After yesterday’s email in which I lobbed the question ‘why so serious?’ at you,
			you might have come away with the wrong impression.

			This Martin guy, does he not care? Is he just a callous, unfeeling and self-centered
			jerk?

			I don’t think so, personally.

			In fact, I care a lot.

			About others, about the future, about our children and the state of the world and what
			have you.

			And I’m not callous or unfeeling either - in fact I make emotional sensitivity and
			intuition part of my work and my daily life.

			And self-centered?

			Um, well... I suppose I’m not free from that. I am, after all, human.

			Says so on my birth certificate.

			So let’s clarify yesterday’s message:

			When I say being serious about stuff won’t help you, it means things like:

			Not taking self so seriously.

			Because self is nothing more than a personal interpretation of a mostly incomprehensible
			and unknowable phenomenon we conveniently call ‘reality’.

			And we’re just human, we have limited ability to understand or make sense of reality.

			So here’s this VAST reality, and this tiny little understanding-machine that tries to
			find its way in reality.

			And this tiny little machine has the temerity to say: “Well this is the understanding I
			have of it, and therefore it is as I see it. And what I see displeases me and that gives
			me the right to be upset, to get bogged down, to be grudging and serious about it”.

			Isn’t that ridiculous?

			We barely understand ourselves, much less our world - and then we are entitled to get
			upset over our limited interpretation and understanding of it?

			Nah.

			So don’t take yourself so seriously.

			Truly, it helps.

			Next, here’s what you do need to take seriously: Other people.

			For me, there’s nothing that makes me laugh more than myself and my silliness.

			But others?

			You BET I take other people seriously.

			Which anyone who has worked with me has experienced.

			Could that be, would that be, should that be you?

			I don’t know.

			Hit reply and let’s find out.

			Cheers,

			Martin

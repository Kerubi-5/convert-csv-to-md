---
title: How Will You Stop Yourself?
status: draft
datePublished: '1490961023'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/e83cc9b7-0106-4fb8-bf15-d9e93bff286c.jpg" width="143" height="190" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/e83cc9b7-0106-4fb8-bf15-d9e93bff286c.jpg" data-file-id="4834477" />One of the most fun parts of my work is asking questions.

Especially the coaching questions that really get at the heart of things.

For example, when someone tells me about a goal or dream they have, I like to ask:

“In what way will you prevent yourself from reaching that goal?”

Yeah I know. Makes you think, doesn’t it?

Sometimes, that’s what a coach needs to do:

Stop you dead in your tracks and force you to assess a situation - the good, the bad, and the possible self-sabotage.

So think about it: with the goals that you have...

How will you prevent yourself from reaching them?

And how can you avoid that behaviour?

Meanwhile, I’ve started posting the coaching questions to Twitter, with the goal of putting one a day out there.

If you don’t follow me there yet, now’s a good time to do it.

Make sure to tweet at me, so that I know you’re one of my readers.

Follow me here:<a href="http:// http://twitter.com/martinstellar" target="_blank" rel="noopener" data-cke-saved-href="http:// http://twitter.com/martinstellar"> http://twitter.com/martinstellar</a>

Cheerio,

Martin

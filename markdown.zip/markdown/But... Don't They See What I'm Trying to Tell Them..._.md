---
title: But... Don't They See What I'm Trying to Tell Them...?
status: publish
datePublished: '1616372773'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-21523" src="http://martinstellar.com/wp-content/uploads/2019/03/MartinStellar_Coaching_Illustrations_Empathy-and-enrollment-1024x768.png" alt="" width="349" height="262" />Isn’t it frustrating, when you see a solution for someone and they just will not buy into it?

But it’s so clear to you! You KNOW that things will change for them, and for the better!

Then how come they don’t enroll?

Don’t they SEE? It’s so clear!

Yep, it’s clear: to you.

And nope, they don’t see it.

Why?

Self-importance.

When you find yourself failing to create a client, or someone refuses to help or collaborate, it’s because you’re approaching the situation from a self-oriented point of view.

The POV is <em>your</em> POV.

You might have the vision, but <em>they</em> will only see that vision, and buy into it, when you manage to show them.

And as long as your point of origin is your conviction that you’ve got it right and they need to change, you won’t enroll them - not as a buyer nor a collaborator.

Instead, put yourself in their shoes.

Apply empathy.

Be a researcher, an anthropologist, asking yourself incessantly ‘what’s going on in that mind, in their world?’

What fears, aspirations, desires are present for them?

What is it like to be them?

Do that, and you make the enrollment process about them instead of about your vision.

That way, people will be far more open to trying out your vision, and you’ll find yourself enrolling with much more ease.

I’ve practiced and honed this technique of ethical selling for decades, and it works, and people love the kind of conversations we have.

And my clients and students?

Well, they sign on clients with more ease, at better prices, and with less awkwardness.

Could be yours to have too...

<a href="https://martinstellar.com/helping-good-people-sell-more-and-generate-a-bigger-impact/">Information and signup</a><a href="http://martinstellar.com/helping-good-people-sell-more-and-generate-a-bigger-impact/"> here.</a>

Cheers,

&nbsp;

Martin

&nbsp;

&nbsp;

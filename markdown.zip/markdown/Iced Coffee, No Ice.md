---
title: Iced Coffee, No Ice
status: publish
datePublished: '1579262710'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - How to sell your work
  - Relationships

---

<img class="alignleft  wp-image-22517" src="http://martinstellar.com/wp-content/uploads/2020/01/MartinStellar_Coaching_Illustrations-Iced-coffee-no-ice-1024x768.jpeg" alt="" width="349" height="262" />“It already has the ice in it”, says the waiter as he puts down the glass of coffee.

It’s my favourite restaurant at the beach, where I like to sit and work in the mornings.

I look: no ice, just coffee. I touch the glass: it’s warm. Very clearly, this coffee is not iced, even though iced coffee is what I asked for.

“Yeah”, he says, “we’re no longer buying the big icecubes, because we had an icemaker installed. These new cubes are so small, they melt away when the coffee pours over it”.

Baffling. I mean, I’m all for reducing costs and optimising operations, but if it is at the expense of customer experience, something isn’t right.

Now, I don’t know if the owner is a penny-pincher, or if he’s simply been bullied into buying the icecube machine by some overzealous hospitality equipment salesperson, but if a customer has to ask for extra ice, it doesn’t bode well for the future of the restaurant.

Which is a real pity, because the place is generally excellent, the food is high quality and the owner is a nice guy who treats his staff well. I want them to stay in business, they deserve it. But this way…? Not a good sign.

Reducing costs is good. Optimising for profit keeps a business healthy.

But a business exists by virtue of customer love, and there’s only so much you can do to reduce costs.

The moment customer experience becomes less important than profit, you’re either on the road to failure, or to becoming one of those unpleasant companies that treat customers like cash-dispensers on legs.

And without customers, a business is nothing.

So keep ‘em happy. Delight the people who give you money. Profit will follow.

Cheers,


Martin

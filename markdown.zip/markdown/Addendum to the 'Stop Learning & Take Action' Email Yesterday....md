---
title: Addendum to the 'Stop Learning & Take Action' Email Yesterday...
status: publish
datePublished: '1487753583'
categories:
  - Doing it right as an entrepreneur or creative professional

---

Because while learning can be a hindrance is you keep stuck in it and you don’t act on it, the opposite is also true:

If you keep taking action and those actions aren’t getting you results, you might well be stuck in a different kind of comfort zone.

And it’s even worse than the first one. After all, if you learn but don’t act, you’re at least learning something.

Whereas if you keep churning away your hours without seeing any returns from your hard work, you’re not learning much and you’re burning yoursefl ujp in the process.

Sometimes, action needs to stop.

Sometimes, you need to stop.

Step back. Look at what you’re doing, what it results in, and observing whether or not you should keep up with the same actions in the same way.

You now, analyse the input and the yield.

Because sometimes, you just need to tweak what you’re doing, change your strategy a bit (and sometimes a lot).

But if you’re stuck in action and you’re running so fast that you’re spinning your little legs like a cartoon character without getting anywher, you don’t give yourself the space to see whether what you’re doing is what you ought to be doing.

Action beats inaction any day of the week.

But there’s nothing like taking the right action.

And that’s why working with a coach is so useful.

A coach sees when you need to slow down, when you need to speed up, and when you need to stand still and take stock.

And he or she can tell you what kind of action will get you the biggest yield.

&nbsp;

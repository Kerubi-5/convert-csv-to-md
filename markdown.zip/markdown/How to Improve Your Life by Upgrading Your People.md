---
title: How to Improve Your Life by Upgrading Your People
status: draft
datePublished: '1492591891'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/e40a78d0-9d48-4581-847e-6af55ddabd01.png" width="228" height="303" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/e40a78d0-9d48-4581-847e-6af55ddabd01.png" data-file-id="4834521" />Last year, I made a conscious decision to upgrade my social circles.

Because while I loved the people I used spend time with, I felt a real need to be inspired. To see good
people doing big things.

To be swept along in other people’s currents.

Because when they say ‘show me your friends and I’ll show you your future’, there’s a lot of truth to that.

In the world of addiction treatment, for example, it’s well known that no remedy or therapy is as big a determinant for success as the people an individual hangs out with.

And the effect of meeting new people has been amazing. It brought me focus, joy, productivity, and some amazing opportunities. And amazing people, obviously.

Just because I sought out people I can learn from and who inspire me.

And that’s something you can do for yourself as well.

Because it’s never a good idea to be the smartest kid in class.

Don’t underestimate how powerful the effect is when you get deliberate about who you spend time with.

For example, that artist group I’m member of, and where I exhibited some photos last fall?

Those people are on fire. After that first group show, they’re putting on one after another. Feeding each other, inspiring each other, showing up and working together. Beautiful to see.

Another example is the Cabal Mastermind group I host.

When I started it, I had no idea if it would work. I’d never done group work before.

But I knew that if I would very carefully select each member, there was a real chance something beautiful would happenAnd something beautiful did happen, and continues to happen.

The seven ladies in this group have SUCH a strong bond, and the interaction and and support dynamics are SO impressive.

It’s a humbling experience to see them grow into such a strong team.

So to make that kind of social circle available to more people, I’m starting a second Cabal group.

A few months ago I sent an invitation for a men-only group, but there weren’t enough men to start, so this time it’ll be a mixed group. Men, women, trans, martians, whatevs.

As before, membership is by invitation and interview only, because like I said: the type of people in your circles matter a lot.

Application opens on May 1st, so stay tuned.

Meanwhile, do this:

Look at the people in your life, and ask yourself if there are enough people who truly inspire you.

If the answer is no, then I highly recommend you seek out new people and start spending time with them.

Your future you will thank you.

Cheers,

Martin

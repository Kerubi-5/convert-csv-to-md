---
title: Ethical Sales Strategies, for People Rich With Integrity
status: pending
datePublished: '1652399813'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-21669" src="http://martinstellar.com/wp-content/uploads/2019/05/MartinStellar_Coaching_Illustrations-Ethical-selling-for-people-rich-with-integrity-1024x768.png" alt="" width="349" height="262" />

A while ago, someone asked what I do, so I said: “I teach people ethical selling”.

“Huh”, they said. “That’s odd, because selling and ethics are diametrically opposed”.

Are they though?

If a baker sells you a loaf of bread, is he being unethical?

He’s got something you want, and you’re both happy to exchange things of value.

Selling – or, trading value – is natural. Older than language. Belongs to being human.

Lack of ethics only comes in when a seller sells something that the other person doesn’t need, or won’t benefit from, or when the buyer is manipulated into buying.

But as long as you, the seller, want the buyer to make the best possible decision for themselves – be it to buy or not to buy – there’s no ethical conflict.

In fact, when you’re happy to take a no if that’s best for the buyer, you’re in full alignment with ethics.

After all, isn't selling about helping someone get the best outcome?

Then all you need to do is detach yourself from the outcome, and serve your buyer in choosing yes or no.

It's them who should be attached to the outcome, not you.

And if they're not, then they probably shouldn't buy your work - and if you have the guts to tell them that, I'd say you're operating with full integrity.

<hr />

On another note:
I'm building an app that coaches you on working your pipeline, moving your deals forward - and closing them faster and at better rates.
It's called SalesFlow Coach, and we're scheduled for beta-release early May 2022.
Register <a href="https://martinstellar.com/salesflow-coach-launch/">here</a> to be notified when it goes live.

---
title: 'Insight: Why You''ll Never Change, and Why That''s a Good Thing'
status: draft
datePublished: '1516707842'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/51ade2de-0fff-48c2-be44-2a5bda4f165c.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/51ade2de-0fff-48c2-be44-2a5bda4f165c.png" data-file-id="4835397" />The other day I called my (ex) abbot, with a question about psychology.

Turned into an interesting conversation, especially when it come to the moment where he said that people don’t change. That it’s fundamentally impossible to change.

I wanted to protest, because I believe in change.

Coaching people to create change is what I do, for crying out loud!

And I see people change all the time.

Especially since I started coaching a few years ago - some of the people I work with, I see them go through enormous, deep, lasting changes.

But speaking with my abbot, I had to agree. I gained an insight: We don’t change.

You can never change. Neither can I.

You as a person, with your mind, and emotions, values and aspirations, your subconscious and your fears - that whole totality of you, which is bigger than you imagine - is what it is. That’s you, and it doesn't change. There may be shifts and movements, but what you are as a human being is fixed. It's what being human is.

This might be hard to accept, but follow along with the psychology here. It’s a helpful view, as you’ll see.

Because when you stop thinking that something in you needs to change, you take the pressure off.

You no longer make yourself wrong for being who and how you are.

And you need that easing up in order to create change.

Because change does exist, just not in what we fundamentally are.

What then changes?

Our perception.

When we gain insight - when things come into sight - about who we are and how we think and so on - our perception changes.

When there’s insight, and you see more, you now have a new, modified experience, modified in whatever big or subtle way.

And when your experience changes, so do your emotions, your thoughts, your decisions, and yes, your world.

Because the way you perceive - your particular brand of making sense of reality - determines the world you live in. In that sense, reality is malleable.

And it’s worth your time to do the work that allows you to change your reality. Or rather: your perception.

The good news?

You don’t need to change. Just be as you are, you’re fine.

There, doesn’t that feel more relaxed?

Good, now for the next step:

Ask yourself, always ask yourself: what else? what more does this mean? What else is it, that I’m witnessing here?

What insight would I like to add to my form of experience?

In other words, my favourite question: what am I missing?

Cheers,

​Martin

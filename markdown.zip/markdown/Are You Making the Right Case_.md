---
title: Are You Making the Right Case?
status: publish
datePublished: '1586419538'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img class="alignleft  wp-image-23131" src="http://martinstellar.com/wp-content/uploads/2020/04/MartinStellar_Coaching_Illustrations-dont-argue-for-limitations-944x1024.jpg" alt="" width="352" height="382" />If you pay attention to it, you’ll find that your internal dialogue - the story you tell yourself about yourself, the world, and your place in it - contains a lot of negotiation and discussion.

We’re always making a case for something. This is a good idea, that’s a failed experiment, that person isn’t friendly…

On and on, a constant defense of the way we see things. Making a case for our worldview and self-view.

As being human goes, that’s unstoppable. Making a case for things is how we define meaning.

But you can choose what case to argue for.

And more often than we realise, we argue for our limitations. We defend our opinion that things are scarce, or too hard, or not worth it, or - worst of all - that *we* aren’t worth it.

Yeah I know, you’re saner than that.

Except that if you look closely, fearlessly, at the narrative in your head, you’ll find that you too argue in ways that are irrational, illogical, and that set you up to not.

To not have, not grow, not sell, not advance, not get the rewards of accolades.

Always defending a view that says no.

Wait, you don’t do that? Quick, somebody call the Dalai Lama - we have an Enlightened One in our midst!

Seriously though: don’t you think that you too argue against things, when you can just as easily argue in favour?

Painful point in case:

All the people who right now struggle to keep sales and revenue going (hard enough as it is) and who tell themselves, and others: “People just ain’t buying”.

Except people are buying. Just not the same things, and for the same reasons, and for the same solutions. But business goes on, money is still being spent, and things are still being bought.

As a business owner, you have a binary choice:

Either you argue that it won’t work, in which case you’ll find little success.

Or you argue that perhaps it might work, given clear direction and lots of action, and you just might find that it will.

The choice is yours - as is the choice to have a call with me, where I’ll try to help you find that direction, and define which actions to take.

I’m giving you an hour of my time, no expectations or sales pitch, to help - but:

You’ll need to bring two things:

Solution-bias, and action-bias. Oh, and you’ll have to have made the case for yourself that yes, you too, probably, can still keep enrolling clients, even at this time.

Got that in place?

Then book a call here: <a href="https://app.acuityscheduling.com/schedule.php?owner=11652475&amp;appointmentType=12332535" target="_blank" rel="noopener noreferrer" data-cke-saved-href="https://app.acuityscheduling.com/schedule.php?owner=11652475&amp;appointmentType=12332535">https://app.acuityscheduling.com/schedule.php?owner=11652475&amp;appointmentType=12332535</a>
Cheers,


Martin

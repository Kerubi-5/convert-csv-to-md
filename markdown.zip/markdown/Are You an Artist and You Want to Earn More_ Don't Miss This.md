---
title: Are You an Artist and You Want to Earn More? Don't Miss This
status: draft
datePublished: '1497633300'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/9e1f1143-b14b-461d-98de-e6e61f450aa9.jpg" width="279" height="320" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/9e1f1143-b14b-461d-98de-e6e61f450aa9.jpg" data-file-id="4834721" />
Gotta love it when someone smart picks up the cue, and chooses to follow something I recommend.

Like Maria Brophy, whom I had the pleasure to meet last week.

If you’ve read me for a while, you know that I never stop recommending daily emails for anyone who wants to grow their business.

So you can imagine my surprise and delight when I read that she was going to give it a go.

Now, you might now know who she is, but if you’re an artist of any kind, and you want to earn money through licensing your art, I think you might want to sign up.

Because art licensing is exactly what she teaches and coaches.

Me, I’ll be reading every single one of them.

Because while I’m barely out of my diapers as a visual artist, I do get a lot of positive feedback on my drawings.

And so yeah, I’ll try to license them - why not?

Would be fun to see them used in companies, for presentations or training materials.

No telling if I’ll pull it off, but you bet I’m going to give it a serious try.

And maybe you should too.

And with Maria’s help, your chances are bound to increase - after all, she was the brains behind getting her husband’s art licensed. The chica knows a thing or two.

Anyway, here’s where you can sign up to receive her daily art biz smarts: <a href="http://mariabrophy.com" target="_blank" rel="noopener noreferrer" data-cke-saved-href="http://mariabrophy.com">http://mariabrophy.com</a>

Cheers,

Martin

---
title: Hit Launch, or Pre-Flight Checklist
status: publish
datePublished: '1639735214'
categories:
  - Business and systems

---

<img class="size-medium wp-image-28325 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/12/MartinStellar_Coaching_Illustrations-Stellar-in-a-tin_may-contain-nuts-226x300.jpg" alt="" width="226" height="300" />

Some things you can do on the fly, and others are best done with a recipe, system, or process.

Take the humble checklist for instance, in the case of aviation.

A good pilot - the kind that tends to survive flying - doesn't take off unless they've run through a checklist of items.

For instance:

- Auxiliary fuel pump — Off
- Flight controls — Free and correct
- Instruments and radios — Checked and set
- Parking brake — Off
- Doors and windows — Locked

You can imagine that there's no big disaster if you try and take off with the parking brake still engaged - but if you fail to lock doors and windows, you could see everyone and their luggage sucked into the skies.

Whenever you land somewhere and that was what did not happen, thank the humble checklist.

And checklists are a very common - and functionally vital - part of many business processes and operations.

So, why wouldn't *you* use one?

Especially when it comes to your most vital, life-giving activity in your business: working your pipeline, and generating the opportunities and sales you want?

From my observations over the years, coaches and consultants are generally terrible at being systematic in how they track and develop the opportunities in their business.

But if you don't have a system - an effective, repeatable approach - how are you going to be effective and efficient?

How are you going to ensure that all your deals move forward, and that you land the clients you deserve?

For example, consider this little checklist:

Go to your list - be it a CRM, spreadsheet, or notebook - and pick a deal.

Ask yourself:

- What needs to happen for this deal to close?

Next, run through the steps in this image:

<img class="size-medium wp-image-28324 alignleft" style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen-Sans, Ubuntu, Cantarell, 'Helvetica Neue', sans-serif;" src="https://martinstellar.com/wp-content/uploads/2021/12/CleanShot-2021-12-17-at-10.53.54-300x221.png" alt="" width="300" height="221" />

Simple pipeline review process, right?

There. A simple, short checklist, that helps you thoughtfully, mindfully, contemplate how each deal needs to move forward, and what each individual in the dynamic needs to do in order to make it happen.

This kind of approach is very much how I work with clients and business partners, and it's really effective.

Especially if you make it a simple daily habit, to just look at a deal, ask yourself a few questions, and schedule some actions.

My problem has always been that if I work with clients, my reach and scale are limited to one person per hour, or a handful if it's in a group setting.

So, I've decided to convert my process and methodology into an app, called SalesFlow Coach.

Basically, I'm trying to turn myself into an app. Or put differently: it's Stellar-in-a-tin. (May contain nuts).

The idea is a guided experience, where you are asked the right questions about your pipeline, deals, and sales, to trigger the perfect, timely actions you need to take, in order to keep your deals moving forward and your sales closing.

I'm working hard on version 0.1 of the app, and I hope to have it ready by Monday, for you to take the system for a spin.

Stay tuned...

&nbsp;

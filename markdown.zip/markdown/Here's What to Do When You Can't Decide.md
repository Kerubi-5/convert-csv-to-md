---
title: Here's What to Do When You Can't Decide
status: publish
datePublished: '1581532953'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - Psychology in sales and marketing

---

<img class="alignleft  wp-image-22649" src="http://martinstellar.com/wp-content/uploads/2020/02/MartinStellar_Coaching_Illustrations-Can’t-decide-Don’t-try-to-1024x768.jpg" alt="" width="347" height="260" />There’s a lot we need to think about in business and we only have so little time.

So it’s useful to choose with precision what we do and don’t think about.

One thing to never think about are the kinds of decisions that can only be made when it both makes sense and feels good too.

When all available logic says ‘yes, correct’, and your gut instinct confirms ‘loving this. let’s do it’.

Those kinds of decisions, which are typically the kind that make a diff cause a big positive change, can’t be thought up.

As long as you’re trying to reason with yourself whether to do thing A or not do it, you’re only wasting time, because you’ll end up in an endless weighing of pros and cons, and end up in those boring mental loops where you keep going over the same options and considerations.

When that happens, you can safely stop thinking about it, because something in or about you just isn’t ready yet to make the decision.

Usually, with most people, that comes down to ‘not enough information, incomplete insight’, and that’s usually down to ‘not having seen the forest for the trees, because we were thinking so hard that we didn’t see anything else than what we wanted to see’.

Big decisions, or scary ones, or important ones or those with a lot of ramifications, they need both sense and emotion (in fact, psychologists say all decisions are driven by emotion).

And the sooner you put the brain down, stop thinking about it, and let your subconscious figure things out, the sooner stuff will fall into place, and you’ll end up with epiphany:

‘Ah! THIS is what I should do. And how. I see so clearly now’.

And then you have your decision.

Until your subconscious lobs one of these insights at you, I’d say you can safely stop thinking about the big decision.

There’s plenty of more readily decidable things to consider, and there’s work to do as well. Both will get you a lot more than banging your head against a decision that your subconscious hasn’t sufficiently worked on.

Or, to put all that into one sentence:

“Can’t decide? Then you can stop thinking about it!”

Cheers,

Martin

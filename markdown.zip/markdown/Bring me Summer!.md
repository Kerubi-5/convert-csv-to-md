---
title: Bring me Summer!
status: draft
datePublished: '1501071365'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img class="alignleft" src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/edc9ad45-afad-4b3b-98d1-d2ece4599a6f.jpg" alt="" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/edc9ad45-afad-4b3b-98d1-d2ece4599a6f.jpg" data-file-id="4834849" />Sure one might complain that winter is too cold, summer too hot, or autumn too wet.

But aside from putting on a sweater in winter, going up North in summer like the foreigners in Southern Spain do, or wearing wellies in autumn, there’s nobody in his right mind who would expect a different season than the one we’re in.

Seasons are seasons, nothing you can do about it.

And in life, there are seasons too. And in business.

Seasons of growth, seasons of retreat and revising, seasons of planning…

So if seasons in nature are something you wouldn’t fight against…

Why would seasons in life or business be any different?

Instead of being upset or impatient that the next season isn’t there yet, why not work with it instead of against it?

In winter, you huddle up at home and keep warm. You go for brisk walks and come home feeling alive.

And if your business is in winter season and you’re not seeing the sales you want…

Why not take that season, and use it to build plans, create assets, connections, and sow the seeds that will sprout when spring comes around?

Sounds a lot more fun than being disgruntled, doesn’t it?

Make use of the season you’re in, instead of letting it get you down.

How?

Talk to a coach, for example - gets you tips and tricks on what you can do now, to prepare for spring. 's Fun, too.

Cheers,

​Martin

---
title: Can't Have the Good Without the Bad? Rubbish. Here's How to Shift the Baseline
status: draft
datePublished: '1549371783'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21358" src="http://martinstellar.com/wp-content/uploads/2019/02/MartinStellar_Coaching_Illustrations-1-Good-and-bad-shift-baseline-1024x768.png" alt="" width="348" height="261" />It’s a common notion, especially in relationships: that in order to have the good times, we also need to accept the bad times.

A thing which is usually said by someone who’s been a jerk and uses it to justify causing a bad situation, I think. But I’m not a relationship expert.

I am however someone who doesn’t need the bad in order to have the good.

Not in relationships, not in life, and not in business.

(I’m open to influence though, so anyone who wants to make a case about why good and bad have to go together, feel free to write in and make your point. You’ll have a hard time persuading me though.)

Seriously though: good compared to what? Bad compared to what?

Here’s the thing:

Everything in our experience of life has a baseline, a ‘normal’.

For someone who’s constantly stressed, their ‘normal’ or baseline, is constantly high.

What’s relaxation for that person, would be a high level of stress for others.

Someone pessimistic has a low baseline in terms of outlook on life - and even their most optimistic moments would seem gloomy to folk like me (and I hope, you).

The trick to not having the bad, is to adjust your normal. To shift your baseline.

Because there will always be ups and downs, that’s just life.

Your experience has peaks and troughs, a constant sine wave.

And logically, if you shift your optimism/pessimism baseline up, the troughs won’t be as heavy.

If you shift your stress baseline down, the stress-peaks won’t wear on you as much.

And, in terms of relationships: if you shift your harmony-baseline up, the bads won’t be quite as bad. (3 hints to make that happen: 1: don’t try to change the other, 2: actually listen properly, 3: never treat the other as if your view of them is correct and factual. It’s not, not ever).

Anyway, our ‘normal’ baseline becomes a norm over time, and we behave and experience as if that’s just the way things are - but they’re not.

Your baselines are under your control.

Optimism, stress, motivation, enjoyment, abundance, wealth, productivity, friendships, communications, habits, conscientiousness:

You name it, and there’s a baseline present in your life, and around that you get your peaks and valleys.

So how do you shift the baseline?

Well, you can hire a coach, or get therapy, or learn to meditate, but really, the solution is simple and already in your reach.

First, become aware of where your baseline in any given area is at. Compare to how others experience or operate.

Next, analyze to learn which people, places, habits or things keep your baseline too high or too low.

Finally, eliminate those disruptors that keep your baseline where it is.

You’ll see it shift by itself.

What baseline is too high or too low in your life?

What do you plan to do about it?

Cheers,

Martin

---
title: Hidden in the Depths... Demons and Monsters?
status: draft
datePublished: '1509464416'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img class="alignleft size-medium wp-image-20050" src="http://martinstellar.com/wp-content/uploads/2017/10/MartinStellar_Illustrations-Grey-Matters-and-stories-and-self-talk-300x225.jpg" alt="" width="300" height="225" />Hey, I’m not into Halloween. In the past few weeks I’ve seen enough pictures of pumpkins to last me a lifetime.

So the topic and title of today’s missive are not about present festivities… but, as always: about you. Your mind.

See we have several kinds of narrative, different stories we tell ourselves about the world.

On the low end, there’s the negative self-talk. Criticism, recriminations, judgment and all that dark stuff.

On the far other side, there’s the nice bits. The things you’re proud of, good at, the things you like about yourself.

If you’re a sensible person, you try to deal with the first class best as can, and increase the second one. Think less bad thoughts, think more good ones.

So far, so good.

But what about all the stuff in the middle?

What about the grey matters? (Which is, incidentally, the title of a book I’m planning to write at some point).

What about all the thoughts and stories and opinions that we do think, but they’re automatic because they aren’t all that bad, and so we don’t really notice?

Those are the devious ones. Those are the secret saboteurs. They are the sly, conniving, energy-draining and grit-dissolving  destroyers of self esteem and forward momentum.

Because while those narratives may run unchecked, they have a big influence. They either strengthen the positive stories, or the negative ones.

And in many cases, they reinforce the negative stories more than the positive ones.

There’s probably science behind the reason why, but I’m not a scientist and besides: I prefer action over analysis.

So if you have a feeling that there’s something dark hidden under the surface, if it seems that no matter how hard you consciously try, you keep getting tripped up and falling back into self-sabotage or procrastination (those two are cousins, btw), maybe try this action:

For the next week, resolve each morning to pay attention to your own internal monologue. To get clarity on how you talk to yourself at those moments when you’re not listening.

I bet you’ll find that there’s a lot you say to yourself, that you wouldn’t dream of telling someone else.

And when you find those thoughts and stories, don’t try to fight it. Don’t beat yourself up over it. It’s a normal part of you, and so is getting the clarity.

When you have that clarity and you uncover the stories, here’s what to do:

Tell the voice “thanks for the information” (i.e. you acknowledge instead of reject part of yourself) and next:

Put your mind somewhere else. Don’t fight, just dodge.

Your mind is a masterfully powerful tool, and it works brilliantly with whatever you focus it on.

So discover where it focusses, and then give it something more useful or uplifting to play with.

In the end, solving negative self-talk doesn’t have to be hard to fix.

All it takes is the courage to truly see, and the repeated action of turning your mind to something else.

It gets easier over time.

If you’re the kind of person who has that courage and is willing to put in the effort to change, I can help you create the best possible story to tell yourself.

And I can help you create a method of ongoing practice, especially fit for you, your personality and your life/work circumstances.

Just hit reply, let’s have a conversation.

Cheers,

​Martin

---
title: Making Habits Fun & Fun Habits
status: draft
datePublished: '1497035290'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/02f3e68b-3dd7-4c06-b2d2-e59c61d0bd85.png" width="250" height="444" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/02f3e68b-3dd7-4c06-b2d2-e59c61d0bd85.png" data-file-id="4834677" />One indispensable thing when it comes to building habits, is to make sure they’re fun.

And yes, even doing things that you don’t necessarily enjoy, can become fun if you create the right kind of habit around it.

Gamifying things, for example - where the context of the habit you create makes it fun, even if the activity itself leaves you cold.

But every time I work on habits with my clients, pretty much for everyone, there’s one habit that is grossly underdeveloped.

And that’s fun habits. Taking care of self. Doing things that make you come alive. Taking time to do thing just because you enjoy them.

Am I any different?

Nope.

Point in case: I live on the coast, and I have ports and sailboats at my disposal, any day I want.

All I need to do is pick up the phone and rent a dinghy or get on board a yacht with a group of people.

And yet, even though I LOVE sailing, I’ve only set foot on a boat once in the last ten years.

But today in Vigo, I had a chance to go sailing, and I jumped on it.

Lovely. The breeze, the silty air, the bobbing of the ship. God, how I’ve missed this.

I even swam to the beach that National Geographic apparently calls the best beach in the world. Fine soft yellow sand, no inhabitants - for 20 minutes I felt like Robinson Crusoe.

Anyway, apparently I need to lead by example.

Which means as far as habits and fun goes, I have nothing to be ashamed about. I set an example, best as can.

But when it comes to fun habits?

I admit I can improve.

So you bet I’ll go out sailing more often, starting today.

I’ll make it a habit.

In fact, tomorrow I’m driving down to Porto, Portugal - and I just might rent a sailboat again. See if I don’t.

As for you?

Well, think of the things you’d really really like to do, but they just keep getting sacrificed on the altar of life stuff and business busyness.

What if you’d make a habit of carving out some time for them?

I’ll help you make sure the other stuff won’t suffer because of it, if you join me in the Habit --&gt; Path coaching programme.

I’ll put some info about the programme on my site in the next few days, so you know what goes into it.

In the meantime, let me know if you want me to help you build happier, funner habits. After all, I've made habit-building an ongoing experiment for the last 20+ years, so I might be able to help.

Cheers,

​Martin

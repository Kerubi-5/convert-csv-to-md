---
title: How to Lead With Values and Create Rapport With Buyers
status: publish
datePublished: '1645519320'
categories:
  - How to sell your work

---

<img class="size-medium wp-image-27916 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/08/MartinStellar_Coaching_Illustrations-Build-Rapport-with-buyers_-Lead-with-values-300x225.jpeg" alt="" width="300" height="225" />

You've probably heard that when talking to a buyer, you should create rapport.

Most advice says that we're supposed to shoot the breeze for a bit, have some casual talk.

About the weather, the kids, a movie, or a sports game...

But I call that lame, and perfunctory.

And it's a waste of time as well.

Much better is to create rapport *before* you even talk to a buyer.

How?

Very simple: you lead with values.

That doesn't mean you have to shout them from the rooftops - it's much subtler than that.

All you need to do, is to be very clear on what your own values are, and then you go looking for buyers who have similar values as you do.

Because when two people care about the same thing, would defend the same thing, get upset about the same things that they believe should change, then you instantly have rapport.

Either implicitly or explicitly, before you even have your first conversation, rapport will be there.

It's really simple, too.

Take a sheet of paper, and write down at least 10 values that you have.

Next, rank them for priority, and identify the three main values, the top three that you'd never ever compromise.

Then, as you go through your prospecting and outreach and marketing and sales, you simply look for people who display similar or compatible values.

And you actively prioritise engaging with, and speaking to, those people.

Very simple - especially given the fact that people have their values always on display:

All it takes:

Just spend a moment looking at someone's website or articles or social media presence.

You'll be able to get an idea of what their values are - and when they match yours, they qualify for more of your time.

That's how you get off on the right foot, moving forward, efficiently and pleasantly, with every buyer you deal with.

&nbsp;

&nbsp;

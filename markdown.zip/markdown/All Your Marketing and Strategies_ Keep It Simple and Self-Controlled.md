---
title: 'All Your Marketing and Strategies: Keep It Simple and Self-Controlled'
status: publish
datePublished: '1632133150'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img class="size-medium wp-image-28022 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/09/MartinStellar_Coaching_Illustrations-All-you-marketing-keep-it-simple-and-self-contolled-300x225.jpeg" alt="" width="300" height="225" />Whenever you make plans or build strategies, it’s important to keep it simple, and keep the outcomes under your control as much as possible.

The more complex your strategy is, the more moving parts you have, and the greater the chance that something breaks or doesn’t work, which can then affect the entire campaign.

And, the more an outcome is not contingent on the quality of your actions, and the amount of time you spend on it, the more unpredictable the outcome.

In the real world though, people often build complex systems and strategies, that are dependent on luck, timing, and things as fickle as the algorithm of a social media platform.

If you’re not in control of the outcomes of your actions, it’s hard to know which actions to prioritise and how to execute on them.

If your plan is complex, you have a chain full of potential weak links.

That’s why you want to build plans and strategies that are as simple as can be, and where every outcome or milestone or performance indicator is as directly linked to your actions as possible.

That’s how you create marketing campaigns and strategies that bring results and that enable you to scale up.

So, are you overwhelmed by the complexity of what you’re trying to do… or underwhelmed by the results it’s getting you?

<a href="https://calendly.com/martinstellar/30-minute-appointment-with-martin-stellar">Talk to me.</a>


Cheers,
Martin

---
title: Cheer When They Unsubscribe...???
status: publish
datePublished: '1627640819'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img class="size-medium wp-image-27880 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/07/MartinStellar_Coaching_Illustrations-Cheer-when-they-unsubscribe-300x225.png" alt="" width="300" height="225" />The best reaction that you could have when somebody unsubscribes?

You cheer.

But wait - don’t we want to grow our numbers?

Don’t we want more readers, more subscribers, a bigger audience?

Yes, obviously.

But not everything is for everybody. Obviously.

I'm saying this because the other day somebody on Twitter said “Hey, I started recording these videos on YouTube, and people are leaving, and it hurts”.

Yeah, of course, it doesn't feel good when people leave.

But then I went to have a look at those videos.

And they're really good.

They're quality, content production is good, delivery is good, presence too.

It's good stuff.

But in terms of branding and positioning, those videos are for a very specific niche: parents.

And since I'm not a parent, this content - good as it may be - just isn't for me.

Now, there's a lot of people like me, who would be interested in what this person might say, if they would be talking about something else.

But if this person wants to brand themselves as an advisor on good parenting practice, then the fact that somebody like me would unsubscribe from that list or unfollow them is actually a good sign.

Because then the creator is left with a smaller audience, a smaller list of followers - but on average, that smaller audience will be far more engaged.

So don't worry about people leaving.

When you see somebody unsubscribe, it is actually a good sign, because it means that you stand for something, you are there with a narrative and a message and a positioning and branding that is for a particular type of person - and the person who leaves signals ‘not for me’.

Those people who it’s not for, when they leave, they’re doing themselves - and you! - a favour.

So don’t worry too much about your numbers.

Cheer when a couple of people unsubscribe.

It’s a sign you’re doing it right.

On another note:

Is branding and boldly positioning yourself something you want help with? <a href="mailto:hello@martinstellar.com">Let me know...</a>

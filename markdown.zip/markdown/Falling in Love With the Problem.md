---
title: Falling in Love With the Problem
status: publish
datePublished: '1507907439'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/9d83707f-fe37-4fe7-beea-a12cbf87b405.jpg" width="350" height="262" align="left" data-file-id="4835093" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/9d83707f-fe37-4fe7-beea-a12cbf87b405.jpg" />You probably know that I don’t believe in problems. More specifically, that I find it useful to reframe a “problem” into a challenge, a dilemma, or an opportunity.

But the other day on Daniel Pink’s podcast, I heard Tina Selig give a completely different spin on things.

Tina says that there’s enormous benefit to falling in love with ‘the problem’ (or any other kind of situation that requires a solution or a decision).

To spend time with it, give it attention - BEFORE you start looking for solutions.

And I agree: we usually define something as ‘needs an answer/solution/decision’ and then we go look for that.

But if we stay with the problem longer, and try to reframe it, we open up far more options for the solution.

Daniel and Tina use the example of planning a joint birthday party. But, what if we look at planning a celebration? Or a way to mark our birthday? Or
a way to get all our friends together? Or something that would be the most surprising? Or a birthday journey? Or a ritual?

Suddenly, there’s all kinds of ways to plan the event… any event, whichever event.

So, before looking for a solution or answer, Tina says it’s good to “Frame-storm before you brainstorm”.

And yep, she’s got it right.

This is exactly the kind of thing that I do when coaching clients.

It’s why one of my favourite coaching questions is: “What else?”

Because when you start with an assumption about which “problem” needs to be solved, you’ll be limited to the option pertaining to that problem.

But if you widen your perception first, and deliberately select a framework for the problem-solving you’re about to do, you’ll be solving the same problem but you’ll have FAR more options to choose from.

So yes. Fall in love with the problem.

Just make sure you break off the engagement, before you end up getting married to the problem.

&nbsp;

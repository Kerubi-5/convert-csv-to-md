---
title: Always in the Corner of Your Eye
status: draft
datePublished: '1517389018'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/661245fc-d999-42e5-9747-50b8cb2c0e06.png" width="350" height="350" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/661245fc-d999-42e5-9747-50b8cb2c0e06.png" data-file-id="4835421" />There’s something just outside your field of vision. Something to the side and just to the back of you.

Do you see it?

Of course you don’t: it moves when you turn your head.

Monsters under the bed?

Oh no, I’m not into fairy tales.

I'm talking about something that you don’t want to see. don’t want to know, don’t want to admit or accept.

That thing that you once saw in a dream, or that thing that people have pointed out before… or that thing that deep down, you know needs attention… except you pretend it isn’t there.

You KNOW it’s there, calling out for attention, but you prefer to act as if it’s not there.

And it’s that thing, the almost invisible - but constantly nagging, in one way or another - that needs attention.

For me, it was two things and I finally mustered up the guts to face them.

The first one was that I persistently procrastinated on the biggest tasks, the most high-leverage activities in my business.

The second, connected to the first one: that I was playing small. Stuck in a comfort zone. Keeping things ticking along, but not building anything big.

And yes, it was scary, and for a few days outright depressing, to face the facts.

But I’m glad I did, because now I know what I want and where to go.

And, I no longer have this nagging notion that was constantly looking over my shoulder.

So here’s a question for you to ponder today:

What truth are you not willing to see?

And, what would happen with you if you’d finally face up to it?

Cheers,

​Martin

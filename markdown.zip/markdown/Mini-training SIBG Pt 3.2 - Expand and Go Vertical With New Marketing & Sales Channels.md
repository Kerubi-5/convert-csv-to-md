---
title: >-
  Mini-training SIBG Pt 3.2 - Expand and Go Vertical With New Marketing & Sales
  Channels
status: pending
datePublished: '1643279857'
categories:
  - Assets and Leverage
  - Business and systems
  - Business Growth Fundamentals

---

<code><img class="size-medium wp-image-28577 alignleft" src="https://martinstellar.com/wp-content/uploads/2022/01/MartinStellar_Coaching_Illustrations-Go-vertical-with-new-marketing-sales-channels_Stages-and-Ingredients-of-Business-Growth-Mini-Training-P.t-3.2-300x225.jpeg" alt="" width="300" height="225" />Training &gt;&gt; Stages &amp; Ingredients of Business Growth Pt. 3.2 Expand and go vertical with new marketing &amp; sales channels</code>

It's an attractive idea, to open new methods and channels for marketing and selling your work.

Advertising, content marketing, social media campaigns, webinar funnels... there's so much you can do!

But I suggest that before you do anything that requires investing money, you start by mining your network for opportunities.

I mean, you've spent decades developing relationships, right?

That means you’ve invested in building relational capital, as Jay Abraham calls it.

And there's nothing in your way of reaping the rewards of that investment.

Now, you're probably thinking that in your larger network, there aren't that many opportunities to be found.

But ask yourself:

What different kinds of opportunities actually exist?

Sure, there's buyer opportunities, but is that all?

What about revenue share partnership opportunities?

And joint ventures?

Or platform access, like guest blogging or writing a column?

Starting a podcast with someone?

Introductions, referrals, and endorsements?

Someone with an large list, who can send emails about your work?

All these, and there are many more types, are opportunities that can drive enormous growth in your business.

So now, I hear you say: "But I don't have anyone like that in my world!"

Ah... now that, that might be true.

But here's the secret to <strong>Mining Your Network for Opportunities:</strong> (aka: MYNO)

<strong>You</strong> might not have them in your world...

But the people in <strong>your</strong> world might have them in <strong>their</strong> world.

(MYNO, btw, is a new mini-training I've started building. As soon as the SIBG series wraps up, I'll be sending you the first chapter. And yes, it'll be included in the free SalesFlow Coach app, along with checklists and workflows).

Anyway:

The people in your world know people - and you would to well to discover who they know, and if they can connect you.

So instead of looking at your network with the question "Who do I know who could represent a channel opportunity?", ask yourself:

"Who do my people know, who might represent an opportunity?"

That, incidentally, is also exactly the question to ask your people:

"Who do you know?"

"Who do you know who might want to start a podcast with me?"

"Who do you know, who would like to receive 20% of gross revenue, for every client they send me?"

"Who do you know, who might have a surplus of clients and is busy, and would avail themselves of my excess unused capacity?"

"Who do you know, who runs a publication and would want me as a columnist?"

"Who do you know, who has an audience but no trainings, that I could build courses for?"

“Who do you know, who has a large database of people who need what I write about, and would they syndicate my articles?”

I'm not saying you shouldn't invest in something like an ad campaign or staff.

But ask yourself:

Doesn't it make more sense to first go for the free option, and see what channels you might discover, if you first mine your network?

Should you not extract all possible value from what you already have and have built - i.e. your relational capital?

Yes, I'm once again recommending you go out and talk to people.

Especially if you're considering investing money:

Mine your network for channel opportunities first.

Coming up tomorrow: SIBG Pt 3.3 - How and when to enter new markets.

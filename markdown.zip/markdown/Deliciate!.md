---
title: Deliciate!
status: publish
datePublished: '1547210344'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img class="alignleft wp-image-21251" src="http://martinstellar.com/wp-content/uploads/2019/01/MartinStellar_Coaching_Illustrations-Deliciate-1024x768.png" alt="" width="351" height="263" />How’s you year shaping up so far?

Most of us, we launch into a new year with zest, vigour and gusto, and probably with another couple of poetic words.

But every day life happens, and we all get to adapt our plans to the changes that start happening when the clock strikes midnight.

It’s easy to then get stressed, disheartened, or worse: to beat yourself up for yet again making resolutions that barely last until the first weekend of the year.

Before you know it your plans are out the window, it’s back to the grind, and the year is shaping up to look pretty much like last year.

If that’s you: stop and deliciate.

~ To delight oneself; to indulge in feasting or revels.

Kindness wins, every single time.

And being kind to the self is where it all starts (quickly followed by kindness to others, of course).

It might not apply to you, but almost everyone can do with some more self-love.

So if your year hasn’t taken off yet and you’re already worried or stressed or frustrated, this one simple judo-move just might give you a healthy, useful, fruitful reboot.

A walk, a bath, a movie or new shoes - whatever thing you know will delight you.

Put the tools down, close your laptop, close the door to the studio, mute your phone, block out a few hours, and go deliciate.

And if you want to put a smile on my face, send me an email and tell me in what way you’re going to do that.

Cheers,

Martin

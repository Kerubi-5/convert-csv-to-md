---
title: Good Ideas? Volunteer Nothing
status: publish
datePublished: '1654039888'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - How to sell your work
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-22145" src="http://martinstellar.com/wp-content/uploads/2019/10/MartinStellar_Coaching_Illustrations-Volunteer-nothing-1024x768.png" alt="" width="361" height="271" />

Good ideas abound, and they’re a dime a dozen.

And unless someone accepts a good idea, it’s little use.

And each day, we volunteer our good ideas to others.

“This thing would really help you!”

“Have you tried XYZ?”

“Dude, you’re holding it wrong - that’s not how it works”.

“Darling, maybe we should stop and ask for directions?”

If you’ve ever volunteered good ideas, you’ll know how rarely they get picked up.

Each time you suggest something, the other person subconsciously is being told that they’re wrong, which is exactly why so many good ideas get lost.
You don't make people wrong, you say? Well, that is what you do, when you have a good idea they need to see - you're right, you want them to agree, so they're in the wrong.

Nobody likes to be made ‘wrong' - and while our intentions may be excellent, our coming out unbeckoned with our good ideas, just doesn’t work.

Everything changes though, when someone asks for our good ideas. That’s when they listen, consider, and often also implement.

This principle - inadvertently ‘making someone wrong’ - is why so many sales opportunities break down.

So how do you get your child, your spouse, your assistant, or indeed your buyer, to ask for your good ideas?

Well, you can’t ‘get them to’. We don’t control other people.

But, we can be the best possible partner in the conversation, for them to want to know, and ask for, our good ideas.

How?

Volunteer nothing. Offer no good advice. Have no excellent recommendations for them.

Instead, learn that person. Investigate what they’re up against.

Ask questions and keep asking them, until they ask you: “What would you do?”

Ask people about their problems, until they ask about your solution.

When they do, that's when you offer your idea, and then you’ll very likely see it heard, considered, and probably even adopted.

But until they ask?

Volunteer nothing.

Not only is it respectful to leave the other to ask instead of taking the high-ground that comes with knowing what’s best for others, it’s also vastly more effective.

&nbsp;

<hr />

On another note:
I'm building an app that coaches you on working your pipeline, moving your deals forward - and closing them faster and at better rates.
It's called SalesFlow Coach, and we're scheduled for beta-release early May 2022.
Register <a href="https://martinstellar.com/salesflow-coach-launch/">here</a> to be notified when it goes live.

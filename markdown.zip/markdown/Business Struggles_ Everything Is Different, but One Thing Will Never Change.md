---
title: Business Struggles? Everything Is Different, but One Thing Will Never Change
status: publish
datePublished: '1610410504'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img class="alignleft wp-image-22202" src="http://martinstellar.com/wp-content/uploads/2019/10/MartinStellar_Coaching_Illustrations-Selling-and-leadership-1024x768.png" alt="" width="352" height="264" />I know, it’s tough trying to keep business going when literally nothing is the same. Society, business, mobility, economy: it’s all different now.

In that sense, the world has never seen a situation as wildly VUCA as the one we’re in now.

Where the term stands for Volatility, Uncertainty, Complexity and Ambiguity.

It’s a concept from the military world, designed to help gain insight and make better decisions when the playing field we find ourselves in is foreign, and we don’t have a map.

Kinda like what the business world - society at large, actually - is in.

But not everything is different.

And there’s one very important element that can keep a business running, and it will never ever change, not so long as there are people.

What will never change, is people’s needs.

And even if your people aren’t buying your thing like before, they still need your work.

And, it’s on us as business owners to find out what their new needs are, and what new method, package, or offer they’ll buy, in order to fulfill those needs.

You just can’t afford to rely on methods and offers that used to work, because VUCA. Everything is different, unknown, volatile…

Except needs. Those remain.

And your people need you, that remains as well.

This fundamental truth - people need things - is what caused me to build the IP to Profit system when lockdowns started happening last year, because it's a step-by-step process for identifying exactly what your past buyers need, that might help them right now.

And if you know how to implement, it can get you new sales from past buyers, in as little as one or two weeks.

Get the training at pay-what-you-want (only until this Friday) <a href="https://gumroad.com/l/AAKEu">right here. </a>

Cheers,

&nbsp;

Martin

&nbsp;

&nbsp;

---
title: Martial Arts for the Mind? You Bet...
status: draft
datePublished: '1533285256'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/685d8782-6679-4917-a683-75257c5e2bab.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/685d8782-6679-4917-a683-75257c5e2bab.png" data-file-id="4835977" />Amazing to see what a human can do, given proper persistent training.

Especially when you look at extreme sports, or martial arts. The jumps people make, the ultra-fast response times, breaking stone by hand…

Or Bruce Lee’s one-inch punch - which might have been staged to some degree, but even accounting for the part, it’s still a massively impressive feat.

The human being simply is an astoundingly large mess of potential and possibility.

But what if you could develop the same kind of power, speed, resilience as a super-trained martial arts specialist - except mentally?

What would your life be like…

...If you could solve any problem?

...If you could overcome any setback, with grace and ease?

...If you would show up to life every single day, fully ready - and able! - to take on whatever life throws at you?

Imagine for a moment what life would be like if you were a Shao-Lin monk of the mind?

Can be yours to have, you know.

And it isn’t that hard. You don’t need to spend 12 years in a monastery. No need to train yourself by crawling up a staircase backwards on your hands and knees in a monastery in Asia.

No, to practice martial arts of the mind, all you need to do is develop the skills that enable you to control your mind.

Because most of us, we’re totally stuck in our heads, have no control over it, and the only respite we get is when we feel good.

But that’s no way to live. And you can change it.

Train your brain, learn how to think critically and develop the skill to make decisions the way an executive would.

In other words: balance rational thought with a healthy emotional world.

Which is quite different from how things usually are in the West:

Completely irrational thought, gullible absorption of whatever shows up in a Facebook feed, and an unhealthy emphasis on feeling good.

Not that feeling good or being happy is bad, but consider this:

Feelings come from thought - so if your thoughts aren’t designed to create wellbeing, how can you end up feeling good, consistently?

Exactly. That’s why every change starts with changing the way you think. And I can show you how, and I will… soon. Working hard to finish the webinar, and I hope to send off the slides to my designer this weekend.

Anyhow, must crack on. Got a webinar to build for you…

Raise your hand to register your interest and I’ll put you on the guest list… get you a nice bonus too: a 30-minute strategy session after the webinar, to make sure you get to implement your learnings in the best possible way…

Hit reply, say yes, and it’s yours…

Cheers,

Martin

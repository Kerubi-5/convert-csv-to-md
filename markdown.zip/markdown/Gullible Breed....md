---
title: Gullible Breed...
status: draft
datePublished: '1535360859'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-20739" src="http://martinstellar.com/wp-content/uploads/2018/08/MartinStellar_Coaching_Illustrations-Gullible-breed-stolen-attention-not-normal-1024x768.png" alt="" width="351" height="263" />There’s a scene in Men In Black, where a group of people accidentally see an alien get caught.

Tommy Lee Jones flashes his memory wipe thingy at them, and proceeds to tell them a BS story, to replace their memory. Something to do with light reflecting off of a cloud of swamp gas, so that they won’t remember that they actually saw an alien.

He sees the empty faces, and sighs: “God, you’re a gullible breed”.

And yes, we are. We’re exceedingly gullible.

Something shows up in a Facebook timeline, and people just take it for truth.

News outlets spin a story so as to fit their purpose, and people buy it.

Marketers online and off tell us that without product X our life will be crap, and folk whip out their credit card.

It’s incredibly easy to fool people.

Here in Spain, people put doctors on a pedestal. As if they’re some kind of miracle workers.

Point in case: when I fell with my motorbike a few months ago, I got up and saw I had some scrapes on my legs.

Nothing that hasn’t happened before, nothing that won’t heal.

But the bystanders were in shock: “You need to go see a doctor!”

I checked my legs, and said: “It’ll heal by itself. Why do I need a doctor?”

“So that he’ll cure it!” they replied.

Hang on, how on earth is a doctor going to ‘cure’ scrapes?

The best he can do is disinfect it, and I can do that just fine by myself. (Or perhaps innocculate me against tetanus, but I already had those a few years ago and so I'm still protected).

So I stopped at the pharmacy on my way home, got some betadine, done.

But people in Spain think a doctor is a demi-god. They were sold the story, and they bought it wholesale.

But it goes much deeper than that kind of thing.

I’m not talking conspiracies here, but there’s an insidious, worldwide exploitation of an evolutionary psychological trait going on.

See, in order to survive, humans need to recognise patterns in their surroundings.

Which is why we evolved to be pattern-seeking machines.

If claws cut us once, we’ll run the very next time we see them.

If these particular berries make us ill, we’ll stay away from anything that looks like it.

If a particular fish is especially tasty or easy to catch, we develop a bias for fishes that look like it.

Seeking out patterns and acting on recognising them has kept us alive. People who ignored patterns ended up having a very niche chat with Darwin in the afterlife.

And marketers exploit this like you wouldn’t believe.

They know how easy it is to fool people and get them to buy things, by tapping into that gullibility that exists in all of us.

And that’s how they have learned how to steal our most valuable asset: our attention.

Because any time you pay attention to something, especially online, someone is making money.

Ever hear of ‘Pay Per View’? That’s a fine example. Each time a PPV ad gets seen, Google makes money.

So there’s this enormous drive and competition, to get better and better at stealing our attention.

That’s why Facebook is so addictive: it’s literally been engineered that way.

But your attention is valuable, because where you place your attention determines directly where your life and your business will go.

If you binge-watch Netflix, you get entertainment but little else.

If by contrast you read a biography or a book on growing your business, you get an upgrade to the mind.

You get to choose - but not if you’ve fallen for the trap, the one that says that letting others steal your attention is the new normal. It’s not.

It may be the norm these days, but there’s nothing normal about being addicted to others stealing our attention.

Your attention is your most valuable asset, and I say: protect it.

And if you notice you can’t unhook yourself from something, ask yourself if it’s because someone is profiting from it.

If so, you might want to eliminate it from your life, or at the very least, severely restrict the time you give it. But better to just do away with it altogether.

Final tip? Think, don’t be gullible. ‘The norm’ is usually not the same as ‘normal’.

Hey, do you think someone in your life would benefit from these daily emails?

You can do them a favour by forwarding this one - and I’d seriously appreciate it if you do...

Thanks!

Martin

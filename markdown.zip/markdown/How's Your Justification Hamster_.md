---
title: How's Your Justification Hamster?
status: draft
datePublished: '1544022981'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21134" src="http://martinstellar.com/wp-content/uploads/2018/12/MartinStellar_Coaching_Illustrations-justification-hamster_reationalisation-1024x768.png" alt="" width="350" height="263" />Ever notice how the mind tries to convince itself of things?

Reasons and argues, in order to prove something as true or not true?

It’s like a justification hamster running round in our minds, driving a thought-factory which outputs nothing but reasons why what we’re thinking or saying is true.

Circular reasoning, stuck in a loop, like an argument that states ‘this is true because it’s true’.

I spoke to someone who was asking about my coaching method.

Tells me they had coach training, and a certificate, but never hung up their shingle.

Unprompted, starts to tell me all the reasons why they can’t, shouldn’t, don’t want to, aren’t skilled enough despite the qualification.

Sounds normal, right? Knows what they want.

Except in big neon lights, the message flashed at me “I’d LOVE to do what Martin does”.

But the justification hamster happily churned away, and in the chat this person showed me that they’d probably a super-skilled coach.

If only they’d put that justification hamster to sleep.

We have a thing we want, or a thing we don’t want.

Next, we have reason why yes, or why not.

Reasons that are irrelevant, or a fallacy, or based on fears.

And then we tell ourselves, over and over again, that our reasons are correct, valid, just, and - well, reasonable.

Except they’re not.

Not once you recognise that your mind is playing tricks.

Look at your mind. Look at what it’s doing, from a meta-perspective.

Thoughts are something you have - it’s not what you are.

You can rise above them, and look down from above, detached, like a researcher.

You’ll notice patterns, lots of (rather boring) repetitions, and a whole bunch of silly things you’re telling yourself.

And if you’re lucky, you’ll see how you’re trying to justify, rationalise, convince yourself - and seeing it is what you need in order to stop doing that, so that you can see things for what they are, instead for what your mind is telling you they are.

Cheers,

Martin

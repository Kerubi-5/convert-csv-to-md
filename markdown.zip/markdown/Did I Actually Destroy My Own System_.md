---
title: Did I Actually Destroy My Own System?
status: draft
datePublished: '1498470158'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - How to sell your work
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/4c2a1c32-5569-4834-a359-02902d0523b4.jpg" width="375" height="280" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/4c2a1c32-5569-4834-a359-02902d0523b4.jpg" data-file-id="4834742" />
Remember that email the other day, where I said it’s a good idea to stop explaining so much and listen instead, when you are looking to find buyers?

It’s ironic, because “Explain” is actually part 2 of my LEAP marketing system.

(I haven’t talked about it in the last year or so because I discontinued the LEAP marketing newsletter, but “LEAP” stands for “Listen, Explain, Ask, Prosper”.

And so, yes: explaining matters when you’re trying to sell your work.

Except most people skip over the first part.

Which part is that? Oh, the one called ‘Listen’ - have you not been listening?

Joking aside, listening really does come first, in the sales process.

You need to know who you’re dealing with, what they need, what keeps your buyer up at night, and what kind of solution they’re looking for.

Only once you really get that (and this applies no matter what you’re selling - art too solves a problem for those who buy it), do you get to explain.

So when your sales are lacking, use this benchmark:

Listen: Have I spent enough time listening to this individual, or to my ideal market?

Explain: Have I adequately explained that I get this person’s/demographics painpoints? (I.e. have I listened so much that *they* feel understood when I explain?)

Ask: Am I actually asking for the sale? (plenty of people skip over this one)

Prosper: Am I doing those three things consistently enough to prosper? Are my prices and my Terms&amp;conditions set up to allow for prosperity in my life?

It’s a simple system, but it’s effective: use it in your sales process, your conversations, and your overall business planning.

And use me if you want to get that system set up and running like a machine.

Because there’s nothing as useful and as much fun as having a system that you can run, test, adapt and iterate, when it comes to being in business.

Cheers,

Martin

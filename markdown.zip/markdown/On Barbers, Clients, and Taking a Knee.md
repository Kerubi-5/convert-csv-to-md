---
title: On Barbers, Clients, and Taking a Knee
status: publish
datePublished: '1569418570'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img class="alignleft  wp-image-22091" src="http://martinstellar.com/wp-content/uploads/2019/09/MartinStellar_Coaching_Illustrations-Barbers-and-kneefalls-1024x768.png" alt="" width="348" height="261" />It took a while to find the right barber in this town: everyone I tried did a good job, but not *my* job - they’d cut my hair the way they wanted, not what I asked for

(In one instance, I actually ended up with a Tintin haircut. Not what I had asked for).

And then I found Jose: super nice guy, talks too much (the way barbers apparently learn in barberschool) and: cuts my hair just how I want it.

I don’t blame the other barbers in town: what you buy there, is what they see as most suitable. It’s their art, their style, and good for them.

But what you buy at Jose’s, is what you asked for. Both options work, and both are valid.

And in fact, I respect the other barbers for their method.

The fact that I have a particular wish doesn’t’ mean it’s their job to execute on that - for that, I need a different barber - apparently, one named Jose.

Clients can often come up with requests that are reasonable enough, but that aren’t what you specialise in, or what you enjoy doing.

That doesn’t make them wrong, it just means that maybe you’re not the person to help them.

Often, we try to accommodate. To include the thing, because that way we get the sale - and it’s often a terrible idea to do that.

For one thing, you’ll end up doing something outside your expertise and that’s of little leverage, or something you don’t enjoy, or both.

But adjusting to requests when we shouldn’t also reduces the chance we’ll close the sale.

Wait, what? We’re giving people that extra thing they want - doesn’t that make them more eager to buy?

Maybe, for some people. But a savvy buyer will see that you’re taking a knee, and it will look desperate, and they’ll back away.

Instead, see if you can solve their need in another way. Help them find and select someone to do that job. Or introduce them to someone in your network. Or maybe there’s something else that you can do for the buyer, that gets them the same outcome, but in a different way.

But never do a haircut that you’re not comfortable doing, and expertly so.

Cheers,


Martin

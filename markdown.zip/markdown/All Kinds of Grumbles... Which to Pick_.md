---
title: All Kinds of Grumbles... Which to Pick?
status: publish
datePublished: '1561368273'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21817" src="http://martinstellar.com/wp-content/uploads/2019/06/MartinStellar_Coaching_Illustrations-Hierarchy-of-grumbles-1024x1024.jpg" alt="" width="349" height="349" />There’s a million different things you could choose to work on:

From the way your office drawers are organised, to the way your team operates, to starting an ad campaign, updating your website, or following up with those prospects you have on file.

Each has a promised reward, and obviously, also a cost.

And like I said yesterday: the things you most resist, are often the things you’ll most stand to benefit from.

But there’s another way of looking at the wildly varied playing field called ‘your business’, and for that I want to remind you of Maslow.

You’ll remember his hierarchy of needs - the things a human needs to have in place, in order to live well and reach self-actualisation.

As a model, it’s nice and inspiring - but it doesn’t give you actual tools… there’s no manual or checklist it comes with, for which actions to take in order to build your hierarchy.

And as you know, action is what moves the needle.

But *which* action?

What out of all the possible activities will have the biggest impacts?

Introducing: Maslow’s hierarchy of grumbles.

Everyone in business (and everyone else, for that matter) will have things that need to get done.

Problems to solve, systems to build, todos needing to get done… a whole washlist of ‘grumbles’.

You grit your teeth, you do stuff, and things start moving.

The trap we fall into, is doing the easy things, the busywork - the low-level grumbles. Cleaning out your inbox, tweaking your social media profiles, updating your email signature - and thus, we get a feeling of accomplishment, because hey - we’re doing things!

Yes, but are those things worth it?

If you busy yourself with low-level grumbles, you might feel good about being active, but will you be making a difference in your business?

Instead of working on low-level grumbles, what would happen in your business if you’d focus on high-level grumbles - the tasks, projects and activities that challenge you and require that you show up as your best, business-building self, instead of occupying yourself with things that seem useful but that have little impact?

What if you:

Worked on a strategy that consistently places you in front of potential clients?

Developed a lead-generation habit, so as to fill your pipeline?

Finally committed to showing up daily to your audience?

Put together that pricing page you’ve been procrastinating on?

Started that podcast? (*points at self*)

Would create standard operating procedures for your team, so that new employees have an easier time on-boarding?

Started reaching out and get booked for public speaking?

Launched that course your people have been asking you for?

What would change in your business and your life, if you gave priority to the high-level, or even meta-level, grumbles?

Pick your battles with care…

&nbsp;

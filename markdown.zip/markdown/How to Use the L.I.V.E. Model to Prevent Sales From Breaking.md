---
title: How to Use the L.I.V.E. Model to Prevent Sales From Breaking
status: pending
datePublished: '1652350731'
categories:
  - How to sell your work

---

<img class="size-medium wp-image-28011 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/09/MartinStellar_Coaching_Illustrations-How-to-prevent-sales-from-breaking-by-using-the-L.I.V.E-model-300x225.jpeg" alt="" width="300" height="225" />
<div>

Super frustrating, when a buyer seems keen and ready, but then they end up not buying.

</div>
<div>

And very often it’s because you skipped over a fundamental, essential, crucial step in the sales process: verification.

</div>
<div>

Meaning: they talk, you listen, you interpret their words and their needs... and usually, we then directly go into provisioning our solution.

</div>
<div>

Or, in the context of the L.I.V.E. model: equipping your buyer, i.e. going for the sale.

</div>
<div>

But if you don't first verify that you understood their case and their need correctly, it's very easy to miss the mark...

</div>
<div>

And then the buyer doesn't feel like you're getting them, or that something intangible is missing, and so they don't buy.

</div>
<div>

To prevent that from happening, remember and apply the L.I.V.E. model. Four simple steps:

</div>
<div>
<ol>
 	<li data-line="0">Listen</li>
 	<li data-line="1">Interpret</li>
 	<li data-line="2">Verify</li>
 	<li data-line="3">Equip</li>
</ol>
</div>
<div>

A nice if - innocent - illustration of how things can go wrong when you don't verify happens here in town, in my local hardware store.

</div>
<div>

The lady who works there is really nice, super helpful.

</div>
<div>

But, in trying to be helpful, she nearly always moves too fast.

</div>
<div>

She gets my request wrong, goes to the back, and comes out with something other than what I’m looking to buy.

</div>
<div>

It’s no big deal, but practically every time I need something, she has to return to the back and go pick out the thing that I <strong>did</strong> ask for.

</div>
<div>

At first, I thought: “She just doesn’t listen”.

</div>
<div>

But that’s not it.

</div>
<div>

What's actually going on dawned on me the other day, when she said:

</div>
<div>

“Oh I thought you wanted XYZ”.

</div>
<div>

See, it’s not that she doesn’t listen - she simply doesn’t stop to verify that we're talking about the same thing.

</div>
<div>

She interprets and straight away moves into trying to equip me with whatever washer or wrench she thinks I need.

</div>
<div>

Again, nothing against her - I like that she’s trying to help and think along with me.

</div>
<div>

But she could make the process so much better if she’d simply ask:

</div>
<div>

“So you want an XYZ in that size?”

</div>
<div>

Then I could say yes, or “No, the other thing/size/colour”.

</div>
<div>

For you in your sales process, this is an extremely important thing to remember.

</div>
<div>

Because there are countless points in the sales process where you interpret people’s statements.

</div>
<div>

But if you then don’t verify you got it right, you keep giving your buyer the sensation that you’re not quite getting them.

</div>
<div>

And with each instance of that happening, your buyer is less bought-in to what you’re trying to say, offer, or have them buy.

</div>
<div>

And so, the sale breaks.

</div>
<div>

So remember the L.I.V.E. model:

</div>
<div>
<ol>
 	<li data-line="0">Listen to what they’re saying.</li>
 	<li data-line="2">Interpret and compute.</li>
 	<li data-line="4">Verify that you got it right.</li>
 	<li data-line="6">And only when you do have it right, do you offer to equip them with your solution.</li>
</ol>
</div>
<div>

It’s really simple, too:

</div>
<div>

“So you’re saying that you want XYZ…?”

</div>
<div>

“Do I have this right, you’re looking for…?”

</div>
<div>

“Tell me if I’m wrong, but do you mean that…?”

</div>
<div>

This way, you invite the buyer to correct you, so that you can calibrate whatever you’ll say next - calibrate it to reflect exactly what <em>they</em> wanted <em>you</em> to hear.

</div>
<div>

Make sense?

</div>
<div>

Verify what you think you heard, instead of running with it.

</div>
<div>

You’ll get more sales.

</div>

<hr />

On another note:
I'm building an app that coaches you on working your pipeline, moving your deals forward - and closing them faster and at better rates.
It's called SalesFlow Coach, and we're scheduled for beta-release early May 2022.
Register <a href="https://martinstellar.com/salesflow-coach-launch/">here</a> to be notified when it goes live.

---
title: Better Than Trying to Flog Yourself Into Productivity...
status: draft
datePublished: '1515676111'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/a28e5560-222a-4cac-8f54-95d5964bc2c0.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/a28e5560-222a-4cac-8f54-95d5964bc2c0.png" data-file-id="4835365" />...is a little trick that I implemented recently, and it might help you too, get more done in less time, while having more fun while doing it.

Because while I can focus well and enjoy putting in hard work, it’s very easy for me to fall into phases where I jump from one activity to the next, from calls to emails to writing and drawing… without getting as much done on them as I’d like - without focus or hard work (you might be able to relate).

The trick (actually, it is nothing more than a decision) is simple: set an ‘hour of power’ in your calendar, every day. Can also be a block of two hours or three, so long as you take mini-breaks inbetween.

However much time you want to block out for work that’s not necessarily creative, but fruitful and productive.

The point is to have a pre-scheduled slot of minutes, reserved for doing the work. Getting the tasks done, the papers filed, the product shipped or the article written.

What you decide to do in that hour is up to you, but make sure it’s the things that you normally procrastinate on, and the things that you know will make a difference in your business.

(There are also things that you procrastinate on that are of the housekeeping nature and don’t cause a significant growth in your revenue or output. I’m not talking about putting those in your Hour of Power).

Right, so now you have a whole hour, every day, to move the needle on your business.

Make sure you set it up so that you don’t get distracted: disable email, Messenger and other notifications. Switch off the doorbell.

Next, prepare a list of what you want to do - in half the time you have.

Planning to fill half the hour instead of the whole bock helps you keep your goals attainable.

S.M.A.R.T. goals, remember? Specific, Measurable, Attainable, Realistic, Time-bound.

Point is that we tend to underestimate what we can do in a year, while we over-estimate what we can do in an hour.

So to keep it attainable, don’t set the bar too high, and give yourself time to dive deeper into a task if it’s called for.

Hunker down, get to work.

To make it more fun, you can create a checklist where you tick off items, or use a spreadsheet like I do. Instead process feedback rocks.

The result of setting this hour? I get more done, in less time, I enjoy it more, and I have more time to spend writing, drawing or creating ideas.

So if you feel your days are messy, or you’re aware that you never get around to doing the real important (and not urgent) work, create space for it.

Simple trick, with a massive impact.

Cheers,

​Martin

---
title: In Which I Get Called Out
status: publish
datePublished: '1652689576'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img class="size-medium wp-image-28328 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/12/MartinStellar_Coaching_Illustrations-Getting-ready-to-launch-SalesFlow-Coach-300x225.jpeg" alt="" width="300" height="225" />A reader named Mark recently wrote in:

"Yo Martin, you've had an invitation about your app in your p.s. for the longest time now... when is it going to be ready?"

Now Mark is a great guy - we spoke a number of times, and over the years he's often commented on my emails.

This time, he also commented on the fact that, more often than not, I launch into building some tool or ebook or framework... only to then abandon the project and start something new.

What can I say: Bright Shiny Object Syndrome is real.

However: I'm rather pleased that this time around the delay is not because I abandoned developing the app...

It's simply that my client roster has increased quite a bit lately, and that means I get to spend less time building and developing the app, in favour of serving said clients.

Now there's one relevant notion I'd like to point you at:

The reason things have gotten so busy is because I put to use the exact frameworks and tools that the app teaches.

I.e. eating my own dogfood, and boy it's nutritious!

And that's why I'm so keen to keep developing it, and release the beta-version ASAP.

I *know* my methodology works - I see it for myself, but also with clients and business partners.

And, I *think* it might work for you as well.

So, once more, and with quantum apologies for the ongoing delay: stay tuned.

<hr />

On another note:
I'm building an app that coaches you on working your pipeline, moving your deals forward - and closing them faster and at better rates.
It's called SalesFlow Coach, and we're scheduled for beta-release early May 2022.
Register <a href="https://martinstellar.com/salesflow-coach-launch/">here</a> to be notified when it goes live.

---
title: Better Thinking, Anyone?
status: draft
datePublished: '1510655496'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/10132620-05f4-4b9c-9172-fddc54bb175a.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/10132620-05f4-4b9c-9172-fddc54bb175a.jpg" data-file-id="4835201" />
Over the last few weeks, I’ve been learning how to code.

You know, write computer programmes. Not that I have any ambition in the field - I don’t want to become a programmer. I’m happy as a coach and author and artist, thank you very much. (And no, I don't have any illusions as to my 'skills' as a programmer. I'm just a student).

But what I do want, is to learn how to think better. I’ve never had the ability to think straight through a problem, in a logical, sequential way.

It’s why I’m not very good at chess: I simply never developed the ability to hold several potential scenarios and outcomes in my mind at the same time.

Now, why would I need to think better?

After all, I’m not stupid. And I’m good at problem solving, so why the need?

Efficiency is the key word.

I’d like to spend less time, thinking harder, to come up with better solutions. And while I will always rely heavily on my intuition,

I can already tell that a better developed brain, and an increasing capacity for reasoning, is helping me.

Here’s why I’m telling you this:

We are not being taught how to use our brain. We’re not taught how to think. We may think we logical, rational human beings,
but we’re not.

We’re highly illogical in fact. Just go through your past two or three days, and you’ll find a memory where your reaction to an event or news item was along the lines of “how come people DO things like that?”

Right? That’s the reaction we get to the completely illogical actions that happen all the time.

In other words: we don’t get trained on how to use the brain.

And so the brain does its job on its own, as it best sees fit. And you know what that leads to?

Endlessly circular inner dialogue… telling yourself the same story, over and over again.

Stories about what’s wrong with that that one did, stories about how we keep screwing things up, stories about how there’s a shortage of love/money/clients… endless stories, and they’re boring as hell because you’ve told them to yourself a thousand times over already!

The brain is a formidable tool, extremely powerful.

But, only if you use the tool, instead of letting it use you.

It’s gotta be you driving that train, baby. Otherwise it’ll either keep rumbling along the same ole tracks, or it’ll run off the tracks altogether. And we’ve all experienced some form and intensity of each of those.

Your mind is there to help you, not control you.

So look at that ongoing conversation, that internal dialogue you have with yourself, and ask yourself: are you tired of it yet?

If so, there’s several options available:

You can learn programming if that takes your fancy, but if overthinking stuff is your problem, it might not be the best choice.

Or you can learn how to ease up - by learning to meditate, or doing visualisation techniques, or taking a course of some sort…

Or, you can talk to me, and together we can create a new story to tell yourself - one where you aren’t hampered by the story, but propelled forward.

Sounds good?

Then let’s chat.

Cheers,

​Martin

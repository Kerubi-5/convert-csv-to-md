---
title: Are We There Yet?
status: draft
datePublished: '1503403800'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/0577d031-b8fb-40f7-9ae5-5881656dc5d3.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/0577d031-b8fb-40f7-9ae5-5881656dc5d3.jpg" data-file-id="4834941" />Kids in the back, sun on the roof, miles of shimmering motorway ahead of you.

And a tiny voice from behind you, for the nth time: “Are we there yet?”

Not that I have much experience there, since I don’t have kids. But I know the concept.

And, I do this to myself too. Just like, maybe, you.

Are we there yet?

Has success shown up knocking on our doors yet?

Is the fight over, can we rely on stable monthly revenue yet?

Have our efforts paid off, any laurels we can rest on? Yet?

I’m afraid it’s harsh news today:

The fight will never be over. Stability will always be an apparent (but illusory) certainty at best.

For people like you and me (entrepreneurs, makers, artists, creative professionals) there can never be a “there” that we’ve arrived at.

There’s been times when I thought I had it made, and I’d relax into prideful self-absorbed complacency - and then I’d be without clients just a few short weeks later.

Oops - things kinda stall when you’re not putting yourself out there - don’t they, Martin?

Here’s the thing: you’re not a kid. You don’t need the end-station of having gotten “there”.

What’s more, the very fact that you’ll never ‘get there’ is a blessing, something to be grateful for.

Because each time you reach some sort of milestone, a new level of success or achievement, there’s another higher mountain top to climb.

That’s the joy and the beauty of being an entrepreneur. There IS no end point, not unless you decide the road ends, at some arbitrarily chosen moment.

So when you find yourself annoyed that you’re still waiting for things to get better or for problems to get solved, remember this:

The road of being self-employed, a business owner who carves out his own path, goes on as long you want it to.

So the best thing to do, is to come to terms with that, and learn how to enjoy the ride.

Because once you make that shift in your perception, and you start to enjoy the journey for its own sake regardless of the results that are or aren’t showing up, things will start to change.

First, your state and your inner equilibrium will change. You’ll be more at peace.

And as a consequence, you’ll perform better, you’ll make better decisions, and that will cause you to move faster towards that elusive “there” end point.

&nbsp;

---
title: And Now For Something Completely Uncommon
status: draft
datePublished: '1526630998'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/d9b3c6a8-2c9a-4625-b7eb-5c70669d48f7.png" width="350" height="386" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/d9b3c6a8-2c9a-4625-b7eb-5c70669d48f7.png" data-file-id="4835729" />Note: This is a one-off announcement, not related to coaching. After today, my regular coaching emails will continue as before.

Right. Ever since I started drawing illustrations and cartoony stuff, people have been telling me they quite like them.

And, that I should sell them, for use in things like presentations, websites, webinars, ebooks, catalogues, training manuals etc…

Obviously, as one does, I dilly-dallied for a long time. You know, because of /reasons.

No more.

I decided to partner with my dear friend Emma Plunkett, and in the last month we’ve worked hard to create a business around our illustrations, and her animation.

And so today, with pomp&amp;circumstance (and rather a lot of jitters, I can tell you), I present:

Uncommon Pictures

Irresistible Illustration and Animation

What we do, and who we’re for?

Think of it like this:

Got a point to make, but it’s tricky to tell or hard to take in?

Uncommon Pictures give your message life, light, and if appropriate: levity.

Check it out here:

<a href="https://uncommon.pictures/" target="_blank" rel="noopener" data-cke-saved-href="https://uncommon.pictures/">Uncommon.Pictures</a>

Question for you: who do you know, who might be interested?

Let me know…

Cheers,

Martin

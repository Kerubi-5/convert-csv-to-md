---
title: How to Make it Easier to Pivot Your Business
status: publish
datePublished: '1594601547'
categories:
  - Business and systems
  - Doing it right as an entrepreneur or creative professional
  - Hope&amp;Survival
  - How to sell your work

---

<!-- wp:image {"align":"left","width":350} --><!-- /wp:image -->

<!-- wp:paragraph -->
<p><a href="http://martinstellar.com/wp-content/uploads/2020/07/MartinStellar_Coaching_Illustrations-Practice-the-parts-scaled.jpg"><img class="alignleft  wp-image-25266" src="http://martinstellar.com/wp-content/uploads/2020/07/MartinStellar_Coaching_Illustrations-Practice-the-parts-1024x768.jpg" alt="" width="344" height="258" /></a>The other day I was reminded of my old piano teacher from 40 years ago.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Lovely old lady. Good teacher, too!</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Whenever I played a piece and made a mistake, my next step was always to start all the way at the beginning.</p>
<p>But she wouldn't have that: she always made me repeat the parts I got wrong.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Otherwise, that way you keep getting better at the parts you know, while doing nothing about the part where it gets tricky.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Oh and I remember those long lessons, with the warm Dutch sun highlighting dust motes and me being as bored as can be.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>But, she made me repeat the hard bits, over and over, and over, until I got them right.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Now, any business consists of various bits - some are hard, and some are easy.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>And the only way a business runs well, is if all the parts work. Together, but also by themselves.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Marketing, outreach, followup, advertising and enrollment conversations: each of these need to work, and then there’s a ton more:</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Your target market, your pricing, your messaging, your ability to find and fill your customer’s needs… it’s a lot.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>If you’ve been in business for a while, you probably have most of those parts working well to some degree.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>But what if you need to pivot?</p>
<p>What if right now clients are not buying, but you want to keep selling and serving?</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Then essentially, you’re looking at learning an entire new musical score, with a whole bunch of hard bits to challenge you.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Because ‘making my business work better’, which used to be the norm before all this mess started happening, is very different from ‘reinvent my revenue stream now that there’s a crisis going on’.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>One way to pivot is by trial &amp; error.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Or, you can use a recipe - a manual that says ‘do this, in that order, in that way’.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>In other words, a system that shows you all the individual parts, and how to do them.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>And that recipe - that system  - that’s what you get when you <a href="https://gumroad.com/l/AAKEu">watch this training.</a><a href="https://www.youtube.com/watch?v=YCBGOnEjuCk" target="_blank" rel="noreferrer noopener"><br /></a><br /<br />Cheers,</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Martin</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>&nbsp;</p>
<!-- /wp:paragraph -->

---
title: 'Keep Things Simple: Use the VASO Model'
status: publish
datePublished: '1650672973'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - Psychology in sales and marketing
  - Values

---

<img class="alignleft wp-image-22391" src="http://martinstellar.com/wp-content/uploads/2019/12/MartinStellar_Coaching_Illustrations-Business-simplicity-systems-1024x1024.jpg" alt="" width="356" height="356" />
<div>

Building or running a business can be hard, but it gets easier if you avoid complexity.

</div>
<div>

Simple is good. Especially when you're starting out, or introducing a new product, or you're pivoting.

</div>
<div>

The fewer moving parts in anything, the easier it is to run the thing, test it, find flaws or bottlenecks, and fix &amp; optimise.

</div>
<div>

Same thing goes for business, marketing, and sales.

</div>
<div>

You can make your business as complicated as you like, with teams, advertisements, funnels, infrastructure, franchises - you name it. A world of options.

</div>
<div>

But the more you add in, the more complex it gets and the harder it gets to figure out what’s broken and needs fixing, or what works and merits more resources.

</div>
<div>

So to help you keep things simple, I created the VASO model, which consists of Values, Assets, Systems, and Outcomes.

</div>
<div>

<strong>Values</strong>

</div>
<div>

These inform your purpose and your mission.

</div>
<div>

And, they enable you to identify and find people who share your values, so that you’ll have rapport with them right off the bat.

</div>
<div>

And anything or anyone or any plan or strategy or tactic, that's not aligned with your values?

</div>
<div>

Out. Simple. Less to fret over.

</div>
<div>

<strong>2: Assets</strong>

</div>
<div>

These can be tangible, like a list of names, hardware, office space - or intangible, such as your network, your skillset, your intellectual capital, your footprint and visibility, or the amount of goodwill and buy-in your audience has for you.

</div>
<div>

And of course, the single most valuable asset in any business:

</div>
<div>

Your list of past &amp; present clients:

</div>
<div>

The people who trusted you so much that they gave you money, meaning they're the most likely money to buy something from you again.

</div>
<div>

<strong>3: Systems</strong>

</div>
<div>

This is where you tie the first two steps together.

</div>
<div>

You build structures, frameworks, Standard Operating Procedures, workflows, documentation, and so on.

</div>
<div>

You automate stuff so that you get to spend more time as the architect of your business, instead of the operator in your business.

</div>
<div>

And, you add metrics, points of measurement, so that you’ll know what works and what doesn’t.

</div>
<div>

<strong>4: Outcomes</strong>

</div>
<div>

It's crucial to have clearly defined outcomes, goals, milestones - you need to know exactly where you're going.

</div>
<div>

Because if you don't have a clear goal, how will you know you're reaching it?

</div>
<div>

How are you going to measure how well your systems are working, if you don't have a well-defined picture of what output you want from your systems and your business?

</div>
<div>

That's the VASO model for keeping things simple, and this is how you put it to work:

</div>
<div>

Ask yourself these questions (longhand brainstorming is best, for this kind of work).

</div>
<div>

1: What are my values?

</div>
<div>

What would I stand on a barricade for?

</div>
<div>

What do I not accept, what change am I willing to fight for, or stake things for?

</div>
<div>

2: What assets do I have in place?

</div>
<div>

What tangible value does each have in my business, what economic value if applicable, and what potential does each asset have, provided I leverage it in a smart and strategic way?

</div>
<div>

3: What systems are in place, and in what way can they be simplified or improved so that they work better, or become easier to measure for output and results?

</div>
<div>

4: What outcomes are my systems producing?

</div>
<div>

What outcomes do I <strong>want</strong> my systems to produce?

</div>
<div>

What do I need to modify in my systems and strategy, to reach my clearly-defined outcomes faster?

</div>
<div>

Point is, everything is a either a system or part of one.

</div>
<div>

And every system is perfect for the outcome it produces.

</div>
<div>

So if you see outcomes you’d like to change, or things are going too slow, you now know which questions to ask, in order to do some high-level, intelligent reflection.

</div>
<div>

You look at how your values and assets can be combined and leveraged so that the system becomes simpler and more measurable, and more likely to get you the outcome you want.

&nbsp;

</div>

<hr />

On another note:
I'm building an app that coaches you on working your pipeline, moving your deals forward - and closing them faster and at better rates.
It's called SalesFlow Coach, and we're scheduled for beta-release early May 2022.
Register <a href="https://martinstellar.com/salesflow-coach-launch/">here</a> to be notified when it goes live.

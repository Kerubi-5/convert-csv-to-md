---
title: Controlling the Economy of Productivity
status: draft
datePublished: '1501500200'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/eb5807c3-d83c-42d5-a311-c1cc2b587566.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/eb5807c3-d83c-42d5-a311-c1cc2b587566.jpg" data-file-id="4834861" />“I need a new car”.

Do you, or do you want one? And if you truly do need a new car, does it have to be a *new* one, or could it also be second hand?

“I need to get in shape”.

Need, or want? Many people would do well to shape up, but very often, there’s no actual need.

“I need to stop procrastinating”.

Need, or want?

I’m not playing semantics here - I’m playing economy.

Because when you tell yourself (or others) that there’s something you need to have or do or change, it becomes a given, a requisite.

Which means it gets importance, priority even.

But when that gets applied to things you want instead of need, you just might end up making yourself more busy and more overwhelmed than you need to be.

Making a clear distinction between what you truly need, and what you actually want is important.

If you start giving your kid pocketmoney, you explain the difference between buying things they need, and things they want - right?

Then, why not apply that to the choices you make as well?

If you’re honest with yourself, you’ll find there’s a ton of things you thought you need, but in reality you want them.

Apply that to the choices relating to work and how you spend your time, and boom:

Suddenly you’re free of self-imposed pseudo-needs, and you have a whole lot more time-capital and energy-capital to spend on things that really matter.

Simple tricks, but so effective.

And that’s the kind of thing that makes coaching people so much fun.

Get some for yourself, if you want…

Cheers,

​Martin

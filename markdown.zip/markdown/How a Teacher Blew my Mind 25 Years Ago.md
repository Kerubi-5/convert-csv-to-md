---
title: How a Teacher Blew my Mind 25 Years Ago
status: draft
datePublished: '1541153658'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21056" src="http://martinstellar.com/wp-content/uploads/2018/11/MartinStellar_Coaching_Illustrations-Eliminate-influence-1024x1024.png" alt="" width="348" height="348" />A lazy summer afternoon in the early 90’s, another class to sit through drowsily.

With lazy movements we settle in and get our books out - but within minutes, I’m wide awake and super-switched on.

What did the teacher just say?

I’m around 20, studying to be a psychiatric nurse, and this class is on group dynamics.

And the teacher just said something that would change my life:

“You cannot not influence”.

Blew my mind.

What it means is: no matter what action, attitude or position you take in relation to a group, your being there has some sort of influence on the group and the individuals.

Even if you only observe, from the outside and without interaction: that still has an influence.

And just as you can’t not influence, you can also not be not influenced.

Even if you were to hole yourself up in a white room, that room too has an influence on you.

The very absence of stimuli will affect you.

(it will, in fact, have you question your sanity after 5 days, and very likely do mental damage after 10).

Anyway: in our lives, we have stimuli, and lotsof ‘em.

Millions of influences, each day: from minute ones like the sound of a train in the distance that you don’t notice, to the way the news influences you, to insidious and addictive like Facebook (and, again, the news), to the books you read and the chatter you overhear on the train… influences and stimuli, all day long.

The only way your poor brain can keep up with that is to only pay attention to a tiny section of it all, and that then gets called reality.

That’s what you get to work with.

And *what* you choose to perceive has a massive, huge influence on you, because you literally can not prevent from being influenced.

And while you might think that tiny influences make little difference: the add up. A bunch of small annoyances throughout the day will leave you feeling… exactly: annoyed.

That’s why it’s good to pay attention to what you let in, and it’s exactly why the Calibrate Reality method has as one of its tools: elimination.

To eliminate everything that doesn’t contribute to your state of being, so that you make space you can fill with things that do.

Because your state is your most precious resource, since it influences (heh) your thoughts, emotions, decisions and actions.

Protect your state.

And the best way to do that, and easiest too: ruthlessly eliminate.

So grab your axe, look at the influences that bring down your state, and…

Chop chop…

Cheers,

Martin

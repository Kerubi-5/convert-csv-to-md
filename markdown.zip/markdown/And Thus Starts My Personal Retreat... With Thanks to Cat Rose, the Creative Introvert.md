---
title: >-
  And Thus Starts My Personal Retreat... With Thanks to Cat Rose, the Creative
  Introvert
status: draft
datePublished: '1513191018'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/f7aea50b-72a7-45c4-a6c9-9eff51a0d9e1.png" width="350" height="350" align="left" data-file-id="4835277" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/f7aea50b-72a7-45c4-a6c9-9eff51a0d9e1.png" />I never thought of myself as an introvert. And I still don’t really.

But after Cat Rose interviewed me last year (I think) for her Creative Introvert Podcast, I started thinking about what it means to be an introvert.

And I noticed that while I love people, I do sometimes need to ‘recover’. Spend time alone, get my ducks in a row, my energy settled. Re-center myself. Which apparently is what happens to introverts.

And after all the people this summer and fall (My uncle staying with me for 6 months, the Cabal retreat in my town, Paula coming back for a personal retreat, two art shows etc etc), I’m basically people’d out.

My habits are back, but my focus isn’t. Yet.

And so I’m going to spend the next four months or so, focussed on 3 things: Work, study, meditation&amp;contemplation. That’s it.

I’ll avoid parties, I won’t go out much (ok, I might escape for a few days of travel, but that’s about it).

I did the same thing a few years ago, after a particularly dysfunctional relationship: spent a full year, basically living like a hermit, inasmuch as possible.

And it was one of the best, most beautiful, most focussed years of my life.

And that’s why I’m telling you.

Sometimes, you need to make the hard choices (more about that tomorrow) and choose yourself.

Sometimes, you need to isolate yourself in order to let your own energy, and plans, and creativity, congeal.

But it’s scary to lots of people. Time alone? Without, like, people?

My social self will starve!

No it won’t - quite the opposite in fact.

When you take time out, for yourself and your inner world, you’ll come back with a stronger, more relaxed social self.

AND with ideas, and results, and a plan, and what have you.

Don’t be afraid to lock yourself in a room or an AirBnB and get down to business.

Life will only get better.

Me, I’m looking forward to the next few months. Should be fun.

And yes, of course I’ll continue coaching: it’s my livelihood and it’s a ton of fun.

But the outgoing, social, fun Martin? Sorry, he’s away for a while. But he’ll be back, no worries.

And if you feel there’s something in your life or work that needs some tender loving care, you just might benefit enormously from stepping away from all the distractions and all the demands that we far too easily say yes to - and dedicate some time and energy to what really matters... to YOU.

Cheers,

​Martin

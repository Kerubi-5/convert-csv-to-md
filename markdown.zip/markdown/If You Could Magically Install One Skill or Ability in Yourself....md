---
title: If You Could Magically Install One Skill or Ability in Yourself...
status: draft
datePublished: '1491295636'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft" src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/74ccd585-d966-4f80-a356-7d51697239ae.png" alt="" width="233" height="311" align="left" data-file-id="4834481" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/74ccd585-d966-4f80-a356-7d51697239ae.png" />...What would it be?

Think about all the things you’re good at.

The work you do, dealing with people, listening... whatever it is that you rock at.

Now think about the things where you feel you’re lacking.

I’ll bet there’s a bunch of things you’d like to be better at.

I sure have a ton of them.

Next, single out the one element that would make the biggest difference in your life.

Maybe focus, or sales, or writing... whichever would have the biggest impact.

Finally, tell me this:

What’s keeping you from making the commitment to install that element, from building it, adding it to your life?

Cheers,

Martin

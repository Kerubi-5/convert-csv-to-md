---
title: Have You Squared Any Circles Lately?
status: draft
datePublished: '1538645362'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-20960" src="http://martinstellar.com/wp-content/uploads/2018/10/MartinStellar_Coaching_Illustrations-Squaring-the-circle_calibrate-reality-1024x1024.png" alt="" width="350" height="350" />Those who climb the highest peaks, the explorers, the crazy ones, and the people who invent the next revolution in human achievement don’t care that what they’re about to do is considered impossible.

You can't run a four-minute mile, or so we thought until Roger Bannister did it.

You can't fly, until the Wright brothers did it.

Space travel was a fantasy long after Jules Verne.

It’s how 99.999% of the world lives:

“It's impossible - no point trying”.

The remaining 0.001% says: I don't care, I'll do it anyway.

Impossible is not an obstacle for them.

These are the people who create change.

They are the ones who square the circle.

They do the impossible.

Like, for example… Oh I don’t know.

They learn how to calibrate reality?

Exactly.

Cheers,

Martin

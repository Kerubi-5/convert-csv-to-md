---
title: Announcement About Changes to These Articles
status: draft
datePublished: '1552291380'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - How to sell your work
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-21462" src="http://martinstellar.com/wp-content/uploads/2019/03/MartinStellar_Coaching_Illustrations-Business-sales-and-customers-1024x768.jpg" alt="" width="351" height="263" />You might remember that last year, I wrote many emails about the workings and application of a training programme I was creating - which I then proceeded to completely not launch.

(It was the ‘Calibrate Reality’ framework, which I recently decided to rename to ‘Stellar Edge’)

And today I decided to shelve the entire thing indefinitely.

Not that there’s anything wrong with it - but it isn't really *right* either.

To wit: last week I had a major insight into why I’d been procrastinating on it so much:

What the training comes down to, is essentially a form of (learn-at-your-own-pace) life coaching…

And I’m not a life-coach - for me it’s all about helping people with their business.

All this became clear when a friend - a business coach - asked me where my heart lies.

And the answer is clear:

Helping people to grow their business - which at it’s core comes down to ‘creating more customers’.

In other words: how to present your product or service in such a way that people want to buy it.

In one word: selling.

(If that word makes you pucker up your nose, you’ll either find that you’ll want to unsubscribe from these emails, or… you might find you’d really best stick around, because I’m never about pushing people. Or manipulating, or sleazy tactics).

Like I said last week: selling is just another word for transferring enthusiasm.

And I happen to know a few seriously effective (and humane, and ethical) methods for doing that.

Which is why at the moment, I’m feverishly working on changing the programme into one that… well… helps you create more buyers (And not to worry: it will still give you a stellar edge over most other people).

Because, you know how people often say they don’t know how to sell, or have ethical objections, or for some reason they keep missing out on sales even though the thing they sell would be just
perfect for the buyer?

I bet you’ll have experienced some of that for yourself at some point or other.

And it’s a real, tough, hard-to-solve problem - which is why the new focus and direction of the programme is going to address that.

The outcome is that you’ll be able to sell more, with more ease, at higher fees, whilst still honouring your values and feeling good about yourself.

Watch this space, because things are going to get interesting…

Except if you really hate sales, then you might not want to stick around.

Just know that it’ll mean though, that you’ll have a tough time being in business.

And if you feel conflicted about it, think of this:

Remember when you bought shoes, or a phone, or a sandwich, or anything really - and it was just perfect, and you’re so happy that you spent the money?

You weren’t upset that the vendour transferred their enthusiasm, right?

If anything, you were grateful, or at least appreciated, them doing a swell job.

Right. Well these emails, and the training, will show you how to become the kind of person who creates that kind of buyer experience.

I’m excited, because now there’s finally the clarity needed to help solve the real, important, problems that every business owner has.

More soon…

Cheers,

Martin

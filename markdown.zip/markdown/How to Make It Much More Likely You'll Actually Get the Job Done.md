---
title: How to Make It Much More Likely You'll Actually Get the Job Done
status: publish
datePublished: '1578917471'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - Psychology in sales and marketing

---

<img class="alignleft  wp-image-22486" src="http://martinstellar.com/wp-content/uploads/2020/01/MartinStellar_Coaching_Illustrations-outcome-vs-attitude-1024x768.png" alt="" width="347" height="260" />A quiet Sunday, and I’m having coffee at the beach with friends.

“I don’t get it”, she says. “I keep telling myself that this weekend, I’ll get stuck in and do this or that big job I have. And I always end up procrastinating on it and doing something else. But I resolved to do it, with all the intent I have - so why don’t I do it?”

There’s a university full of psychologists who could make a fortune answering that question, but in the end, the why isn’t relevant.

More relevant and more useful is asking ‘in what way do I need to show up, execute, or perform, so that the job can get done?’

Consider:

If you say “I’ll get it done this weekend” means you saddle yourself with an amount of work, time-spend and exertion, that you can’t completely measure or schedule for. Too many moving parts, no telling how much energy you’ll have or how much you’ll actually need…

So the moment you show up to do the job, your subconscious gets overwhelmed and poof goes your motivation, and hello Netflix.

If you want to get a job done, don’t impose a ‘done’ on yourself.

Instead, decide to spend time working on it, with the specific attitude and type of focus required to do that job.

Process instead of outcome - and the attitude you’ll need to bring in order to perform the process best as can.

This weekend, I wanted to knock my projects &amp; tasks back into shape. And so I didn’t say “I’ll sort Todoist out”, but instead my intent was:

“I’m going to spend time like a strategist, and give my most top-level mindwork to planning out my weeks and months, and making sure all my projects are sorted properly” - and yep, that worked.

‘Complete a project’ isn’t a very good goal. It’s an outcome that results from a goal that describes your way of operating… so when you want to get stuff done, choose not the goals, but the version of you (and the behaviour that version brings) that can make the goals real.

Cheers,



Martin

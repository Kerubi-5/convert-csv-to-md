---
title: Do You Know How to Show Up?
status: draft
datePublished: '1490710553'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

Back in my tailoring days, I had a client who was a lawyer (he was one of the nice
			kinds otherwise I wouldn’t have worked with him).

			He worked from home and I always remember that when I’d visit him to do fittings or
			deliver his suit, he would be fully dressed up.

			Suit, tie, shoes, cufflinks - ready for business.

			When there was nobody there to see him.

			When I asked him why, he told me that it’s because he like to dress for business. It’s
			good for his mindset.

			And it’s the perfect example of how to show up.

			No I don’t mean you need to wear a suit. You can if you want to, but it’s not required.
			The point is that if you want success to show up in your life, there’s a particular way
			you need to show up to your work.

			How you show up matters. A lot.

			So think of the goal you cherish.

			And ask yourself: How do I need to show up to my work in order create that success,
			reach that goal?

			Cheers,

			Martin

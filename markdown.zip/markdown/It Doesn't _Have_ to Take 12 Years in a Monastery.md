---
title: It Doesn't *Have* to Take 12 Years in a Monastery
status: draft
datePublished: '1531848337'
categories:
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/81900fbc-2d7a-4314-9684-530b8d0224f8.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/81900fbc-2d7a-4314-9684-530b8d0224f8.png" data-file-id="4835921" />When I say that I show people how to live with effortless mastery, that doesn’t meant that I’m a master of anything, not of life and much less of myself.

You might think you’re as flawed as the next man, but you’re not. Not if the next man is me.

And yet, over the years I’ve found tricks - methods rather - of handling self, mind, and outside circumstances, that together cause me to live in a pretty permanent state of flow and ease.

That is to say: the flow states come and go, but the ease, that’s something pretty much undertone throughout my life and my days.

And that’s what I mean when I say ‘effortless, masterful living’.

To be able to handle anything, no matter what - without constantly being knocked for six.

And I SO wish to share that with you.

Because really, life is too short to spend it living in struggle and strife.

And the deep, cold, hard psychological truth is this:

You don’t have to live in struggle and strife.

For example: when my tailoring company went belly up almost a decade ago, I remember waking up, and it hit me:

‘Oh geez… it’s not just that I have debts and am in trouble…. it’s much worse… I am actually completely bankrupt’.

Now normally, for most people, that would be the start of a really bad day, right?

But it wasn’t.

I remember laying in bed for hours, staring at the ceiling…

… in complete, perfect bliss.

Not happiness or joy, but something beyond that.

Then I got up, got on the phone, and started to take action to get out of the hole (which I did quite nicely, over time. Hello).

Now, you might think that it takes 12 years in a monastery to get to that kind of attitude and reacting. And sure, it helped a ton.

But truthfully, I don’t believe we need that in order to life effortlessly.

I’m reminded of my childhood friend Jan, whom I always admired enormously for exactly that effortless, roll-with-the-punches attitude. He had that by nature at age 16.

So what’s the difference? What took me 12 years in a monastery in order to finally learn how to live with grace and ease?

Resistance. I fought, argued, resisted - kicked and screamed, for years.

And it wasn’t until I yielded, gave in, gave up, somewhere 8 or 9 years in, that things FINALLY started to become easier.

Silly? No, it was just my path.

But I want to make your path easier and faster.

Which is why I’m creating Calibrate Reality Dojo - a training that helps you create that flow and ease and effortless living that I’m so in love with.

In the next few weeks, I’ll announce a free webinar where you’ll learn the basics, so don’t miss it.

Because really, isn’t life too short to life in struggle and strife?

Cheers,

Martin

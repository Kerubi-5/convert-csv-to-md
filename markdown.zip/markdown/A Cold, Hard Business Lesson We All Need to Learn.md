---
title: A Cold, Hard Business Lesson We All Need to Learn
status: publish
datePublished: '1520615752'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - How to sell your work
  - Psychology in sales and marketing

---

<img class="alignleft size-medium wp-image-20308" src="http://martinstellar.com/wp-content/uploads/2018/03/MartinStellar_Illustrations-Ethical-sales-that-work-300x225.png" alt="" width="300" height="225" />It’s never about you.

It's a cold hard lesson because it's a fact, but at least it's rooted in care. Behold:

It's never about you, no matter how good your work is, or how beautiful, or how worth it.

No matter how much you need the money.

No matter how passionate you are about your work and what it does.

If you want a healthy business, it’s always, only and exclusively, about them:

Your buyer, and whether or not their life gets better by buying.

This attitude shows, and creates trust - a requirement for sales.

And if you can also step away from the sale, be 100% ok with it if they don’t buy, you build even more trust.

And you can’t fake that.

The only way you can create that level of trust is if you genuinely, really, have “the right decision for them” as your first and foremost interest.

But doesn’t that contradict the notion that a business must make money, and that you need to look out for #1 first?

No contradiction at all, because the more trust you create in others, the more you’ll end up selling.

That’s why in the enrollment conversations I have with potential clients, I’m not trying to sell anything.

I show up, I serve, I coach.

&nbsp;

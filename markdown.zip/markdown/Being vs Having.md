---
title: Being vs Having
status: draft
datePublished: '1484731374'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

There’s a big difference between what you have and what you are.

Except most people mix the two up.

And I’m talking about the thoughts and the feelings that you - wait for it - have.

Because you're not your thoughts .

You’re not your feelings.

You just HAVE them.

But we identify with them.

We call ourselves insecure because we feel insecure.

But that makes no sense.

Feeling insecure doesn’t mean that you have to BE it.

Or we call ourselves a failure because when we think of our life and career, there’s been a ton of unsuccessful attempts.

But thinking about things you tried that didn’t succeed doesn’t make you BE a failure.

If anything, it makes you be a person who tried a lot and learned a lot.

Because no experiment ever fails.

This confusion, the human tendency to mix up what you think&amp;feel with that what you are, is destructive.

It closes you into a self-defined self-image, of a kind that programs you to not evolve and grow and experiment.

Think about it.

Suppose you think to yourself: “I’ll never succeed. I can’t make this work, I’ll never amount to anything”.

(a very common and very human thought pattern).

What kind of future would you have, if you were to take that as the definition of you?

Not a very fun future.

So take a step back, and observe yourself.

See that you ARE a person, who HAS thoughts and feelings.

Recognise that the having and the being are not the same.

And realise that what you think and feel is very, very relative.

Take it from an ex-monk.

Because for years, I kept thinking that what I think matters. That how I feel is significant.

And I’m not saying your thoughts and feelings aren’t relevant - the point is that they are relative.

They can change and they do, all the time.

You learn something new, and your thinking changes.

Someone smiles at you and your sour mood lifts, or someone lashes out and your mood crashes.

Totally unstable, all of it.

And you want to define yourself by something as fickle as the wind?

Nah. You’re better than that.

When I coach people, this theme often comes up.

Because it’s SO human to mistake the having for the being.

And every time that a client sees the difference and stops this dysfunctional identifying, big changes happen in their lives.

Want some of that for yourself?

Maybe I can help.

Here's info about what it looks like to work together: http://martinstellar.com/business-coaching/

Cheers,

Martin

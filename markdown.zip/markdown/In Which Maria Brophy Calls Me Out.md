---
title: In Which Maria Brophy Calls Me Out
status: draft
datePublished: '1490002512'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

Last Friday I had a long Skype conversation with Maria Brophy, a rather well-known
			art licensing consultant, about some plans we’re making.

			We also got to talking about more personal stuff, such as our goals and the reasons why
			we do what we do.

			And that’s when I called her out: “That goal you mention, is it big enough? Because to
			me, it sounds like you’re playing it safe”.

			Because hey, even with friends I sometimes just can’t stop myself from coaching. Call it
			professional deformation.

			She took the hint, and agreed that a bigger goal would serve her better.

			But then we got to talking about why I coach people. How I don’t practice coaching, but
			that it is what I am, on a deep level.

			And when I told her what my vision is, it was her time to call me out.

			Because she reads my dailies, and she quite rightly observed that I don’t talk much
			about my why, and my mission and vision.

			So, thanks Maria. I’ll take your dare.

			Hum. I notice I’m feeling a little nervous now. That’s a good thing. Onwards!

			Everything I do, all my work with people, the writing I do and socialising and helping
			people, is for one big overarching purpose:

			To show as many people as I can that reality isn’t what we think.

			That what we call reality is a persistent illusion.

			That absolutely none of the definitions we assign to the things we perceive, are
			actually what those things really are.

			We are raised to buy into stories about what we are, who we are, what life is for and
			about, and we buy it all, lock stock and barrel.

			And so we go through life living in a bubble of created meaning and the more we grow
			into believing it, the more we lose our childlike curiosity.

			We stop wondering, we unlearn to question everything, and we end up compliant
			life-livers.

			We get scared when we read the news, we get a job when we need to pay bills, and we feel
			joy or sadness when the violins set in.

			Just the way we’re told.

			And my mission is to show you that this is no way to live.

			My job is to bring as many people as I can into my world.

			To show you the very different reality that I live in.

			To have you experience, for yourself or by proxy, that reality isn’t what you think it
			is.

			Don’t get me wrong: I’m not saying reality doesn’t exist. A table is real and is a
			table. People are real, and you can’t walk through walls (but feel free to try).

			But what you think reality is and what it’s for and what it means to be alive, is
			different from what you think.

			The same goes for me, of course: What I think things are is also erroneous. But at least
			I have discovered the eternally questioning mind.

			And to live in that state, where nothing is what it seems and where there’s always
			something more, something deeper, something behind it, that’s amazing.

			And I wish for you to experience that, and that’s why I do what I do: write, coach, get
			on stages - whatever I can.

			This is also why I chose the name Cabal for the coaching group I host for a few select
			clients.

			Where ‘Cabal’ means ‘a secret society that works together towards a common goal’.

			But here’s the kicker: you don’t need to be part of that group in order to be part of my
			Cabal.

			You reading this, you are also part of this movement.

			Every time you read me, you get a glimpse of what life is like when you question
			everything, when you’re insatiably eager for deeper understanding.

			The movement I started without knowing what I was doing.... whoda thunk?

			But it happened, people are opening up to the world as seen through a monk’s eyes, and I
			keep hearing that it’s working. That the people who read me or work with me are
			changing.

			And I can’t tell you how enormously grateful I am that it’s happening.

			In a few months, my book will be out, and then there will be even more people getting a
			taste of ‘life unlike you’ve ever lived it’.

			And I’m grateful for you, my readers.

			You make my days joyful. Knowing that you’re out there means the world to me.

			So there you have it: the reason Martin does what he does.

			Happy now, Maria?

			So to give you something to work with today:

			What in your life do you consider true, that if it weren’t true would change everything?
			Think about it...

			Cheers,

			Martin

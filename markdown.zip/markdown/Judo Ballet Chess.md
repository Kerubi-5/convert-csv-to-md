---
title: Judo Ballet Chess
status: publish
datePublished: '1500483757'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/eacd21df-c86d-47ff-a884-ad686e194cc7.jpg" width="350" height="229" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/eacd21df-c86d-47ff-a884-ad686e194cc7.jpg" data-file-id="4834821" />These are the three modes I work with.

Chess, judo, and ballet. That’s all I need, and it’s all that you need - for life, business, or well-being.

Sometimes, you play chess: you need to be strategic, see the options, think ahead, and see the big picture of interacting possibilities.

At other times, life or business are like martial arts: stand still, feel what’s happening in and around you, and respond in an agile way.
You may need to duck and evade - people or situations - and at other times you need to take an existing momentum, act with instead of against it, and floor ‘the opponent’.

But mostly, most days, life can actually be like ballet, a dance, a way to flow and graciously be yourself.

Note how in none of this there’s battle, strife, or struggle.

Does that mean there’s no problems?

Of course not: problems can always arise.

But if you take the chess-judo-ballet attitude, you don’t need to *experience* problems as problems.

Instead, they’re either a dance, a chess-match, or an act of martial arts.

Each of which you can learn and become good at.

&nbsp;

&nbsp;

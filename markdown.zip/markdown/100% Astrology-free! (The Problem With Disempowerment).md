---
title: 100% Astrology-free! (The Problem With Disempowerment)
status: draft
datePublished: '1539168160'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-20971" src="http://martinstellar.com/wp-content/uploads/2018/10/100-astrology-free-1024x768.png" alt="" width="364" height="273" />Fun fact: in my 25 years of studying and practicing spirituality, I’ve NEVER seen any of the great spiritual teachers talk about astrology, reiki, psychic readings, LOA, healing crystals, tarot, runes, or any of the other things that you can buy on the shelves of the ‘spiritual’ supermarket these days.

Wow, hey - did you hear that? That was the sound of half of my readers clicking the unsubscribe button.

Pity for them, because if you don’t read this email, you miss out on a super-empowering psychological insight that will serve you for the rest of your life.

I use the word ‘supermarket’ on purpose, because - the most vocal supporters of the things listed above also sell them.

Which isn’t necessarily bad, but if they sell it telling you that it’s a very spiritual thing, you’re being lied to.

Obviously, the fact that I’ve not come across spiritual teachers and sages talking about it doesn’t mean they don’t, but if you spend 25 years reading everything from the Bhagavad Ghita to Basho the Zen-monk to Thich Nhat Hanh to Eckhart Tolle to Alan Watts (listen to that guy if you have any interest in actual, proper spirituality) to Carl Jung to Taoism and Zen and so on, and you find that none of them are into the modern-day supposedly spiritual things, it makes you think.

Too long, didn’t read: spirituality is something inner, and it’s about reducing.

Spirituality is not about adding stuff.

Simply strip away everything that isn’t IT, whatever IT may be, (“The Tao that can be spoken is not TAO”), and you end up with nice, simple yet deep, spiritual insight.

But you can only get there by eliminating, not by buying into yet another fad that Facebook’s algorithms throw at you, or that clever marketers promote as ‘the solution’.

Now, for the super-empowering insight:

The problem with the products on the shelves of the spiritual supermarket is that they disempower you.

When you believe that the planets are the cause of things, you are not the responsible party. When tarot cards tell you what something is or means, you’re not finding the answers in yourself.

When a crystal is supposed to heal you, you’re not relying on your own biological ability to get better.

See the problem?

All those products place responsibility outside yourself, when really everything is in your mind.

You choose your beliefs, whether you know it or not.

And if you believe that the truth or the betterment is out there and comes for out there, then what are you doing with the in-here?

If you blame a planet for your internet failing, or former lives for the problems or failings of your current life, where does that leave your own responsibility?

Sounds pretty disempowering to me.

What I’m saying is that when you adopt the belief that once you take full ownership, and you reduce and remove everything that does not stem from, activates, and works with your own inner world, you’ll gradually discover an enormous, scary big, amount of power in yourself.

Or believe in gods and angels, it’s really not my problem. But it might be yours…

My recipe for happiness and a fulfilled successful life?

Any belief you choose to adopt, make sure it’s one that empowers you, and is based on ownership and you being responsible.

Me, I’m 100% astrology-free.

Are you?

Cheers,

Martin

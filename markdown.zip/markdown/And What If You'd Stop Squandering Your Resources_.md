---
title: And What If You'd Stop Squandering Your Resources?
status: publish
datePublished: '1519042528'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/54e40248-b6aa-47a7-8ff0-39e066db4131.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/54e40248-b6aa-47a7-8ff0-39e066db4131.png" data-file-id="4835461" />And what if you’d stop squandering your resources?

Oh I know: you’re doing all you can. you’re leveraging all you’ve got: your cash, your network, your talents and skills and your audience.

But I put it to you that despite all that, you’re still squandering your resources.

When you’re stuck, you know that action - any action - will get you unstuck. Except, do you actually leap into action?

When you’re confused about what to do next, you know that talking to someone impartial and experienced will help you gain clarity. Except, did you pick up the phone?

When you feel unable to complete certain tasks or projects, obviously it will help you to learn some more skills. But I’ll venture that you have a pile of unread info-products in your download folder.

When you’re stressed, you know that meditating or going for a nice long walk will calm you right down. Unless you don’t meditate or walk.

When you don’t have a plan for making your big dream come to life, you know that writing things out, and planning them, will be the start of a plan that might actually work. Except there’s all those updates to scroll through on Facebook and Instagram first!

The common element in all this?

Your untapped potential. Resources such as the ability to learn, to take action, to plan and to create clarity: all those things are yours to use, and they work. IF you use them.

It’s so easy to feel as if there’s a shortage in this or that area of your life. But there’s probably not a single so-called shortage that can’t be fixed by using your own, innate resources.

Question is: do you actually use them? Do you put your many talents to use, or do you let them just sit there idly?

C’mon people. You were built to be a problem-solver and a maker of things. And you have all the tools you need to solve problems, and to make whatever you want to make.

Those resources in you, they work - but only if you use them.

Do you? All of them? All the time?

&nbsp;

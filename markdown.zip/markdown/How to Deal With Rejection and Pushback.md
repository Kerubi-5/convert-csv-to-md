---
title: How to Deal With Rejection and Pushback
status: draft
datePublished: '1538127081'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-20946" src="http://martinstellar.com/wp-content/uploads/2018/09/MartinStellar_Coaching_Illustrations-Dealing-with-pushback-and-rejection-1024x1024.png" alt="" width="352" height="352" />When you get pushback from people, they’re usually not at fault.

Even someone who is known to be difficult is likely to buy into your plan, your mission or your request - provided you actually reach them.

Because in nearly all cases, pushback is a signal that you didn’t reach the other person.

Didn’t connect with them, or didn’t get to show them the full picture, or maybe some part of them feels that there’s some sort of threat waiting for them.

And it’s not their job to give in to your idea.

Instead, it’s your job to figure out what’s happening with them, and why they push back.

When you try to do that, two things will happen:

First, they’ll lower their defenses because suddenly the situation isn’t about you and your idea any more, but about them and their objections. Win #1

Secondly, you’ll enable them to express their concerns, to which you can respond, which will enable them to sell themselves on buying into your idea.

You can take pushback as a rejection, or you can see it as a signal that you need to tune in to the other more, and open up a different kind of conversation. Choice is yours…

Cheers,

Martin

---
title: Disconnect and Reach Deeper
status: draft
datePublished: '1505126500'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/b23e6ab7-0226-4ae9-8f64-193a000adbb1.jpg" width="350" height="388" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/b23e6ab7-0226-4ae9-8f64-193a000adbb1.jpg" data-file-id="4835013" />There’s a little trick I like to play on myself.

It’s a nifty way to access ideas and solutions that I can’t reach with my everyday mind, and it’s simple:

Whenever I run into some sort of trouble (confusion, lack of focus, indecisiveness, communication problems, you name it) I pretend for a moment that I’m not me.

I imagine that the problem isn’t mine, but somebody else’s.

And then I ask myself: what would I advise that person?

What course of action, what attitude, would I recommend?

Of course the act of separating a problem from my being me is artificial: the problem doesn’t become that of someone else. It’s still mine to deal with.

But by making that artificial separation, I’m no longer IN the situation, as the confused or troubled person - but suddenly I’m free to take the role of an external advisor.

And it works a charm. Each time I do this, solutions come up. Ways out or around. Attitudes that take the edge off and the stress away.

Each time, I discover that there’s hidden depths, only waiting to be discovered.

And the same thing goes for you.

Because you are far more, and far more capable, than you think. Even if you happen to have an inflated sense of self: there’s more to you than you might think.

And the best trick that I know of to bring that best self out, is to pretend for a moment that the other self isn’t you, but separate from you.

As always: questions are the answer.

If you find yourself stuck or facing some sort of difficulty, ask yourself: what would you recommend if it were someone else dealing with the problem?

Then sit back and watch what comes to the surface…

Cheerio,

Martin

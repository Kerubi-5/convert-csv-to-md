---
title: Busyness Does Not Equal Business - Put a Rock in the River
status: publish
datePublished: '1548243127'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21318" src="http://martinstellar.com/wp-content/uploads/2019/01/MartinStellar_Coaching_Illustrations-Busyiness-vs-business-rock-in-the-river-1024x768.png" alt="" width="352" height="264" />Ever notice how your day fills up with a multitude of tiny tasks and chores, and you just never get around to the big ones - the tasks that actually make a difference in your business?

After all, updating a social media profile or website, filing invoices, emptying your inbox or organizing your pencils does little to drive growth.

What happens when we experience busyness but don’t manage to take care of business, is like filling a bottle with pebbles and sand, leaving no space to put in any nice fat rocks.

I see this with many of my friends abroad: they’ve been saying for years that they want to come visit, but never manage. Because life, job, kids, business - stuff gets in the way!

Other friends though, they pick a date in the calendar some months ahead, and as the day of departure gets closer, life arranges itself around that date. Presto, a friend shows up.

If you want to travel, or if you want to drive growth in your business, you need to place a rock in the river.

Do that, and the water will flow around it.

Or in the metaphor of the bottle: put in rocks first, and then top up with pebbles and sand.

Or, back to cold hard business facts:

Prioritise and plan the tasks that make a difference and that move the needle on your revenue, and let busyness fit in around it.

Not the other way around, because if you let the small and the menial fill your day, you’ll never travel and you’ll never end up growing that business of yours.

One of the things I enjoy most about coaching entrepreneurs, is helping you figure out exactly which activities and projects will have the biggest impact on your bottom line.

If you want to talk and get some help with that, let me know.

Good chance we can find some fun low-hanging fruit that will be fun for you to work on and net you more business fast.

Cheers,

Martin

---
title: Archetypes and the Case for Being a Technologist in Business
status: publish
datePublished: '1595895551'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-22710" src="http://martinstellar.com/wp-content/uploads/2020/02/MartinStellar_Coaching_Illustrations-Technologist-in-business-1-1024x768.jpg" alt="" width="351" height="263" />It's useful to think in terms of archetypes: roles and identities that you can adopt, to achieve specific results.

For example, the E-myth says that someone who’s awesome at doing something people pay for, isn’t necessarily also good at running or scaling a business: the doer archetype vs the owner archetype.

Which makes sense, because when you go from being the <em>operator in your business, </em>to operating <em>as the owner of the business,</em> things get easier.

You stop exclusively working <em>in</em> your business, and start to dedicate more time to working <em>on</em> your business.

But a level up from the Owner archetype, is the Artist.

The visionary, the architect, the designer, the maker… that’s the archetype that turns a good, fun, and profitable business, into a dream machine.

But there’s a level above the Artist archetype, and that's the technologist.

Technology comes from the Greek ‘Tekhne’ (art, craft) and ‘Logion’ (oracle, discourse), or:

Systematic treatment of an art, craft, or technique, and as such can be understood as:

The precise, deliberate, measured and intentional application of skills&amp;knowledge in the art of building a business. Systematically.

And that - creating systems - is what enables you to get a lot more return out of all the time and energy you put into your business.

So long as you don't create measurable systems, you'll always be operating in your business.

But once you start putting systems in place, that's when you're working <em>on</em> your business, and that's when the fun begins.

And building systems is what I help people with - so if you're tired of always having to do the hard work and you're ready to start getting better results and enjoy your business more, <a href="mailto:martinstrella@gmail.com">let me know</a>.

We'll schedule a short call to see what your goals are and whether or not we're a good fit, and we'll take it from there.

Cheers,

&nbsp;

Martin

&nbsp;

&nbsp;

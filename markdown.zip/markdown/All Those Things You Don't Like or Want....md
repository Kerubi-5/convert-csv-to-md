---
title: All Those Things You Don't Like or Want...
status: draft
datePublished: '1516966434'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/d4de6dd9-c180-4018-b475-c5de37eb2ddf.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/d4de6dd9-c180-4018-b475-c5de37eb2ddf.png" data-file-id="4835409" />The things that are a drudgery...

Are unpleasant, unwanted, uninspiring…

All the things that frustrate you, that you endure, the things that ought to be different but aren’t…

All that and everything else that doesn’t do anything to uplift your mood or your state…

What if none of that mattered?

Would be nice, wouldn’t it?

To just have things be as they are, without any negative experience connected, whatsoever.

No, I’m not talking about some mythical blissed-out state of utter detachment.

What I’m talking about is the one thing that you can change, to a) suffer much less from the negatives in life and b) be far more able, focussed, and energised to change the things that really matter.

Because once you have one gripe, you’ll quickly have a million, and very likely you’ll be so occupied being bothered by them, that you won’t have the energy or the clarity to really make changes in those things that have to change.

I’m not advocating acceptance and then nothing. I’m advocating acceptance as a starting point.

And what is that one thing that you can change?

For that, ask yourself: what is it that makes those things into negatives?

Is it something to do with the things themselves?

No matter how negative something might be objectively, it’s always only our own view on them that makes us experience them as negative.

And our view on things is something we can always change - but only if we want to, and dare to.

There’s nothing outside of you that makes an experience negative. It’s all in how you choose to see things.

And once you shift your view from ‘not want that’ to ‘I accept that it’s there’, you’re stop wasting your energy on maintaining a negative state of experience, and you can put that energy into actually changing the thing that triggers that experience.

So, what view would you like to change?

Cheers,

​Martin

---
title: Let's Make Things Simpler
status: draft
datePublished: '1587548261'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - How to sell your work
  - Psychology in sales and marketing

---

<a href="http://martinstellar.com/wp-content/uploads/2020/04/IP2Profit_Introduction_MartinStellar_Coach-Consultant-for-Ethical-Business-Growth-scaled.jpg"><img class="alignleft wp-image-23269" src="http://martinstellar.com/wp-content/uploads/2020/04/IP2Profit_Introduction_MartinStellar_Coach-Consultant-for-Ethical-Business-Growth-1024x768.jpg" alt="" width="352" height="264" /></a>After receiving feedback on the training webinar, and how it was actually quite overwhelming for some of the attendees, I thought I’d make things simpler.

So, <a href="http://martinstellar.com/wp-content/uploads/2020/04/IP2Profit_Introduction_MartinStellar_Coach-Consultant-for-Ethical-Business-Growth.pdf" target="_blank" rel="noopener noreferrer" data-cke-saved-href="http://martinstellar.com/wp-content/uploads/2020/04/IP2Profit_Introduction_MartinStellar_Coach-Consultant-for-Ethical-Business-Growth.pdf">here’s a short outline that describes the system</a> - intended for you to see how easy it can be to generate business, once you connect the dots…

Where the dots are:

- Your USP, or: the reason why people give you money instead of your competitor

- The current, urgent, changed needs your customers have

- And of course, the specific, narrow solution to those needs that you can offer.

I won’t go into the details here, because you’ll find the outline <a href="http://martinstellar.com/wp-content/uploads/2020/04/IP2Profit_Introduction_MartinStellar_Coach-Consultant-for-Ethical-Business-Growth.pdf" target="_blank" rel="noopener noreferrer" data-cke-saved-href="http://martinstellar.com/wp-content/uploads/2020/04/IP2Profit_Introduction_MartinStellar_Coach-Consultant-for-Ethical-Business-Growth.pdf">(10-minute read) in the PDF.</a>

Meanwhile, I’m looking for a few people who are motivated and committed, but want some help staying on track.

Meaning: strategic planning, choosing the right milestones and actions, and accountability.

So if you’re switched on and working hard, but you’d like to be more efficient, more focused and get faster results, I have space for a few people to enroll in accountability coaching.

It’s the most affordable option to work with me and it gets you daily support by email plus a weekly strategy call - so if now is the time to get more results for your efforts…

Let me know and I’ll send you the details on how it works.
Cheers,

Martin

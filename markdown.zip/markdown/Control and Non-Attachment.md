---
title: Control and Non-Attachment
status: draft
datePublished: '1506106664'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft" src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/dde33f58-3eb0-466b-b299-0ac5486c30c7.jpg" alt="" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/dde33f58-3eb0-466b-b299-0ac5486c30c7.jpg" data-file-id="4834981" />A curious thing:

When I made this drawing a few weeks ago, I wasn’t really trying.

As in: I remember that I had just written the article, on a busy day, and I didn’t have a bunch of time or space in my brain to make something “good”.

I just wanted to create a quick illustration for my article, and so I did.

But…

That particular drawing was by far the most popular at the show. It got the most comments, people really liked it, and it was one of the three that I sold.

But all I did was create a quick, almost throwaway, drawing.

Which to others apparently really spoke.

So what does this tell us?

Aside from the fact that I’m at my best when I’m not even trying?

Or maybe… just maybe… that IS the message.

That when we do things because they’re natural, and we take our minding mind out of the equation… that is when we shine brightest?

Might be a pretty nice lesson, don’t you think?

So, what if you would apply that to the activities that develop your business?

What if we would stop trying so damn hard, and instead simply do the things we do, and make the choices we make, simply because it’s natural and called for - but without overthinking it?

Without trying so hard, and:

Without being attached to the outcome?

I’ll tell you this:

The more attached I am to a certain outcome, the more unlikely I am to be “the right way” in the moment, and therefore more unlikely to get the right outcome.

Also: if I’m attached to the outcome and it turns out different, I experience disappointment and/or frustration, which doesn’t help at all.

This is why I draw without attachment, I coach without attachment, and I smile at random strangers without attachment or expecting them to smile back.

I just do things - as best as can, and then I let go.

Because in the end, we can only control what goes in (our attitude and actions) but not what comes out (the final result).

And in my experience, the best approach is to work in a deliberate but non-attached way.

It just might turn out awesome, AND it’ll be a ton more fun.

Just another way for you to be in control…

Cheers,

Martin

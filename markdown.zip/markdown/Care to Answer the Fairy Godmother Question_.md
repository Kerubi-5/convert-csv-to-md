---
title: Care to Answer the Fairy Godmother Question?
status: draft
datePublished: '1510924532'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/a4e25a15-4346-488e-9d57-f5b5bf2a0322.png" width="350" height="350" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/a4e25a15-4346-488e-9d57-f5b5bf2a0322.png" data-file-id="4835209" />In coaching everything hinges on questions.

Asking the right questions is what enables a coach to create a situation where you can reach solutions fast (try it some time - there’s nothing like a coaching session…)

The right questions function like a mirror - enabling you to get clarity on who and how you are.

Anyway, one of my favourite is the ‘fairy godmother question’:

If I had a magic wand that I could wave for you…

What would you like me to change with it?

Let me know, because the answer will either trigger me to suggest a solution, or it will reveal something interesting for you…

Cheers,

​Martin

---
title: I'm on a Mission. Join Me?
status: publish
datePublished: '1553594981'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - How to sell your work
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-21511" src="http://martinstellar.com/wp-content/uploads/2019/03/MartinStellar_Coaching_Illustrations-Invite-and-enroll-1024x768.jpg" alt="" width="351" height="263" />Everywhere you look, you’ll see people trying to rally troops, further agendas, create change, start or lead movements.

So many people with a mission, and a vision for the future of their lives, their family, the planet, their business, their customers...

And while there’s many a bad apple in that set, the majority of these people are trying to do good things, for good reasons.

But, many of them are ‘doing it wrong’.

Meaning, it’s all too easy to fall into a default attitude of trying to persuade others.

“Buying this product (or service) will do you good, it’s the perfect solution”.

“Eat your greens, you’ll grow big and strong”.

“Fund my mission to Mars, because humanity needs it”.

“Wrap up, it’s cold outside”.

“Put the cap on the toothpaste!” (otherwise I’ll give you hell until you do - though that’s rarely said outright).

“Hey, you really need to start exercising again”.

See the pattern?

All those approaches are a push, it’s trying to persuade people.

And the reason that’s such an uphill battle, is that nobody likes to be told what to do.

Nobody likes to be sold to.

But, most everyone loves to buy, or buy-in.

So, what if there’s an easier way, one that is build on empathy?

What if instead of trying to persuade people, you’d try and figure out what would make that person want to buy in, and enroll in your vision?

What if, instead of push, you turn your vision for what you hope they’ll do, into an invitation?

That way, the other person makes a decision of their own accord. They have ownership over it.

They themselves buy in.

Much more fun - and far more effective - than trying to persuade.

&nbsp;

---
title: I'm 99% Certain You Too Underestimate the Power of This
status: draft
datePublished: '1499433563'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/278f818e-1c89-42a6-a61e-972878d90882.jpg" width="350" height="392" align="left" data-file-id="4834781" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/278f818e-1c89-42a6-a61e-972878d90882.jpg" />
“This”?

I’m talking about the inside view, the ‘how it’s made’ - the look inside the kitchen.

Or in popular parlance: How the sausage gets made.

People just LOVE seeing how things go together.

And this applies to any industry, whether you’re an artist or coach or instructor or you build apps or design websites or whatever.

See, for your ideal audience - the people who will want to buy your work - what you do is almost magical.

Or at the very least: fascinating and enlightening.

“But how?”, you ask. “Why?”

“I just do XYZ, I put things together. There’s no magic in that”.

Ah but that’s where you’re mistaken.

For YOU it’s no magic - after all, you’ve been doing it for years, it’s second nature, a matter of learning and practice.

But it’s not about you: It’s about THEM.

To the viewer, it’s exactly because it seems so effortless for you, and they don’t have that skill, that your work looks so special or magical.

A ballerina, gracefully floating across a stage. An athlete in full control of every muscle.

A musician who picks a few strings, and I’m transported and enraptured (you won’t believe what a good flamenco player can do to you).

A designer who just draws, or clicks a few buttons - and BOOM. Design. Wow.

So if you want to get more engagement, more conversations, and more sales coming from those conversations, do this:

Work your magic, and show it to people.

Give them the behind-the-scenes-look.

Every day if you can.

And then watch what happens in your inbox and ultimately in your bank account.

You may not be a magician.

But if you demonstrate your mastery over your work, you’ll look like one. And you bet that’s good for sales.

And, I can help you find the best and most powerful way to do it.

All you need to do is click reply. I’ll even give you a no-cost strategy session.

To get one, start by answering a few questions here: <a href="https://martin283.typeform.com/to/v7Dsh8" target="_blank" rel="noopener" data-cke-saved-href="https://martin283.typeform.com/to/v7Dsh8">https://martin283.typeform.com/to/v7Dsh8</a>

Cheers,

Martin

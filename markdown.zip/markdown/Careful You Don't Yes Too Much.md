---
title: Careful You Don't Yes Too Much
status: draft
datePublished: '1550492243'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21400" src="http://martinstellar.com/wp-content/uploads/2019/02/MartinStellar_Coaching_Illustrations-Yes-is-expensive-2-1024x768.png" alt="" width="356" height="267" />There’s so many things out there that could get your attention, it might as well be an infinite amount.

Sights, sounds, smells… people, ideas, books and cakes and boots and projects… more things you can choose, than you could ever count.

As humans we need to select, and filter: we can only handle so many things.

A couple of handfuls of friends, one career at a time, a certain maximum of concurrent projects, one conversation at a time, really not more than x slices of cake…

So out of those infinite things, which ones do you choose? What gets your attention, your energy, and your. time?

What, in other words, do you decide to spend of yourself on?

For most people the answer is ‘as much as possible’, and they struggle through overwhelm incessantly.

These are the people who say yes - too easily, too often.

Others are in the habit of saying no out of principle, and they deliberate carefully about whether to say yes to something - instead of ‘yessing everything and everyone into their lives’.

And from my experience and observation, those who are prudent in how they spend their yesses, are the ones who have most calm, clarity, decisiveness, productivity, and because of all that: better results.

Bonus: they tend to be happier folk too, fun to be around.

Experiences and people and what have you: any given day, the world is ready to bury you under things to potentially say yes to.

It’s the wise who don’t, and who spend their yesses slowly and intentionally.

Yes is like a currency, and it’s very expensive. Everything you say yes to, comes at the cost of saying no to everything else.

Are you’re sure you’re yessing the right things, and that you’re not unintentionally saying no to things you actually areally want or need?

Cheers,

Martin

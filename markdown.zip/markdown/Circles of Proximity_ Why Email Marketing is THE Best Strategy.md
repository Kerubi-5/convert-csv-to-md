---
title: 'Circles of Proximity: Why Email Marketing is THE Best Strategy'
status: draft
datePublished: '1489580635'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

My life ain’t easy.

Right now, I’m having a seriously hard time getting people to see how powerful and effective it is to send your list daily emails.

So let me explain it differently, in terms of circles of proximity. See if it makes sense to you, and if it explains why email marketing is many times more effective than trying to sell directly on social media.

The numbers I'm using are made up, to illustrate the point.

Circle 1: World population, approx. 7 billion people. Most of them pretty nice. Others... well, let’s say folk like you and me wouldn’t miss them if they’d be gone.

Circle 2: People who are interested in the kind of work you do. Let’s say 500 million.

Circle 3: People who have, or will soon, spend money on the kind of work you do. 1 million.

Circle 4: People who know about you. Suddenly, that’s a much smaller group. Let’s say 10000.

Circle 5: Folks who follow you on social media. Call it 5000.

Circle 6: These are the people who signed up to your email list, because they’re interested in you as a professional. 1000? Good work.

Circle 7: This is where it gets interesting. These are the folks who open all, or most, of your daily emails. Say 30%, which is my average. So that’s 300. These are your fans.

Circle 8: An even smaller group: the people who actually reply to you when you send emails. They interact, you get to know each other, you have conversations with them. Maybe 150.

Circle 9: Here’s where it gets really interesting: the smallest group, the most intimate circle... they are the people who give you money for your work. Maybe only 50 of them, but imagine:

What would your business look like if 50 people give you money once a year, for a $500 or $1000 purchase?

Pretty nice, right? And absolutely within reach.

And as you well know, it’s damn hard to get that to happen with people at on social media.

But in their inbox? Where they gave you permission? And they grow evermore fond of you because you’re so committed to showing up and being helpful and inspiring?

MUCH easier.

So. If you want to grow your business and sell more, do this:

1: Build your list. Manuals available online. Get your learn on, and get your growth on.

2: Send them daily emails, that are helpful and inspiring and that, yes, also show that you’re open for business.

Start it, keep it up, and you will see sales coming your way.

And if you want to learn the writing of those emails from a pro, I have a mentoring program where I personally guide you for three months, training you in how to write emails that will thrill your audience and help you build your business.

It’s not cheap, but it’s an investment that will pay itself back many many times over.

Details are here: http://martinstellar.com/starship-mentorprise-writing-coach/

Cheerio,

Martin

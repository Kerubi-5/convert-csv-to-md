---
title: Deliberately Doing the Perfectly Imperfect
status: draft
datePublished: '1504799398'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/d51f7b46-942b-4273-a9a1-c23ea8a1be20.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/d51f7b46-942b-4273-a9a1-c23ea8a1be20.jpg" data-file-id="4835001" />Ever wondered why the world is such an imperfect place?

Wars, famines, corruption, power-hungry politicians and pollution… to name but a few of the horrors that have been with us since humanity began.

Ever considered that maybe, this blatant and hurtful imperfection… is actually quite the way things should be?

Hang on, I’m not saying that evil things are good. I’m not saying that we shouldn’t try to improve and evolve as a species. That’s not the point.

There are things that need to be improved, and there are tasks in our lives that we need to shoulder.

But what if the imperfection of the world, is its perfection?

What if the world, as it is, is simply perfectly imperfect, and should be that way, and will be that way?

This notion was shown to me almost 25 years ago, and it never really sat right with me.

Something in me always wanted to protest. And part of me still does.

And yet…. I’ve come to embrace imperfection.

Starting with me: I’m imperfect, in many ways.

And that’s ok: I’m perfectly imperfect. Just the way it is. No use fretting over it.

Same thing with my drawings: while I’m actually a bit of a perfectionist, I’ve learned to let go of that tendency, and now I create and publish absolutely imperfect drawings.

And I can’t tell you how liberating that is. And, it’s the perfect (ha!) setup for me to start improving.

Because while I don’t live with the illusion that things can, or should be, perfect, I do believe that things can improve.

And that, the incremental, gentle, non-forced, steady progress towards improvement, that makes the whole imperfection of things not just bearable, but a perfect (ha!) jumping off point.

Alright, enough with the puns.

All this to impress on you that imperfection is part of reality, and the sooner you embrace it, the sooner it will serve you, instead of frustrate you.

And the reason I was able to let go and accept imperfection?

Well, credit goes to the Cabal group.

Robbie Kaye, Katrina Gorman, Paula Mould, Salley Knight and Leigh Shenton: these are the members of the group, and they (while I didn’t even notice) helped me get over myself, and embrace my imperfection.

So if you want to learn anything from what these ladies taught your humble servant, make it this:

That being imperfect is fine - and that you can create change out of that imperfection.

For me, doing the perfectly imperfect has become life-changing. Might do the same for you...

And if you want to meet the ladies and hear what they have to say, go watch this short video: <a href="https://www.facebook.com/TheCabalCreative/videos/1780248581988598/" target="_blank" rel="noopener" data-cke-saved-href="https://www.facebook.com/TheCabalCreative/videos/1780248581988598/">https://www.facebook.com/TheCabalCreative/videos/1780248581988598/</a>

And if you want to help us out, we’d be most grateful if you share the video with your online peeps.

Thanks!

Martin

&nbsp;

---
title: Money Tight, Time is Short - Have You Tried a 4-Day Workweek?
status: draft
datePublished: '1528104182'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/68a6cabc-5ef5-4eaf-b9dd-225a1c044f8e.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/68a6cabc-5ef5-4eaf-b9dd-225a1c044f8e.png" data-file-id="4835777" />Yeah I know - reducing your work hours when times are hard is the last thing you ought to do, right?

Except, maybe it’s the first thing to do.

Maybe, if you work less instead of more (isn’t it bizarre how we can always plan more and more and more work into our future, no matter how little of it we end up doing? And we just keep thinking that tomorrow, or next week, we’ll be able to perform like a machine and check all o’ dem things to do off our lists! - except, tomorrow and next week we perform just the way we always do), maybe then you’ll be able to actually get more stuff done.

Because the default for most people when it’s crunch time, is ‘think less, work more’.

When in reality, a far more useful approach is ‘before doing any work, stop and think (and decide), and then only do the highest-impact work, the stuff that you previously thought about’.

But nope, that’ not what we tend to do. We tend to frantically run around, ever more erratically, like a headless chicken, throwing more plates into the air and running our little hineys off trying to keep them all spinning.

Now here’s a monk’s suggestion:

What if you impose limits?

Because the more you limit yourself, the more potential becomes accessible to you.

Just think: right now, you have 7 days a week, in which you can plan work activities.

If you’re smart, you exclude weekends, and you have only five. Even so: just like objects accumulate to fill your available space, work expands to fill available time.

And if the crunch is on, and there’s bills to pay or investments to make, you don’t have a lot of time. So why would you give yourself a lot of time?

Reduce the budgeted hours.

Cut back on your workweek.

Work four days a week, or even three, but work them (and yourself), as hard as you can sustainably do, without wearing yourself out?

Now, in terms of action and prodcutivity, this is the hard path. It means a tough choice and hard work.

And yes, ‘tough choices = easy life, easy choices = tough life’, but still.

Now, to make it all easier on yourself, here’s the psychological reason why limits on your time work so well.

When you tell yourself that you have 7 days, you’re effectively telling your subconscious that you have all the time in the world to get stuff done.

And if you don’t manage, well there’s always next week. Reschedule, no big deal.

But when you put a limit on your time, your subconscious gets a whole different message:

“Showtime. Things to get done. Limited time, let’s get to it”.

Now, this has to be done carefully and deliberately. It only works if you a) radically uphold your rule to only work 4 days a week, and b) actually do knuckle down on the other days.

If either are not in place, it won’t work and can even backfire.

But if you come at this without BS-ing yourself? And do the work?

Miracles. Handle with care, but you might want to try it.

Another thing to try: speaking with a coach who can help you to accomplish more, in less time, with less stress.

Apply here --&gt; <a href="https://martin283.typeform.com/to/v7Dsh8" target="_blank" rel="noopener" data-cke-saved-href="https://martin283.typeform.com/to/v7Dsh8">https://martin283.typeform.com/to/v7Dsh8</a>

Cheers,

Martin

---
title: My Crystal Ball Says This Is What You Want
status: publish
datePublished: '1622453119'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<p class="p1"><img class="alignleft wp-image-22118 " src="https://martinstellar.com/wp-content/uploads/2019/10/MartinStellar_Coaching_Illustrations-things-are-bought-not-sold-300x225.png" alt="" width="353" height="265" />I might be mistaken, but I’m pretty sure you want people to buy your work.</p>
<p class="p1">Because if you show me a business owner who doesn’t want buyers, I’ll show you a catastrophic business failure waiting to happen.</p>
<p class="p1">So yeah, you want buyers.</p>
<p class="p1">(Huh. This crystal ball really works.)</p>
<p class="p1">Problem is, most people think that in order to get buyers, you have to ‘sell’ your work, and then we get all stuck and uncomfortable and conflicted.</p>
<p class="p1">So let’s solve that right now:</p>
<p class="p1">You don’t need to sell your work, if instead you make it easy to buy your work.</p>
<p class="p1">Because things are bought, not sold.</p>
<p class="p1">When something is actually really ‘sold’, it’s called coercion, bullying, or forcing people.</p>
<p class="p1">In all other situations, what happens is that someone decides to buy.</p>
<p class="p1">There may be a sales process before that, there may be a pitch, or dealing with objections, but in the end it’s always the buyer who makes the decision.</p>
<p class="p1">And that is what selling - especially selling in an ethical, pleasant way - is all about.</p>
<p class="p1">Helping someone figure out what they want, why they want it and when, and then making it easy for them to make a decision.</p>
<p class="p1">There you go:</p>
<p class="p1">Ethical selling in a nutshell.</p>
<p class="p1">If that’s not enough for you though, and you want to crack the nut on how to get people to buy in and enroll themselves, there's the Sales for Nice People training.</p>
<p class="p1">It's ten weeks of live, 1 on 1 training sessions with yours truly, and ongoing email support throughout.</p>
<p class="p1">This framework is a structured way of handling the buying process, based on everything I’ve learned in the last 25 years of learning psychology and business.</p>
<p class="p1">It’s powerful stuff.</p>
<p class="p1">Once you're done with the ten weeks, you will:</p>

<ul class="ul1">
 	<li class="li1">Enroll clients with more ease than you ever thought possible</li>
 	<li class="li1">Sell your work while staying true to your moral and ethical values</li>
 	<li class="li1">Sign on coaching and consulting clients without ever having to worry about violating your integrity</li>
 	<li class="li1">Have sales conversations that are fun and 100% free of pushiness or manipulation</li>
 	<li class="li1">Get inside the mind of your buyer, so that they'll see you as a trusted advisor instead of a seller they need to fend off</li>
 	<li class="li1">Have sales conversations that create clients exactly because the conversation itself is an act of service</li>
 	<li class="li1">Reduce objections and build trust automatically</li>
 	<li class="li1">Increase your conversion rate</li>
 	<li class="li1">Sell your work at higher fees</li>
 	<li class="li1">Enroll more clients, have more impact, and earn more money</li>
</ul>
<p class="p1">More information and <a href="http://martinstellar.com/helping-good-people-sell-more-and-generate-a-bigger-impact/">signup here.</a></p>
&nbsp;

&nbsp;

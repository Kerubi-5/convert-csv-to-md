---
title: Is This You?
status: publish
datePublished: '1603844933'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - How to sell your work
  - Psychology in sales and marketing
  - Relationships

---

<img class="alignleft wp-image-21518" src="http://martinstellar.com/wp-content/uploads/2019/03/MartinStellar_Coaching_Illustrations-Ethical-selling-1024x768.png" alt="" width="351" height="263" />In my work with entrepreneurs and leaders, there’s three things I keep hearing over and over again:

1: “I just don’t know how to sell my stuff”.

2: “Selling sucks - if only I didn’t have to sell, running a business would be so much more fun”.

And the biggest painpoint of all:

3: “I just can’t seem to sell at the rates that my work is worth”.

Do you recognise yourself in any of these?

If you’ve ever said any of these things, I might have a solution for you.

Because:

If #1 is your issue, you might want to adjust how you see yourself and your relationship to others.

Meaning: yes you do know how to sell. You do it every day, and everybody does.

'Selling' (or: exchanging value) is older than language.

We’ve always traded: safety, food, community, protection, companionship… selling is inherent to being human, in that everyday we find ourselves in situations where we try to have others see our point of view, and buy into it.

If you struggle with the 2nd problem: same thing. You have an idea of what 'selling' is, and you dislike that idea - but it's not that hard to reframe it in terms of simply seeking to find common ground with people, enabling the both of you to move forward together.

And if it’s # 3 that does your head in? You can’t get paid what you’re worth, or people keep walking away even though your work is a perfect fit?

Then very likely, there’s a lack of empathetic alignment between what you’re trying to communicate, and what the other person is hearing, feeling, or thinking.

And for all these sales problems, I have a training that will cause a dramatic shift in your thinking and your sales process.

Now, this is not your standard sales training, with a 3-step close, and 'the top 15 ways to overcome objections', and 'how to get past the gatekeeper', and all that stuff that regular sales trainers teach.

No, with the LEAP Framework for Ethical Selling, you get a complete shift in how you relate to the kind of people who most need your work.

It enables better conversations, easier followup, voluntary buy-in from prospects at each stage of the enrollment process, and, best of all:

You develop a skillset and attitude that allows you to enroll more buyers, with more ease, without ever compromising your values.

If you're the kind of person who wants to serve buyers, you might find it <a href="http://martinstellar.com/helping-good-people-sell-more-and-generate-a-bigger-impact/">quite, quite transformative. </a>

But even if it's not for you, or the $1500 price tag is out of reach for you, remember one thing:

Humanity has never not been in the business of selling things - or what Dan Pink calls 'to sell is human'.

We all do it, all the time, always have done, and once you accept that 'selling' is a natural part of human interaction, you'll find that it gets easier and easier, whether we're talking about buyers, team mates, your spouse or your kids or anyone you want to get results with of any kind.

<a href="http://martinstellar.com/helping-good-people-sell-more-and-generate-a-bigger-impact/">This will help.</a>

Cheers,

&nbsp;

Martin

&nbsp;

&nbsp;

&nbsp;

---
title: Easy Choices
status: draft
datePublished: '1513259541'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img class="alignleft size-medium wp-image-20142" src="http://martinstellar.com/wp-content/uploads/2017/12/MartinStellar_Illustrations-Easy-choices-hard-life-hard-choices-easy-life-300x300.png" alt="" width="300" height="300" />The other day I heard a quote on a podcast, and my mind lit up like a XMas tree:

Easy choices, hard life. Hard choices, easy life.

It resonated with me enormously, because I’ve experienced both sides.

For example, I used to have a bad habit of overeating. Easy choice: put it in your mouth.

Which made me feel guilty and bloated. Hard life.

Or: after graduating college at age 16, I dropped out of every single education I tried. Easy choice.

But the consequence was that I had to learn everything I need to live and build a business, on my own, and that was damn hard. And it meant that I
frittered away my dad’s inheritance by making bad choices. Hard life.

But, I also made hard choices: For example, I went into a monastery - which is (psychologically speaking) as hard as, say, training to be a navy seal.

People think a monastic life is all peaceful meditation and stuff, but it’s not like that. Life in a monastery is brutal.

But the transformation I went through and the person I became, caused me to now have an easy life.

So what easy choices have you made, or are you making… that cause your life to be harder than it needs to be?

Next question: is it worth it… or would you actually rather make the hard choice, and make your life easier?

If the answer is yes, but you lack the discipline or commitment, then let’s talk.

I might be able to give you a workaround…

Cheers,

​Martin

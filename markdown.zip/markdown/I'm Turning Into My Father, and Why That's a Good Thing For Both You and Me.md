---
title: I'm Turning Into My Father, and Why That's a Good Thing For Both You and Me
status: draft
datePublished: '1526327285'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/70202247-c8b1-4143-a354-bbed53a9b537.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/70202247-c8b1-4143-a354-bbed53a9b537.png" data-file-id="4835717" />You know how people say that inevitably, we all end up turning into our father?

It’s happening to me.

And I don’t mean that I’ve suddenly started making dad jokes - I’ve been doing that for decades. And I’ve had a man-cave for as long as well, so no. I don’t mean in the typical way.

My dad was a system’s analyst, which is basically a top-level version of someone who writes enormously complex software.

My dad would fly into banks and companies like IBM and Xerox, to analyse the software they used in their mainframe computers.

And right now, I’m performing a similar sort of analysis my own ‘computer’, or rather: my mind.

I’m analysing, very carefully, how this machine of mine works, where it has bugs, and which parts of the ‘program’ really work well and can do with upgrades. And, I do the same kind of thing with my coaching clients.

In other words: I’m turning into my own version of a systems analyst.

Except I the ‘software’ that I write isn’t for computers, but for your mind.

And your mind creates the life you live, so in essence we’re talking about the Operating System that runs your life.

Because everything is a system:

Your mind, your relationships, your career, your children, your hobbies and your entire life.

Each of those, a set of elements and dynamics and propensities and reactions and what have you, each creating an outcome.

And a system is perfect, always is. Perfect for the result - the outcome - it gets.

If you want different results or outcomes, you’ll need to make modifications to the system.

And I’m getting to be quite, quite good at it.

I’m learning some really nifty tricks lately. Especially when it comes to getting organised, staying that way, and: getting stuff done.

When I said last week that decisions and choices are key to creating the life you want, I meant that also in relation to how you organise your stuff.

I’m learning David Allen’s Getting Things Done system, and wow: it’s amazing. It forces you to make choices about all the different tasks and projects and materials in your life - and just that, the repeated, deliberate choice of deciding what each thing is and where it should go - that by itself is the start of a system that really works.

A system that makes you, and your business, work - and keeps you executing.

Procrastination hasn’t been around thesse parts, in the last two weeks.

And I can show you how to get this organised and high-performance as well.

Want some?

Cheers,

Martin

---
title: A Recovering Monk's Manifesto for Happy and Successful LIving
status: draft
datePublished: '1489407505'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

show up

			serve

			persist

			have more conversations

			send daily emails

			grab the opportunities

			love the process

			water the seeds you plant

			learn to say no

			fire toxic people from your life. yes, all of them

			trust the process if you can’t trust yourself

			serve

			be real

			and in case you didn’t get the memo: send daily emails

			...to be continued...

			Much love,

			Martin

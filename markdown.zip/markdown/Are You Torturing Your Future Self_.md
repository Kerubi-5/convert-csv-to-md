---
title: Are You Torturing Your Future Self?
status: publish
datePublished: '1591780702'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-21956" src="http://martinstellar.com/wp-content/uploads/2019/08/MartinStellar_Coaching_Illustrations-Be-nice-to-future-self-1024x768.jpg" alt="" width="358" height="269" />On any given 8-hour workday, how much is on your todo list? And, can you reasonably expect yourself to get it all done?

Before you answer, keep in mind the inevitable distractions: a phone call, an urgent email, a task you forgot about but it's urgent - and also, the human need to eat, rest, or sit back and reflect… that’s easily 2 to 3 hours out of your day, right? At best, you’ll be able to spend 5 to 6 hours doing actual work.

Now look at your usual pile of tasks again, and consider: how many of your work hours need to be spent in states of high-focus and high-productivity, in order to get your work done and get it done right? And, can you actually work at that level for that many hours?

Unless you take your coffee intravenously, you probably can’t.

Most people can work for 8 hours, but we can only work at our highest level for 2 hours, maybe 4.

So here you have a workday that’s effectively 5 or so hours, with about 3 hours of deep work.

Now look at your todo list again: are you seriously expected to get all of that done, in what’s effectively a 3-hour day? Are you really that super-human?

Obviously neither you or I are super-human.

But here’s the trap: on a subconscious level, we think that our future self actually is superhuman.

Unstoppable. Driven. Radically committed, terrifically hard-working, able to concentrate and stay on task for hours on end.

In other words, we allow our now-self to create a massive problem for our future self.

"I, here, now, decide that X and Y and Z need to get done today - and given that the 'I' that I'll be later on is some sort of productivity demi-god, we can give him another todo! He can handle it!"

3 Hours later, your future self has exerted themselves, checked things off the list, happy to have done so much - but the list of task and chores is almost as long as when the day started… and still no end in sight.

This is how a lot of procrastination starts: saddling our future self with a job that is, if not impossible, highly unreasonable.

So if you tend to find yourself overwhelmed, and frustrated that there’s not enough time in your day, and annoyed that you didn’t get more done, maybe try to be a little more compassionate with your future self.

Instead of saying things like:

“Tomorrow, I’ll catch up on all the work I avoided last month!”

“This afternoon, I’ll write that proposal that normally requires 12 to 14 hours!”

“I’ll have cake today, because starting tomorrow, I’m going to be 100% on the strictest diet of my life”.

This will never work, because your future self isn’t a magical ninja-level fixer of everything that your past self hasn’t done yet.

Your future self is - surprisingly - exactly like you.

So why do we overload and torture our future self this way?

Because psychologically (and this can be measured in brain activity) our mind pretends that our future self is a different person, not us.

But once you realise that it’s the same person, you can decide to set tasks not for ‘that other dude called future self’, but for you, yourself.

Be nice to your future self. It’s the easiest way to getting things done.

---
title: Moving Parade
status: publish
datePublished: '1580900433'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - Ethics and marketing
  - How to sell your work
  - "Psychology in sales and\r\n\t\t\tmarketing"

---

<img class="alignleft wp-image-22610" src="http://martinstellar.com/wp-content/uploads/2020/02/MartinStellar_Coaching_Illustrations-Moving-parade-in-marketing-1024x768.jpg" alt="" width="349" height="262" />A few times a week I spend some time at the terrace of a local restaurant here in town, to do some work and warm myself in the sun.

As any restaurant that wants people in for lunch and dinner, they have signs with menu items - but this owner, he only puts them out an hour or so before lunch time.

Now, I don’t know if there’s a logical reason behind it, or if it’s the fabled Andalusian laziness, or simply not thinking things through, but I do know this:

The 150 to 500 people who walk by in the morning do not get the message that - hey, here you can eat, it’s not just a café!

So when the time comes that a tourist gets hungry, this restaurant is not one of the ones they remember as an option for grabbing a bite to eat, because they haven’t seen any sign or menu advising them that it’s an option.

In marketing there’s the concept of the ‘moving parade’: the notion that there’s always a stream of people who might want what you sell, and that it’s your job to stay in view, or in touch, so that when they’re ready to buy, you’re the one they think of.

So these 150 to 500 people, that’s his moving parade, literally. And if only he’d advertise to them that he serves food and not just drinks and coffee, he’d likely see an uptick in diners and lunchers. (Yes, I’ll mention it to him, see if he agrees and wants see if it makes a difference).

Now, in any business there’s a moving parade. There’s always folk who know about you, who are thinking of buying your work but it’s not the time yet, and so the question is:

What are you doing in your business, to stay visible and remembered, by the people in your moving parade?

Cheers,

Martin

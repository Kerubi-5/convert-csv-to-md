---
title: Oh Wow.... The Real Reason Artists Starve
status: draft
datePublished: '1523383108'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/d229a455-2951-4510-a824-68f1a3eb754b.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/d229a455-2951-4510-a824-68f1a3eb754b.jpg" data-file-id="4835625" />
Holy crap this being an artist thing is expensive!

Since I decided to start creating art last month and setting up a studio, I’ve been going to the supply shop several times a week.

And it’s amazing to see how expensive all that stuff is… you go in to buy some charcoal and an eraser, and you go home a hundred bucks lighter, with all kinds of materials you didn’t know you needed but which are so awesome to have…

NOW I understand why artists starve!

Obviously, spending is at our own discretion. I could easily have bought the charcoal and eraser and nothing else.

But it made me think…

So many artists and other creatives have a massive hangup around money.

As if it degrades the art to be paid for it. As if it’s selling out if you earn high fees.

As if it means you’re *shudder* commercial, and not a real artist.

Well, now that I’m on the buying&amp;arting side of the fence, let me tell you this:

If you don’t earn well from your art, then how are you going to keep funding your art practice?

Without money, how will you buy the lifestyle that allows you time to daydream, ideate, plan your next piece?

With insufficient funds, how are you going to invest in a studio assistant, and a new website, and a social media manager?

In other words: the amount you need for yourself (regardless of whether you have a humble or more luxurious number) is unrelated to how much money your art business needs.

Your business has its own financial needs, and they need to be met.

So regardless of how you feel about money, or what moral or artistic attitudes you have around it…

If you want your art business to pay the bill, there’s only one way:

Run it like a business. And yes, that means selling, and it means asking for enough money - for your business, not your personal needs.

Is all this clear to you, a given, already underway?

Then maybe talking to a coach would be the difference between ticking over, and rocking it in your business and your business’s economy.

Let me know if you want to talk about how to make that happen…

Cheers,

​Martin

---
title: 5 Core Points You Have to Get Right if You Want Your Business to Grow
status: pending
datePublished: '1654153118'
categories:
  - Business Growth Fundamentals

---

<img class="size-medium wp-image-27905 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/08/MartinStellar_Coaching_Illustrations-5-ps-that-you-have-to-get-right-if-you-want-to-grow-your-business-300x225.jpeg" alt="" width="300" height="225" />
<div>

Here is a quick tip - a high-level primer - on how to make growing your business easier.

</div>
<div>

It's based on the five P's, where first off, you have:

</div>
<div>

1. The <strong>Problem</strong> that people are looking to get solved - what is that problem, <em>specifically</em>?

And why would people want <em>you</em> to solve it?

And why now?

And how much will it cost them... if they <em>don't</em> solve the problem?

2. <strong>Product</strong>: what product or service do you have that solves that problem?

What does it do for people? What does it not do?

What about your product do you need to communicate?

3. <strong>Process</strong>: what is your best, most reliable process, for finding the right people and getting in front of them?

4. Who, specifically, are the right <strong>People</strong> for what you do?

Because if you try to sell to the wrong ones, you're going to be churning a lot of time and wasting a lot of effort and resources.

Therefore you also need to ask yourself: Who are the people you should ignore?

Also very useful: who are the people who could generate introductions for you?

</div>
<div>And then once you have the conversation with the right people, once they know about you, once they are asking about your solution, you get the fifth P:</div>
<div></div>
<div>5. What <strong>Promise</strong> do you make them?</div>
<div></div>
<div>What specific, measurable, beneficial outcome do they gain from your work?</div>
<div></div>
<div>Whenever you find that things aren't working the way you expect them to work, or you're not selling enough or people balk at your prices, or your growth has stagnated:</div>
<div></div>
<div>You'll find the solution in reviewing and improving the answers to these 5 questions.</div>
<div></div>
<div>When something's off with either Problem, Product, Process, People or Promise, your business stops growing or suffers, or you lose clarity on what to do and where to turn.</div>
<div></div>
<div>Whenever that happens, take some time to answer the 5 questions in detail, and you'll very likely come up with insights or ideas on what you can change or improve.</div>
<div></div>
<div>

&nbsp;

<hr />

On another note:
I'm building an app that coaches you on working your pipeline, moving your deals forward - and closing them faster and at better rates.
It's called SalesFlow Coach, and we're scheduled for beta-release in June 2022.
Register <a href="https://martinstellar.com/salesflow-coach-launch/">here</a> to be notified when it goes live.

&nbsp;

</div>

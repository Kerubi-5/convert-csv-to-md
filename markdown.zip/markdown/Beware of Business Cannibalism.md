---
title: Beware of Business Cannibalism
status: publish
datePublished: '1570714449'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img class="alignleft  wp-image-21318" src="http://martinstellar.com/wp-content/uploads/2019/01/MartinStellar_Coaching_Illustrations-Busyiness-vs-business-rock-in-the-river-1024x768.png" alt="" width="353" height="265" />It’s such a tricky trap, so easy to fall into:

Doing the work that supports your business, while postponing the work that grows it.

Your site, your social media updates, organising your files, emptying your inbox…

And while all those things are helpful, or useful, or even necessary, they should never be allowed to cannibalise the time you could spend on the activities that drive growth.

But this trap - business cannibalism - is exactly what causes the majority of struggles in business.

If your goal is ‘x number of clients’, then it’s good to ask, when planning your day (you do plan your day, don’t you?): Does this activity directly contribute to reaching my goal?

If the answer is no, then the activity is the last thing you should schedule.

Think of it like this: if you fill a bottle with sand, you can’t get the pebbles in.

If you fill your days with business maintenance, you’ll have no time left for business-growth.

Plan your important activities first, and fill the gaps with the other stuff.

And if there’s one big important growth activity to prioritise, it’s having conversations.

Because conversation build a relationship which causes trust, and it’s inside that a potential buyer becomes an actual buyer.

And I’ll show you  *how* to have those conversations, once you enroll in my 10-week ethical sales training, which is still in pilot launch at 30% off.

Let me know if that’s something for you…

Cheers,


Martin

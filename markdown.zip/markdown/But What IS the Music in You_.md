---
title: But What IS the Music in You?
status: draft
datePublished: '1530717318'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/da05f437-9e52-461f-bedb-020c62195b8e.png" width="350" height="350" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/da05f437-9e52-461f-bedb-020c62195b8e.png" data-file-id="4835885" />Seems like yesterday’s email about Paganini’s Stradivarius struck a chord.

Which is funny because one does not play chords on a violin - so let’s say: it resonated with my readers, given that I got a ton more response than I normally do.

Now, I believe there’s music in every person on earth.

As in: something special, unique, and highly valuable+appreciated - *provided* that you allow it to emerge.

And here’s where we go straight to a deep, harsh, psychological truth:

We’ve been taught to keep it in, hush it up, and whatever you do: don’t outshine anyone.

Well, I blame Henry Ford.

Ok, not the dude himself, but the industrial revolution we think of when we think of Ford.

Because when humanity started to build factories, we ran into a problem:

We weren’t used to working as nicely behaved, obedient worker drones.

Probably because humans are not supposed to be worker drones to begin with, but I might be wrong.

People would show up, get the job, work till payday, and then disappear again, long as money lasted.

Clearly, you can’t staff a factory that way.

And so a shift started: to retrain people.

No longer did it matter if you could forge a gate or make a wagon-wheel: all you needed was to do one thing, acceptably well, over and over every day.

And that changed everything: what we call work-ethics these days, social structures, urban infrastructures and even education. (Didn’t realise that until I heard Seth Godin talk about it: our current educational system is the heritage of the industrial revolution. Curious relic, no?)

Ok, so I’m not here to transform education.

But, I might be able to help YOU transform.

Into what?

Well, what about transforming into someone who discards the limited way of thinking that we hold as normal, and instead forge your own way?

What if you’d decide, once and for all, to let your music out?

Or your book, or that career change you want? Your big dream, the one you shelved years ago because /reasons?

What if you decide, today, that you’ll set aside whatever objections your mind throws in the mix… and start living the life you actually were meant to live?

Ok, let’s make it a game:

If you were to make that momentous decision…

What would you decide?

What song would YOU sing?

I’m genuinely interested… let me know.

Cheers,

Martin

---
title: 'Baseline Thinking: You''re Perfect?'
status: draft
datePublished: '1499856785'
categories:
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/a7b34d65-b019-4842-ab40-1971aa7f2a64.jpg" width="350" height="386" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/a7b34d65-b019-4842-ab40-1971aa7f2a64.jpg" data-file-id="4834797" />Ever hear people say that you’re perfect, just the way you are?

It’s a wonderful idea, but if you take it literally, it’s pretty ludicrous.

I mean, imagine someone who is depressed, or overweight, or angry, short-tempered, broke, schizofrenic, a failure, to name but a few things - how can that person feel they are perfect?

You wouldn’t *feel* perfect, and logically speaking, you wouldn’t *think* you are.

Yes, the self-help industry shows us lots of wonderful things, but not all of them make sense, and those that do often get misunderstood.

And yet, the idea that you’re perfect is a mighty powerful tool - IF you know how to use it.

Especially when there are things you want to change.

So here’s how it works:

‘Being perfect’ doesn’t mean that there’s nothing wrong or that nothing needs to be changed.

We can, we will, all benefit from change.

But ‘I am perfect’ is meant to serve you as a baseline, a status quo assessment of exactly the configuration that makes up you at this moment.

And from that baseline, you get to choose what you want to change.

It enables you to choose what you want to create.

Which is a lot easier, if you start with the notion that as things are now, the baseline, you’re fine.

Compare that to “I’m broken/wrong/a failure, and I need to fix that”, and you’ll see that starting with the A-OK baseline will give you far more power and potential.

Trying to fix something broken is starting from a negative, and psychologically, that’s just not the most helpful or effective way.

This is what a lot of my work is about: helping clients to see that what they consider wrong or broken is in fact natural, the consequence of previous life experiences.

And when you consider something - anything - as normal and OK, you suddenly have the power to create something new.

Current status quo = baseline. What do you want to create from that starting point?

Because we’re all creators.

And creating change is one of the most beautiful things we can do.

So yeah, you’re perfect.

Next: what do you want to create?

Oh, and also: do you want some help with that?

Let me know, and I’ll give you a no-cost, no-expectation strategy session.

Cheers,

Martin

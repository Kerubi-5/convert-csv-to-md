---
title: Excitrified!
status: draft
datePublished: '1488879617'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/5cb320d1-c5d1-4276-be07-48e9e3371208.jpg" width="382" height="286" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/5cb320d1-c5d1-4276-be07-48e9e3371208.jpg" data-file-id="4834473" />In 30 minutes, it’ll be showtime.

That stage you see there, that’s where I’ll be.

First time I’ve spoken for so many people, in a place like this.

And I’m petrified.

Excited too.

Or, as my client Paula Mould says:

Excitrified!

So here’s why I’m talking about this:

I’m eating my own dogfood. I’m stepping out of my comfort zone.

But more importantly:

I got this opportunity because of diligent and relentless effort, and I so wish for you to put in that effort too.

Showing up.

Serving people with helpful marketing.

Daily emails.

And persisting until things begin to work.

This workshop today, it wasn’t luck.

It wasn’t given to me: I earned it.

And you can earn your own opportunities too, so long as you keep putting in the hours and keep at it.

And when you do, you earn, and deserve, all the goodness that comes your way.

But only if you earn it.

I’m going in.

If I’m not back by midnight, send in the cavalry.

Cheerio,

Martin

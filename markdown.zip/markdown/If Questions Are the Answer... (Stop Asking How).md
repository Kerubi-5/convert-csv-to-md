---
title: If Questions Are the Answer... (Stop Asking How)
status: publish
datePublished: '1578555761'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-20785" src="http://martinstellar.com/wp-content/uploads/2018/09/MartinStellar_Illustrations-questions-1024x1024.png" alt="" width="350" height="350" />

Asking questions helps, creates clarity, gets you answers.

But to get quality answers, you need to ask quality questions.

I remember when I was 10 or so, trying to work out maths problems and asking my teacher how to do it, and she replied: “You’re asking me to do it for you”.

Asking people how to do something is actually a low-quality question.

The only person you should ask ‘how’, is yourself. Asking it from another, is a way to disempower yourself. You put the onus of finding a solution on the teacher, but it’s much better to put it on yourself.

One of my coaches, when I ask him ‘how to do thing A or B’, will throw the question back at me.

And if I then say ‘I don’t know’, he tells me the penalty for saying ‘I don’t know’ is $10.

A strong and effective way to force me into finding my own answers.

From my experience, some of the most powerful and effective questions to ask yourself, are all formulated so as to make you fully responsible for finding the answer.

“How do I solve for xyz?”

“What can I do to change this (or create that)?”

“In what way is my attitude an obstacle in this issue?” “What shift in my behaviour or habits will lead me to an eventual breakthrough?”

“Which belief do I cling to that keeps me stuck, and what new belief would I like to put in its place?” "What skill can I learn that helps me achieve result X?"

That’s the kind of question that actually helps. Especially if you ask yourself.

Of course you can also ask them of others – teachers, mentors, peers, coaches.

But be careful who you ask, and question the answer.

Because if someone proceeds to answer the question, it’s their answer and not yours. Which might help, but it can also send you into the weeds.

The best kind of help, is the kind that pulls out the answer from you.

Enter the world of coaching, where answers are triggered, not given.

If that’s what you want, hit reply and let’s talk - let's see if we’re a good match.

And if not, at the very least, develop a practice of asking questions of yourself.

The right kind, the type listed above.

And for best results, journal your answers. It’s the best way to get out of your head, and access your deeper levels of intelligence and insight.

You have a lot of answers in you. Just make sure you ask the right questions, so as to bring them out.

Cheers,

Martin

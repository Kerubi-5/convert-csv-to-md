---
title: Oh Look, It's Everybody's Favourite Nemesis (+ How to Deal With Resistance)
status: publish
datePublished: '1640688493'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-28385 size-medium" src="https://martinstellar.com/wp-content/uploads/2021/12/MartinStellar_Coaching_Illustrations-How-to-deal-with-resistance-300x225.jpeg" alt="" width="300" height="225" />It's not ready yet.

I'm not ready yet.

I can't.

I don't know how.

I don't have the time for it.

Can't afford it.

No, I don't want to eat my broccoli.

We've tried that.

That would never work.

It's too soon, too small, too late, too big.


What do each of these statements have in common?

<strong>They're all the voice of Resistance.</strong>

Steven Pressfield wrote <em>Turning Pro</em> and <em>The War of Art</em>, diving deep into Resistance - and I seriously recommend you read them.

Because this morning I realised I myself had run headlong into Resistance, and it's by the grace of those books, that I noticed it, and was able to do something about it.

What happened?

Well, last week I launched my SalesFlow Coach app, and I was ready to start reaching out to people and ask them for feedback interviews - but, there were some serious bugs, so I had to hold off and fix them first.

Completed that yesterday, got ready to start doing outreach, and found myself thinking:

"Yes it's nice that you're building a tool to help people work their pipeline, but...

"What about your own pipeline, Martin? When did you last review it, and work on your opportunities? Shouldn't you do that first?"

Eg: Resistance, with a big capital R.

So I woke up conflicted:

Should I work on generating interviews today... or should I work my pipeline? Maybe pipeline, eh? Yeah, maybe best.

And then the veil fell away, and I realised what I was looking at:

The ugly, treacherous, lying and conniving face of Resistance.

And so, today, I'm not working my pipeline.

Nope, I'm sending interview requests.

So how then did I overcome that voice of Resistance?

With the one single thing that actually works:

Not fighting it.

Because that's where most people go wrong, when faced with Resistance:

They get angry with themselves, they fight, they berate themselvves, they try to bully Resistance into submission...

And none of that works.

You can't fight Resistance and expect to overcome it.

The only thing that does work, is to acknowledge and accept that Resistance is part of you - it's part of all of us.

Once you do that, you can get to level 2:

Understanding that Resistance isn't there to sabotage you - it thinks it's helping you.

Helping is - for better or worse - what it's trying to do.

And, it's telling you something you need to know.

So listen to it, tell it: "Thanks for the information", and then it's time for action.

Not action in terms of doing the thing you're resisting though.

No, you want to look at that thing, and break it down into smaller pieces.

Because as per David Kadavy:

If you resist part of a process, or project, the part is still too big.

So break it down into smaller bits and keep doing that until you're looking at parts that are so small, you couldn't possibly not get started.

Anyway, hope that's helpful for you today.

Resistance isn't the enemy, so don't fight it.

And whatever you resist, break it down.

And with that said, here's me, off to send interview requests.

Plus, an invitation:

As I'm interviewing in order to get feedback on the SalesFlow Coach app:

If you're a coach or consultant, I'd love your opinion.

<a href="https://calendly.com/martinstellar/feedback-interview">Care to spend 20 minutes on Zoom, and I'll show you what I've built?</a>

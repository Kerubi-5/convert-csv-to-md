---
title: A Lesson George Bernard Shaw Wants You to Learn
status: publish
datePublished: '1625444581'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Ethics and\r\n\t\t\tmarketing"
  - How to sell your work
  - Psychology in sales and marketing

---

<!-- wp:image {"align":"left","id":22003,"width":350,"height":209,"sizeSlug":"large"} --><!-- /wp:image -->

<!-- wp:paragraph -->
<p><a href="http://martinstellar.com/wp-content/uploads/2019/08/MartinStellar_Coaching_Illustrations-Confidence-vs-Neediness-people-pleasing-and-approval-seeking.jpg"><img class="alignleft  wp-image-22003" src="http://martinstellar.com/wp-content/uploads/2019/08/MartinStellar_Coaching_Illustrations-Confidence-vs-Neediness-people-pleasing-and-approval-seeking-1024x768.jpg" alt="" width="348" height="261" /></a>“The single biggest problem in communication is the illusion that it has taken place.” ~ George Bernard Shaw</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Sure, it’s presumptuous of me to speak on behalf Mr. Shaw - but, whatever.</p>
<p>I’ll take that liberty, because I’m sure he’d be happy if more people realised the wisdom of his words.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Because yes, we often think we communicate, when actually we don’t.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>That is: we think we communicate thing A, and then act all surprised (or even upset) when it appears that the other person heard thing B.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>If you’ve ever been in a situation where you found yourself thinking ‘why are they not getting it?’, then that’s what happened.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>You said one thing, but the other heard another thing.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Of course you can blame the other for being stubborn or contrary, and in some cases that may be at play - but even then, that does not exonerate you from the responsibility of communicating in a different way, and trying to find out how to get your message across.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>And this applies everywhere: In business and selling; at home; with your spouse or kids; with your students or team mates or prospects:</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>It’s on us to find the way ‘in’, and figure out how to get the right message across.</p>
<p>Misunderstandings are not 'their fault' - they are 'our responsibility to fix'.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>And here’s the secret: <em>saying more won’t help more. </em></p>
<p>In fact, when you think that communication has taken place but it hasn’t, the more you keep talking, the bigger the misunderstanding will become.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Put differently: if the other person doesn’t seem to get you, explaining harder will be counterproductive.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Instead, ask questions.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Because unless you learn more about the other person and what they heard and what they think of it, how are you going to accurately adjust your message?</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>When you find that a buyer (or friend or team mate or spouse) isn’t getting what you mean, ask yourself this:</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>What did they hear me say?</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>How does it differ from what I meant?</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>What should I ask them, to figure out how to adjust the message I’m trying to communicate?</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>That question - "What did they hear me say?" is a very useful tool in all communication - and especially in the context of selling and signing on clients.</p>
<p>And in fact, it's not just a question to ask yourself:</p>
<p>You'll find that when communication or the sale isn't working, you should ask the other person. </p>
<p>You'll be amazed at what might surface, and how well the conversation can go after that. </p>
<p>&nbsp;</p>
<!-- /wp:paragraph -->

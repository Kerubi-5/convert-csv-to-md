---
title: MUCH Better Than Resolutions (Exercise Inside)
status: draft
datePublished: '1513878849'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/fa0261a5-27d0-46df-86e3-ceb3c1c0af0f.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/fa0261a5-27d0-46df-86e3-ceb3c1c0af0f.png" data-file-id="4835301" />Here’s a fun little exercise to help you get started with an awesome 2018.

Works a lot better than resolutions.

I call it the Energy Planner.

This exercise is designed to modify the context in which you live and work.

It’s about changing elements in your environment, in order to be more productive, have more time, earn more money, and live a more fulfilled life.

After all, it’s well known that the context makes all the difference when we want to create and achieve things.

The example of an alcoholic: no matter how effective the treatment was, and how happy and resolved the individual, if they go home where their spouse is still drinking and the person goes back to hanging out with his drinking buddies, it won’t be long before he or she falls off the wagon again.

And that’s just social context - there’s more.

So, to have a wonderful and stellar year, do this:

Draw four columns on a piece of paper, just like in the drawing, and title them as follows:

People

Places

Things

Habits

Divide each column in two, vertically. Label left one with a plus sign, and the right one with a minus.

Take some time to reflect for this exercise.

Which people in your life give you energy?

Write the names down under the plus in the first column.

Which people sap your energy, make you feel like you lost a quart of blood?

Under the minus.

Same thing for habits, and the other two columns.

Be ruthless here. Even if you like an item or person, the fact that they drain your energy means they go under the minus.

Be extensive, list everything that comes to mind.

If you want a physical element to the exercise, cut up the columns into 8 strips.

The plus columns, glue them to a piece of paper, or frame it or whatever, just so that you can keep it handy, as a reminder.

The minus columns… well, be creative. Burn them, bury them, tear them up, whatever you want.

And for the next year and thereafter, seek to experience as many of the plus things that you listed.

The minus things fall under the category ‘avoid at all cost’.

Obviously, you can’t just eliminate a boss or a relative from your life, but you can - and should - work to change the dynamic. You can always change the dynamics.

Which is something that I can help with, if you don’t know how. Just let me know.

Cheers,

​Martin

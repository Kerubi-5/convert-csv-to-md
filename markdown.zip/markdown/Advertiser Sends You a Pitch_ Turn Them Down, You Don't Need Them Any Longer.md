---
title: Advertiser Sends You a Pitch? Turn Them Down, You Don't Need Them Any Longer
status: draft
datePublished: '1489745888'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

Lately, several of my clients have been receiving messages from companies that
			offer them visibility.

			Some are in the form of web-advertising, others in magazines, and some in the form of
			paying to be shown in a gallery.

			Now, there might be some cases where the offer is good and it’s worth the investment, do
			remember this:

			The fact that they found you means that very likely, you don’t need them.

			Because for you to get noticed, to show up in search results or a news feed, means
			you’re already on your way to building up your own visibility. Otherwise they’d have
			found and pitched someone else.

			This doesn’t mean it’s always a bad idea to take the deal, but there’s a strategic
			decision to be made:

			Is investing in their offer going to get you better results than what you can create by
			building on what you already have?

			And, would you prefer spending the cash on broadcast advertising, or does it make more
			sense to spend time on getting seen whilst also building relationships with your
			audience?

			Remember, dollars are finite. And time is too, except time renews itself every day.

			So what’s a better spend, what will give you a higher return on your investment?

			If you were to ask me, my preference in most cases would be ‘spend time, build your
			audience’.

			Because having relationships and conversations with people gets you a FAR higher ROI
			than broadcasting ads at them.

			Anyway, I’m going back to drafting the manuscript of The Prosperous Artist. This book
			ain’t gonna write itself.

			Cheers,

			Martin

---
title: Acts of Service... Acts of Devotion... and SELLING???
status: publish
datePublished: '1605140373'
categories:
  - Ethics and marketing
  - How to sell your work
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-21625" src="http://martinstellar.com/wp-content/uploads/2019/04/MartinStellar_Coaching_Illustrations-Selling-as-an-act-of-service-and-devotion-1024x768.png" alt="" width="348" height="261" />Last year when I developed my signature LEAP framework for ethical selling, I experimented for a while with the moniker 'sales coach monk' - something that one of my mentors suggested.

But then another mentor held my feet to the fire:

“That sounds nice, but what does a 'sales coach monk' bring that another sales coach doesn’t?”

The answer might surprise you.

See, back in the monastery, we worked with a concept called ‘active devotion’.

Because it’s all very nice to sit and meditate and feel all spiritual and stuff, but it’s in applying yourself to activities that serve the other, the community and the world at large, that real spiritual, or personal, transformation takes place.

Exemplified by that Zen story, where a new student says to his master: “I’ve eaten well, thank you. When does my training begin?”

And the master replies: “Right now: go wash your bowl. After that, there's wood that needs chopping".

Active devotion is a deep and powerful tool for change.

It’s serving something beyond self.

And that’s what a 'sales coach monk' can teach you:

How to make the process of selling (or: enrolling people, or ‘moving people’ as Dan Pink calls it) something that is in itself an act of service.

You serve the other in making the best decision for them, at this point in time - whether that turns out to be a yes or a no.

And for those who have a spiritual orientation in life, you can even take it a step higher than ‘act of service’: make selling an act of devotion.

And that has nothing to do with beliefs, or religiosity.

You’re devoted to things, regardless of what you do or don’t believe.

You’re devoted to your kids, your spouse, your horse, your hobby, your crossfit or the novel you’re writing… and, if you’ve got Heart and your business exists to make things better... then you’re devoted to your business as well.

Right?

Right. So then, what if you make the process of enrolling people itself, an act of devotion?

Meaning, you devote yourself to serving a buyer as best as can - you devote yourself to giving them the best possible outcome of interacting with you.

In other words, you come from the heart - not from your wallet.

The result?

Sales conversations that people absolutely love, where they’ll be far more eager to buy from you, and - if you get it right - where people might literally tell you “Take my money!” (No joke - I’ve actually had a someone say that. Twas fun).

Is that the kind of sales conversation you’d like to have with your people?

Cool.

I'll show you how.

You can schedule a 20-minute <a href="https://martinstellar.com/helping-good-people-sell-more-and-generate-a-bigger-impact/">sales audit</a> right here. I'll also show you how the ethical selling framework goes together, and if you want the 1 on 1 training, we can discuss what that would look like.

Cheers,

&nbsp;

Martin

&nbsp;

&nbsp;

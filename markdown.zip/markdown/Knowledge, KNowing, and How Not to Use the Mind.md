---
title: Knowledge, KNowing, and How Not to Use the Mind
status: draft
datePublished: '1543228963'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft size-large wp-image-21111" src="http://martinstellar.com/wp-content/uploads/2018/11/MartinStellar_Coaching_Illustrations-Knowledge-vs-Knowing-1024x768.png" alt="" width="1024" height="768" />Ever tried to reach a conclusion, insight or decision about something - and no matter how much you bang your head against it, you just can’t seem to get there?

Yeah… in a case like that, maybe try something else?

Thing is, the mind is powerful but it’s limited. It can only get ahead if it has sufficient data.

And any time you find yourself stuck up in your head, going round in circles, it means your brain simply doesn’t have enough info - i.e. data - in order to advance.

The default reaction in such cases is then to go and put more data in.

Watch another webinar, read another book, take another course, etc etc.

But that rarely helps, because more knowledge isn’t what the mind needs.

It needs more data, but not the kind that you put in from the outside.

Instead, what would really help is using the data you already have, except you can’t get to it.

And the reason you can’t get to it, is because mind is a binary thing (something is or isn’t true, we agree or disagree, we approve or disapprove).

So when you try hard to *think* your way through something, you focus your attention on a thought process, thereby excluding the insight you already have, and which you could notice if you wouldn’t be
doggedly keeping it out of sight by focusing on rational thought.

See I’ve been interviewing people to get feedback on my CRD system (the thing that helps you create clarity and make decisions that are more aligned with the outcomes you want) and some of the feedback has been that it’s all very rational and thought-based.

But that’s not how the system works.

Calibrate Reality Dojo isn’t about thinking more - it’s about thinking better.

And that means stepping away from (overthinking) in a narrow focused way, and letting your subconscious lend you a hand.

Instead of narrowing down, laserlike, on your thoughts, it’s about widening your mental perception, so as to include information, ideation, and creative insight that hides below the surface of your conscious thought.

That’s how you go from dryly analysing knowledge and data, to creatively processing knowledge as well as insight.

That’s how you use the mind the way it was intended.

After all, your subconscious is vast, but the mind is a fairly small box. Make sure you don’t get stuck in it, but instead let your intuition and creative resourcefulness help out.

That’s how you go from unsatisfying dead-end thinking on knowledge, and enable yourself to reach the insight you can call *knowing*.

Because knowledge and knowing are two very different things and shouldn’t be confused.

Analysing knowledge is pretty boring.

But to reach *knowing*?

Not that hard, and dramatically more fun&amp;useful.

Cheers,

Martin

---
title: Multiply Revenue by Ten in One Year? Can be Done, but...
status: draft
datePublished: '1525705075'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/2da90690-ca99-48fc-bd98-4d3d972f0111.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/2da90690-ca99-48fc-bd98-4d3d972f0111.png" data-file-id="4835693" />...But it takes a very special kind of person to pull it off.

And that doesn’t mean in terms of skill or abilities or talent, or anything innate or genetic.

The ‘special’ you need to in order to create 10X results have mostly, almost exclusively, to do with how you show up.

As in: who do you need to be, in order to get such results? How do you need to show up, to make it happen?

I’ll show you exactly that, by using Katrina Gorman’s testimonial as a sort of mini case-study.

I’ll piece it apart first and comment, and I’ll put the full testimonial at the end.

Says Katrina:

“Since having coaching sessions with Martin and being in the Cabal, I've seen an increase in my art sales x10 in my first year”.

Yes, ten times. In one year. (I previously mentioned her and said 4 times, but I had incorrect information. She actually multiplied by ten. Amazing).

Now before we go on: I had my part in it, but just my coaching by itself would never have been enough. If Katrina hadn’t brought her grit, persistence, eagerness to learn and her attitude to taking massive action, nobody could have made it happen. She’s a real tough cookie.

“Great things are working by doing the work of taking on better business habits and suggestions that are given. That's the biggest thing I've found with being coached. Staying open to different perspectives, then taking action. ”

Note: habits (yes!) and taking on suggestions. (Which is not the same as ‘following advice’. It’s ‘choosing the advice that works for you’, but it also means not bypassing the advice that doesn’t).

Sometimes, an idea or suggestion might show up for the right reasons, but in a format that just doesn’t do it for you. Then we simply create a different format, to get the same result. And then you’ll want to take it on. Right?

“Learning how important your mindset really is in your art business”.

Oh and she got that part right, dear ole’ Kat. Like everyone, she came in with mindset-elements that weren’t serving her, and by and by she replaced those with new ones that got her that 10X result.

Mindset and self-awareness are really where it all starts.

“The other part is by continuing to do what's working with support of encouraging people.”

Here, she’s talking about me but also the coaching group I run and that she’s part of, called The Cabal. Info here.

“Martin will ask questions for you to find ways to help you get out of your own way.”

Yep. That’s in essence my job description. I’m like an icebreaker for your mind. Asking you those questions that will free up the way for you.

“So if your ready for it, and thinking about it, it's a great move”.

As in: ready to join us as a new Cabal member. Because at the moment we’re 3 artists strong, plus one artist-coach, and we’ve decided we would like to invite someone new into our midst. Would that be you...?

“To keep moving forward. Best thing I can say is give it your all and see what happens for you.

Being in the Cabal has been invaluable for my personal and business growth. And thankful that I found them when I did.”

We’re just as grateful as she is, because she’s in invaluable part of the team.

Right, now who is The Cabal for?

If you read her testimonial, you’ll see the kind of person we’re looking for:

Artist

Ambitious

Open-minded, yet feet-on-the-ground

Action-biased

Persistent

Able to muster up patience

Helpful and willing to accept help.

And, able to keep watering the crop until it yields, like a good little farmer (instead of expecting miracles. 10x can happen, but it's never guaranteed and as all results: it takes time).

And above all: willing to be coached. Because that can be the hardest part - to allow the guidance and direction you get in a group like this, to have its bearing on your mind, your habits, and your results.

Like I said: it takes a special kind of person.

Are you?

Cheers,

​Martin

P.s. Here’s her whole testimonial in one go:
“Since having coaching sessions with Martin and being in the Cabal, I've seen an increase in my art sales x10 in my first year. Great things are working by doing the work of taking on better business habits and suggestions that are given. That's the biggest thing I've found with being coached. Staying open to different perspectives, then taking action. Learning how important your mindset really is in your art business.

The other part is by continuing to do what's working with support of encouraging people. Martin will ask questions for you to find ways to help you get out of your own way.

So if your ready for it, and thinking about it, it's a great move. To keep moving forward. Best thing I can say is give it your all and see what happens for you. Being in the Cabal has been invaluable for my personal and business growth. And thankful that I found them when I did.”

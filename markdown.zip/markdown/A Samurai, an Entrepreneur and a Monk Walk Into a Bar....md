---
title: A Samurai, an Entrepreneur and a Monk Walk Into a Bar...
status: draft
datePublished: '1530202474'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/8893301b-9f5b-4698-aacd-1f437c34f93d.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/8893301b-9f5b-4698-aacd-1f437c34f93d.png" data-file-id="4835869" />Asked a friend - a neuroscientist who teaches entrepreneurs about marketing and psychology - for his feedback on that new Calibrate Reality programme I’m developing.

In case you missed it: that’s a coaching trajectory that teaches you how to live with effortless mastery.

We had an interesting exchange, also to do with my site and my branding - and in the end he joked:

“You could brand yourself as a warrior-monk”.

Not all that funny, actually - because he’s spot on.

Not that I’m a fighter in a physical sense. As a kid I had Judo lessons and I played with bow&amp;arrow, and that’s about as warrior-like as I get.

That is to say: in terms of arms, and battle between people.

Where it comes to attitude and identity though, then yes, I’m totally a warrior. Except more like a Zen-monk than a Samurai.

To me, running a business (and a life, for that matter) is one continuous, ongoing Zen tea-ceremony.

Now, you might think that’s a matter of sitting still, and very carefully stirring your tea just so.

But it goes a LOT deeper.

It goes back all the way back to something called Bushido - the Way of the Warrior.

It’s a set of precepts - not even a formalised code of rules - that’s traditionally considered the ultimate code of conduct for warriors - be it a samurai, a spiritual warrior, or indeed a business-warrior.

Now Bushido is not about fighting or warring. In fact, martial arts range from kick&amp;punch (i.e. karate), to wrestle&amp;jostle (judo), to ‘whatever you do, don’t kick or punch’ (Aikido) - and Bushido tells us to avoid violence at all cost.

So when there's talk about 'warrior', it's about the inner attitude, not about outer violence. Or inner, for that matter.

These are the tenets of Bushido:

•    Righteousness

•    Heroic Courage

•    Benevolence, Compassion

•    Respect

•    Honesty

•    Honour

•    Duty and Loyalty

•    Self-Control

See? Nothing about fighting or winning or dominating. It’s all about the mind.

The attitude. The way you show up.

It’s about how you identify in life and business.

And from my 25 years of experience in deepening that connection with the inner warrior, I can tell you it’s amazingly powerful as an identity  - or archetype - to lean into.

In the end, there’s little difference between someone sailing into the arctic, facing a sworded enemy, or starting a business.

In a practical sense there’s differences, but as far as the mind goes, it’s pretty much the same.

They are all heroic endeavours, making you the entrepreneur a hero of sorts.

Now if you then add on the warrior as the identity you step into… guess what that’s going to do for your life, business, fulfillment, happiness, revenue…?

Imagine: When you show up to your business and life with a code of conduct like Bushido - with all those wonderful attitudes you just read, as your mental weapons…

… and you show up as an accomplished, masterful warrior, ready for anything …

It's something you can train, you know. And there's no tea-ceremony or monastic training required.

In fact, that new Calibrate Reality Programme I'm creating is designed precisely to show you how to live from the archetype of the warrior. So stay tuned for more info...

Martin

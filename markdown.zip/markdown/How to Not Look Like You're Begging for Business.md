---
title: How to Not Look Like You're Begging for Business
status: draft
datePublished: '1492798417'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/ae6afcff-a78d-4c19-8315-eee52d110a73.jpg" width="197" height="350" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/ae6afcff-a78d-4c19-8315-eee52d110a73.jpg" data-file-id="4834529" />Interesting conversation with a client, about pricing her work.

She’s been frustrated, because even though her work isn’t priced cheap, it’s proving hard to sell enough of it.

(Yes, I meant to say that. Most people think cheaper sells better, but for the majority of entrepreneurial services or products that’s not true. To which you can probably attest, if you’ve ever ran a sale. Basically, selling is hard, at whatever price. Which is why I say you might as well sell at a high price, if it’s going to be equally hard anyway.)

In any case, this client: She does raise her rates from time to time, and keeps selling, but it’s not turning over the way she wants it to.

Now obviously, I’ll always advise to seek out people who are willing to pay you rates that your work is worth.

Underpricing yourself is a terrible idea, and again: it sooner kills sales instead of increasing them.

Especially if you go and try to create prices on a case-by-case basis, trying to please the person looking to buy from you.

Terrible idea. Because for one thing, you don’t know what that person can afford or is willing to spend. And the fact that they have a simple job and drive an old car doesn’t mean they don’t have enough money.

(Ever see the car Warren Buffet drives? Apparently it’s an old clunker, despite the fact that the man has more money than god).

So what someone can afford (or is willing to spend on your work) is none of your business.

Your business is: to stay in business.

And you can only do that if you earn good money: enough to invest, pay taxes, save for the future, go on holidays, and have enough free time to actually live life. You know, basic financial prosperity stuff.

So the only thing that’s your business, is getting paid what your work is worth.

But if you try and tailor your prices to what you think the market will bear, you create several problems.

For one thing, it’ll keep you focused on a market that won’t pay much. Ouch.

Also: it’ll make you look like a supplicant, as if you’re begging for business.

It’s effectively people-pleasing behaviour, and believe me: people will sense the desperation behind your juggling your prices. And that’s a major turn-off for a buyer.

No, better to behave with confidence and authority.

You make or do things that people benefit from, right? And it’s something that’s worth good money, yes?

Then ask for good money.

You’ll probably sell fewer items (though in many cases, a higher price will get you more sales, not fewer), but at a higher price.

So you’ll work less, earn the same (or more) and have more time to learn, relax, ideate, and take care of self.

Always remember: you’re the business owner, which means it’s your shop and you make the rules and the prices.

This gives power to the buyer, because when you present your offer, they have the right to veto. Fair is fair.

Whereas when you try to adjust your prices based on what you guess they’ll spend, you’re effectively removing their power, by making them an offer they can’t refuse or that they’re not supposed to refuse. .

“I’m cuttin’ me own throat here. You can’t not buy this, you can’t do that to me”.

Nah. Not like that.

Do good work, the best you can. And earn good money for it. That’s how you build prosperity.

(Which I’ll help you with if you want - just holler)

Cheers,

Martin

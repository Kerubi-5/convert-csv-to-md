---
title: 10 Principles for a Fun and Profitable Business
status: publish
datePublished: '1619569796'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-22416" src="http://martinstellar.com/wp-content/uploads/2019/12/MartinStellar_Coaching_Illustrations-10-principles-for-a-fun-and-profitable-business-1024x1024.jpeg" alt="" width="346" height="346" />Some of these took me a long while to accept, others to discover, and some to implement.

All of it is, I guess, a work in progress - like the self, our business, and life in general.

So here’s what I learned over the years, in no particular order, to help make your business easier, more fun, and more profitable.

1: Learn how to write copy.

Business will always require writing, and the sooner you get a grip on how to write tightly, in a way that’s clear and compelling, the better you’ll do.

It’s an unmissable skill in business.

2: Learn how to enroll people.

You can call it selling or persuasion or whatever you want, but if you have a business, you deal with people and you want people to align with your vision, right?

Whether we want buyers, high-performing teams, active and responsive followers... you want to really *get* psychology in such a way that you’re able to *move people*.

Because that’s what enrolling and selling are ultimately about.

3: Always stay active in growing your list.

It’s the core asset of your business and you should never stop growing it.

4: Speaking of assets: your business is full of them, except we tend to overlook or discount them, especially when they aren’t tangible.

A fleet of cars is an asset, but so it a list of past customers, who might buy again or introduce you to someone.

More assets: your reputation, your network, the quality of your work, your intellectual capital...

They're all assets that can be leveraged, and your life and business are full of them.

Get off your assets, and put them to use for your business.

5: Never get good at the small stuff.

Sure it’s great if you know how to fix the printer or design a logo - but if your money-making activity is, say, doing SEO at $100 an hour, you spending an hour fixing the printer just cost you a hundred bucks.

Better pay someone 25 and use your time to do work that pays.

6: Protect the owner (that would be you, operating as a business owner, instead of a business operator).

Most of the time, we work *in* our business, and forget to work *on* our business.

This is a massively bad idea because it keeps us stuck in the hamsterwheel of doing and making, stealing time from architecting, strategising, and planning, which is what make for business growth.

7: Values and shared values are the core of finding product-market fit - and enrolling buyers.

Not everyone who shares your values will be a good client for you, but if you look at your best, most lucrative and most fun clients, you’ll likely find that those people had a lot in common with you, in terms of values.

Find more of those people.

8: Keep things simple.

And that’s how simple I’ll keep this point :)

9: Systemise everything.

Systems aren’t boring: they are what free up your mind for creative thinking, problem-solving, and creating content that attracts people or that people will pay for.

After all, these days we’re all a publishing company, whether we publish work for marketing or for getting paid.

10: Talk to your people.

Video, email marketing, public talks or social media:

It doesn’t matter where you do it, but you’ve got to show up.

Nothing will show up (clients, opportunities, partners, etc) unless you do.

There’s a lot more that goes into a business that’s fun and profitable of course, but if you look at this list, you’ll see there’s a nice set of do’s, don’t’s, skills and attitudes in there, enough to keep you on the right track.

And if you want 1 on 1 help? <a href="mailto:hello@martinstellar.com">Get in touch...</a>

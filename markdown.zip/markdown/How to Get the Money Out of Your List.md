---
title: How to Get the Money Out of Your List
status: publish
datePublished: '1615364745'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<p class="p1"><img class="size-medium wp-image-26626 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/03/MartinStellar_Coaching_Illustrations-Get-the-money-out-of-your-list-300x225.png" alt="" width="300" height="225" />Riffing on about email marketing, it’s shocking how many people leave money on the table.</p>
Meaning: there's money in your email list - but it's on you to make that money come to you. People aren't just going to throw it at you.
<p class="p1">So consider the following:</p>
<p class="p1">If someone gives you their email address, they trust you.</p>
<p class="p1">They’re interested in what you do and say.</p>
<p class="p1">And they give you <i>permission</i>, to show up in a highly private, highly curated space: their inbox.</p>
<p class="p1">And if you consider trust, interest and permission, you’re talking about a potential client.</p>
<p class="p1">All it takes for you to turn that potential client into an actual client, is a simple, short message, going out consistently and frequently.</p>
<p class="p1">And so as you evolve and build your business, and people sign up to your list, you’re building an asset.</p>
<p class="p1">That asset holds value.</p>
<p class="p1">But if you don’t work the asset - if you don’t intentionally and deliberately stay in touch with people - that value stays right where it is.</p>
<p class="p1">And it’s so easy to change that!</p>
<p class="p1">Talk to people, send them an email daily, be helpful and personal.</p>
<p class="p1">Even if you only have a few 100 subscribers, that’s enough to generate inquiries and sales.</p>
<p class="p1">But what do most people do?</p>
<p class="p1">Mail once in a blue moon, or they only send promotional messages without any value or meat.</p>
<p class="p1">And that’s just wrong.</p>
<p class="p1">People didn’t give you permission to send promo - they gave you permission to be meaningful and helpful in their inbox.</p>
<p class="p1">They’re not interested in offers or deals - they’re interested in how you can help them.</p>
<p class="p1">And you can share that, just by spending 10 or 20 minutes a day writing up a short ditty and sending it.</p>
<p class="p1">If you don’t, know this:</p>
<p class="p1">There’s people waiting to hear from you, and some of those people would give you money - IF they would hear from you.</p>
<p class="p1">Don’t let a perfectly good asset - your email list - go to waste.</p>
<p class="p1">Try the 30-day challenge I mentioned yesterday, see what it does for your results…</p>
<p class="p1">Cheers,</p>
<p class="p1">Martin</p>
<p class="p1">P.s. Oh and if you want to get started but you’re not sure what your narrative should be about or which buyer persona you should write to, or in which format, let me know. I’ll give you 20 minutes on Zoom to help you get started.</p>

---
title: Collective Forward Momentum
status: draft
datePublished: '1504603406'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/542c86ae-4ced-4f21-bfa6-60b644bd0459.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/542c86ae-4ced-4f21-bfa6-60b644bd0459.jpg" data-file-id="4834989" />They say we’re the sum of the 5 people we spend most time with.

And while I don’t know if that’s factually true, we all observe how we or others take on aspects and attitudes of others. And the more often we spend time with those others, the stronger the effect will be. We take on more.

Which means it’s worthwhile being very deliberate about who gets your time.

Me, I love being around people who know more than I do, have created more, built more, learned more. Spurs me on to become a better me.

And while I could have known that spending 2 hours a week with a group of artists would affect me, I had no idea it would break open my self-imposed “I can’t draw” attitude.

Which isn’t to say that these days I consider myself a spectacular draftsman or illustrator, but I have fun doing it and people seem to enjoy seeing my work.

And yes, all that is the consequence of running the Cabal coaching group for a year.

People influence each other, there’s nothing we can do about it.

And these female artists, even though I was (and am) there to do the coaching job, influenced me. And now my life is different. Very different.

(Thanks girls!)

And this is why I chose the phrase ‘Collective Forward Momentum’ as the tagline for our new Cabal Creative project.

You know, the one where we in the Cabal group will open up to help you with your life and your business - whether you’re an artist or not).

Because together, humanity can do amazing things.

Consider: for centuries, running a mile in under 4 minutes was considered physically impossible.

But then Roger Banister pulled it off in 1954, and since then it became a standard accomplishment for students and athletes alike.

And since then, humans went on to do even crazier things: big wave surfing, wingsuit flight, and that crazy skater who jump the Chinese Wall three times I think - on a sprained ankle and a torn knee. Just a couple of examples.

Because one person broke through the ceiling, others wanted that too, and so one after another, people brought together a momentum that pulled others along in its wake.

This is collective forward momentum at work. It’s the habitual, matter-of-fact negating of limits previously considered real.

It’s a way for you - IF you seek out the right people - to achieve things that you dream of but have so far considered unattainable.

Because no matter what you’re achieved so far, there’s more in you. Always, everyone. Where you are at now is just a stage.

And it’s the community that you move in that will make or break your chances of moving into the next stage.

So, if you’re fed up with the status quo and you’re ready to level up, do this:

Pick a team of winners, and find a way to spend as much time together as you can.

The rising tide raises all ships, and collective forward momentum is irresistibly compelling.

Cheers,

​Martin

&nbsp;

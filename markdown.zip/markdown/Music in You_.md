---
title: Music in You?
status: draft
datePublished: '1561709036'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/d01e814a-7ae9-4f73-aeb3-4eb5284ddb21.png" width="350" height="350" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/d01e814a-7ae9-4f73-aeb3-4eb5284ddb21.png" data-file-id="4835881" />One day, the world-famous violinist Niccolo Paganini was about to play for a sold out opera house.

But he wasn’t ready. There was five minutes left, but he was running around like a madman.

They told him it was showtime, and get yourself ready, man.

He dashed into a room, came out with a violin, and went on stage - where he proceeded to, let’s say, rock the house.

Afterwards, he was asked: “Normally you’re so cool and collected, but you were a madman before the opera. What happened?”

Paganini replied: “I couldn’t find my Stradivarius, so in the end I had to borrow someone’s violin. I’m glad it happened, because I discovered that the music isn’t in my violin. The music is in me”.

And so it goes with all of us:

We spend half a lifetime thinking that the magic, the talent or the results exist outside of us - when in reality, it all, already, exists in you.

And that notion is exactly why we have teachers, trainers, and coaches:

To help you discover, access, and unleash ‘the music in you’.

And, it’s a perfect test for me, to figure out who I can actually help.

Because there’s nothing I can do for someone who is ‘running around trying to find their Strad’. Except for, maybe, show them this article.

But beyond that, no coach or trainer can help a person who looks for the music or the answers outside of themselves.

So ask yourself: where are you looking - inside or out?

Because if you’re looking for the music in you, and if these coaching articles resonate with you, then maybe I can help you find your music.

Want to give it a go?

Hit reply, let’s have a chat and see what happens…

Cheers,

Martin

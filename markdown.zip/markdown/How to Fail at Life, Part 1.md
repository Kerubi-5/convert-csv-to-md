---
title: How to Fail at Life, Part 1
status: draft
datePublished: '1494009520'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/a4309e8b-be31-4ad5-b4c5-63612b5d7c47.jpg" width="250" height="185" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/a4309e8b-be31-4ad5-b4c5-63612b5d7c47.jpg" data-file-id="4834581" />You can try to fight reality all you want, but you’ll never win.

And the best way to ensure a miserable life, is to argue with reality.

But reality is what it is, and it ain’t ever going to change, no matter how much you fight against it or try to convince it that it should be different.

Reality has an uncanny way of ignoring that kind of thing. In case you hadn’t noticed.

You can’t change reality. If you could, it wouldn’t be very real now, would it?

What you can change however, is YOUR reality.

You can change your way of seeing reality.

Because reality and the facts in it are not objective.

You can’t contemplate or perceive reality without you being in the mix.

And you - by default and unavoidably - colour the reality you perceive.

One man sees a war and gets depressed. But the next one  - say, a weapons manufacturer - sees dollarsigns.

Same facts. Different perception.

What reality is, in an objective sense, is ultimately unimportant. The only thing that matters is what you make of the facts.

What they mean to you, how you interpret them.

What you decide reality should mean. To you.

So don’t argue with reality.

Instead, deliberately and carefully choose your perception of it.

It’s the best way to live a happy and fulfilled life, regardless of what the facts, circumstances or events might be.

And if you find this hard to accept, you might want to read Victor Frankl’s Man’s Search for Meaning, about his time in a Nazi concentration camp.

Or, you can work with me and I’ll show you my way of ‘bending’ reality.

The book is cheaper, but working with me is more fun.

Either way, don’t argue with reality. It’ll always win.

Cheers,

Martin

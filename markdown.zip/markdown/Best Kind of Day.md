---
title: Best Kind of Day
status: draft
datePublished: '1521223637'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/7e83d99f-c2e6-4592-8262-274299c113ce.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/7e83d99f-c2e6-4592-8262-274299c113ce.jpg" data-file-id="4835553" />Some of the best days are those when a client reaches the end of a programme, and tells me they’re not going to renew.

When I hear things like “I’m good” or “I’m in a good place” or “I got this”, and they want to go ahead alone.

When that happens, I smile, because in the end it’s my job to get fired.

Coaching isn’t like some kinds of therapy, where the process implies you stay for years on end.

No, a coach is there to take you to a certain level, and once you get there?

At that point you no longer need me.

And then you get to fly solo, baby.

So that happened this week: client graduated, I celebrated.

Meaning, there’s a spot opening up in my calendar for the near future.

Let me know if you’ve been thinking of levelling up, and you’re ready to do it.

Comes a time when enough is enough, and you are ready to make changes.

Is that you?

Cheers,

​Martin

---
title: 'Ain''t no Cost (Re: Calibrate Reality Webinar)'
status: draft
datePublished: '1540371600'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-20677" src="http://martinstellar.com/wp-content/uploads/2018/08/MartinStellar_Coaching_Illustrations-Canclone-the-self-1024x1024.png" alt="" width="359" height="359" />A reader yesterday told me she wouldn’t attend tomorrow’s CRD webinar, and that at some point in the future she might want to hire me.

Looks like I didn’t make it sufficiently clear: this webinar is free, there’s no cost to it.

In case that’s what has held you back from registering.

And no, it’s not going to be one of those cheesy things where you get 5 minutes of content, and the rest of it is a sales pitch.

You read my emails, you know that that’s not my style.

What you’ll get is this: Stellar-in-a-tin.

Meaning, the webinar, in case you missed it, is the result of my 25 years of learning psychology, optimising self and performance and thinking, and over a decade of being in business.

I’ve taken the core of my coaching methodology, and created a simple, applicable, results-oriented framework out of it.

You watch the webinar, you get an upgrade to the mind.

Or in the words of Paula Mould:

“CRD is mind bending. Reality changing.

I highly recommend the Calibrate Reality Dojo if you're ready to see clearly and take massive action."

Now where it says ‘massive action’, that points at a kind of cost, in that: I’ll be offering you some homework tasks in the webinar.

And if you do it, you’ll dramatically increase the impact that the webinar and my CRD framework will have on you.

So: want to learn what has enabled me to live my life and run my business with effortless mastery?

And, learn the framework that gives me a sense of control, less stress, and flow in my life and business?

Then register ye here: http://martinstellar.com/crd-webinar-registration/

See you tomorrow!

Cheers,

Martin

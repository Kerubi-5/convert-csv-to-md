---
title: Drunk On Potential
status: draft
datePublished: '1512120169'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/d7179bed-97dd-4808-9b79-4f8aef4f2e98.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/d7179bed-97dd-4808-9b79-4f8aef4f2e98.png" data-file-id="4835245" />I’ve been giving a lot of thought to how exactly I help.

What it is I do for people.

Sure, helping people make more money is one thing.

And it’s fun, and useful.

But it’s… too one-sided.

And the more I think about it, the more I realise: what really fires me up, is getting people to grow, and specifically: to help you reach more of your potential.

Because while I might not know you personally yet, I do know this:

Whatever your station in life, and whatever your accomplishments: I know that you have more in store.

We all do.

The potential of the human being is staggeringly large.

But we only reach a certain level, and then we plateau.

Either because we don’t know how to reach more of our potential, or because we don’t believe that there’s more to reach.

But there is. There’s always more.

Your potential as a human being is big, and it’s my mission to help as many as I can, to reach that potential.

So does that make me a potentiality coach?

A potentialite?

I don’t know, and the label really doesn’t matter.

Because the only thing that matters is that you grow, evolve, and reach ever higher levels.

That can be in terms of the money you make, or the quality of your relationships, or your personal fulfillment in life… all that is up to you.

My job is to help you get there.

Each time that you drink from your potential and you empty the bottle, and you think that’s really the limit&amp;all that’s in store for you…

I’ll uncork a new bottle of potential, for you to sip from.

Until yes, you get drunk on potential. Which is quite unlike alcoholic inebriation: instead you'll find your head spinning more, in a good way, with every step of potential you unlock for yourself.

So yes. If you want more out of life and you don’t know how to get it, maybe I can help.

Just get in touch if you’d like to find out…

Cheers,

​Martin

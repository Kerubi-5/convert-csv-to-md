---
title: How to Not Look Needy When Selling
status: publish
datePublished: '1568197790'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-22053" src="http://martinstellar.com/wp-content/uploads/2019/09/MartinStellar_Coaching_Illustrations-How-to-not-look-needy-when-selling-1024x768.jpg" alt="" width="351" height="263" />Ever noticed the way a hungry animal behaves? The way it walks, sniffs, looks at everything asking itself ‘is it food?’

Not a pretty look, right? Pretty desperate.

That’s pretty much how we look to potential buyers, if we allow neediness to show up in how we show up.

And I’m not talking about a hungry kitten - it makes us look more like predators, when neediness appears in a sales situation.

Yeah you need the sale, I know. Bills, payroll, suppliers, subscriptions… but you can’t afford, literally, to look needy. Just not.

And so, you need to dissasociate yourself from the outcome. Sale, no sale… be ok with either.

But that’s easier said than done, because: see above ---&gt; you need the sale.

And yet, you need to detach yourself from the outcome.

How?

As always, by performing the one master move to make everything in life and business easier: make it about them.

You’re selling something, so by default what you need isn’t the point. It’s what your buyer needs, because that’s what people pay for: the things they need.

So the only question really, is ‘do they need this?’

And that’s it. Stay with that question, let your buyer answer it, and a) they’ll sell themselves if they really need it and b) you’ll not look needy.

Simple, right?

Cheers,

Martin

---
title: Inspire me... I dare you!
status: draft
datePublished: '1493376636'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/4ec6efc7-d36b-47fb-b8f5-a0d402ad4487.jpg" width="200" height="266" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/4ec6efc7-d36b-47fb-b8f5-a0d402ad4487.jpg" data-file-id="4834561" />Sometimes people ask me who my ideal client is.

Invariably, my answer is: People who inspire me.

Because it’s not my job to inspire my clients.

My clients inspire me, because of the spark of genius I see in them.

And then my job is to create a situation where that genius can bloom.

Along the way, there’s obstacles in the way, and we work on them.

We deal with mindset, necessary skills, fears to be overcome.

Fostering growth by way of helping you improve your inner game - THAT’S my job.

So what then are the things that inspire me?

Can be various things.

A big ambition, that’ll usually do it. I can’t resist people who dare to dream big.

Or a thoroughly giving attitude in life, along with the clarity of mind to give without hurting the self. Because one of the problems with givers, is that we tend to give IT all, instead of giving it OUR all.

And that’s the difference between a successful giver and a struggling giver.

Other ways to inspire me?

Great compassion and love for others. A mission to make a difference.

And one of my favourite inspirations?

Ruthless self-awareness. Because the one thing guaranteed to keep success away is by refusing to look in the mirror.

And that’s what makes my job so much fun: to hold up a mirror for a client, and then to see the lightbulb switch on.

Magic, when that happens.

So, do you think you would inspire me?

If so, you might want to join my next Cabal Mastermind group.

Because while I have no idea who will join once the doors open on Monday, I’ll tell you this:

Everyone in that group (just as in the existing Cabal group) will fit a very particular profile, and will be selected based on that.

A tight-knit powerful team like that isn’t open to anyone who will pay for membership.

No, it’s only for people who inspire me, who have something special, who take action and responsibility, and who are committed to removing the obstacles in their way.

Is that you? And you want to be in a group of people like that, and benefit from the collective velocity?

Then here's more info, and a button at the bottom of the page for you to apply for membership: <a href="http://martinstellar.com/cabal-group-coaching-action-takers/" target="_blank" rel="noopener noreferrer" data-cke-saved-href="http://martinstellar.com/cabal-group-coaching-action-takers/">http://martinstellar.com/cabal-group-coaching-action-takers/</a>

Cheers,

Martin

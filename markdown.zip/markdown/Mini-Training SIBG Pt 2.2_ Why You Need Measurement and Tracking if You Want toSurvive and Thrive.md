---
title: "Mini-Training SIBG Pt 2.2: Why You Need Measurement and Tracking if You Want to\r\n\t\t\tSurvive and Thrive"
status: pending
datePublished: '1642672417'
categories:
  - Business and systems
  - Business Growth Fundamentals

---

<div>

<img class="size-medium wp-image-28555 alignleft" src="https://martinstellar.com/wp-content/uploads/2022/01/MartinStellar_Coaching-Illustrations_Why-you-need-measurement-and-tracking-if-you-want-to-survive-and-thrive_Mini-training_Stages-and-Ingredients-of-Business-Growth-300x225.png" alt="" width="300" height="225" /><code>Trainings &gt;&gt; Stages and Ingredients of Business Growth &gt;&gt; 2.2 Tracking and metrics</code>

</div>
<div>

"What gets measured, improves" sounds so very dull, doesn't it?

Yes it's how things work, but c'mon... does business really have to turn into a machine with dials and knobs and levers?

Do you need spreadsheets, dashboards, Google Analytics, performance reports and what have you?

Depends.

There's a lot of fun to be had "flying blind", if you will, with your eyes mostly on the overall revenue and profit you make.

And, you can certainly make good money that way.

But it brings two problems:

1: Without tracking and measurement, it's hard to make fast changes when things go wrong.

And things will go wrong, sooner or later - a business is a balancing act, it's inherently unstable.

At any time, new competitors can show up, or algorithm changes, or disruptive technologies, or privacy legislation, or supply chain issuess...

There's a million moving pieces and you never know which one will break and cause havoc.

But when you have numbers, tracking, and data, that enables you to make fast decisions on what to fix, what to drop, where to pivot, where to invest or divest.

2: Running a business without metrics stifles growth over time.

If you don't know with precision which 20% of your clients bring you 80% of your revenue...

If you don't know which ad campaign or landing page outperforms the other one...

If you don't track which of your sales people perform well, and which ones need coaching...

If you don't know which of your blog posts are too unrelated to the rest, and bring down your SEO ranking instead of adding to it...

(need I go on?)

In short, how do you make something grow when you don't know why it is, or isn't, working?

If your orchard isn't yielding apples... does it need more water? Fertiliser? Pest remediation? Pruning?

How will you know, if you don't know - if you don't have data?

So yeah: If you want to increase stability in your business, and facilitate growth: track, measure, and review.

- Measure the amount of time you spend on housekeeping vs Growth-Driving Activities
- Track your proposals out - quantity and dollar amount - and compare the number against sales closed and dollars earned
- Yes, use Google Analytics or some other measurement tool
- Track how much you put out on social media, and how many inbound requests (not shares and likes - you can't pay rent with those) you receive
- And, yes, create dashboards that show you in one view how the different elements of your busines are working.

It's the only way for you to know with precision and accuracy how your business is running, and what to change, fix, prevent, or improve.

And, the big win from all of this:

Once you have tracking, numbers and data, you'll know which parts of your business need more resources, time, or money, to get the maximum possible returns and growth.

And tomorrow, we'll dive into the benefits and principles behind outsourcing and delegating.

And for that to go right, you need to know - based on numbers - what you should or shouldn't outsource or delegate.

Get the picture?

&nbsp;

</div>

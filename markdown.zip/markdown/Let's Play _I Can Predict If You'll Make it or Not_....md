---
title: Let's Play "I Can Predict If You'll Make it or Not"...
status: draft
datePublished: '1529591483'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/f281750a-0f53-4fb9-a413-df28697fe6b9.png" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/f281750a-0f53-4fb9-a413-df28697fe6b9.png" data-file-id="4835829" />Of course, I can't predict your future success or absence thereof. Those bastards at Amazon just won't deliver that crystal ball I bought.

But, a simple exercise will reveal the state of a specific, make-or-break attitude that an entrepreneur needs to make it.

Here’s the exercise:

First, pick an outcome - a dream you have, or wish or goal… something you really care about. Business, personal, whatever you want.

Got it?

Now ask yourself: which obstacles stand in my way of getting it?

Write 'em down all of them. Do a braindump, and write down all possible (real or projected/imaginary) obstacles that could prevent your achieving the goal.

Then, mark each obstacle with an S or an O.

O stands for obstacles that are outside of your influence, imposed by others or the situation.

S stands for the kind of obstacles that stem from self. Could be skills that are lacking, leadership qualities to develop, beliefs you know are holding you back, bad habits or good ones that are missing… you name it.

Count the O’s and S’s.

If you score higher on the ‘Other’ field than you do on the ‘Self’ field, you won’t make it.

Ok, that’s not fair: it ain’t that cut &amp; dry. But you get the point.

Because, there’s a strong correlation between the amount of ownership someone takes over whatever obstacle there is in life, and the amount of success or the speed of getting there.

The more you take responsibility, the better you’ll do.

Finger-pointers and blame-dispensers don’t tend to go many places, you know?

Want to go places?

Then you are responsible.

For the way you think, the way you frame obstacles, and for the way you persistently transform any seemingly external obstacle, into something that becomes your responsibility to resolve.

You can apply this to literally anything, even things that are truly outside of your control.

Imagine a freelancer with a client who keeps changing the scope of work on a project.

Outside obstacle, isn’t it?

Nope, it’s not. That too is an inner obstacle, in that the freelancer can decide to select clients more carefully.

Turning an outer obstacle into an item that you can take ownership over.

So what’s something in your list that you’ve always seen as ‘outer obstacle’, but that you can actually own and resolve?

Oh yeah, and um: when will you start?

Cheers,

Martin

---
title: Free Advice for People Who Won't Take it
status: draft
datePublished: '1489493805'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

Back in my copywriting days, I did a lot of work through freelancing websites.

(And yes, if you deliver quality, keep raising your rates and you know how to use the platform, you can earn seriously good money there, even though most people say you can’t).

Anyway, my profile there is still active, and sometimes I still get job offers. I don’t take them because copywriting is behind me, so I normally delete them. Except for the one I got yesterday.

Some guy messaged me - not because he wanted to hire me, but because he wanted free advice.

Along the lines of “Martin, I’m impressed with your career, I want to be a digital nomad, and would like you tell me the mindsets and methods that helped you get to where you are?”

But he didn’t want to pay for my advice, because apparently I work for free and my rent pays itself.

But ok, I’m a nice guy so I wrote him up a few pointers. Not that I think he’ll take them on board, because I get the feeling he’s not the kind of person who gets it. But one never knows, so I sent him this:

###

If I'd get on skype with you to give you free advice, I'd give you the worst possible example. I talk with people for a living, not for free. Unless someone earns a gift, in some way or other, and I offer them a coaching session.

But here's a few takeaways for you:

1: Value yourself and your work (see my opening paragraph). Get paid what you're worth.

2: Identify the thing that nobody does quite as well, or the way, as you do it (zone of genius - read Gay Hendricks) and package it into a service or product that solves problems.

3: Put it out there relentlessly and unceasingly

4: Build systems. Iterate and optimise them

5: Pay yourself first

6: Develop habits that keep you healthy physically, mentally and spiritually. This is non-negotiable. Learn daily.

7: Learn what neuroplasticity is and how to use it for yourself (habit hacking, growth hacking etc)

And the most important?

Serve.

The money you make, you *earn* it, by *serving* people.

###

I ended by wishing him luck and that if he’s serious and willing to invest some money, I would talk to him.

But I got no reply, not even a thank you.

Ah well. Such is the world of freebie-seekers. They ask for advice they won’t understand or value, they expect it for free, and then they forget to say thank you.

I’m not complaining - I’m only writing this for you to take the lesson (if you’ll take it) that you must avoid freebie-seekers at all cost.

There’s a lot of people out there who want to meet with you just to ‘pick your brain’ (horrible expression, but hey) and think that they’re entitled to free help.

But no. People can earn their free help, but they’re not entitled to it.

And it’s good practice to avoid anyone who doesn’t value you and your work the way you value it (or ought to).

So if you are the kind of person who takes advice and is willing to invest in it, just let me know.

Cheerio,

Martin

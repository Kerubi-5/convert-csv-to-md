---
title: Now They See It, Now They Buy
status: publish
datePublished: '1604881827'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "How to sell your\r\n\t\t\twork"
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-21724" src="http://martinstellar.com/wp-content/uploads/2019/05/MartinStellar_Coaching_Illustrations-Vision-drives-decision-1024x768.jpg" alt="" width="351" height="263" />There’s a guy I like to learn from - the late Jim Camp, known as the world’s most feared negotiator.

One of his lessons is that ‘vision drives decision’, and since every sale is effectively a negotiation, it’s really important that you work with your prospect’s vision.

Because unless they see themselves experiencing the benefit of your product or service, your only chance to cause a sale is to force the issue - and we’re nice people, we don’t force people into buying.

Now, most people try to persuade a vision onto someone.

They make compelling arguments, they proffer explanations, they paint the ‘after’, they point out the problems that remain without the purchase…

But it’s much more effective to have a prospect develop their own vision, instead.

That way, they own the vision instead of ‘borrowing’ it from you, which makes it far more likely that they’ll also buy your work.

And the best way for someone to develop their own vision of ‘problem solved because I bought this thing’?

Questions.

The last thing you want to do when selling, is tell people what to see.

Instead, ask questions that have them gain clarity and insight, and they’ll develop their vision all by themselves.

What kind of question to ask depends on many things - from the product or service you offer, to the personality of the buyer, the price point, your own personality... to name but a few moving parts.

But, as long as your questions come from a place of empathy (i.e. putting yourself into their world), you’ll be fine.

Empathy shows the other that it’s about their results first, their decision second, and your sale last.

And that’s exactly the kind of ethical, integrity-based selling that I teach.

Want to dive deep on what questions to ask your particular buyers, so that they'll happily build their own vision and desire, and volunteer 'How does it work?' or 'Where do I pay?'

Then the <a href="http://martinstellar.com/helping-good-people-sell-more-and-generate-a-bigger-impact/">LEAP Framework for Ethical Selling</a> might be just the thing you need...

But, before making any decisions, let's have a short conversation, and see if that 1 on 1 training truly is what will help you enroll more buyers.

Just <a href="https://calendly.com/martinstellar/20min">pick a time here...</a>

Cheers,

&nbsp;

Martin

&nbsp;

&nbsp;

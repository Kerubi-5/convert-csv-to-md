---
title: Nothing Much to Say...
status: draft
datePublished: '1520536632'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/_compresseds/fd40ed4e-04ee-40e2-8252-defbe9d097bd.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/_compresseds/fd40ed4e-04ee-40e2-8252-defbe9d097bd.jpg" data-file-id="4835525" />...except this, the haiku I wrote last week.

On this day I want to tell you, whether you're a woman, man, or other, that an idea coupled with words spoken, can be a powerful powerful weapon.

Because it's easy to think that only guns are tools of violence, but so are words.

And many of us - present company included - use words as weapons far too often. But I'm working on it, and I hope so are you.

That haiku, it's not about guns.

It's about how we treat each other.

LOVE.

Martin

---
title: 'BizFun, Pt 4: Do They Need It, Do They Want It, Will They Pay For It?'
status: publish
datePublished: '1615975510'
categories:
  - Doing it right as an entrepreneur or creative professional

---

<img class="size-medium wp-image-26648 alignleft" src="https://martinstellar.com/wp-content/uploads/2021/03/MartinStellar_Coaching_Illustrations-Problem-validation_market-research-300x225.png" alt="" width="300" height="225" />### Part 4 in the Business Fundamentals series ###

So you have this particular skill, it really works for people, and you know there’s a need for it.

Logically, the next step is to get out there, show it to people, kick up dust, and offer your thing.

“Because hey, it’s good and they need it!”, right?

Wrong.

Going back to step 1 in this Business Fundamentals series: you need to do things in the wrong order.

And stepping out to market your services needs to happen <em>after</em> you validate with your market.

Never before.

I’ve been guilty of getting this wrong so very many times, it’s not even funny.

Like, last year, when the crisis and lockdowns happened, and I decided to create a complete system for anyone to pivot from offline marketing to online.

Because hey, I saw a need, it was real, and dire.

Except I didn’t validate, but instead I went straight into building.

Fairly stupid, because it was only after months of developing and marketing, that I realised:

What I built is far to complex for people to buy. (see yesterday: selling people a problem).

What I should have done, is talk to people, ask what they’re up against, ask what they need and what they’d want to pay for.

In other words: I should have done market research first, and build second.

If I’d done that, I’d have built something far simpler and more agile to implement.

This isn’t to say that what you’re trying to get out there and sell isn’t right or ready or sellable.

It means that unless you measure your theory about what people want to pay for against what the market tells you they’ll buy, you’re guessing.

It’s inefficient.

You might be marketing to the wrong audience.

Or using the wrong messaging for the right audience.

Or you might be talking about solving problem X, which people want solved, but they’ll resonate a lot more with secondary solution Y - which you’re not highlighting.

And unless you validate your problem-set and assess the problem-cost (more about those in a future installment of BizFun), and you get a reading on what people want and need, you’ll get what I used to get:

Crickets.

Well, I’ve learned my lesson (and I sincerely hope you learned it too, today).

I’m starting a new venture with a friend, to help bootstrapped founders grow, without ever having to raise investments.

It’s called <a href="http://growboots.com" data-cke-saved-href="http://growboots.com">Growboots</a>, and we’re very deliberately not building or offering anything yet.

It would be super easy and a ton of fun to start creating content, or build a calculator, write an ebook, do a video series…

And it would also be stupid.

Instead, we’re in research mode, so as to learn what a bootstrapper really needs - not what we think they need.

So whatever consulting or coaching you offer: unless you’re flooded with clients and booked full:

Talk to people. Interview them. Learn your people.

It’s the only way to get a decent ROI out of your marketing efforts (which, I repeat, should come <em>after</em> you do your research).

Cheers,

Martin

P.s. If you are a bootstrapped founder: we’re paying it forward, so our research is in the form of a no-cost 20 minute audit. You can schedule one at the bottom of <a href="http://growboots.com" data-cke-saved-href="http://growboots.com">this page.</a>

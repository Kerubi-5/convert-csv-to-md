---
title: 2 Steps to Growing Your Business - But Hardly Anyone Implements Them
status: publish
datePublished: '1584119102'
categories:
  - Business and systems
  - "Doing it right as an entrepreneur or creative\r\n\t\t\tprofessional"
  - How to sell your work
  - Psychology in sales and marketing

---

<img class="alignleft  wp-image-22830" src="http://martinstellar.com/wp-content/uploads/2020/03/MartinStellar_Coaching_Illustrations-LEAP-Marketing-System-1024x768.jpg" alt="" width="350" height="263" />Some of my readers already know that in the last few months, I’ve been deploying a marketing system that guarantees increases in revenue of 20% or more.

It’s super effective, really reliable (actually comes with a guarantee), and really the only thing wrong with it, is that I didn’t invent it myself - I simply obtained a license to teach and implement the system for clients, because it's one of the best systems for growth I've seen.

But the other day, I realised how wonderfully it dovetails with my own LEAP model for running and growing a business.

LEAP being the Listen, Explain, Ask, Profit framework I invented.

And in terms of that marketing system, here’s how it works, and the steps to implement if you want to grow your business:

<strong>Listen:</strong>

What is it it that makes people buy from you, and not someone else? What do customers opine about doing business with you? Why do they give you money?

You’ll have an idea, but until you talk to your people, and listen, you’ll be operating on assumptions and random soundbites and data points.

But once you get your buyer’s feedback, and motivation, in their own words: then you have a USP - a Unique Selling Proposition - that speaks with the voice of your best buyers, and attracts more of that kind of buyer.

Homework: survey your customers (current and past - you want to learn why people stopped doing business with you as well as why they still do)

<strong>Explain:</strong>

You take that USP - the thing that differentiates you and makes people love you - and you make it part of every piece of communication you do. If there’s a compelling reason that your market has told you is why they buy with you, state that reason.

Integrate your USP, make it part of your messaging, brand, tagline, the way you answer emails or the phone: make sure that those who deal with you are made aware of why you are you and therefore preferable over your competition.

Homework: well, that. Update your branding, your messaging, your bios on social media, your email signature, your tagline: live your key differentiator out loud. It’s why people love your work, remember?

<strong>Ask:</strong>
Here we look at your database - your past current, and future customers - and we start asking tough questions about who tends to buy what, and what kinds of offers we can make to see if people will buy something else.

Packages, special offers, add-on services or upsells: You simply ask: “I’ve got this thing here - is it something you’d want?”

When you do that, after defining your USP and making it part of your messaging, you’ll find that digging into your database and your numbers brings up all kinds of opportunities for people who love (or loved) doing business with you, to buy something again.

Homework: analyse your database, create packages and offers, and run campaigns (email, phone, social media, in-person meetings once travel is advisable again): create theories about what people might want to buy, and ask them if they want to.

<strong>Finally, profit:</strong>
This is where we create strategic alliances with businesses that serve a similar audience to yours, and we create partnerships based on cross-promotion and commission - and it only takes a few well-chosen strategic partners, for you to increase your revenue without scaling up your workload or your advertising budget.

Homework: analyse your market, identify products and services they already buy, and get in touch with people who sell them, to see if you can create partnerships.

And that, in a nutshell, is the LEAP marketing system.

Follow these steps in order, and you’ll see your revenue go up.

Or, have me implement the steps for you, and I’ll get you to at least 20% growth. Guaranteed.

Shall we talk?

Cheers,


Martin

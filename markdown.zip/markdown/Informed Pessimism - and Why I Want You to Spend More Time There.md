---
title: Informed Pessimism - and Why I Want You to Spend More Time There
status: publish
datePublished: '1521746786'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/67001e81-c2bb-41b6-8d9a-6e907323fe21.jpg" width="350" height="262" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/67001e81-c2bb-41b6-8d9a-6e907323fe21.jpg" data-file-id="4835573" />When it seems like it’ll never work...

When you wonder why others get it - the money, the success, the recognition - but you don’t yet...

All the moments when you despair, wake up at night and worry, each time you wonder how you’re going to make payroll or pay rent…

That’s when you’re heading for the valley of despair.

Going through the phase of informed pessimism.

And I want you to spend more time there - but ONLY if you do it with the right attitude.

The valley of despair is a concept I learned from one of my mentors, Peter Shallard.

It’s part of the image here, which shows you the stages in the life of an entrepreneur.

1: Uninformed optimism.

This is how a business starts, or a new project, or a new marketing strategy.

You may know some stuff, but the whole picture is largely an unknown, and only time and experience will reveal all that you’re not seeing at the start.

And so, you venture out, thinking “I can do this”. Totally stoked.

And you can 'do it', but not before you get a couple of reality checks, and you discover that ‘holy crap, this is a lot harder/more complex than I thought!’

And so, you enter phase two:

2: Informed pessimism.

Oh yes things are hard, and they maybe even suck. A lot. And it’s getting worse, and fast too.

This phase is normal, and insanely useful to an entrepreneur, I’ll show you in a moment.

Next, once you’re worn down, you end up in the next phase:

3: The valley of despair.

That’s where things are bleak and hopeless, and you might even wonder if you’ve got what it takes.

Wonder if you should maybe just chuck it all in, that whole entrepreneur idea.

Now what lots of people do, is to stop here - either with a business idea, or with a project, or a work of art or a book - and go back to phase one.

They go back to starting something, because there you get to enjoy the boundless (uninformed) optimism that got you started in the first place.

Don’t do that. Push through. Don’t be distracted by the ‘bright shiny object’ of another project.

Keep on pushing, because once you are out of the valley of despair, you enter:

4: Informed optimism, where you know the pitfalls, but you also know how to balance them with the optimism and all the opportunities you see.

In that fourth phase, things are working, better all the time. You’re adjusting, improving, and you end up in the final phase:

5: Success and fulfilment. Meaning… Well, you fill in the blank.

It’s tempting to try and stay in phase 4 and 5. After all, that’s where the fun happens.

But the dirty little secret of the life of entrepreneurs (of all lives, really) is that the magic happens as you slide down that slope, into phase 2, into informed pessimism.

In that phase, you’re growing most, as a human and an entrepreneur.

It’s where the hardships and the wake-up calls and the reality checks forge you into something stronger.

In phase 2, you get upgraded. It’s the crucible where you get shaped, where the impurities in the wood get burnt up and only carbon remains.

It’s the pressure that turns carbon into diamonds.

It’s under pressure that you grow most, as a person and as an entrepreneur.

IF you can be aware of it.

And even better: if you can welcome and seek out the transition from phase one into phase 2.

It’s applied practice of Antifragile (Read the book, by Nassim Nicholas Taleb. It’s brilliant).

And it’s important to be conscious of these phases, and to deliberately relish the experiences in phase 2.

No matter how hard or unpleasant they are, it’s in phase 2 that real inner change takes places.

I say seek it out.

And on that note: seek out a coach if you want to make the whole process faster and more fun.

Because these phases WILL come back in various forms and ways, and it sure is good to have company from someone impartial who's been through his own phases, and can help you move forward.

So, holler when you're ready.

---
title: How to Be Reed
status: draft
datePublished: '1496404785'
categories:
  - Psychology in sales and marketing

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/b454357a-b2c1-4885-8b9f-22f450aafc1a.jpg" width="350" height="233" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/b454357a-b2c1-4885-8b9f-22f450aafc1a.jpg" data-file-id="4834653" />Back in the days, I used to read a lot Sufi books.

Especially Rumi’s Fihi Ma Fihi sparked me. You might want to try it if that’s your thing.

Anyway, one of the concepts in Sufism that comes back over and over again, is the concept of reed.

For one thing because of the alluring sound of the Ney flute, which is made of reed.

But also in a metaphorical sense, in that reed is utterly resilient.

Bamboo, cane, reed - it’s practically impossible to stop it from growing unless you dig up the roots.

The roots spread underground, passing through the tiniest crevices underground, and expand on the other side, and plop: within days, there’s a new patch coming up.

But the best image, is that of reed in the wind.

Ever see that?

It don’t care how hard the wind blows: it just bends and sways. There’s no storm strong enough to break it, I don’t think.

And so the Sufis wax lyrical about how we too can be like reed.

Instead of trying to resist the onslaught of life, and get blown over when stuff comes at us, why not be like reed?

Sway, give, recover. Because when you resist and fight and try to stand your ground amidst the things that can happen on any given day, you just might break.

And sometimes, especially when we’re talking about overwhelm or a stream of setbacks, simply letting it happen and moving with it, will make everything a whole lot easier.

So those times when you feel the burden, remember the reed.

Cheers,

Martin

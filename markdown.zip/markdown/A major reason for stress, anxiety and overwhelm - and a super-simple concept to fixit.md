---
title: "A major reason for stress, anxiety and overwhelm - and a super-simple concept to fix\r\n\t\t\tit"
status: draft
datePublished: '1534400595'
categories:
  - Psychology in sales and marketing

---

<img class="alignleft wp-image-20709" src="http://martinstellar.com/wp-content/uploads/2018/08/MartinStellar_Coaching_Illustrations-overwhelm-and-stress-closing-open-loops-1024x768.png" alt="" width="344" height="258" />If there’s a conversation you need to have and it’s taking space in your mind - have the conversation.

If there’s an unfinished job you keep remembering, write it down.

When you have a finnicky problem you can’t seem to solve, journal and brainstorm on it.

If there’s a pile of unfolded laundry in your bedroom, fold it and store it away.

If there’s dishes in the sink, wash them.

(note: don’t fall into the freelancer-favourite ‘I’ll just clean the fridge and kitchen cupboards out while I’m at it’ - instead, write that (separate) task down).

If you keep remembering to water the plants or order new printer ink, water them or order it.

Do you see a pattern here?

All of these items are open loops. Unfinished business.

And your mind, your subconscious, keeps bringing them back to your attention, because you told it to.

You made a mental note to ‘remember this thing’.

And it does, and it’ll keep reminding you, like the faithful servant it is.

But each time you tell yourself ‘remember this’, you’re creating an open loop.

Those add up, and after a while your subconscious is adrift in a whole mess of unfinished business.

And bam: overwhelm, stress, anxiety, confusion, lack of clarity, and the inevitable consequence:

Procrastination on those tasks that actually really matter for your life and your business.

The solution is simple and elegant:

The tasks you can do in two minutes or less: take 30 or 60 minutes, and rip through them. Execute, do, check off. You’ll feel a LOT better, quick smart.

And all the things that take longer, or that are contingent on somebody else’s feedback, deliverables, or presence: make a note of it.

Not a mental note, but a hard copy. In your phone, or your computer, or a notebook.

That way, your brain gets the message ‘you can drop it now, it’s stored elsewhere’.

You’re closing the open loops that cause stress.

Now, you might object that when you do make lists and notes, you never go back to review and execute (I used to be guilty of that as well).

But consider this: if you live in stress and overwhelm, you likely don’t execute on all those reminders anyway, so there’s little lost there.

Besides, you can use post-it notes in prominent places to remind you of the tasks that you really shouldn’t forget.

And in any case, the calm and clarity you get from doing a lot of small tasks and writing down the bigger ones will make you feel better, AND it will help you get back to your lists so as to execute.

So, remember: your brain is not a hard drive, it’s not built for storing things.

Don’t fill it with open loops.

Your brain is a processor, an idea&amp;solutions machine. The best thing you can do for yourself is to commit to offloading all reminders from it, so that you get the mental space you need to perform at your highest intellectual capacity.

And if that sounds like a good idea, just wait and see what you’ll learn in my Calibrate Reality Webinar…

There’s still spots on the guest list, so hit reply if you want to be on it.

Cheers,

Martin

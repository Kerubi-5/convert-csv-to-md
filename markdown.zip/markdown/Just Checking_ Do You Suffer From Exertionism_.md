---
title: 'Just Checking: Do You Suffer From Exertionism?'
status: publish
datePublished: '1526984413'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/ebd4c44d-583b-49b8-bbcc-21a41df6fed8.png" width="350" height="350" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/ebd4c44d-583b-49b8-bbcc-21a41df6fed8.png" data-file-id="4835737" />Perfectionism is the enemy of done... but there might be another problem...

You know the drill: Working on something far beyond the call of duty, far beyond what constitutes ‘good’ or ‘good enough’ or ‘ready’.

Endlessly nitpicking at things, rewriting, editing, going over all the materials again - ooh, another little tweak that is direly needed. And another one! And another!

This way, perfectionism keeps you stuck. Keeps you from launching that thing you’re working on.

But what if your problem is different… what if you suffer from exertionism?

Yes, I made the word up. It means:

An unhealthy, unproductive attachment to the feeling of having worked really really hard.

I saw it yesterday, helping a friend pull together a project for which a powerful proposal had to be created.

“I always take very very long at this kind of thing”, she said.

And yep. Took her hours. Which is good - it’s no use to half-ass something. Quality work requires quality effort, and sometimes at length.

But there’s always a point where it’s ready. Good enough. Time to ship it already.

But some people can’t live with themselves. If they do something really well, and really fast, that… can’t be right.

“But I’ve not slaved away over it yet. Can’t be ready”.

“Unless I stay up till 4AM, I’ve not given it my all”.

“Without the stress, second-guessing and rewriting, it can’t be ready”.

Get the picture?

For this kind of person, nothing will ever be ready unless an inordinate amount of effort and exertion has gone into it. We’ve got to slave away, deplete ourselves - really exert ourselves to the point of deep fatigue.

But all that gets you is lost time, and the (rather insignificant) feeling that you’ve ‘done a good job’. (Insignificant because the feeling is tied to your efforts, not to the results you’re creating. Much better to feel good about the result itself).

But doing a good job shows in the result - not necessarily in the amount of exertion that went into creating that result.

If you’re really good at something and can create stellar results on something important real quick, then your job is done.

The only reason to then keep chipping away at it is for you to feel satisfied in having exerted yourself. And while that does feel good, it feels a LOT better to say ‘done’ and move on to the next project.

Exertion for its own sake is pointless, if you want to build things.

So if you suffer from this phenomenon, I really recommend you look up exertionists anonymous. I’m sure there’s a 12-step group near you somewhere.

Seriously though: Done is done. Perfectionism doesn’t help, nor does exertionism.

This article? It’s done. Time to ship it (hello!)

&nbsp;

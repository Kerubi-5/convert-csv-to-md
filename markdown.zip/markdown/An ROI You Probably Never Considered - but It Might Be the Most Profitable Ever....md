---
title: >-
  An ROI You Probably Never Considered - but It Might Be the Most Profitable
  Ever...
status: draft
datePublished: '1545302206'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img class="alignleft wp-image-21177" src="http://martinstellar.com/wp-content/uploads/2018/12/MartinStellar_Coaching_Illustrations-Coaching-insight-returns-1024x768.png" alt="" width="355" height="266" />An ROI you’ve probably never considered before - but it just might be the most profitable

We invest in learning, and develop skills.

Invest in SEO, and get more traffic.

Money into a new website, and you get more conversion and transaction from your visitors.

Invest in a new computer, and your workflow speeds up.

None of those are bad, but investing in nuts&amp;bolts is only the basic level.

The real ROI to watch for, is Return On Insight.

Because what you bring into sight, becomes something you get to monitor, measure, and improve.

When you gain insight into:

… your default reaction when someone pushes your buttons (blame, anger, denial, self-recrimination etc etc), you get to gradually block that reaction, and react in a different way.

… the way you tend to procrastinate over and over on exactly the things that drive growth (something I tend to do and so might you), you get to make a decision about changing that behaviour.

… how repeatedly spending time on activities that hardly move the needle on your business or wellbeing, you get to make choices on different ways to spend your precious time and energy.

They say nothing changes if nothing changes, and the best, most effective and often profitable change to make, is on the amount of insight you have into the way you operate in life.

It’s tempting to invest in practical matters, nuts&amp;bolts tactics, and learning things. Useful, even.

But your results will never be large if you don’t also develop insight, or put differently: self-awareness.

And thus, welcome to the world of coaching, where insight and self-awareness are what bring you the biggest returns, beginning with your own sense of well-being, control, and a sense of ‘getting it right’.

Some people balk at that, and prefer to invest in ‘things’ that are meant to increase net returns. You’ll find plenty of teachers and service providers who’ll be happy to deliver, and you’ll get marginal results (sounds familiar?)

Others - the smart ones - don’t discount those kinds of investments, but they make the development of insight and self-awareness a priority.

If you’re the latter, maybe we should talk?

Cheers,

Martin

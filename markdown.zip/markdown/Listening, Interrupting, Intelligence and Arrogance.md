---
title: Listening, Interrupting, Intelligence and Arrogance
status: draft
datePublished: '1531923286'
categories:
  - Doing it right as an entrepreneur or creative professional
  - "Psychology in sales\r\n\t\t\tand marketing"

---

<img src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/d7f044c0-7108-4476-9a6e-a751d4f849f4.png" width="350" height="307" align="left" data-cke-saved-src="https://gallery.mailchimp.com/f05dc59f4bf8170c301679377/images/d7f044c0-7108-4476-9a6e-a751d4f849f4.png" data-file-id="4835929" />Do you ever interrupt people, because you already know what they’re going to say next?

Maybe you’ve had the conversation before, or maybe it’s easy to see where they’ll go with their discourse. Could be easy - a bit of intuition and intelligence go a long way..

And yet...

If you then cut someone off because of that, you’re robbing yourself. (aside from showing yourself as presumptuous and arrogant).

That other person is trying to share a body of thought, a holistic picture of something they want you to consider. They’re trying to share an insight, most likely for your benefit, or for the benefit of all.

And if you then cut someone off and don’t give them space and time, you’ll not have the full insight - you miss out.

You’ll only have the part that they were able to throw out before getting interrupted.

And no matter how intelligent you are, you simply can’t infer someone else’s full insight from only half the story.

If you want to live well, have relationships that work, and be more successful in whatever endeavour you choose, it behoves you to observe very very closely.

To look at what’s happening in you, and around you, in the mind of another person, and to what happens in life in a more general sense. (Exception: people who nag or who complain just for the sake of it. Life’s too short for that kinda thing).

In fact, I credit all my success and my fortitude to my abbot’s recommendation:

“Listen to life”.

And there’s plenty of people in life who just might share a super-significant insight with you, so we’ve got our work cut out for us.

Are you up for the job?

Cheers,

Martin
